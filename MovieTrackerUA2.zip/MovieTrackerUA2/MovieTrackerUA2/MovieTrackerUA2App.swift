import SwiftUI

@main
struct MovieTrackerUA2App: App {
    var body: some Scene {
        WindowGroup {
            MovieListView()
        }
    }
}
