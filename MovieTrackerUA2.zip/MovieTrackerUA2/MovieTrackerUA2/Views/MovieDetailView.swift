import SwiftUI

struct MovieDetailView: View {
    let movie: Movie
    @ObservedObject var viewModel: MovieViewModel
    @State private var imageScale: CGFloat = 1.0
    @State private var showHeart = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                ZStack {
                    RoundedRectangle(cornerRadius: 24)
                        .fill(
                            LinearGradient(
                                colors: [.blue.opacity(0.15), .purple.opacity(0.15)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(height: 230)

                    Image(systemName: movie.posterSystemImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 110, height: 110)
                        .scaleEffect(imageScale)
                        .gesture(
                            MagnificationGesture()
                                .onChanged { value in
                                    imageScale = value
                                }
                                .onEnded { _ in
                                    withAnimation(.spring()) {
                                        imageScale = 1.0
                                    }
                                }
                        )

                    if showHeart {
                        Image(systemName: "heart.fill")
                            .font(.system(size: 44))
                            .foregroundStyle(.pink)
                            .offset(y: -70)
                            .transition(.scale.combined(with: .opacity))
                    }
                }

                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text(movie.title)
                            .font(.largeTitle)
                            .bold()

                        Spacer()

                        Button {
                            viewModel.toggleFavorite(movie)
                            withAnimation(.spring()) {
                                showHeart = true
                            }

                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                withAnimation {
                                    showHeart = false
                                }
                            }
                        } label: {
                            Image(systemName: movie.isFavorite ? "star.fill" : "star")
                                .font(.title2)
                                .foregroundStyle(movie.isFavorite ? .yellow : .gray)
                        }
                    }

                    Label(movie.genre, systemImage: "film")
                    Label(String(movie.year), systemImage: "calendar")
                    Label(String(format: "%.1f / 5", movie.rating), systemImage: "star.leadinghalf.filled")

                    Divider()

                    Text("Résumé")
                        .font(.title3)
                        .bold()

                    Text(movie.summary)
                        .font(.body)
                        .foregroundStyle(.primary)
                }
            }
            .padding()
        }
        .navigationTitle("Détails")
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    NavigationStack {
        MovieDetailView(movie: Movie.sampleData[0], viewModel: MovieViewModel())
    }
}
