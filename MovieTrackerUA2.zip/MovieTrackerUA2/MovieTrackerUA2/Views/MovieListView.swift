import SwiftUI

struct MovieListView: View {
    @StateObject private var viewModel = MovieViewModel()

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Toggle("Afficher seulement les favoris", isOn: $viewModel.showOnlyFavorites)
                }

                Section("Mes films") {
                    ForEach(viewModel.filteredMovies) { movie in
                        NavigationLink {
                            MovieDetailView(movie: movie, viewModel: viewModel)
                        } label: {
                            MovieRowView(movie: movie)
                        }
                        .simultaneousGesture(
                            TapGesture(count: 2)
                                .onEnded {
                                    // Geste 1 : double tap pour ajouter ou retirer des favoris.
                                    viewModel.toggleFavorite(movie)
                                }
                        )
                        .contextMenu {
                            Button {
                                viewModel.toggleFavorite(movie)
                            } label: {
                                Label(
                                    movie.isFavorite ? "Retirer des favoris" : "Ajouter aux favoris",
                                    systemImage: movie.isFavorite ? "star.slash" : "star"
                                )
                            }

                            Button {
                                viewModel.increaseRating(for: movie)
                            } label: {
                                Label("Augmenter la note", systemImage: "hand.thumbsup")
                            }
                        }
                    }
                    .onDelete(perform: viewModel.deleteMovie) // Geste 2 : swipe pour supprimer.
                    .onMove(perform: viewModel.moveMovie)
                }
            }
            .navigationTitle("Movie Tracker UA2")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Réinitialiser") {
                        viewModel.resetData()
                    }
                }

                ToolbarItem(placement: .topBarTrailing) {
                    EditButton()
                }
            }
        }
    }
}

#Preview {
    MovieListView()
}
