import Foundation

final class MovieViewModel: ObservableObject {
    @Published var movies: [Movie] = Movie.sampleData
    @Published var showOnlyFavorites: Bool = false

    var filteredMovies: [Movie] {
        showOnlyFavorites ? movies.filter { $0.isFavorite } : movies
    }

    func toggleFavorite(_ movie: Movie) {
        guard let index = movies.firstIndex(where: { $0.id == movie.id }) else { return }
        movies[index].isFavorite.toggle()
    }

    func deleteMovie(at offsets: IndexSet) {
        let moviesToDelete = offsets.map { filteredMovies[$0] }
        for movie in moviesToDelete {
            movies.removeAll { $0.id == movie.id }
        }
    }

    func moveMovie(from source: IndexSet, to destination: Int) {
        var updated = filteredMovies
        updated.move(fromOffsets: source, toOffset: destination)

        if showOnlyFavorites {
            let nonFavorites = movies.filter { !$0.isFavorite }
            movies = updated + nonFavorites
        } else {
            movies = updated
        }
    }

    func increaseRating(for movie: Movie) {
        guard let index = movies.firstIndex(where: { $0.id == movie.id }) else { return }
        movies[index].rating = min(movies[index].rating + 0.1, 5.0)
    }

    func resetData() {
        movies = Movie.sampleData
        showOnlyFavorites = false
    }
}
