import Foundation

struct Movie: Identifiable, Hashable {
    let id: UUID
    var title: String
    var genre: String
    var year: Int
    var rating: Double
    var summary: String
    var posterSystemImage: String
    var isFavorite: Bool

    init(
        id: UUID = UUID(),
        title: String,
        genre: String,
        year: Int,
        rating: Double,
        summary: String,
        posterSystemImage: String,
        isFavorite: Bool = false
    ) {
        self.id = id
        self.title = title
        self.genre = genre
        self.year = year
        self.rating = rating
        self.summary = summary
        self.posterSystemImage = posterSystemImage
        self.isFavorite = isFavorite
    }
}

extension Movie {
    static let sampleData: [Movie] = [
        Movie(
            title: "Inception",
            genre: "Science-fiction",
            year: 2010,
            rating: 4.8,
            summary: "Un voleur spécialisé dans l'extraction de secrets dans les rêves reçoit une mission presque impossible : implanter une idée dans l'esprit d'une cible.",
            posterSystemImage: "brain.head.profile"
        ),
        Movie(
            title: "Interstellar",
            genre: "Aventure",
            year: 2014,
            rating: 4.9,
            summary: "Un groupe d'explorateurs traverse un trou de ver afin de trouver un nouveau foyer pour l'humanité.",
            posterSystemImage: "sparkles.rectangle.stack"
        ),
        Movie(
            title: "Parasite",
            genre: "Drame",
            year: 2019,
            rating: 4.7,
            summary: "Une famille précaire infiltre progressivement le quotidien d'une famille riche dans une satire sociale tendue et brillante.",
            posterSystemImage: "building.2.crop.circle"
        ),
        Movie(
            title: "The Dark Knight",
            genre: "Action",
            year: 2008,
            rating: 4.9,
            summary: "Batman affronte le Joker, un criminel aussi imprévisible que redoutable, qui plonge Gotham dans le chaos.",
            posterSystemImage: "moon.stars.fill"
        ),
        Movie(
            title: "Spirited Away",
            genre: "Animation",
            year: 2001,
            rating: 4.8,
            summary: "Une jeune fille se retrouve dans un monde d'esprits et doit faire preuve de courage pour sauver ses parents.",
            posterSystemImage: "wind"
        )
    ]
}
