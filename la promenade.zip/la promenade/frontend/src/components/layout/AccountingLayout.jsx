import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  LayoutGrid,
  FileText,
  CreditCard,
  RotateCcw,
  BarChart3,
  Bell,
  LogOut,
  BadgeCheck,
} from "lucide-react";
import { clearSession, getUser } from "@/lib/auth";

function SideItem(props) {
  const { to, icon: Icon, label, end = false } = props;

  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        [
          "flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold transition",
          isActive
            ? "bg-blue-50 text-blue-700"
            : "text-slate-700 hover:bg-slate-100",
        ].join(" ")
      }
    >
      <Icon size={18} />
      <span>{label}</span>
    </NavLink>
  );
}

export default function AccountingLayout() {
  const nav = useNavigate();
  const user = getUser();

  function logout() {
    clearSession();
    nav("/login", { replace: true });
  }

  const initials =
    (user?.fullName || "A")
      .split(" ")
      .slice(0, 2)
      .map((p) => p[0]?.toUpperCase())
      .join("") || "A";

  return (
    <div className="bg-slate-100 min-h-screen">
      {/* SIDEBAR FIXE */}
      <aside className="fixed left-0 top-0 h-screen w-72 bg-white border-r border-slate-200 flex flex-col z-30">
        <div className="p-6">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-xl bg-blue-600 text-white flex items-center justify-center">
              <BadgeCheck size={20} />
            </div>

            <div>
              <div className="text-lg font-extrabold text-slate-900 leading-tight">
                Hôtel La
                <br />
                Promenade
              </div>
              <div className="text-xs text-slate-500 mt-1">Gestion événements</div>
            </div>
          </div>
        </div>

        {/* MENU SCROLLABLE SI BESOIN */}
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          <nav className="space-y-1">
            <SideItem to="/accounting" icon={LayoutGrid} label="Dashboard" end />
            <SideItem to="/accounting/factures" icon={FileText} label="Factures" />
            <SideItem to="/accounting/paiements" icon={CreditCard} label="Paiements" />
            <SideItem to="/accounting/remboursements" icon={RotateCcw} label="Remboursements" />
            <SideItem to="/accounting/rapports" icon={BarChart3} label="Rapports" />
            <SideItem to="/accounting/notifications" icon={Bell} label="Notifications" />
          </nav>
        </div>

        {/* BOUTON TOUJOURS VISIBLE */}
        <div className="p-4 border-t border-slate-200 bg-white">
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 transition"
          >
            <LogOut size={18} />
            <span>Déconnexion</span>
          </button>
        </div>
      </aside>

      {/* CONTENU DÉCALÉ À DROITE DE LA SIDEBAR */}
      <div className="ml-72 min-h-screen">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-20">
          <div className="text-xl font-bold text-slate-900">Espace Comptabilité</div>

          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">
              {initials}
            </div>
            <div className="leading-tight">
              <div className="text-sm font-semibold text-slate-900">
                {user?.fullName || "Comptabilité"}
              </div>
              <div className="text-xs text-slate-500">{user?.email || ""}</div>
            </div>
          </div>
        </header>

        <main className="p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}