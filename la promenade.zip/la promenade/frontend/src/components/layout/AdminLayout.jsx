import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  LayoutGrid,
  Clock3,
  Users,
  Building2,
  Briefcase,
  Bell,
  Settings,
  LogOut,
  BadgeCheck,
  FileText,
} from "lucide-react";

import { clearSession, getUser } from "../../lib/auth";

function SideItem({ to, icon: Icon, label, end = false }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        [
          "flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold",
          isActive ? "bg-blue-50 text-blue-700" : "text-slate-700 hover:bg-slate-100",
        ].join(" ")
      }
    >
      <Icon size={18} />
      <span>{label}</span>
    </NavLink>
  );
}

export default function AdminLayout() {
  const nav = useNavigate();
  const user = getUser();

  function logout() {
    clearSession();
    nav("/login", { replace: true });
  }

  const initials =
    (user?.fullName || "Admin")
      .split(" ")
      .slice(0, 2)
      .map((p) => p[0]?.toUpperCase())
      .join("") || "A";

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="flex">
        {/* SIDEBAR */}
        <aside className="w-72 bg-white border-r border-slate-200 min-h-screen flex flex-col">
          {/* Brand */}
          <div className="p-6">
            <div className="flex items-start gap-3">
              <div className="h-10 w-10 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                <BadgeCheck size={20} />
              </div>

              <div>
                <div className="text-lg font-extrabold text-slate-900 leading-tight">
                  Hôtel La
                  <br />
                  Promenade
                </div>
                <div className="text-xs text-slate-500 mt-1">Gestion événements</div>
              </div>
            </div>
          </div>

          {/* Menu */}
          <nav className="px-4 space-y-1">
            {/* ✅ end=true pour éviter le highlight sur /admin/* */}
            <SideItem to="/admin" icon={LayoutGrid} label="Tableau de bord" end />

            <SideItem to="/admin/demandes" icon={Clock3} label="Demandes en attente" />
            <SideItem to="/admin/utilisateurs" icon={Users} label="Utilisateurs" />

            <SideItem
              to="/admin/salles-reservations"
              icon={Building2}
              label="Salles & Réservations"
            />

            <SideItem to="/admin/services" icon={Briefcase} label="Services" />
            <SideItem to="/admin/notifications" icon={Bell} label="Notifications" />
            <SideItem to="/admin/facturation" icon={FileText} label="Facturation & Paiements" />
            <SideItem to="/admin/parametres" icon={Settings} label="Paramètres" />
          </nav>

          {/* Logout bottom */}
          <div className="mt-auto p-4 border-t border-slate-200">
            <button
              onClick={logout}
              className="w-full flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100"
            >
              <LogOut size={18} />
              <span>Déconnexion</span>
            </button>
          </div>
        </aside>

        {/* MAIN */}
        <main className="flex-1">
          {/* TOPBAR */}
          <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6">
            <div className="text-xl font-bold text-slate-900">Administration</div>

            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">
                {initials}
              </div>

              <div className="leading-tight">
                <div className="text-sm font-semibold text-slate-900">{user?.fullName || "Admin"}</div>
                <div className="text-xs text-slate-500">{user?.email || ""}</div>
              </div>
            </div>
          </header>

          {/* CONTENT */}
          <div className="p-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}