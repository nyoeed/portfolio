export function fmtMoneyCAD(n) {
  const x = Number(n || 0);
  return x.toLocaleString("fr-CA", { style: "currency", currency: "CAD" });
}