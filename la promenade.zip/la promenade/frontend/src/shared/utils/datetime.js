export function fmtDateFR(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return d.toLocaleDateString("fr-CA", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function fmtTimeFR(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return d.toLocaleTimeString("fr-CA", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function fmtDateTimeFR(iso) {
  if (!iso) return "-";
  return `${fmtDateFR(iso)} • ${fmtTimeFR(iso)}`;
}
