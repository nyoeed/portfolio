import { Navigate, Route, Routes } from "react-router-dom";

import LoginPage from "@/features/auth/pages/LoginPage.jsx";
import RegisterPage from "@/features/auth/pages/RegisterPage.jsx";
import PendingApprovalPage from "@/features/auth/pages/PendingApprovalPage.jsx";
import InitAdminPage from "@/features/auth/pages/InitAdminPage.jsx";
import ForgotPasswordPage from "@/features/auth/pages/ForgotPasswordPage.jsx";
import ResetPasswordPage from "@/features/auth/pages/ResetPasswordPage.jsx";

import AdminLayout from "@/components/layout/AdminLayout.jsx";
import AdminHome from "@/features/admin/dashboards/pages/AdminHome.jsx";
import AdminDemandes from "@/features/admin/requests/pages/AdminRequestsPage.jsx";
import AdminUtilisateurs from "@/features/admin/users/pages/AdminUsersPage.jsx";
import AdminSallesReservations from "@/features/admin/rooms/pages/AdminRoomsReservationsPage.jsx";
import AdminServices from "@/features/admin/services/pages/AdminServicesPage.jsx";
import AdminNotifications from "@/features/admin/notifications/pages/AdminNotificationsPage.jsx";
import AdminParametres from "@/features/admin/settings/pages/AdminSettingsPage.jsx";
import AdminBillingPage from "@/features/admin/billing/pages/AdminBillingPage.jsx";

import OrganizerLayout from "@/features/organizer/layout/OrganizerLayout.jsx";
import OrganizerHome from "@/features/organizer/dashboard/pages/OrganizerHome.jsx";
import OrganizerEventsPage from "@/features/organizer/events/pages/OrganizerEventsPage.jsx";
import OrganizerCreateEventPage from "@/features/organizer/create/pages/OrganizerCreateEventPage.jsx";
import OrganizerRoomsAvailabilityPage from "@/features/organizer/spaces/pages/OrganizerRoomsAvailabilityPage.jsx";
import OrganizerRoomsCalendarPage from "@/features/organizer/spaces/pages/OrganizerRoomsCalendarPage.jsx";
import OrganizerReservationsPage from "@/features/organizer/spaces/pages/OrganizerReservationsPage.jsx";
import OrganizerServicesPage from "@/features/organizer/services/pages/OrganizerServicesPage.jsx";
import OrganizerGuestsPage from "@/features/organizer/guests/pages/OrganizerGuestsPage.jsx";
import OrganizerDocumentsPage from "@/features/organizer/documents/pages/OrganizerDocumentsPage.jsx";
import OrganizerBillingPage from "@/features/organizer/billing/pages/OrganizerBillingPage.jsx";
import OrganizerReportsPage from "@/features/organizer/reports/pages/OrganizerReportsPage.jsx";
import OrganizerNotificationsPage from "@/features/organizer/notifications/pages/OrganizerNotificationsPage.jsx";
import OrganizerSettingsPage from "@/features/organizer/settings/pages/OrganizerSettingsPage.jsx";

import CoordinatorLayout from "@/features/coordinator/layout/CoordinatorLayout.jsx";
import CoordinatorDashboardPage from "@/features/coordinator/pages/CoordinatorDashboardPage.jsx";
import CoordinatorEventsPage from "@/features/coordinator/pages/CoordinatorEventsPage.jsx";
import CoordinatorEventDetailPage from "@/features/coordinator/pages/CoordinatorEventDetailPage.jsx";
import CoordinatorRoomsPage from "@/features/coordinator/pages/CoordinatorRoomsPage.jsx";
import CoordinatorServicesPage from "@/features/coordinator/pages/CoordinatorServicesPage.jsx";
import CoordinatorAlertsPage from "@/features/coordinator/pages/CoordinatorAlertsPage.jsx";
import CoordinatorReportsPage from "@/features/coordinator/pages/CoordinatorReportsPage.jsx";
import CoordinatorSettingsPage from "@/features/coordinator/pages/CoordinatorSettingsPage.jsx";

import AccountingLayout from "@/components/layout/AccountingLayout.jsx";
import AccountingDashboardPage from "@/features/accounting/dashboard/pages/AccountingDashboardPage.jsx";
import AccountingInvoicesPage from "@/features/accounting/invoices/pages/AccountingInvoicesPage.jsx";
import AccountingPaymentsPage from "@/features/accounting/payments/pages/AccountingPaymentsPage.jsx";
import AccountingRefundsPage from "@/features/accounting/refunds/pages/AccountingRefundsPage.jsx";
import AccountingReportsPage from "@/features/accounting/reports/pages/AccountingReportsPage.jsx";
import AccountingNotificationsPage from "@/features/accounting/notifications/pages/AccountingNotificationsPage.jsx";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/pending-approval" element={<PendingApprovalPage />} />
      <Route path="/init-admin" element={<InitAdminPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />

      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<AdminHome />} />
        <Route path="demandes" element={<AdminDemandes />} />
        <Route path="utilisateurs" element={<AdminUtilisateurs />} />
        <Route path="salles-reservations" element={<AdminSallesReservations />} />
        <Route path="services" element={<AdminServices />} />
        <Route path="notifications" element={<AdminNotifications />} />
        <Route path="parametres" element={<AdminParametres />} />
        <Route path="facturation" element={<AdminBillingPage />} />
      </Route>

      <Route path="/organizer" element={<OrganizerLayout />}>
        <Route index element={<OrganizerHome />} />
        <Route path="evenements" element={<OrganizerEventsPage />} />
        <Route path="creer-evenement" element={<OrganizerCreateEventPage />} />
        <Route path="espaces/disponibilites" element={<OrganizerRoomsAvailabilityPage />} />
        <Route path="espaces/calendrier" element={<OrganizerRoomsCalendarPage />} />
        <Route path="espaces/reservations" element={<OrganizerReservationsPage />} />
        <Route path="services/demandes" element={<OrganizerServicesPage />} />
        <Route path="services/traiteur" element={<OrganizerServicesPage />} />
        <Route path="services/audiovisuel" element={<OrganizerServicesPage />} />
        <Route path="services/securite" element={<OrganizerServicesPage />} />
        <Route path="services/autres" element={<OrganizerServicesPage />} />
        <Route path="services/devis-estimatif" element={<OrganizerServicesPage />} />
        <Route path="invites" element={<OrganizerGuestsPage />} />
        <Route path="documents" element={<OrganizerDocumentsPage />} />
        <Route path="facturation" element={<OrganizerBillingPage />} />
        <Route path="rapports" element={<OrganizerReportsPage />} />
        <Route path="notifications" element={<OrganizerNotificationsPage />} />
        <Route path="parametres" element={<OrganizerSettingsPage />} />
      </Route>

      <Route path="/coordinator" element={<CoordinatorLayout />}>
        <Route index element={<CoordinatorDashboardPage />} />
        <Route path="evenements" element={<CoordinatorEventsPage />} />
        <Route path="evenements/:id" element={<CoordinatorEventDetailPage />} />
        <Route path="salles" element={<CoordinatorRoomsPage />} />
        <Route path="services" element={<CoordinatorServicesPage />} />
        <Route path="alertes" element={<CoordinatorAlertsPage />} />
        <Route path="rapports" element={<CoordinatorReportsPage />} />
        <Route path="parametres" element={<CoordinatorSettingsPage />} />
      </Route>

      <Route path="/accounting" element={<AccountingLayout />}>
        <Route index element={<AccountingDashboardPage />} />
        <Route path="factures" element={<AccountingInvoicesPage />} />
        <Route path="paiements" element={<AccountingPaymentsPage />} />
        <Route path="remboursements" element={<AccountingRefundsPage />} />
        <Route path="rapports" element={<AccountingReportsPage />} />
        <Route path="notifications" element={<AccountingNotificationsPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
