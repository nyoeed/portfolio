import { accountingApi } from "@/components/lib/accountingApi.js";
import { useState } from "react";
import { X, Download, Trash2, RefreshCcw } from "lucide-react";

function formatMoney(value) {
  return `${Number(value || 0).toFixed(2)} $`;
}

function formatDate(value) {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("fr-CA");
}

export default function InvoiceDetailsModal({
  open,
  onClose,
  invoice,
  onUpdated,
  onDeleted,
}) {
  const [status, setStatus] = useState(invoice?.status || "pending");
  const [loadingStatus, setLoadingStatus] = useState(false);
  const [loadingDelete, setLoadingDelete] = useState(false);
  const [error, setError] = useState(null);

  if (!open || !invoice) return null;

  async function handleUpdateStatus() {
    try {
      setLoadingStatus(true);
      setError(null);
      await accountingApi.updateInvoiceStatus(invoice.id, status);
      if (onUpdated) {
        await onUpdated();
      }
    } catch (err) {
      console.error(err);
      setError(err?.response?.data?.message || err.message || "Erreur de mise à jour.");
    } finally {
      setLoadingStatus(false);
    }
  }

  async function handleDeleteInvoice() {
    const ok = window.confirm("Voulez-vous vraiment supprimer cette facture ?");
    if (!ok) return;

    try {
      setLoadingDelete(true);
      setError(null);
      await accountingApi.deleteInvoice(invoice.id);
      if (onDeleted) {
        await onDeleted();
      }
      onClose();
    } catch (err) {
      console.error(err);
      setError(err?.response?.data?.message || err.message || "Erreur lors de la suppression.");
    } finally {
      setLoadingDelete(false);
    }
  }

  function handleDownload() {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>${invoice.invoiceNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 32px; color: #0f172a; }
            h1, h2, h3 { margin: 0 0 12px 0; }
            .section { margin-bottom: 24px; }
            .row { margin-bottom: 8px; }
            .label { font-weight: bold; }
            .box { border: 1px solid #cbd5e1; border-radius: 12px; padding: 16px; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <h1>Facture ${invoice.invoiceNumber}</h1>
          <div class="section box">
            <div class="row"><span class="label">Client :</span> ${invoice.clientName || "-"}</div>
            <div class="row"><span class="label">Email :</span> ${invoice.clientEmail || "-"}</div>
            <div class="row"><span class="label">Événement :</span> ${invoice.eventTitle || invoice.eventName || "-"}</div>
            <div class="row"><span class="label">Type :</span> ${invoice.eventType || "-"}</div>
          </div>

          <div class="section box">
            <div class="row"><span class="label">Date émission :</span> ${formatDate(invoice.issueDate)}</div>
            <div class="row"><span class="label">Date échéance :</span> ${formatDate(invoice.dueDate)}</div>
            <div class="row"><span class="label">Date paiement :</span> ${formatDate(invoice.paidAt)}</div>
            <div class="row"><span class="label">Statut :</span> ${invoice.status || "-"}</div>
          </div>

          <div class="section box">
            <div class="row"><span class="label">Sous-total :</span> ${formatMoney(invoice.subtotal)}</div>
            <div class="row"><span class="label">Taxe (${Number(invoice.taxRate || 0).toFixed(2)}%) :</span> ${formatMoney(invoice.taxAmount)}</div>
            <div class="row"><span class="label">Total :</span> ${formatMoney(invoice.total)}</div>
            <div class="row"><span class="label">Déjà payé :</span> ${formatMoney(invoice.paidSum)}</div>
            <div class="row"><span class="label">Montant restant :</span> ${formatMoney(invoice.remainingAmount)}</div>
          </div>

          <script>
            window.onload = function() {
              window.print();
            };
          </script>
        </body>
      </html>
    `);

    printWindow.document.close();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />

      <div className="relative z-10 w-full max-w-4xl rounded-2xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              Détails de la facture
            </h2>
            <p className="text-sm text-slate-500">{invoice.invoiceNumber}</p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"
          >
            <X size={18} />
          </button>
        </div>

        <div className="space-y-6 px-6 py-6">
          {error ? (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          ) : null}

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <InfoCard title="Informations client">
              <InfoRow label="Nom" value={invoice.clientName} />
              <InfoRow label="Email" value={invoice.clientEmail} />
            </InfoCard>

            <InfoCard title="Informations événement">
              <InfoRow label="Nom événement" value={invoice.eventName} />
              <InfoRow label="Titre événement" value={invoice.eventTitle} />
              <InfoRow label="Type événement" value={invoice.eventType} />
            </InfoCard>

            <InfoCard title="Dates">
              <InfoRow label="Créée le" value={formatDate(invoice.createdAt)} />
              <InfoRow label="Date émission" value={formatDate(invoice.issueDate)} />
              <InfoRow label="Date échéance" value={formatDate(invoice.dueDate)} />
              <InfoRow label="Date payée" value={formatDate(invoice.paidAt)} />
            </InfoCard>

            <InfoCard title="Montants">
              <InfoRow label="Sous-total" value={formatMoney(invoice.subtotal)} />
              <InfoRow
                label={`Taxe (${Number(invoice.taxRate || 0).toFixed(2)}%)`}
                value={formatMoney(invoice.taxAmount)}
              />
              <InfoRow label="Total" value={formatMoney(invoice.total)} />
              <InfoRow label="Déjà payé" value={formatMoney(invoice.paidSum)} />
              <InfoRow
                label="Montant restant"
                value={formatMoney(invoice.remainingAmount)}
                strong
              />
            </InfoCard>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="mb-3 text-sm font-semibold text-slate-700">
              Modifier le statut
            </div>

            <div className="flex flex-col gap-3 md:flex-row md:items-center">
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-blue-500"
              >
                <option value="pending">En attente</option>
                <option value="partial">Partielle</option>
                <option value="paid">Payée</option>
                <option value="late">En retard</option>
              </select>

              <button
                type="button"
                onClick={handleUpdateStatus}
                disabled={loadingStatus}
                className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-60"
              >
                <RefreshCcw size={16} />
                {loadingStatus ? "Mise à jour..." : "Mettre à jour le statut"}
              </button>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={handleDownload}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              <Download size={16} />
              Télécharger la facture
            </button>

            <button
              type="button"
              onClick={handleDeleteInvoice}
              disabled={loadingDelete}
              className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-5 py-3 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-60"
            >
              <Trash2 size={16} />
              {loadingDelete ? "Suppression..." : "Supprimer"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoCard({ title, children }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5">
      <div className="mb-4 text-sm font-bold text-slate-800">{title}</div>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function InfoRow({ label, value, strong = false }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-slate-100 py-2 last:border-b-0">
      <span className="text-sm text-slate-500">{label}</span>
      <span className={`text-sm text-right ${strong ? "font-bold text-blue-700" : "font-semibold text-slate-900"}`}>
        {value || "-"}
      </span>
    </div>
  );
}