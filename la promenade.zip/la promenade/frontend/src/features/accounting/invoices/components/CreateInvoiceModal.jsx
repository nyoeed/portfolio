import { useEffect, useMemo, useState } from "react";
import { accountingApi } from "@/components/lib/accountingApi.js";
import { X } from "lucide-react";

function formatDateTime(value) {
  if (!value) return "-";
  return new Date(value).toLocaleString("fr-CA", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

export default function CreateInvoiceModal({ open, onClose, onCreated, initialEventId = "" }) {
  const [events, setEvents] = useState([]);
  const [eventsLoading, setEventsLoading] = useState(false);
  const [selectedEventId, setSelectedEventId] = useState("");

  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [eventTitle, setEventTitle] = useState("");
  const [eventType, setEventType] = useState("");
  const [issueDate, setIssueDate] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [subtotal, setSubtotal] = useState("");
  const [taxRate, setTaxRate] = useState("18");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const selectedEvent = useMemo(
    () => events.find((event) => event.id === selectedEventId) || null,
    [events, selectedEventId],
  );

  useEffect(() => {
    if (!open) return;

    const today = new Date().toISOString().slice(0, 10);
    const due = new Date();
    due.setDate(due.getDate() + 15);

    setSelectedEventId("");
    setClientName("");
    setClientEmail("");
    setEventTitle("");
    setEventType("");
    setIssueDate(today);
    setDueDate(due.toISOString().slice(0, 10));
    setSubtotal("");
    setTaxRate("18");
    setError(null);
    setLoading(false);

    let cancelled = false;

    async function loadEvents() {
      try {
        setEventsLoading(true);
        const rows = await accountingApi.invoiceableEvents();
        if (cancelled) return;
        const safeRows = Array.isArray(rows) ? rows : [];
        setEvents(safeRows);

        const preferred = safeRows.find((row) => row.id === initialEventId) || null;
        const firstAvailable = safeRows.find((row) => Number(row.invoiceCount || 0) === 0) || safeRows[0] || null;
        const target = preferred || firstAvailable;
        if (target) {
          setSelectedEventId(target.id);
        }
      } catch (err) {
        if (!cancelled) {
          console.error(err);
          setEvents([]);
          setError("Impossible de charger les événements facturables.");
        }
      } finally {
        if (!cancelled) {
          setEventsLoading(false);
        }
      }
    }

    loadEvents();

    return () => {
      cancelled = true;
    };
  }, [open, initialEventId]);

  useEffect(() => {
    if (!selectedEvent) return;

    setClientName(selectedEvent.clientName || "");
    setClientEmail(selectedEvent.clientEmail || "");
    setEventTitle(selectedEvent.title || "");
    setEventType(selectedEvent.type || "");
    setSubtotal(String(Number(selectedEvent.suggestedSubtotal || 0)));
  }, [selectedEvent]);

  const previewTax = useMemo(() => {
    const sub = Number(subtotal || 0);
    const rate = Number(taxRate || 0);
    return (sub * rate) / 100;
  }, [subtotal, taxRate]);

  const previewTotal = useMemo(() => Number(subtotal || 0) + previewTax, [subtotal, previewTax]);

  async function handleSubmit(e) {
    e.preventDefault();

    if (!selectedEventId || !issueDate || !dueDate || subtotal === "" || taxRate === "") {
      setError("Veuillez remplir tous les champs obligatoires.");
      return;
    }

    try {
      setLoading(true);
      setError(null);

      await accountingApi.createInvoice({
        eventId: selectedEventId,
        issueDate,
        dueDate,
        subtotal: Number(subtotal),
        taxRate: Number(taxRate),
      });

      if (onCreated) {
        await onCreated();
      }

      onClose();
    } catch (err) {
      console.error(err);
      setError(err.message || "Impossible de créer la facture.");
    } finally {
      setLoading(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />

      <div className="relative z-10 w-full max-w-3xl rounded-2xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Créer une facture</h2>
            <p className="text-sm text-slate-500">Sélectionnez un événement existant pour créer une facture liée par eventId.</p>
          </div>

          <button type="button" onClick={onClose} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 px-6 py-6">
          {error ? (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
          ) : null}

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Field label="Événement *">
              <select
                value={selectedEventId}
                onChange={(e) => setSelectedEventId(e.target.value)}
                disabled={eventsLoading || loading}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500 disabled:opacity-60"
              >
                <option value="">Sélectionner un événement</option>
                {events.map((event) => (
                  <option key={event.id} value={event.id}>
                    {event.title} — {event.type || "Sans type"} {Number(event.invoiceCount || 0) > 0 ? "(déjà facturé)" : ""}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Nom du client">
              <input value={clientName} readOnly className="w-full rounded-xl border border-slate-200 bg-slate-100 px-4 py-3 text-slate-700 outline-none" />
            </Field>

            <Field label="Email du client">
              <input value={clientEmail} readOnly className="w-full rounded-xl border border-slate-200 bg-slate-100 px-4 py-3 text-slate-700 outline-none" />
            </Field>

            <Field label="Type d’événement">
              <input value={eventType} readOnly className="w-full rounded-xl border border-slate-200 bg-slate-100 px-4 py-3 text-slate-700 outline-none" />
            </Field>

            <Field label="Date émission *">
              <input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" />
            </Field>

            <Field label="Date échéance *">
              <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" />
            </Field>

            <Field label="Sous-total *">
              <input type="number" step="0.01" min="0" value={subtotal} onChange={(e) => setSubtotal(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" placeholder="10000" />
            </Field>

            <Field label="Taux de taxe (%) *">
              <input type="number" step="0.01" min="0" value={taxRate} onChange={(e) => setTaxRate(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" placeholder="18" />
            </Field>
          </div>

          {selectedEvent ? (
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="text-sm font-semibold text-slate-700">Résumé de l’événement sélectionné</div>
              <div className="mt-3 grid grid-cols-1 gap-3 text-sm text-slate-700 md:grid-cols-2">
                <div>
                  <div className="text-xs text-slate-500">Titre</div>
                  <div className="font-semibold text-slate-900">{eventTitle || selectedEvent.title}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Statut</div>
                  <div className="font-semibold text-slate-900">{selectedEvent.status || "-"}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Date</div>
                  <div className="font-semibold text-slate-900">{formatDateTime(selectedEvent.startAt)}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Salle</div>
                  <div className="font-semibold text-slate-900">{selectedEvent.roomName || "-"}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Budget</div>
                  <div className="font-semibold text-slate-900">{Number(selectedEvent.budget || 0).toFixed(2)} $</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Services estimés</div>
                  <div className="font-semibold text-slate-900">{Number(selectedEvent.serviceEstimated || 0).toFixed(2)} $</div>
                </div>
              </div>
            </div>
          ) : null}

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="text-sm font-semibold text-slate-700">Aperçu</div>
            <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-3">
              <div>
                <div className="text-xs text-slate-500">Sous-total</div>
                <div className="font-semibold text-slate-900">{Number(subtotal || 0).toFixed(2)} $</div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Taxes</div>
                <div className="font-semibold text-slate-900">{previewTax.toFixed(2)} $</div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Total estimé</div>
                <div className="font-semibold text-slate-900">{previewTotal.toFixed(2)} $</div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50">
              Annuler
            </button>

            <button type="submit" disabled={loading || eventsLoading || !selectedEventId} className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60">
              {loading ? "Création..." : "Créer la facture"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <div className="mb-2 text-sm font-semibold text-slate-700">{label}</div>
      {children}
    </label>
  );
}
