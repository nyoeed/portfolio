import { useEffect, useState } from "react";
import { accountingApi } from "@/components/lib/accountingApi.js";
import { Search, FileText, BellRing } from "lucide-react";
import CreateInvoiceModal from "../components/CreateInvoiceModal";
import InvoiceDetailsModal from "../components/InvoiceDetailsModal";

function formatMoney(value) {
  return `${Number(value || 0).toFixed(2)} $`;
}

function formatDate(value) {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("fr-CA");
}

function StatusBadge({ status }) {
  const map = {
    paid: "bg-green-100 text-green-700",
    pending: "bg-amber-100 text-amber-700",
    late: "bg-red-100 text-red-700",
    partial: "bg-blue-100 text-blue-700",
  };

  return <span className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${map[status] || "bg-slate-100 text-slate-700"}`}>{status || "-"}</span>;
}

export default function AccountingInvoicesPage() {
  const [rows, setRows] = useState([]);
  const [invoiceableEvents, setInvoiceableEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  const [openCreateModal, setOpenCreateModal] = useState(false);
  const [preselectedEventId, setPreselectedEventId] = useState("");
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [openDetailsModal, setOpenDetailsModal] = useState(false);

  async function loadInvoices(currentSearch = search, currentStatus = status) {
    try {
      setLoading(true);
      setError(null);
      const [invoiceRows, eventRows] = await Promise.all([
        accountingApi.invoices({ search: currentSearch.trim(), status: currentStatus.trim() }),
        accountingApi.invoiceableEvents(),
      ]);
      setRows(Array.isArray(invoiceRows) ? invoiceRows : []);
      setInvoiceableEvents((Array.isArray(eventRows) ? eventRows : []).filter((row) => Number(row.invoiceCount || 0) === 0));
    } catch (err) {
      console.error(err);
      setError("Impossible de charger les factures.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadInvoices(); }, []);

  function handleSubmit(e) {
    e.preventDefault();
    loadInvoices(search, status);
  }

  function handleOpenCreate(eventId = "") {
    setPreselectedEventId(eventId);
    setOpenCreateModal(true);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Factures</h1>
          <p className="mt-1 text-sm text-slate-500">Gérez les factures liées aux événements et repérez immédiatement les événements non encore facturés</p>
        </div>
        <button type="button" onClick={() => handleOpenCreate("")} className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-700">+ Créer une facture</button>
      </div>

      {invoiceableEvents.length > 0 ? (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
          <div className="mb-3 flex items-center gap-2 text-amber-900">
            <BellRing size={18} />
            <div className="font-bold">Événements en attente de facture</div>
          </div>
          <div className="space-y-3">
            {invoiceableEvents.slice(0, 4).map((event) => (
              <div key={event.id} className="flex flex-col gap-3 rounded-xl border border-amber-200 bg-white p-4 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="font-semibold text-slate-900">{event.title}</div>
                  <div className="text-sm text-slate-600">{event.clientName || "Organisateur"} • {event.type || "Sans type"}</div>
                  <div className="mt-1 text-xs text-slate-500">{formatDate(event.startAt)} • budget suggéré {formatMoney(event.suggestedSubtotal || event.budget)}</div>
                </div>
                <button type="button" onClick={() => handleOpenCreate(event.id)} className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800">Créer la facture</button>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <SummaryCard title="Total factures" value={rows.length} icon={<FileText size={20} />} />
        <SummaryCard title="Factures payées" value={rows.filter((r) => r.status === "paid").length} icon={<FileText size={20} />} />
        <SummaryCard title="Factures en retard" value={rows.filter((r) => r.status === "late").length} icon={<FileText size={20} />} />
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <form onSubmit={handleSubmit} className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input type="text" placeholder="Rechercher une facture, un client, un événement..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 text-sm outline-none focus:border-blue-500" />
          </div>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500">
            <option value="">Tous les statuts</option>
            <option value="paid">Payée</option>
            <option value="pending">En attente</option>
            <option value="partial">Partielle</option>
            <option value="late">En retard</option>
          </select>
          <button type="submit" className="rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white hover:bg-slate-800">Rechercher</button>
        </form>
      </div>

      {loading ? <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-slate-500">Chargement des factures...</div> : null}
      {error ? <div className="rounded-2xl border border-red-200 bg-red-50 p-10 text-center text-red-600">{error}</div> : null}
      {!loading && !error ? (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <div className="border-b border-slate-200 px-6 py-4"><h2 className="font-bold text-slate-900">Liste des factures</h2></div>
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-slate-50">
                <tr className="text-left text-xs font-bold uppercase tracking-wide text-slate-500">
                  <th className="px-6 py-4">Facture</th>
                  <th className="px-6 py-4">Client</th>
                  <th className="px-6 py-4">Événement</th>
                  <th className="px-6 py-4">Dates</th>
                  <th className="px-6 py-4">Montant</th>
                  <th className="px-6 py-4">Statut</th>
                  <th className="px-6 py-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.length === 0 ? (
                  <tr><td colSpan={7} className="px-6 py-10 text-center text-sm text-slate-500">Aucune facture trouvée.</td></tr>
                ) : rows.map((invoice) => (
                  <tr key={invoice.id} className="hover:bg-slate-50">
                    <td className="px-6 py-4 align-top"><div className="font-semibold text-slate-900">{invoice.invoiceNumber}</div><div className="text-xs text-slate-500">Créée le {formatDate(invoice.createdAt)}</div></td>
                    <td className="px-6 py-4 align-top"><div className="font-medium text-slate-800">{invoice.clientName}</div><div className="text-xs text-slate-500">{invoice.clientEmail || "-"}</div></td>
                    <td className="px-6 py-4 align-top"><div className="font-medium text-slate-800">{invoice.eventTitle || invoice.eventName || "-"}</div><div className="text-xs text-slate-500">{invoice.eventType || "-"}</div></td>
                    <td className="px-6 py-4 align-top text-sm text-slate-700"><div>Émise : {formatDate(invoice.issueDate)}</div><div>Échéance : {formatDate(invoice.dueDate)}</div><div>Payée : {formatDate(invoice.paidAt)}</div></td>
                    <td className="px-6 py-4 align-top"><div className="font-semibold text-slate-900">{formatMoney(invoice.total)}</div><div className="text-xs text-slate-500">HT: {formatMoney(invoice.subtotal)}</div><div className="text-xs text-slate-500">Payé: {formatMoney(invoice.paidSum)}</div><div className="text-xs font-semibold text-blue-600">Restant: {formatMoney(invoice.remainingAmount)}</div></td>
                    <td className="px-6 py-4 align-top"><StatusBadge status={invoice.status} /></td>
                    <td className="px-6 py-4 align-top"><button type="button" onClick={() => { setSelectedInvoice(invoice); setOpenDetailsModal(true); }} className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50">Voir détails</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}

      <CreateInvoiceModal open={openCreateModal} onClose={() => setOpenCreateModal(false)} onCreated={() => loadInvoices(search, status)} initialEventId={preselectedEventId} />
      <InvoiceDetailsModal open={openDetailsModal} onClose={() => setOpenDetailsModal(false)} invoice={selectedInvoice} />
    </div>
  );
}

function SummaryCard({ title, value, icon }) {
  return <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div><div className="text-sm text-slate-500">{title}</div><div className="mt-1 text-2xl font-extrabold text-slate-900">{value}</div></div><div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100 text-blue-600">{icon}</div></div>;
}
