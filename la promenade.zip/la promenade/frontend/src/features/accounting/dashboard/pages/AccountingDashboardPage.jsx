import { useEffect, useState } from "react";
import { accountingApi } from "@/components/lib/accountingApi.js";
import {
  DollarSign,
  AlertTriangle,
  CreditCard,
  TrendingUp,
  Bell,
  FilePlus2,
} from "lucide-react";

function formatMoney(value) {
  return `${Number(value || 0).toFixed(2)} $`;
}

function formatDate(value) {
  if (!value) return "-";
  return new Date(value).toLocaleString("fr-CA", { dateStyle: "medium", timeStyle: "short" });
}

export default function AccountingDashboardPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadDashboard() {
      try {
        const json = await accountingApi.dashboard();
        setData(json);
      } catch (err) {
        console.error(err);
        setError("Impossible de charger le dashboard.");
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, []);

  if (loading) {
    return <div className="py-20 text-center text-slate-500">Chargement du dashboard...</div>;
  }

  if (error) {
    return <div className="py-20 text-center font-medium text-red-500">{error}</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">Tableau de bord comptable</h1>
        <p className="mt-1 text-sm text-slate-500">Vue d’ensemble des finances, demandes de facturation et paiements simulés</p>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-4">
        <DashboardCard title="Revenus totaux" value={formatMoney(data.totalRevenue)} icon={<DollarSign size={22} />} color="green" />
        <DashboardCard title="Factures en retard" value={data.lateInvoicesCount ?? 0} icon={<AlertTriangle size={22} />} color="red" />
        <DashboardCard title="Paiements à valider" value={data.pendingPaymentsCount ?? 0} icon={<CreditCard size={22} />} color="orange" />
        <DashboardCard title="Revenus ce mois" value={formatMoney(data.revenueThisMonth)} icon={<TrendingUp size={22} />} color="blue" />
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Panel title="Événements à facturer" icon={<FilePlus2 size={18} />}>
          {(data.pendingInvoiceRequests || []).length === 0 ? (
            <EmptyText>Aucun événement en attente de facture.</EmptyText>
          ) : (
            data.pendingInvoiceRequests.map((event) => (
              <div key={event.id} className="px-6 py-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="font-semibold text-slate-900">{event.title}</div>
                    <div className="text-sm text-slate-600">{event.clientName || "Organisateur"}</div>
                    <div className="mt-1 text-xs text-slate-500">{event.type || "Sans type"} • {formatDate(event.startAt)}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-slate-900">{formatMoney(event.budget)}</div>
                    <div className="text-xs text-amber-600">Aucune facture créée</div>
                  </div>
                </div>
              </div>
            ))
          )}
        </Panel>

        <Panel title="Notifications comptables" icon={<Bell size={18} />}>
          {(data.notifications || []).length === 0 ? (
            <EmptyText>Aucune notification.</EmptyText>
          ) : (
            data.notifications.map((item) => (
              <div key={item.id} className="px-6 py-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="font-semibold text-slate-900">{item.title}</div>
                    <div className="mt-1 text-sm text-slate-600">{item.message || "-"}</div>
                  </div>
                  <div className="text-right text-xs text-slate-500">
                    <div>{item.isRead ? "Lu" : "Non lu"}</div>
                    <div className="mt-1">{formatDate(item.createdAt)}</div>
                  </div>
                </div>
              </div>
            ))
          )}
        </Panel>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Panel title="Factures en retard">
          {(data.lateInvoices || []).length === 0 ? (
            <EmptyText>Aucune facture en retard.</EmptyText>
          ) : (
            data.lateInvoices.map((invoice) => (
              <div key={invoice.id} className="px-6 py-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="font-semibold text-slate-900">{invoice.invoiceNumber}</div>
                    <div className="text-sm text-slate-600">{invoice.clientName}</div>
                    <div className="mt-1 text-xs text-slate-500">{invoice.eventTitle || "-"}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-slate-900">{formatMoney(invoice.amount || invoice.total)}</div>
                    <div className="mt-1 text-xs text-red-500">{invoice.lateDays ?? 0} jour(s) de retard</div>
                  </div>
                </div>
              </div>
            ))
          )}
        </Panel>

        <Panel title="Paiements récents">
          {(data.recentPayments || []).length === 0 ? (
            <EmptyText>Aucun paiement récent.</EmptyText>
          ) : (
            data.recentPayments.map((payment) => (
              <div key={payment.id} className="px-6 py-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="font-semibold text-slate-900">{payment.paymentNumber}</div>
                    <div className="text-sm text-slate-600">{payment.clientName}</div>
                    <div className="mt-1 text-xs text-slate-500">{payment.eventTitle || "-"}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-slate-900">{formatMoney(payment.amount)}</div>
                    <div className="mt-1 text-xs text-slate-500">{payment.method || "-"}</div>
                  </div>
                </div>
              </div>
            ))
          )}
        </Panel>
      </div>
    </div>
  );
}

function DashboardCard({ title, value, icon, color }) {
  const colors = {
    green: "bg-green-100 text-green-600",
    red: "bg-red-100 text-red-600",
    orange: "bg-orange-100 text-orange-600",
    blue: "bg-blue-100 text-blue-600",
  };

  return (
    <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <div className="text-sm text-slate-500">{title}</div>
        <div className="mt-1 text-2xl font-extrabold text-slate-900">{value}</div>
      </div>
      <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${colors[color]}`}>{icon}</div>
    </div>
  );
}

function Panel({ title, icon, children }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white">
      <div className="flex items-center gap-2 border-b border-slate-200 px-6 py-4">
        {icon || null}
        <h2 className="font-bold text-slate-900">{title}</h2>
      </div>
      <div className="divide-y divide-slate-100">{children}</div>
    </div>
  );
}

function EmptyText({ children }) {
  return <div className="px-6 py-5 text-sm text-slate-500">{children}</div>;
}
