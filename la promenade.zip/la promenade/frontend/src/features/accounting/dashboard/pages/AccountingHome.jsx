export default function AccountingHome() {
  return <div className="p-6 text-xl font-bold">Accounting Dashboard ✅</div>;
}
