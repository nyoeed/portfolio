import { useEffect, useMemo, useState } from "react";
import { accountingApi } from "@/components/lib/accountingApi.js";
import { X } from "lucide-react";

function formatMoney(value) {
  return `${Number(value || 0).toFixed(2)} $`;
}

export default function CreateRefundModal({ open, onClose, onCreated }) {
  const [invoices, setInvoices] = useState([]);

  const [invoiceId, setInvoiceId] = useState("");
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  const [refundDate, setRefundDate] = useState("");

  const [loading, setLoading] = useState(false);
  const [loadingInvoices, setLoadingInvoices] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!open) return;

    const today = new Date().toISOString().slice(0, 10);

    setInvoiceId("");
    setAmount("");
    setReason("");
    setRefundDate(today);
    setError(null);
    setLoading(false);

    loadInvoices();
  }, [open]);

  async function loadInvoices() {
    try {
      setLoadingInvoices(true);
      setError(null);

      const json = await accountingApi.invoices({});
      setInvoices(Array.isArray(json) ? json : []);
    } catch (err) {
      console.error(err);
      setError(err.message || "Impossible de charger les factures.");
    } finally {
      setLoadingInvoices(false);
    }
  }

  const selectedInvoice = useMemo(() => {
    return invoices.find((inv) => String(inv.id) === String(invoiceId)) || null;
  }, [invoiceId, invoices]);

  async function handleSubmit(e) {
    e.preventDefault();

    if (!invoiceId || !amount || !reason || !refundDate) {
      setError("Veuillez remplir tous les champs obligatoires.");
      return;
    }

    const refundAmount = Number(amount);

    if (refundAmount <= 0) {
      setError("Le montant doit être supérieur à 0.");
      return;
    }

    if (selectedInvoice && refundAmount > Number(selectedInvoice.total || 0)) {
      setError("Le remboursement ne peut pas dépasser le total de la facture.");
      return;
    }

    try {
      setLoading(true);
      setError(null);

      await accountingApi.createRefund({
        invoiceId: Number(invoiceId),
        amount: refundAmount,
        reason,
        refundDate,
      });

      if (onCreated) {
        await onCreated();
      }

      onClose();
    } catch (err) {
      console.error(err);
      setError(err.message || "Impossible de créer le remboursement.");
    } finally {
      setLoading(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />

      <div className="relative z-10 w-full max-w-2xl rounded-2xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Créer un remboursement</h2>
            <p className="text-sm text-slate-500">
              Associer un remboursement à une facture existante
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 px-6 py-6">
          {error ? (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          ) : null}

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Field label="Facture *">
              <select
                value={invoiceId}
                onChange={(e) => setInvoiceId(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                disabled={loadingInvoices}
              >
                <option value="">
                  {loadingInvoices ? "Chargement des factures..." : "Sélectionner une facture"}
                </option>

                {invoices.map((invoice) => (
                  <option key={invoice.id} value={invoice.id}>
                    {invoice.invoiceNumber} — {invoice.clientName} —{" "}
                    {invoice.eventTitle || invoice.eventName || "-"} —{" "}
                    {formatMoney(invoice.total)}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Montant à rembourser *">
              <input
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                placeholder="250.00"
              />
            </Field>

            <Field label="Date remboursement *">
              <input
                type="date"
                value={refundDate}
                onChange={(e) => setRefundDate(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
              />
            </Field>

            <div className="md:col-span-2">
              <Field label="Raison *">
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  rows={4}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                  placeholder="Expliquez la raison du remboursement..."
                />
              </Field>
            </div>
          </div>

          {selectedInvoice ? (
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="text-sm font-semibold text-slate-700">Facture sélectionnée</div>

              <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
                <Info label="Facture" value={selectedInvoice.invoiceNumber} />
                <Info label="Client" value={selectedInvoice.clientName} />
                <Info label="Événement" value={selectedInvoice.eventTitle || selectedInvoice.eventName || "-"} />
                <Info label="Total facture" value={formatMoney(selectedInvoice.total)} />
              </div>
            </div>
          ) : null}

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              Annuler
            </button>

            <button
              type="submit"
              disabled={loading || loadingInvoices}
              className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? "Création..." : "Créer le remboursement"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <div className="mb-2 text-sm font-semibold text-slate-700">{label}</div>
      {children}
    </label>
  );
}

function Info({ label, value }) {
  return (
    <div>
      <div className="text-xs text-slate-500">{label}</div>
      <div className="font-semibold text-slate-900">{value || "-"}</div>
    </div>
  );
}