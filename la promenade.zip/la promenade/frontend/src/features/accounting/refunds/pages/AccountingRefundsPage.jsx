import { useEffect, useState } from "react";
import { accountingApi } from "@/components/lib/accountingApi.js";
import { Search, RotateCcw } from "lucide-react";
import CreateRefundModal from "../components/CreateRefundModal";
import RefundDetailsModal from "../components/RefundDetailsModal";

function formatMoney(value) {
  return `${Number(value || 0).toFixed(2)} $`;
}

function formatDate(value) {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("fr-CA");
}

function StatusBadge({ status }) {
  const map = {
    pending: "bg-amber-100 text-amber-700",
    approved: "bg-green-100 text-green-700",
    rejected: "bg-red-100 text-red-700",
    processed: "bg-blue-100 text-blue-700",
  };

  return (
    <span
      className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${
        map[status] || "bg-slate-100 text-slate-700"
      }`}
    >
      {status || "-"}
    </span>
  );
}

export default function AccountingRefundsPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  const [openRefundModal, setOpenRefundModal] = useState(false);

  const [selectedRefund, setSelectedRefund] = useState(null);
  const [openDetailsModal, setOpenDetailsModal] = useState(false);

  async function loadRefunds(currentSearch = search, currentStatus = status) {
    try {
      setLoading(true);
      setError(null);

      const json = await accountingApi.refunds({
        search: currentSearch.trim(),
        status: currentStatus.trim(),
      });
      setRows(Array.isArray(json) ? json : []);
    } catch (err) {
      console.error(err);
      setError("Impossible de charger les remboursements.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadRefunds();
  }, []);

  function handleSubmit(e) {
    e.preventDefault();
    loadRefunds(search, status);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Remboursements</h1>
          <p className="mt-1 text-sm text-slate-500">
            Gérez les remboursements liés aux factures
          </p>
        </div>

        <button
          type="button"
          onClick={() => setOpenRefundModal(true)}
          className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-700"
        >
          + Créer un remboursement
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-4">
        <SummaryCard
          title="Total remboursements"
          value={rows.length}
          icon={<RotateCcw size={20} />}
        />

        <SummaryCard
          title="En attente"
          value={rows.filter((r) => r.status === "pending").length}
          icon={<RotateCcw size={20} />}
        />

        <SummaryCard
          title="Traités"
          value={rows.filter((r) => r.status === "processed").length}
          icon={<RotateCcw size={20} />}
        />

        <SummaryCard
          title="Montant total"
          value={formatMoney(
            rows.reduce((sum, row) => sum + Number(row.amount || 0), 0)
          )}
          icon={<RotateCcw size={20} />}
        />
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-3 lg:flex-row lg:items-center"
        >
          <div className="relative flex-1">
            <Search
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              placeholder="Rechercher un remboursement, un client ou une facture..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 text-sm outline-none focus:border-blue-500"
            />
          </div>

          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500"
          >
            <option value="">Tous les statuts</option>
            <option value="pending">En attente</option>
            <option value="approved">Approuvé</option>
            <option value="processed">Traité</option>
            <option value="rejected">Refusé</option>
          </select>

          <button
            type="submit"
            className="rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white hover:bg-slate-800"
          >
            Rechercher
          </button>
        </form>
      </div>

      {loading ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-slate-500">
          Chargement des remboursements...
        </div>
      ) : error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-10 text-center text-red-600">
          {error}
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <div className="border-b border-slate-200 px-6 py-4">
            <h2 className="font-bold text-slate-900">Liste des remboursements</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-slate-50">
                <tr className="text-left text-xs font-bold uppercase tracking-wide text-slate-500">
                  <th className="px-6 py-4">Numéro</th>
                  <th className="px-6 py-4">Client</th>
                  <th className="px-6 py-4">Facture</th>
                  <th className="px-6 py-4">Raison</th>
                  <th className="px-6 py-4">Montant</th>
                  <th className="px-6 py-4">Date création</th>
                  <th className="px-6 py-4">Statut</th>
                  <th className="px-6 py-4">Actions</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100">
                {rows.length === 0 ? (
                  <tr>
                    <td
                      colSpan={8}
                      className="px-6 py-10 text-center text-sm text-slate-500"
                    >
                      Aucun remboursement trouvé.
                    </td>
                  </tr>
                ) : (
                  rows.map((refund) => (
                    <tr key={refund.id} className="hover:bg-slate-50">
                      <td className="px-6 py-4 align-top">
                        <div className="font-semibold text-slate-900">
                          {refund.refundNumber}
                        </div>
                      </td>

                      <td className="px-6 py-4 align-top">
                        <div className="font-medium text-slate-800">
                          {refund.clientName || "-"}
                        </div>
                      </td>

                      <td className="px-6 py-4 align-top">
                        <div className="font-medium text-slate-800">
                          {refund.invoiceNumber || "-"}
                        </div>
                      </td>

                      <td className="px-6 py-4 align-top text-sm text-slate-700 max-w-xs truncate">
                        {refund.reason || "-"}
                      </td>

                      <td className="px-6 py-4 align-top">
                        <div className="font-semibold text-slate-900">
                          {formatMoney(refund.amount)}
                        </div>
                      </td>

                      <td className="px-6 py-4 align-top text-sm text-slate-700">
                        {formatDate(refund.createdAt)}
                      </td>

                      <td className="px-6 py-4 align-top">
                        <StatusBadge status={refund.status} />
                      </td>

                      <td className="px-6 py-4 align-top">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedRefund(refund);
                            setOpenDetailsModal(true);
                          }}
                          className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                        >
                          Détails
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <CreateRefundModal
        open={openRefundModal}
        onClose={() => setOpenRefundModal(false)}
        onCreated={() => loadRefunds()}
      />

      <RefundDetailsModal
        open={openDetailsModal}
        refund={selectedRefund}
        onClose={() => {
          setOpenDetailsModal(false);
          setSelectedRefund(null);
        }}
        onUpdated={() => loadRefunds()}
        onDeleted={() => loadRefunds()}
      />
    </div>
  );
}

function SummaryCard({ title, value, icon }) {
  return (
    <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <div className="text-sm text-slate-500">{title}</div>
        <div className="mt-1 text-2xl font-extrabold text-slate-900">
          {value}
        </div>
      </div>

      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-100 text-blue-600">
        {icon}
      </div>
    </div>
  );
}