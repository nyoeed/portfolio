import { useEffect, useMemo, useState } from "react";
import { accountingApi } from "@/components/lib/accountingApi.js";
import { X } from "lucide-react";

function formatMoney(value) {
  return `${Number(value || 0).toFixed(2)} $`;
}

function formatDate(value) {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("fr-CA");
}

export default function RecordPaymentModal({ open, onClose, onCreated }) {
  const [invoices, setInvoices] = useState([]);

  const [invoiceId, setInvoiceId] = useState("");
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("Virement bancaire");
  const [paidAt, setPaidAt] = useState("");
  const [reference, setReference] = useState("");

  const [loading, setLoading] = useState(false);
  const [loadingInvoices, setLoadingInvoices] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!open) return;

    const today = new Date().toISOString().slice(0, 10);

    setInvoiceId("");
    setAmount("");
    setMethod("Virement bancaire");
    setPaidAt(today);
    setReference("");
    setError(null);
    setLoading(false);

    loadInvoices();
  }, [open]);

  async function loadInvoices() {
    try {
      setLoadingInvoices(true);
      setError(null);

      const json = await accountingApi.invoices({});

      // ✅ uniquement les factures encore payables
      const availableInvoices = (Array.isArray(json) ? json : []).filter((invoice) =>
        ["pending", "late", "partial"].includes(invoice.status)
      );

      setInvoices(availableInvoices);
    } catch (err) {
      console.error(err);
      setError(err.message || "Impossible de charger les factures.");
    } finally {
      setLoadingInvoices(false);
    }
  }

  const selectedInvoice = useMemo(() => {
    return invoices.find((inv) => String(inv.id) === String(invoiceId)) || null;
  }, [invoiceId, invoices]);

  useEffect(() => {
    if (!selectedInvoice) return;

    // ✅ préremplir avec le reste à payer réel
    const remaining = Math.max(Number(selectedInvoice.remainingAmount || 0), 0);
    setAmount(String(remaining));
  }, [selectedInvoice]);

  async function handleSubmit(e) {
    e.preventDefault();

    if (!invoiceId || !amount || !method || !paidAt) {
      setError("Veuillez remplir tous les champs obligatoires.");
      return;
    }

    const amountNum = Number(amount);
    const remaining = Number(selectedInvoice?.remainingAmount || 0);

    if (amountNum <= 0) {
      setError("Le montant doit être supérieur à 0.");
      return;
    }

    // ✅ empêcher de payer plus que le reste
    if (selectedInvoice && amountNum > remaining) {
      setError(`Le montant dépasse le reste à payer (${formatMoney(remaining)}).`);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      await accountingApi.createPayment({
        invoiceId: Number(invoiceId),
        amount: amountNum,
        method,
        paidAt,
        reference,
      });

      if (onCreated) {
        await onCreated();
      }

      onClose();
    } catch (err) {
      console.error(err);
      setError(err.message || "Impossible d’enregistrer le paiement.");
    } finally {
      setLoading(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />

      <div className="relative z-10 w-full max-w-2xl rounded-2xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Enregistrer un paiement</h2>
            <p className="text-sm text-slate-500">
              Sélectionnez une facture encore à régler
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 px-6 py-6">
          {error ? (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          ) : null}

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Field label="Facture *">
              <select
                value={invoiceId}
                onChange={(e) => setInvoiceId(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                disabled={loadingInvoices}
              >
                <option value="">
                  {loadingInvoices ? "Chargement des factures..." : "Sélectionner une facture"}
                </option>

                {invoices.map((invoice) => (
                  <option key={invoice.id} value={invoice.id}>
                    {invoice.invoiceNumber} — {invoice.clientName} —{" "}
                    {invoice.eventTitle || invoice.eventName || "-"} —{" "}
                    Total: {formatMoney(invoice.total)} — Restant: {formatMoney(invoice.remainingAmount)}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Montant *">
              <input
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                placeholder="11800"
              />
            </Field>

            <Field label="Méthode de paiement *">
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
              >
                <option>Virement bancaire</option>
                <option>Carte bancaire</option>
                <option>Espèces</option>
                <option>Chèque</option>
              </select>
            </Field>

            <Field label="Date paiement *">
              <input
                type="date"
                value={paidAt}
                onChange={(e) => setPaidAt(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
              />
            </Field>

            <div className="md:col-span-2">
              <Field label="Référence">
                <input
                  value={reference}
                  onChange={(e) => setReference(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                  placeholder="Ex: VIR-BNP-001"
                />
              </Field>
            </div>
          </div>

          {selectedInvoice ? (
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="text-sm font-semibold text-slate-700">
                Facture sélectionnée
              </div>

              <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
                <div>
                  <div className="text-xs text-slate-500">N° facture</div>
                  <div className="font-semibold text-slate-900">
                    {selectedInvoice.invoiceNumber}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-500">Client</div>
                  <div className="font-semibold text-slate-900">
                    {selectedInvoice.clientName}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-500">Événement</div>
                  <div className="font-semibold text-slate-900">
                    {selectedInvoice.eventTitle || selectedInvoice.eventName || "-"}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-500">Total facture</div>
                  <div className="font-semibold text-slate-900">
                    {formatMoney(selectedInvoice.total)}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-500">Déjà payé</div>
                  <div className="font-semibold text-slate-900">
                    {formatMoney(selectedInvoice.paidSum)}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-500">Reste à payer</div>
                  <div className="font-semibold text-blue-700">
                    {formatMoney(selectedInvoice.remainingAmount)}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-500">Statut</div>
                  <div className="font-semibold capitalize text-slate-900">
                    {selectedInvoice.status}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-500">Date échéance</div>
                  <div className="font-semibold text-slate-900">
                    {formatDate(selectedInvoice.dueDate)}
                  </div>
                </div>
              </div>
            </div>
          ) : null}

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              Annuler
            </button>

            <button
              type="submit"
              disabled={loading || loadingInvoices}
              className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? "Enregistrement..." : "Enregistrer le paiement"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <div className="mb-2 text-sm font-semibold text-slate-700">{label}</div>
      {children}
    </label>
  );
}