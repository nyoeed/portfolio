import { X, Download } from "lucide-react";

function formatMoney(value) {
  return `${Number(value || 0).toFixed(2)} $`;
}

function formatDate(value) {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("fr-CA");
}

export default function PaymentDetailsModal({ open, onClose, payment }) {
  if (!open || !payment) return null;

  function handleDownload() {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>${payment.paymentNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 32px; color: #0f172a; }
            h1, h2, h3 { margin: 0 0 12px 0; }
            .section { margin-bottom: 24px; }
            .row { margin-bottom: 8px; }
            .label { font-weight: bold; }
            .box { border: 1px solid #cbd5e1; border-radius: 12px; padding: 16px; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <h1>Paiement ${payment.paymentNumber}</h1>

          <div class="box">
            <div class="row"><span class="label">Référence :</span> ${payment.reference || "-"}</div>
            <div class="row"><span class="label">Montant payé :</span> ${formatMoney(payment.amount)}</div>
            <div class="row"><span class="label">Méthode :</span> ${payment.method || "-"}</div>
            <div class="row"><span class="label">Date paiement :</span> ${formatDate(payment.paidAt)}</div>
            <div class="row"><span class="label">Statut paiement :</span> ${payment.status || "-"}</div>
          </div>

          <div class="box">
            <div class="row"><span class="label">Facture :</span> ${payment.invoiceNumber || "-"}</div>
            <div class="row"><span class="label">Statut facture :</span> ${payment.invoiceStatus || "-"}</div>
            <div class="row"><span class="label">Date émission :</span> ${formatDate(payment.issueDate)}</div>
            <div class="row"><span class="label">Date échéance :</span> ${formatDate(payment.dueDate)}</div>
          </div>

          <div class="box">
            <div class="row"><span class="label">Client :</span> ${payment.clientName || "-"}</div>
            <div class="row"><span class="label">Email :</span> ${payment.clientEmail || "-"}</div>
            <div class="row"><span class="label">Événement :</span> ${payment.eventTitle || "-"}</div>
            <div class="row"><span class="label">Type événement :</span> ${payment.eventType || "-"}</div>
          </div>

          <div class="box">
            <div class="row"><span class="label">Sous-total :</span> ${formatMoney(payment.subtotal)}</div>
            <div class="row"><span class="label">Taxe (${Number(payment.taxRate || 0).toFixed(2)}%) :</span> ${formatMoney(payment.taxAmount)}</div>
            <div class="row"><span class="label">Total facture :</span> ${formatMoney(payment.total)}</div>
            <div class="row"><span class="label">Déjà payé :</span> ${formatMoney(payment.paidSum)}</div>
            <div class="row"><span class="label">Reste à payer :</span> ${formatMoney(payment.remainingAmount)}</div>
          </div>

          <script>
            window.onload = function() {
              window.print();
            };
          </script>
        </body>
      </html>
    `);

    printWindow.document.close();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />

      <div className="relative z-10 w-full max-w-4xl rounded-2xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              Détails du paiement
            </h2>
            <p className="text-sm text-slate-500">{payment.paymentNumber}</p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"
          >
            <X size={18} />
          </button>
        </div>

        <div className="space-y-6 px-6 py-6">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <InfoCard title="Informations paiement">
              <InfoRow label="N° paiement" value={payment.paymentNumber} />
              <InfoRow label="Référence" value={payment.reference} />
              <InfoRow label="Montant payé" value={formatMoney(payment.amount)} strong />
              <InfoRow label="Méthode" value={payment.method} />
              <InfoRow label="Date paiement" value={formatDate(payment.paidAt)} />
              <InfoRow label="Statut paiement" value={payment.status} />
              <InfoRow label="Créé le" value={formatDate(payment.createdAt)} />
            </InfoCard>

            <InfoCard title="Informations facture">
              <InfoRow label="N° facture" value={payment.invoiceNumber} />
              <InfoRow label="Statut facture" value={payment.invoiceStatus} />
              <InfoRow label="Date émission" value={formatDate(payment.issueDate)} />
              <InfoRow label="Date échéance" value={formatDate(payment.dueDate)} />
              <InfoRow label="Date facture payée" value={formatDate(payment.invoicePaidAt)} />
            </InfoCard>

            <InfoCard title="Client & événement">
              <InfoRow label="Client" value={payment.clientName} />
              <InfoRow label="Email" value={payment.clientEmail} />
              <InfoRow label="Événement" value={payment.eventTitle} />
              <InfoRow label="Type événement" value={payment.eventType} />
            </InfoCard>

            <InfoCard title="Montants facture">
              <InfoRow label="Sous-total" value={formatMoney(payment.subtotal)} />
              <InfoRow
                label={`Taxe (${Number(payment.taxRate || 0).toFixed(2)}%)`}
                value={formatMoney(payment.taxAmount)}
              />
              <InfoRow label="Total facture" value={formatMoney(payment.total)} />
              <InfoRow label="Déjà payé" value={formatMoney(payment.paidSum)} />
              <InfoRow
                label="Montant restant"
                value={formatMoney(payment.remainingAmount)}
                strong
              />
            </InfoCard>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={handleDownload}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              <Download size={16} />
              Télécharger / Imprimer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoCard({ title, children }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5">
      <div className="mb-4 text-sm font-bold text-slate-800">{title}</div>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function InfoRow({ label, value, strong = false }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-slate-100 py-2 last:border-b-0">
      <span className="text-sm text-slate-500">{label}</span>
      <span className={`text-sm text-right ${strong ? "font-bold text-blue-700" : "font-semibold text-slate-900"}`}>
        {value || "-"}
      </span>
    </div>
  );
}