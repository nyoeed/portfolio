import { useEffect, useState } from "react";
import { accountingApi } from "@/components/lib/accountingApi.js";
import { Search, CreditCard } from "lucide-react";
import RecordPaymentModal from "../components/RecordPaymentModal";
import PaymentDetailsModal from "../components/PaymentDetailsModal";

function formatMoney(value) {
  return `${Number(value || 0).toFixed(2)} $`;
}

function formatDate(value) {
  if (!value) return "-";
  return new Date(value).toLocaleDateString("fr-CA");
}

function StatusBadge({ status }) {
  const map = {
    completed: "bg-green-100 text-green-700",
    pending: "bg-amber-100 text-amber-700",
    failed: "bg-red-100 text-red-700",
    cancelled: "bg-slate-100 text-slate-700",
  };
  const labels = { completed: 'validé', pending: 'à valider', failed: 'refusé', cancelled: 'annulé' };
  return <span className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${map[status] || 'bg-slate-100 text-slate-700'}`}>{labels[status] || status || '-'}</span>;
}

export default function AccountingPaymentsPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [openPaymentModal, setOpenPaymentModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [openDetailsModal, setOpenDetailsModal] = useState(false);

  async function loadPayments(currentSearch = search, currentStatus = status) {
    try {
      setLoading(true);
      setError(null);
      const json = await accountingApi.payments({ search: currentSearch.trim(), status: currentStatus.trim() });
      setRows(Array.isArray(json) ? json : []);
    } catch (err) {
      console.error(err);
      setError("Impossible de charger les paiements.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadPayments(); }, []);

  async function handleDecision(paymentId, nextStatus) {
    try {
      await accountingApi.updatePaymentStatus(paymentId, nextStatus);
      await loadPayments(search, status);
    } catch (err) {
      console.error(err);
      setError("Impossible de mettre à jour ce paiement.");
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    loadPayments(search, status);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Paiements</h1>
          <p className="mt-1 text-sm text-slate-500">Validez les paiements simulés des organisateurs ou ajoutez un paiement manuel</p>
        </div>
        <button type="button" onClick={() => setOpenPaymentModal(true)} className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-700">+ Ajouter un paiement manuel</button>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <SummaryCard title="Total paiements" value={rows.length} icon={<CreditCard size={20} />} />
        <SummaryCard title="Paiements validés" value={rows.filter((r) => r.status === "completed").length} icon={<CreditCard size={20} />} />
        <SummaryCard title="Paiements à valider" value={rows.filter((r) => r.status === "pending").length} icon={<CreditCard size={20} />} />
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <form onSubmit={handleSubmit} className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1"><Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input type="text" placeholder="Rechercher un paiement, un client, un événement..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 text-sm outline-none focus:border-blue-500" /></div>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500"><option value="">Tous les statuts</option><option value="completed">Validé</option><option value="pending">À valider</option><option value="failed">Refusé</option><option value="cancelled">Annulé</option></select>
          <button type="submit" className="rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white hover:bg-slate-800">Rechercher</button>
        </form>
      </div>

      {loading ? <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-slate-500">Chargement des paiements...</div> : null}
      {error ? <div className="rounded-2xl border border-red-200 bg-red-50 p-10 text-center text-red-600">{error}</div> : null}
      {!loading && !error ? (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <div className="border-b border-slate-200 px-6 py-4"><h2 className="font-bold text-slate-900">Liste des paiements</h2></div>
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-slate-50"><tr className="text-left text-xs font-bold uppercase tracking-wide text-slate-500"><th className="px-6 py-4">Paiement</th><th className="px-6 py-4">Facture</th><th className="px-6 py-4">Client</th><th className="px-6 py-4">Événement</th><th className="px-6 py-4">Montant</th><th className="px-6 py-4">Méthode</th><th className="px-6 py-4">Date</th><th className="px-6 py-4">Statut</th><th className="px-6 py-4">Actions</th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {rows.length === 0 ? <tr><td colSpan={9} className="px-6 py-10 text-center text-sm text-slate-500">Aucun paiement trouvé.</td></tr> : rows.map((payment) => (
                  <tr key={payment.id} className="hover:bg-slate-50">
                    <td className="px-6 py-4 align-top"><div className="font-semibold text-slate-900">{payment.paymentNumber}</div><div className="text-xs text-slate-500">Ref : {payment.reference || '-'}</div></td>
                    <td className="px-6 py-4 align-top"><div className="font-medium text-slate-800">{payment.invoiceNumber || '-'}</div></td>
                    <td className="px-6 py-4 align-top"><div className="font-medium text-slate-800">{payment.clientName || '-'}</div></td>
                    <td className="px-6 py-4 align-top"><div className="font-medium text-slate-800">{payment.eventTitle || '-'}</div></td>
                    <td className="px-6 py-4 align-top"><div className="font-semibold text-slate-900">{formatMoney(payment.amount)}</div><div className="text-xs text-blue-600">Restant facture: {formatMoney(payment.remainingAmount)}</div></td>
                    <td className="px-6 py-4 align-top text-sm text-slate-700">{payment.method || '-'}</td>
                    <td className="px-6 py-4 align-top text-sm text-slate-700"><div>{formatDate(payment.paidAt)}</div><div className="text-xs text-slate-500">Créé le {formatDate(payment.createdAt)}</div></td>
                    <td className="px-6 py-4 align-top"><StatusBadge status={payment.status} /></td>
                    <td className="px-6 py-4 align-top"><div className="flex flex-wrap gap-2">{payment.status === 'pending' ? (<><button type="button" onClick={() => handleDecision(payment.id, 'completed')} className="rounded-lg bg-green-600 px-3 py-2 text-xs font-semibold text-white hover:bg-green-700">Valider</button><button type="button" onClick={() => handleDecision(payment.id, 'failed')} className="rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white hover:bg-red-700">Refuser</button></>) : null}<button type="button" onClick={() => { setSelectedPayment(payment); setOpenDetailsModal(true); }} className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50">Voir détails</button></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}

      <RecordPaymentModal open={openPaymentModal} onClose={() => setOpenPaymentModal(false)} onCreated={() => loadPayments(search, status)} />
      <PaymentDetailsModal open={openDetailsModal} onClose={() => setOpenDetailsModal(false)} payment={selectedPayment} />
    </div>
  );
}

function SummaryCard({ title, value, icon }) {
  return <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div><div className="text-sm text-slate-500">{title}</div><div className="mt-1 text-2xl font-extrabold text-slate-900">{value}</div></div><div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100 text-blue-600">{icon}</div></div>;
}
