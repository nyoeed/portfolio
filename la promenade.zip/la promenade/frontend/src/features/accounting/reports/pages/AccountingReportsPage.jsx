import { useEffect, useMemo, useState } from "react";
import { accountingApi } from "@/components/lib/accountingApi.js";
import {
  DollarSign,
  FileText,
  BarChart3,
  TrendingUp,
  Download,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts";

function formatMoney(value) {
  return `${Number(value || 0).toFixed(2)} $`;
}

function formatPercent(value) {
  return `${Number(value || 0).toFixed(1)}%`;
}

const PIE_COLORS = ["#4F46E5", "#10B981", "#F59E0B", "#8B5CF6", "#EF4444", "#06B6D4"];

export default function AccountingReportsPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [startDate, setStartDate] = useState("2025-09-01");
  const [endDate, setEndDate] = useState("2026-03-31");

  async function loadReports(customStart = startDate, customEnd = endDate) {
    try {
      setLoading(true);
      setError(null);

      const json = await accountingApi.reports({ startDate: customStart, endDate: customEnd });
      setData(json);
    } catch (err) {
      console.error(err);
      setError(err.message || "Impossible de charger les rapports.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadReports();
  }, []);

  function handleApplyFilters() {
    loadReports(startDate, endDate);
  }

  function handleExportCSV() {
    if (!data?.charts?.revenueByEventType?.length) return;

    const rows = data.charts.revenueByEventType.map((item) => ({
      type_evenement: item.eventType,
      nombre: item.invoiceCount,
      revenus_totaux: item.totalRevenue,
      revenu_moyen: item.averageRevenue,
      pourcentage_total: item.percentOfTotal,
    }));

    const headers = Object.keys(rows[0]);
    const csv = [
      headers.join(","),
      ...rows.map((row) =>
        headers.map((h) => `"${String(row[h] ?? "").replace(/"/g, '""')}"`).join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "rapport-financier.csv";
    a.click();

    URL.revokeObjectURL(url);
  }

  function handleExportPDF() {
    window.print();
  }

  const pieData = useMemo(() => {
    return (
      data?.charts?.revenueByEventType?.map((item) => ({
        name: item.eventType,
        value: Number(item.totalRevenue || 0),
      })) || []
    );
  }, [data]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">
            Rapports financiers
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Analyses et exports des données comptables
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handleExportCSV}
            className="inline-flex items-center gap-2 rounded-xl bg-green-600 px-4 py-3 text-sm font-semibold text-white hover:bg-green-700"
          >
            <Download size={16} />
            Export Excel
          </button>

          <button
            type="button"
            onClick={handleExportPDF}
            className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-4 py-3 text-sm font-semibold text-white hover:bg-red-700"
          >
            <Download size={16} />
            Export PDF
          </button>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="flex items-center gap-3">
            <label className="text-sm font-semibold text-slate-700">
              Période :
            </label>

            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500"
            />

            <span className="text-sm text-slate-500">à</span>

            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500"
            />
          </div>

          <button
            type="button"
            onClick={handleApplyFilters}
            className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"
          >
            Appliquer
          </button>
        </div>
      </div>

      {loading ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-slate-500">
          Chargement des rapports...
        </div>
      ) : error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-10 text-center text-red-600">
          {error}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-5">
            <StatCard
              title="Total revenus"
              value={formatMoney(data?.summary?.totalRevenue)}
              icon={<DollarSign size={18} />}
            />
            <StatCard
              title="Factures émises"
              value={data?.summary?.invoicesCount || 0}
              icon={<FileText size={18} />}
            />
            <StatCard
              title="Taux de paiement"
              value={formatPercent(data?.summary?.paymentRate)}
              icon={<BarChart3 size={18} />}
            />
            <StatCard
              title="Paiement moyen"
              value={formatMoney(data?.summary?.averagePayment)}
              icon={<DollarSign size={18} />}
            />
            <StatCard
              title="Évolution"
              value={formatPercent(data?.summary?.evolution)}
              icon={<TrendingUp size={18} />}
              highlight
            />
          </div>

          <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 bg-white p-5">
              <div className="mb-4 text-sm font-bold text-slate-900">
                Revenus par mois
              </div>

              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data?.charts?.monthlyRevenue || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="label" />
                    <YAxis />
                    <Tooltip
                      formatter={(value) => [formatMoney(value), "Revenus"]}
                    />
                    <Line
                      type="monotone"
                      dataKey="revenue"
                      stroke="#4F46E5"
                      strokeWidth={3}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5">
              <div className="mb-4 text-sm font-bold text-slate-900">
                Répartition des revenus par type d'événement
              </div>

              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={90}
                      label={({ name, percent }) =>
                        `${name} ${(percent * 100).toFixed(0)}%`
                      }
                    >
                      {pieData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={PIE_COLORS[index % PIE_COLORS.length]}
                        />
                      ))}
                    </Pie>

                    <Tooltip
                      formatter={(value) => [formatMoney(value), "Revenus"]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="mb-4 text-sm font-bold text-slate-900">
              Revenus par type d'événement (détaillé)
            </div>

            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data?.charts?.revenueByEventType || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="eventType" />
                  <YAxis />
                  <Tooltip
                    formatter={(value, name) => {
                      if (name === "totalRevenue") {
                        return [formatMoney(value), "Revenus (€)"];
                      }
                      if (name === "invoiceCount") {
                        return [value, "Nombre d'événements"];
                      }
                      return [value, name];
                    }}
                  />
                  <Bar dataKey="totalRevenue" fill="#4F46E5" name="totalRevenue" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
            <div className="border-b border-slate-200 px-6 py-4">
              <h2 className="font-bold text-slate-900">
                Tableau récapitulatif par type
              </h2>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-slate-50">
                  <tr className="text-left text-xs font-bold uppercase tracking-wide text-slate-500">
                    <th className="px-6 py-4">Type d'événement</th>
                    <th className="px-6 py-4">Nombre</th>
                    <th className="px-6 py-4">Revenus totaux</th>
                    <th className="px-6 py-4">Revenu moyen</th>
                    <th className="px-6 py-4">% du total</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {(data?.charts?.revenueByEventType || []).length === 0 ? (
                    <tr>
                      <td
                        colSpan={5}
                        className="px-6 py-10 text-center text-sm text-slate-500"
                      >
                        Aucune donnée disponible pour cette période.
                      </td>
                    </tr>
                  ) : (
                    data.charts.revenueByEventType.map((item, index) => (
                      <tr
                        key={`${item.eventType}-${index}`}
                        className="hover:bg-slate-50"
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <span
                              className="h-2.5 w-2.5 rounded-full"
                              style={{
                                backgroundColor:
                                  PIE_COLORS[index % PIE_COLORS.length],
                              }}
                            />
                            <span className="font-medium text-slate-900">
                              {item.eventType}
                            </span>
                          </div>
                        </td>

                        <td className="px-6 py-4 text-slate-700">
                          {item.invoiceCount}
                        </td>

                        <td className="px-6 py-4 font-semibold text-slate-900">
                          {formatMoney(item.totalRevenue)}
                        </td>

                        <td className="px-6 py-4 text-slate-700">
                          {formatMoney(item.averageRevenue)}
                        </td>

                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="h-2 w-28 rounded-full bg-slate-100">
                              <div
                                className="h-2 rounded-full bg-blue-600"
                                style={{
                                  width: `${Math.min(
                                    Number(item.percentOfTotal || 0),
                                    100
                                  )}%`,
                                }}
                              />
                            </div>
                            <span className="text-sm font-semibold text-slate-700">
                              {formatPercent(item.percentOfTotal)}
                            </span>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>

                {(data?.charts?.revenueByEventType || []).length > 0 ? (
                  <tfoot className="bg-slate-50">
                    <tr className="text-sm font-bold text-slate-900">
                      <td className="px-6 py-4">TOTAL</td>
                      <td className="px-6 py-4">
                        {(data?.charts?.revenueByEventType || []).reduce(
                          (sum, item) => sum + Number(item.invoiceCount || 0),
                          0
                        )}
                      </td>
                      <td className="px-6 py-4">
                        {formatMoney(data?.summary?.totalRevenue)}
                      </td>
                      <td className="px-6 py-4">
                        {formatMoney(
                          (data?.charts?.revenueByEventType || []).reduce(
                            (sum, item) => sum + Number(item.averageRevenue || 0),
                            0
                          )
                        )}
                      </td>
                      <td className="px-6 py-4">100%</td>
                    </tr>
                  </tfoot>
                ) : null}
              </table>
            </div>
          </div>

          <div className="rounded-2xl border border-blue-200 bg-blue-50 p-5">
            <div className="text-sm font-bold text-slate-900">Options d’export</div>
            <p className="mt-1 text-sm text-slate-600">
              Exporter ces données au format Excel ou PDF pour vos analyses et rapports internes.
            </p>

            <div className="mt-4 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleExportCSV}
                className="inline-flex items-center gap-2 rounded-xl bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-700"
              >
                <Download size={16} />
                Télécharger Excel
              </button>

              <button
                type="button"
                onClick={handleExportPDF}
                className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700"
              >
                <Download size={16} />
                Télécharger PDF
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function StatCard({ title, value, icon, highlight = false }) {
  return (
    <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div>
        <div className="text-sm text-slate-500">{title}</div>
        <div
          className={`mt-1 text-2xl font-extrabold ${
            highlight ? "text-green-600" : "text-slate-900"
          }`}
        >
          {value}
        </div>
      </div>

      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-100 text-blue-600">
        {icon}
      </div>
    </div>
  );
}