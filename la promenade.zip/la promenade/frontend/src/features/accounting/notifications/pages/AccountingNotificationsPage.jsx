import { useEffect, useMemo, useState } from "react";
import { Bell, Check, Mail, RefreshCw } from "lucide-react";
import { accountingApi } from "@/components/lib/accountingApi.js";
import { getMyAccount, updateMyAccount } from "@/features/auth/api/account.api";

function formatDate(value) {
  if (!value) return "-";
  return new Date(value).toLocaleString("fr-CA", { dateStyle: "medium", timeStyle: "short" });
}

export default function AccountingNotificationsPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tab, setTab] = useState("all");
  const [prefs, setPrefs] = useState({
    notificationEmailEnabled: true,
    notificationInAppEnabled: true,
    notificationSmsEnabled: false,
  });
  const [savingPrefs, setSavingPrefs] = useState(false);

  async function loadRows() {
    try {
      setLoading(true);
      setError(null);
      const [json, me] = await Promise.all([accountingApi.notifications(), getMyAccount()]);
      setRows(Array.isArray(json) ? json : []);
      setPrefs((s) => ({ ...s, ...me }));
    } catch (err) {
      console.error(err);
      setError("Impossible de charger les notifications.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadRows();
  }, []);

  async function handleRead(id) {
    try {
      await accountingApi.markNotificationRead(id);
      await loadRows();
    } catch (err) {
      console.error(err);
      setError("Impossible de marquer cette notification comme lue.");
    }
  }

  async function savePrefs(patch) {
    try {
      setSavingPrefs(true);
      const updated = await updateMyAccount({ ...prefs, ...patch });
      setPrefs((s) => ({ ...s, ...updated }));
    } catch (err) {
      setError(err?.response?.data?.message || "Impossible de mettre à jour les préférences.");
    } finally {
      setSavingPrefs(false);
    }
  }

  const filteredRows = useMemo(
    () => rows.filter((item) => (tab === "unread" ? !item.isRead : true)),
    [rows, tab]
  );
  const unreadCount = rows.filter((x) => !x.isRead).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Notifications comptables</h1>
          <p className="mt-1 text-sm text-slate-500">
            Paiements simulés, événements à facturer et alertes de remboursement avec préférences personnelles.
          </p>
        </div>
        <button
          type="button"
          onClick={loadRows}
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
        >
          <RefreshCw size={16} />
          Rafraîchir
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[1fr_360px]">
        <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <div className="border-b px-5 py-4">
            <div className="flex items-center justify-between gap-3">
              <div className="text-sm font-extrabold text-slate-900">Centre de notifications</div>
              <div className="flex gap-2 text-xs font-bold">
                <button
                  onClick={() => setTab("all")}
                  className={`rounded-full px-3 py-1 ${tab === "all" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-700"}`}
                >
                  Toutes ({rows.length})
                </button>
                <button
                  onClick={() => setTab("unread")}
                  className={`rounded-full px-3 py-1 ${tab === "unread" ? "bg-blue-600 text-white" : "bg-blue-50 text-blue-700"}`}
                >
                  Non lues ({unreadCount})
                </button>
              </div>
            </div>
          </div>

          {loading ? <div className="p-10 text-center text-slate-500">Chargement...</div> : null}
          {error ? <div className="p-10 text-center text-red-600">{error}</div> : null}

          {!loading && !error ? (
            <div className="divide-y divide-slate-100">
              {filteredRows.length === 0 ? (
                <div className="px-6 py-10 text-center text-sm text-slate-500">Aucune notification.</div>
              ) : (
                filteredRows.map((item) => (
                  <div
                    key={item.id}
                    className={`flex items-start justify-between gap-4 px-6 py-5 ${item.isRead ? "bg-white" : "bg-blue-50/60"}`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <Bell size={16} className="text-blue-600" />
                        <div className="font-semibold text-slate-900">{item.title}</div>
                      </div>
                      <div className="mt-1 text-sm text-slate-600">{item.message || "-"}</div>
                      <div className="mt-2 text-xs text-slate-500">{formatDate(item.createdAt)}</div>
                    </div>
                    <div className="flex shrink-0 items-center gap-3">
                      <span
                        className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${item.isRead ? "bg-slate-100 text-slate-600" : "bg-blue-100 text-blue-700"}`}
                      >
                        {item.isRead ? "Lu" : "Non lu"}
                      </span>
                      {!item.isRead ? (
                        <button
                          type="button"
                          onClick={() => handleRead(item.id)}
                          className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                        >
                          <Check size={14} />
                          Marquer lu
                        </button>
                      ) : null}
                    </div>
                  </div>
                ))
              )}
            </div>
          ) : null}
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="text-sm font-extrabold text-slate-900">Préférences personnelles</div>
          <div className="mt-1 text-sm text-slate-500">
            Active ou désactive tes canaux de notification comptable.
          </div>
          <div className="mt-5 space-y-3 text-sm">
            <label className="flex items-center justify-between rounded-2xl border border-slate-200 px-4 py-3">
              <div>
                <div className="font-semibold text-slate-900">Notifications internes</div>
                <div className="text-slate-500">Alertes dans la plateforme.</div>
              </div>
              <input
                type="checkbox"
                checked={!!prefs.notificationInAppEnabled}
                disabled={savingPrefs}
                onChange={(e) => {
                  const v = e.target.checked;
                  setPrefs((s) => ({ ...s, notificationInAppEnabled: v }));
                  savePrefs({ notificationInAppEnabled: v });
                }}
              />
            </label>

            <label className="flex items-center justify-between rounded-2xl border border-slate-200 px-4 py-3">
              <div>
                <div className="font-semibold text-slate-900">Emails</div>
                <div className="text-slate-500">Copies des alertes importantes.</div>
              </div>
              <div className="flex items-center gap-2">
                <Mail size={16} className="text-blue-600" />
                <input
                  type="checkbox"
                  checked={!!prefs.notificationEmailEnabled}
                  disabled={savingPrefs}
                  onChange={(e) => {
                    const v = e.target.checked;
                    setPrefs((s) => ({ ...s, notificationEmailEnabled: v }));
                    savePrefs({ notificationEmailEnabled: v });
                  }}
                />
              </div>
            </label>

            <label className="flex items-center justify-between rounded-2xl border border-slate-200 px-4 py-3">
              <div>
                <div className="font-semibold text-slate-900">SMS</div>
                <div className="text-slate-500">Préparé pour les urgences critiques.</div>
              </div>
              <input
                type="checkbox"
                checked={!!prefs.notificationSmsEnabled}
                disabled={savingPrefs}
                onChange={(e) => {
                  const v = e.target.checked;
                  setPrefs((s) => ({ ...s, notificationSmsEnabled: v }));
                  savePrefs({ notificationSmsEnabled: v });
                }}
              />
            </label>
          </div>
        </section>
      </div>
    </div>
  );
}
