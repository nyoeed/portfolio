import { Plus, PackagePlus, Pencil, Trash2, UtensilsCrossed, MonitorSpeaker, Shield, Truck, LayoutGrid } from "lucide-react";

import StatPill from "../components/stats/StatPill";
import CategoryTabs from "../components/tabs/CategoryTabs";
import ServiceCard from "../components/cards/ServiceCard";

import ServiceModal from "../modals/ServiceModal";
import BundleModal from "../../bundles/modals/BundleModal";
import ConfirmDeleteModal from "../../../../shared/ui/ConfirmDeleteModal";

import { useAdminServicesPage } from "../hooks/useAdminServicesPage";
import { badgeClass, badgeLabel, fmtPrice } from "../utils/format";

export default function AdminServicesPage() {
  const s = useAdminServicesPage();

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="text-xs font-bold text-slate-500">Administration</div>
          <h1 className="mt-1 text-2xl font-extrabold text-slate-900">Services</h1>
          <p className="mt-1 text-sm font-semibold text-slate-500">
            Gérez le catalogue de services pour les événements
          </p>
        </div>

        <button
          onClick={s.openCreate}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-blue-700"
          type="button"
        >
          <Plus size={18} />
          Ajouter un service
        </button>
      </div>

      {s.error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
          {s.error}
        </div>
      ) : null}

      {/* Stats */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <StatPill label="Total Services" value={s.loading ? "…" : s.stats.total} />
        <StatPill icon={UtensilsCrossed} label="Traiteur" value={s.loading ? "…" : s.counts["Traiteur"]} />
        <StatPill icon={MonitorSpeaker} label="Audiovisuel" value={s.loading ? "…" : s.counts["Audiovisuel"]} />
        <StatPill icon={Shield} label="Sécurité" value={s.loading ? "…" : s.counts["Sécurité"]} />
        <StatPill icon={Truck} label="Logistique" value={s.loading ? "…" : s.counts["Logistique"]} />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <StatPill icon={LayoutGrid} label="Autres" value={s.loading ? "…" : s.counts["Autres"]} />
      </div>

      {/* Tabs */}
      <CategoryTabs active={s.activeCategory} onChange={s.setActiveCategory} counts={s.counts} />

      {/* Services grid */}
      {s.loading ? (
        <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">
          Chargement…
        </div>
      ) : s.services.length === 0 ? (
        <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">
          Aucun service dans cette catégorie.
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {s.services.map((row) => (
            <ServiceCard
              key={row.id}
              s={row}
              onEdit={() => s.openEdit(row)}
              onDelete={() => s.askDelete(row)}
            />
          ))}
        </div>
      )}

      {/* FORFAITS */}
      <div className="rounded-2xl border bg-white p-5 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="text-base font-extrabold text-slate-900">Forfaits personnalisés</div>
          <button
            onClick={() => {
              s.setBundleMode("create");
              s.setBundleToEdit(null);
              s.setBundleOpen(true);
            }}
            className="inline-flex items-center gap-2 text-sm font-extrabold text-blue-700 hover:underline"
            type="button"
          >
            <PackagePlus size={18} />
            Créer un forfait
          </button>
        </div>

        {s.bundles.length === 0 ? (
          <div className="mt-4 text-sm font-semibold text-slate-500">Aucun forfait pour le moment.</div>
        ) : (
          <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
            {s.bundles.map((b) => (
              <div key={b.id} className="rounded-2xl border bg-white p-4 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-extrabold text-slate-900">{b.name}</div>
                    <div className="mt-1 text-xs font-semibold text-slate-500">
                      {(b.services || []).map((x) => x.name).join(" + ") || b.description || "—"}
                    </div>
                  </div>

                  <span className={`rounded-full px-3 py-1 text-xs font-extrabold ${badgeClass(b.availability)}`}>
                    {badgeLabel(b.availability)}
                  </span>
                </div>

                <div className="mt-3 text-lg font-extrabold text-blue-700">
                  {fmtPrice(b.price)}€ <span className="text-xs font-bold text-slate-500">/ {b.unitLabel}</span>
                </div>

                <div className="mt-3 flex justify-end gap-2">
                  <button
                    className="rounded-lg p-2 text-blue-700 hover:bg-blue-50"
                    title="Modifier"
                    type="button"
                    onClick={() => {
                      s.setBundleMode("edit");
                      s.setBundleToEdit(b);
                      s.setBundleOpen(true);
                    }}
                  >
                    <Pencil size={16} />
                  </button>
                  <button
                    className="rounded-lg p-2 text-red-600 hover:bg-red-50"
                    title="Supprimer"
                    type="button"
                    onClick={() => {
                      s.setBundleToDelete(b);
                      s.setBundleDelOpen(true);
                    }}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modals services */}
      <ServiceModal
        open={s.modalOpen}
        mode={s.modalMode}
        initial={s.serviceToEdit}
        onClose={() => s.setModalOpen(false)}
        onSaved={async () => {
          await s.loadStats();
          await s.loadServices(s.activeCategory);
        }}
      />

      <ConfirmDeleteModal
        open={s.delOpen}
        title="Supprimer le service"
        message={s.serviceToDelete ? `Voulez-vous vraiment supprimer "${s.serviceToDelete.name}" ?` : "Supprimer ce service ?"}
        loading={s.deleting}
        onCancel={() => {
          s.setDelOpen(false);
          s.setServiceToDelete(null);
        }}
        onConfirm={s.confirmDeleteService}
      />

      {/* Modals forfaits */}
      <BundleModal
        open={s.bundleOpen}
        mode={s.bundleMode}
        initial={s.bundleToEdit}
        services={s.services}
        onClose={() => s.setBundleOpen(false)}
        onSaved={async () => {
          await s.loadBundles();
        }}
      />

      <ConfirmDeleteModal
        open={s.bundleDelOpen}
        title="Supprimer le forfait"
        message={s.bundleToDelete ? `Voulez-vous vraiment supprimer "${s.bundleToDelete.name}" ?` : "Supprimer ce forfait ?"}
        loading={s.bundleDeleting}
        onCancel={() => {
          s.setBundleDelOpen(false);
          s.setBundleToDelete(null);
        }}
        onConfirm={s.confirmDeleteBundle}
      />
    </div>
  );
}