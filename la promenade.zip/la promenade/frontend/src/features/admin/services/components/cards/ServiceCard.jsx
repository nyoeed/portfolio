import { Pencil, Trash2 } from "lucide-react";
import { catIcon, catHeaderClass } from "../../utils/categoryUi";
import { badgeClass, badgeLabel, fmtPrice, unitShort, toAbsoluteUrl } from "../../utils/format";

export default function ServiceCard({ s, onEdit, onDelete }) {
  const Icon = catIcon(s.category);

  return (
    <div className="overflow-hidden rounded-2xl border bg-white shadow-sm">
      <div className={`relative px-4 py-3 ${catHeaderClass(s.category)} border-b`}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="rounded-xl bg-white/70 p-2">
              <Icon size={18} className="text-slate-700" />
            </div>
            <div>
              <div className="text-sm font-extrabold text-slate-900">{s.name}</div>
              <div className="mt-0.5 inline-flex rounded-full bg-white/70 px-2 py-0.5 text-[11px] font-bold text-slate-700">
                {s.category}
              </div>
            </div>
          </div>

          <span className={`rounded-full px-3 py-1 text-xs font-extrabold ${badgeClass(s.availability)}`}>
            {badgeLabel(s.availability)}
          </span>
        </div>

        {s.imageUrl ? (
          <div className="mt-3 overflow-hidden rounded-xl border bg-white">
            <img
              src={toAbsoluteUrl(s.imageUrl)}
              alt={s.name}
              className="h-28 w-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = "none";
              }}
            />
          </div>
        ) : null}
      </div>

      <div className="px-4 py-4">
        <div className="min-h-[44px] text-sm font-semibold text-slate-600">
          {s.description || <span className="text-slate-400">—</span>}
        </div>

        <div className="mt-3 border-t pt-3">
          <div className="flex items-end justify-between">
            <div className="text-xs font-bold text-slate-500">Tarif</div>
            <div className="text-right">
              <div className="text-lg font-extrabold text-slate-900">
                {fmtPrice(s.price)}€{" "}
                <span className="text-xs font-bold text-slate-500">/ {unitShort(s.unitLabel)}</span>
              </div>
            </div>
          </div>

          <div className="mt-3 flex justify-end gap-2">
            <button onClick={onEdit} className="rounded-lg p-2 text-blue-700 hover:bg-blue-50" title="Modifier" type="button">
              <Pencil size={16} />
            </button>
            <button onClick={onDelete} className="rounded-lg p-2 text-red-600 hover:bg-red-50" title="Supprimer" type="button">
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}