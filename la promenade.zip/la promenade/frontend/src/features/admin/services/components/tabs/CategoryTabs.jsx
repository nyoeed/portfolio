import { CATEGORIES } from "../../utils/constants";
import { catIcon } from "../../utils/categoryUi";

export default function CategoryTabs({ active, onChange, counts }) {
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-2xl border bg-white p-3 shadow-sm">
      <button
        onClick={() => onChange("")}
        className={[
          "rounded-xl px-4 py-2 text-sm font-extrabold",
          active === ""
            ? "bg-blue-600 text-white"
            : "bg-slate-50 text-slate-700 hover:bg-slate-100",
        ].join(" ")}
        type="button"
      >
        Tous
      </button>

      {CATEGORIES.map((c) => {
        const Icon = catIcon(c);
        return (
          <button
            key={c}
            onClick={() => onChange(c)}
            className={[
              "inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-extrabold",
              active === c
                ? "bg-blue-600 text-white"
                : "bg-slate-50 text-slate-700 hover:bg-slate-100",
            ].join(" ")}
            type="button"
          >
            <Icon size={16} />
            {c}
            <span className={active === c ? "text-white/90" : "text-slate-500"}>
              {counts[c] ?? 0}
            </span>
          </button>
        );
      })}
    </div>
  );
}