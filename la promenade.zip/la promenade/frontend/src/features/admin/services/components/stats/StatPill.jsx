export default function StatPill({ icon: Icon, label, value }) {
  return (
    <div className="rounded-2xl border bg-white px-5 py-4 shadow-sm">
      <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
        {Icon ? <Icon size={16} className="text-slate-500" /> : null}
        <span>{label}</span>
      </div>
      <div className="mt-2 text-2xl font-extrabold text-slate-900">{value}</div>
    </div>
  );
}