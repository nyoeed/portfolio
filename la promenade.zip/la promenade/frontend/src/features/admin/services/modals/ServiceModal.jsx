import { useEffect, useState } from "react";
import { Image as ImageIcon } from "lucide-react";
import { CATEGORIES } from "../utils/constants";
import { createService, updateService } from "../api/services.api";

export default function ServiceModal({ open, mode, initial, onClose, onSaved }) {
  const isEdit = mode === "edit";

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [file, setFile] = useState(null);

  const [form, setForm] = useState({
    name: "",
    category: "Traiteur",
    description: "",
    unitLabel: "par personne",
    price: "",
    availability: "available",
  });

  useEffect(() => {
    if (!open) return;
    setError("");
    setLoading(false);
    setFile(null);

    setForm({
      name: initial?.name || "",
      category: initial?.category || "Traiteur",
      description: initial?.description || "",
      unitLabel: initial?.unitLabel || "par personne",
      price: initial?.price != null ? String(initial.price) : "",
      availability: initial?.availability || "available",
    });
  }, [open, initial]);

  if (!open) return null;

  async function submit(e) {
    e.preventDefault();
    setError("");

    const name = form.name.trim();
    const category = form.category;
    const unitLabel = form.unitLabel;
    const availability = form.availability;
    const price = Number(form.price);

    if (!name || !category || !unitLabel || !Number.isFinite(price) || price < 0) {
      setError("Veuillez remplir: nom, catégorie, unité et prix (>=0).");
      return;
    }

    const fd = new FormData();
    fd.append("name", name);
    fd.append("category", category);
    fd.append("description", form.description.trim());
    fd.append("unitLabel", unitLabel);
    fd.append("price", String(price));
    fd.append("availability", availability);
    if (file) fd.append("image", file);

    setLoading(true);
    try {
      const data = isEdit
        ? await updateService(initial.id, fd)
        : await createService(fd);

      onSaved?.(data);
      onClose?.();
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur lors de l’enregistrement.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <div className="text-lg font-extrabold text-slate-900">
            {isEdit ? "Modifier un service" : "Ajouter un service"}
          </div>
          <button
            onClick={onClose}
            className="rounded-lg px-2 py-1 text-sm font-semibold text-slate-600 hover:bg-slate-100"
            type="button"
          >
            Fermer
          </button>
        </div>

        <form onSubmit={submit} className="space-y-4 p-5">
          {error ? (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
              {error}
            </div>
          ) : null}

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="text-xs font-bold text-slate-600">Nom</label>
              <input
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.name}
                onChange={(e) => setForm((s) => ({ ...s, name: e.target.value }))}
                placeholder="Ex: Menu Prestige"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600">Catégorie</label>
              <select
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.category}
                onChange={(e) => setForm((s) => ({ ...s, category: e.target.value }))}
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600">Disponibilité</label>
              <select
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.availability}
                onChange={(e) => setForm((s) => ({ ...s, availability: e.target.value }))}
              >
                <option value="available">Disponible</option>
                <option value="unavailable">Indisponible</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600">Tarif</label>
              <input
                type="number"
                step="0.01"
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.price}
                onChange={(e) => setForm((s) => ({ ...s, price: e.target.value }))}
                placeholder="35"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600">Unité</label>
              <select
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.unitLabel}
                onChange={(e) => setForm((s) => ({ ...s, unitLabel: e.target.value }))}
              >
                <option value="par personne">par personne</option>
                <option value="par jour">par jour</option>
                <option value="par heure">par heure</option>
                <option value="forfait">forfait</option>
                <option value="par unité">par unité</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="text-xs font-bold text-slate-600">Description</label>
              <textarea
                rows={3}
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.description}
                onChange={(e) => setForm((s) => ({ ...s, description: e.target.value }))}
                placeholder="Ex: Menu gastronomique 4 plats..."
              />
            </div>

            <div className="sm:col-span-2">
              <label className="text-xs font-bold text-slate-600">Image (optionnel)</label>
              <div className="mt-1 flex items-center gap-3">
                <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border bg-white px-4 py-2 text-sm font-extrabold text-slate-700 hover:bg-slate-50">
                  <ImageIcon size={18} />
                  Choisir une image
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => setFile(e.target.files?.[0] || null)}
                  />
                </label>
                <div className="text-sm font-semibold text-slate-600">
                  {file ? file.name : "Aucun fichier"}
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
              disabled={loading}
            >
              Annuler
            </button>
            <button
              type="submit"
              className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-blue-700 disabled:opacity-60"
              disabled={loading}
            >
              {loading ? "Enregistrement..." : isEdit ? "Enregistrer" : "Créer"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}