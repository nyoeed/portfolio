import { api } from "../../../../lib/api";

export async function fetchServicesStats() {
  const { data } = await api.get("/api/admin/services/stats");
  return data || {};
}

export async function fetchServices(category = "") {
  const qs = category ? `?category=${encodeURIComponent(category)}` : "";
  const { data } = await api.get(`/api/admin/services${qs}`);
  return Array.isArray(data) ? data : [];
}

export async function createService(formData) {
  const { data } = await api.post("/api/admin/services", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function updateService(serviceId, formData) {
  const { data } = await api.patch(`/api/admin/services/${serviceId}`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function removeService(serviceId) {
  const { data } = await api.delete(`/api/admin/services/${serviceId}`);
  return data;
}