import { useEffect, useMemo, useState } from "react";
import { CATEGORIES } from "../utils/constants";
import { fetchServices, fetchServicesStats, removeService } from "../api/services.api";
import { fetchBundles, removeBundle } from "../../bundles/api/bundles.api";

export function useAdminServicesPage() {
  const [stats, setStats] = useState({ total: 0, byCategory: [] });
  const [services, setServices] = useState([]);
  const [bundles, setBundles] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [activeCategory, setActiveCategory] = useState("");

  // service modal
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState("create");
  const [serviceToEdit, setServiceToEdit] = useState(null);

  // delete service modal
  const [delOpen, setDelOpen] = useState(false);
  const [serviceToDelete, setServiceToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  // bundle modals
  const [bundleOpen, setBundleOpen] = useState(false);
  const [bundleMode, setBundleMode] = useState("create");
  const [bundleToEdit, setBundleToEdit] = useState(null);

  const [bundleDelOpen, setBundleDelOpen] = useState(false);
  const [bundleToDelete, setBundleToDelete] = useState(null);
  const [bundleDeleting, setBundleDeleting] = useState(false);

  const counts = useMemo(() => {
    const base = {};
    for (const c of CATEGORIES) base[c] = 0;
    for (const row of stats.byCategory || []) base[row.category] = Number(row.count || 0);
    return base;
  }, [stats]);

  async function loadStats() {
    const data = await fetchServicesStats();
    setStats({
      total: Number(data?.total || 0),
      byCategory: data?.byCategory || [],
    });
  }

  async function loadServices(category = activeCategory) {
    const list = await fetchServices(category);
    setServices(list);
  }

  async function loadBundles() {
    const list = await fetchBundles();
    setBundles(list);
  }

  async function refreshAll() {
    setLoading(true);
    setError("");
    try {
      await Promise.all([loadStats(), loadServices(), loadBundles()]);
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur chargement services.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refreshAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    loadServices(activeCategory).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeCategory]);

  function openCreate() {
    setModalMode("create");
    setServiceToEdit(null);
    setModalOpen(true);
  }

  function openEdit(s) {
    setModalMode("edit");
    setServiceToEdit(s);
    setModalOpen(true);
  }

  function askDelete(s) {
    setServiceToDelete(s);
    setDelOpen(true);
  }

  async function confirmDeleteService() {
    if (!serviceToDelete) return;
    setDeleting(true);
    try {
      await removeService(serviceToDelete.id);
      setServices((list) => list.filter((x) => x.id !== serviceToDelete.id));
      await loadStats();
      setDelOpen(false);
      setServiceToDelete(null);
    } catch (err) {
      alert(err?.response?.data?.message || "Erreur suppression service.");
    } finally {
      setDeleting(false);
    }
  }

  async function confirmDeleteBundle() {
    if (!bundleToDelete) return;
    setBundleDeleting(true);
    try {
      await removeBundle(bundleToDelete.id);
      setBundles((list) => list.filter((x) => x.id !== bundleToDelete.id));
      setBundleDelOpen(false);
      setBundleToDelete(null);
    } catch (err) {
      alert(err?.response?.data?.message || "Erreur suppression forfait.");
    } finally {
      setBundleDeleting(false);
    }
  }

  return {
    // data
    stats,
    services,
    bundles,
    counts,

    // ui
    loading,
    error,
    activeCategory,
    setActiveCategory,

    // actions
    refreshAll,
    loadStats,
    loadServices,
    loadBundles,

    // services modal
    modalOpen,
    setModalOpen,
    modalMode,
    serviceToEdit,
    openCreate,
    openEdit,

    // services delete
    delOpen,
    setDelOpen,
    serviceToDelete,
    setServiceToDelete,
    deleting,
    askDelete,
    confirmDeleteService,

    // bundles modals
    bundleOpen,
    setBundleOpen,
    bundleMode,
    setBundleMode,
    bundleToEdit,
    setBundleToEdit,

    // bundles delete
    bundleDelOpen,
    setBundleDelOpen,
    bundleToDelete,
    setBundleToDelete,
    bundleDeleting,
    confirmDeleteBundle,
  };
}