import { UtensilsCrossed, MonitorSpeaker, Shield, Truck, LayoutGrid } from "lucide-react";

export function catIcon(cat) {
  if (cat === "Traiteur") return UtensilsCrossed;
  if (cat === "Audiovisuel") return MonitorSpeaker;
  if (cat === "Sécurité") return Shield;
  if (cat === "Logistique") return Truck;
  return LayoutGrid;
}

export function catHeaderClass(cat) {
  if (cat === "Traiteur") return "bg-blue-50";
  if (cat === "Audiovisuel") return "bg-purple-50";
  if (cat === "Sécurité") return "bg-red-50";
  if (cat === "Logistique") return "bg-green-50";
  return "bg-orange-50";
}