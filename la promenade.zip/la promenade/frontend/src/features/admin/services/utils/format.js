const API_ORIGIN = import.meta.env.VITE_API_ORIGIN || "http://localhost:4000";

export function toAbsoluteUrl(url) {
  if (!url) return "";
  const base = url.startsWith("http") ? url : `${API_ORIGIN}${url}`;
  const sep = base.includes("?") ? "&" : "?";
  return `${base}${sep}v=${Date.now()}`;
}

export function fmtPrice(n) {
  const x = Number(n || 0);
  return x.toLocaleString("fr-FR", { maximumFractionDigits: 2 });
}

export function unitShort(unitLabel) {
  return unitLabel || "";
}

export function badgeClass(availability) {
  return availability === "available"
    ? "bg-green-100 text-green-700"
    : "bg-slate-100 text-slate-700";
}

export function badgeLabel(availability) {
  return availability === "available" ? "Disponible" : "Indisponible";
}