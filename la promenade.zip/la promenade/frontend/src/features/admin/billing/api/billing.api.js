import { api } from "@/lib/api.js";

export const billingApi = {
  summary: () => api.get("/api/admin/billing/summary").then((r) => r.data),

  invoices: (params) =>
    api.get("/api/admin/billing/invoices", { params }).then((r) => r.data),

  payments: (params) =>
    api.get("/api/admin/billing/payments", { params }).then((r) => r.data),

  refunds: (params) =>
    api.get("/api/admin/billing/refunds", { params }).then((r) => r.data),

  createRefund: (body) =>
    api.post("/api/admin/billing/refunds", body).then((r) => r.data),

  downloadPdf: (id) =>
    api
      .get(`/api/admin/billing/invoices/${id}/pdf`, { responseType: "blob" })
      .then((r) => r.data),
};