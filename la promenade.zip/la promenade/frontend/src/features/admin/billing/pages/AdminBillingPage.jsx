import { useEffect, useMemo, useState } from "react";
import BillingKpiRow from "../components/BillingKpiRow.jsx";
import BillingTabs from "../components/BillingTabs.jsx";
import BillingToolbar from "../components/BillingToolbar.jsx";
import InvoiceTable from "../components/InvoiceTable.jsx";
import PaymentsTable from "../components/PaymentsTable.jsx";
import RefundsTable from "../components/RefundsTable.jsx";
import RefundModal from "../components/RefundModal.jsx";
import { billingApi } from "../api/billing.api.js";

export default function AdminBillingPage() {
  const [tab, setTab] = useState("invoices"); // invoices | payments | refunds
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");

  const [refundOpen, setRefundOpen] = useState(false);

  // data
  const [summary, setSummary] = useState({
    totalPaid: 0,
    totalPending: 0,
    totalOverdue: 0,
    totalInvoicesThisMonth: 0,
  });

  const [invoices, setInvoices] = useState([]);
  const [payments, setPayments] = useState([]);
  const [refunds, setRefunds] = useState([]);

  // ui states
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // -----------------------
  // Loaders
  // -----------------------
  async function loadSummary() {
    const s = await billingApi.summary();
    // si jamais backend renvoie encore totalInvoices, on fallback
    setSummary({
      totalPaid: s.totalPaid ?? 0,
      totalPending: s.totalPending ?? 0,
      totalOverdue: s.totalOverdue ?? 0,
      totalInvoicesThisMonth: s.totalInvoicesThisMonth ?? s.totalInvoices ?? 0,
    });
  }

  async function loadInvoices() {
    const rows = await billingApi.invoices({ q, status });
    setInvoices(rows);
  }

  async function loadPayments() {
    const rows = await billingApi.payments({ q });
    setPayments(rows);
  }

  async function loadRefunds() {
    const rows = await billingApi.refunds({ q });
    setRefunds(rows);
  }

  async function loadAll() {
    await Promise.all([loadSummary(), loadInvoices(), loadPayments(), loadRefunds()]);
  }

  // -----------------------
  // Initial load
  // -----------------------
  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        setError("");
        setLoading(true);
        await loadAll();
      } catch (e) {
        if (!alive) return;
        setError(getErrMsg(e));
      } finally {
        if (!alive) return;
        setLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // -----------------------
  // Reload on filters / tab
  // -----------------------
  useEffect(() => {
    const t = setTimeout(() => {
      let alive = true;

      (async () => {
        try {
          setError("");
          setLoading(true);

          // reload only current tab data
          if (tab === "invoices") await loadInvoices();
          else if (tab === "payments") await loadPayments();
          else await loadRefunds();

          // refresh summary too (so KPI stays accurate)
          await loadSummary();
        } catch (e) {
          if (!alive) return;
          setError(getErrMsg(e));
        } finally {
          if (!alive) return;
          setLoading(false);
        }
      })();

      return () => {
        alive = false;
      };
    }, 350);

    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, status, tab]);

  // -----------------------
  // Actions
  // -----------------------
  function handleView(invoice) {
    alert(`Voir facture: ${invoice.number}`);
  }

  async function handleDownload(invoice) {
    try {
      setError("");
      const blob = await billingApi.downloadPdf(invoice.id);

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${invoice.number}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (e) {
      setError(getErrMsg(e));
    }
  }

  async function addRefund(payload) {
    try {
      setError("");
      setLoading(true);

      await billingApi.createRefund({
        invoiceNumber: payload.invoiceNumber,
        clientName: payload.clientName,
        amount: payload.amount,
        date: payload.date,
        reason: payload.reason,
        status: payload.status,
      });

      setRefundOpen(false);

      // refresh refunds + summary
      await Promise.all([loadRefunds(), loadSummary()]);
      setTab("refunds");
    } catch (e) {
      setError(getErrMsg(e));
    } finally {
      setLoading(false);
    }
  }

  // -----------------------
  // Table per tab
  // -----------------------
  const table = useMemo(() => {
    if (tab === "invoices") {
      return <InvoiceTable rows={invoices} onView={handleView} onDownload={handleDownload} />;
    }
    if (tab === "payments") {
      return <PaymentsTable rows={payments} />;
    }
    return <RefundsTable rows={refunds} />;
  }, [tab, invoices, payments, refunds]);

  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-slate-500">Administration</div>
          <div className="mt-1 text-2xl font-extrabold text-slate-900">Facturation & Paiements</div>
          <div className="mt-1 text-sm text-slate-600">
            Gérez toutes les factures, paiements et remboursements
          </div>
        </div>

        {loading ? <div className="text-sm text-slate-500">Chargement…</div> : null}
      </div>

      {/* Error banner */}
      {error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      ) : null}

      {/* KPI (✅ plus de hack) */}
      <BillingKpiRow summary={summary} />

      {/* Tabs */}
      <BillingTabs active={tab} onChange={setTab} />

      {/* Toolbar */}
      <BillingToolbar
        q={q}
        setQ={setQ}
        status={status}
        setStatus={setStatus}
        showStatusFilter={tab === "invoices"}
        right={
          tab === "refunds" ? (
            <button
              onClick={() => setRefundOpen(true)}
              className="px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700"
            >
              Nouveau remboursement
            </button>
          ) : null
        }
      />

      {/* Tables */}
      {table}

      {/* Modal */}
      <RefundModal open={refundOpen} onClose={() => setRefundOpen(false)} onSubmit={addRefund} />
    </div>
  );
}

function getErrMsg(e) {
  return e?.response?.data?.message || e?.message || "Erreur inconnue";
}