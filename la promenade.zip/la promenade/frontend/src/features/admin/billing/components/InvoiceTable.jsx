import { Eye, Download } from "lucide-react";
import Money from "./Money.jsx";
import StatusPill from "./StatusPill.jsx";

const statusLabel = {
  paid: "Payée",
  pending: "En attente",
  overdue: "En retard",
};

export default function InvoiceTable({ rows, onView, onDownload }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-100">
        <div className="text-sm font-bold text-slate-900">Liste des factures</div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-[900px] w-full text-sm">
          <thead className="bg-slate-50 text-slate-600">
            <tr>
              <th className="text-left px-4 py-3 font-semibold">N° FACTURE</th>
              <th className="text-left px-4 py-3 font-semibold">ÉVÉNEMENT</th>
              <th className="text-left px-4 py-3 font-semibold">CLIENT</th>
              <th className="text-left px-4 py-3 font-semibold">DATE</th>
              <th className="text-left px-4 py-3 font-semibold">ÉCHÉANCE</th>
              <th className="text-right px-4 py-3 font-semibold">MONTANT</th>
              <th className="text-left px-4 py-3 font-semibold">STATUT</th>
              <th className="text-right px-4 py-3 font-semibold">ACTIONS</th>
            </tr>
          </thead>

          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-slate-100 hover:bg-slate-50">
                <td className="px-4 py-3 font-semibold text-slate-900">{r.number}</td>
                <td className="px-4 py-3 text-slate-800">{r.eventName}</td>
                <td className="px-4 py-3 text-slate-800">{r.clientName}</td>
                <td className="px-4 py-3 text-slate-600">{fmtDate(r.date)}</td>
                <td className="px-4 py-3 text-slate-600">{fmtDate(r.dueDate)}</td>
                <td className="px-4 py-3 text-right">
                  <Money value={r.amount} />
                </td>
                <td className="px-4 py-3">
                  <StatusPill kind={r.status} label={statusLabel[r.status] || r.status} />
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => onView?.(r)}
                      className="inline-flex items-center justify-center w-9 h-9 rounded-xl border border-slate-200 hover:bg-slate-50"
                      title="Voir"
                    >
                      <Eye size={16} />
                    </button>
                    <button
                      onClick={() => onDownload?.(r)}
                      className="inline-flex items-center justify-center w-9 h-9 rounded-xl border border-slate-200 hover:bg-slate-50"
                      title="Télécharger PDF"
                    >
                      <Download size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}

            {rows.length === 0 && (
              <tr>
                <td className="px-4 py-10 text-center text-slate-500" colSpan={8}>
                  Aucune facture trouvée.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function fmtDate(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "short", year: "numeric" }).format(d);
}