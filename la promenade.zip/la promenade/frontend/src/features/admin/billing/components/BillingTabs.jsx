export default function BillingTabs({ active, onChange }) {
  const Tab = ({ id, children }) => {
    const isActive = active === id;
    return (
      <button
        onClick={() => onChange(id)}
        className={[
          "px-3 py-1.5 text-sm font-semibold rounded-lg border",
          isActive
            ? "bg-blue-600 text-white border-blue-600"
            : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50",
        ].join(" ")}
      >
        {children}
      </button>
    );
  };

  return (
    <div className="flex items-center gap-2">
      <Tab id="invoices">Factures</Tab>
      <Tab id="payments">Paiements reçus</Tab>
      <Tab id="refunds">Remboursements</Tab>
    </div>
  );
}