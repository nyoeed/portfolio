const pillBase =
  "inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold border";

const map = {
  paid: "bg-green-50 text-green-700 border-green-200",
  pending: "bg-amber-50 text-amber-700 border-amber-200",
  overdue: "bg-red-50 text-red-700 border-red-200",
  processed: "bg-green-50 text-green-700 border-green-200",
  method: "bg-blue-50 text-blue-700 border-blue-200",
};

export default function StatusPill({ kind, label }) {
  const cls = map[kind] || "bg-slate-50 text-slate-700 border-slate-200";
  return <span className={`${pillBase} ${cls}`}>{label}</span>;
}