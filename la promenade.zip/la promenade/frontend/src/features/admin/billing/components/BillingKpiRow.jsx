import Money from "./Money.jsx";

function Card({ title, value, sub }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="text-xs font-semibold text-slate-500">{title}</div>
      <div className="mt-2 text-2xl font-bold text-slate-900">{value}</div>
      {sub ? <div className="mt-1 text-xs text-slate-500">{sub}</div> : null}
    </div>
  );
}

/**
 * ✅ Utilisation:
 * <BillingKpiRow invoices={invoices} />
 * ou
 * <BillingKpiRow summary={summary} />
 */
export default function BillingKpiRow({ invoices, summary }) {
  // ---- Mode 1: summary (backend)
  if (summary) {
    return (
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Card title="Revenus totaux" value={<Money value={summary.totalPaid} />} sub="Factures payées" />
        <Card title="En attente" value={<Money value={summary.totalPending} />} sub="Factures en attente" />
        <Card title="En retard" value={<Money value={summary.totalOverdue} />} sub="Factures en retard" />
        <Card
          title="Total factures"
          value={String(summary.totalInvoicesThisMonth ?? 0)}
          sub="Ce mois"
        />
      </div>
    );
  }

  // ---- Mode 2: invoices (frontend calc)
  const paid = (invoices || []).filter((x) => x.status === "paid");
  const pending = (invoices || []).filter((x) => x.status === "pending");
  const overdue = (invoices || []).filter((x) => x.status === "overdue");

  const sum = (arr) => arr.reduce((acc, x) => acc + Number(x.amount || 0), 0);

  const totalPaid = sum(paid);
  const totalPending = sum(pending);
  const totalOverdue = sum(overdue);

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
      <Card title="Revenus totaux" value={<Money value={totalPaid} />} sub="Factures payées" />
      <Card title="En attente" value={<Money value={totalPending} />} sub={`${pending.length} facture(s)`} />
      <Card title="En retard" value={<Money value={totalOverdue} />} sub={`${overdue.length} facture(s)`} />
      <Card title="Total factures" value={String((invoices || []).length)} sub="Ce mois" />
    </div>
  );
}