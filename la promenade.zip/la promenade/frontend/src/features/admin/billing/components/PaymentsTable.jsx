import Money from "./Money.jsx";
import StatusPill from "./StatusPill.jsx";

export default function PaymentsTable({ rows }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-100">
        <div className="text-sm font-bold text-slate-900">Paiements reçus</div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-[820px] w-full text-sm">
          <thead className="bg-slate-50 text-slate-600">
            <tr>
              <th className="text-left px-4 py-3 font-semibold">N° FACTURE</th>
              <th className="text-left px-4 py-3 font-semibold">CLIENT</th>
              <th className="text-right px-4 py-3 font-semibold">MONTANT</th>
              <th className="text-left px-4 py-3 font-semibold">DATE DE PAIEMENT</th>
              <th className="text-left px-4 py-3 font-semibold">MÉTHODE</th>
            </tr>
          </thead>

          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-slate-100 hover:bg-slate-50">
                <td className="px-4 py-3 font-semibold text-slate-900">{r.invoiceNumber}</td>
                <td className="px-4 py-3 text-slate-800">{r.clientName}</td>
                <td className="px-4 py-3 text-right">
                  <Money value={r.amount} />
                </td>
                <td className="px-4 py-3 text-slate-600">{fmtDate(r.paidAt)}</td>
                <td className="px-4 py-3">
                  <StatusPill kind="method" label={r.method} />
                </td>
              </tr>
            ))}

            {rows.length === 0 && (
              <tr>
                <td className="px-4 py-10 text-center text-slate-500" colSpan={5}>
                  Aucun paiement trouvé.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function fmtDate(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "short", year: "numeric" }).format(d);
}