import { X } from "lucide-react";
import Money from "./Money.jsx";

export default function RefundModal({ open, onClose, onSubmit }) {
  if (!open) return null;

  function submit(e) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      invoiceNumber: fd.get("invoiceNumber")?.toString().trim(),
      clientName: fd.get("clientName")?.toString().trim(),
      amount: -Math.abs(Number(fd.get("amount") || 0)),
      date: fd.get("date")?.toString(),
      reason: fd.get("reason")?.toString().trim(),
      status: "processed",
    };
    onSubmit?.(payload);
  }

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
            <div>
              <div className="text-lg font-bold text-slate-900">Nouveau remboursement</div>
              <div className="text-xs text-slate-500">Créer un remboursement lié à une facture.</div>
            </div>
            <button onClick={onClose} className="w-9 h-9 rounded-xl border border-slate-200 hover:bg-slate-50">
              <X size={16} />
            </button>
          </div>

          <form onSubmit={submit} className="p-5 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Field label="N° facture" name="invoiceNumber" placeholder="INV-2026-001" required />
              <Field label="Client" name="clientName" placeholder="Nom du client" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Field label="Montant" name="amount" type="number" placeholder="2500" required />
              <Field label="Date" name="date" type="date" required />
            </div>

            <div>
              <label className="text-sm font-semibold text-slate-700">Raison</label>
              <input
                name="reason"
                placeholder="Ex: Annulation événement"
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200"
                required
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="text-xs text-slate-500">
                Note: le montant sera enregistré en négatif (ex: <Money value={-2500} />).
              </div>
              <button className="px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700">
                Créer
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

function Field({ label, name, type = "text", placeholder, required }) {
  return (
    <div>
      <label className="text-sm font-semibold text-slate-700">{label}</label>
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200"
      />
    </div>
  );
}