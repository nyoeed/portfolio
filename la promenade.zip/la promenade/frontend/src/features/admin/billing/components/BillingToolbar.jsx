export default function BillingToolbar({ q, setQ, status, setStatus, showStatusFilter = true, right }) {
  return (
    <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
      <div className="flex flex-col gap-2 md:flex-row md:items-center">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Rechercher (N° facture, client, événement)..."
          className="w-full md:w-[360px] rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200"
        />

        {showStatusFilter && (
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="w-full md:w-[200px] rounded-xl border border-slate-200 px-3 py-2 text-sm bg-white outline-none focus:ring-2 focus:ring-blue-200"
          >
            <option value="">Tous statuts</option>
            <option value="paid">Payée</option>
            <option value="pending">En attente</option>
            <option value="overdue">En retard</option>
          </select>
        )}
      </div>

      <div className="flex items-center justify-end">{right}</div>
    </div>
  );
}