export default function Money({ value, currency = "€" }) {
  const n = Number(value || 0);

  const formatted = new Intl.NumberFormat("fr-FR", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(Math.abs(n));

  const sign = n < 0 ? "-" : "";
  return (
    <span className={n < 0 ? "text-red-600 font-semibold" : "text-slate-900 font-semibold"}>
      {sign}{formatted} {currency}
    </span>
  );
}