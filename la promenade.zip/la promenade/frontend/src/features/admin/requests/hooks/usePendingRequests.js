import { useEffect, useMemo, useState } from "react";
import {
  approvePendingRequest,
  fetchPendingRequests,
  rejectPendingRequest,
} from "../api/requests.api";

export function usePendingRequests() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState(null);

  async function load() {
    setLoading(true);
    try {
      const data = await fetchPendingRequests();
      setRows(Array.isArray(data) ? data : []);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const pendingCount = useMemo(() => rows.length, [rows]);

  async function onApprove(id) {
    setBusyId(id);
    try {
      await approvePendingRequest(id);
      await load();
    } finally {
      setBusyId(null);
    }
  }

  async function onReject(id) {
    setBusyId(id);
    try {
      await rejectPendingRequest(id);
      await load();
    } finally {
      setBusyId(null);
    }
  }

  return {
    rows,
    loading,
    busyId,
    pendingCount,
    load,
    onApprove,
    onReject,
  };
}