function roleLabel(role) {
  if (role === "organizer") return "Organisateur";
  if (role === "coordinator") return "Coordonnateur";
  if (role === "accounting") return "Comptabilité";
  return role || "-";
}

export default function RolePill({ role }) {
  return (
    <span className="inline-flex items-center rounded-full bg-blue-100 px-3 py-1 text-xs font-semibold text-blue-700">
      {roleLabel(role)}
    </span>
  );
}