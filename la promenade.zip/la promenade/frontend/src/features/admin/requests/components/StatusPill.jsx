export default function StatusPill({ status }) {
  const label = status === "pending" ? "En attente" : status;
  return (
    <span className="inline-flex items-center rounded-full bg-yellow-100 px-3 py-1 text-xs font-semibold text-yellow-700">
      {label}
    </span>
  );
}