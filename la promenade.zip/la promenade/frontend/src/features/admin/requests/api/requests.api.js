import {
  approveRequest,
  getPendingRequests,
  rejectRequest,
} from "../../api/adminApi";

export async function fetchPendingRequests() {
  return getPendingRequests();
}

export async function approvePendingRequest(id) {
  return approveRequest(id);
}

export async function rejectPendingRequest(id) {
  return rejectRequest(id);
}