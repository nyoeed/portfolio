import { Check, X, Mail, User2 } from "lucide-react";
import { usePendingRequests } from "../hooks/usePendingRequests";
import RolePill from "../components/RolePill";
import StatusPill from "../components/StatusPill";
import { formatDate } from "../../../../shared/utils/dates";

export default function AdminRequestsPage() {
  const r = usePendingRequests();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">
          Demandes en attente
        </h1>
        <p className="mt-1 text-sm text-slate-600">
          Gérez les demandes d&apos;inscription des nouveaux utilisateurs
        </p>
      </div>

      <div className="rounded-2xl border border-blue-200 bg-blue-50 p-5">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center">
            <User2 size={22} />
          </div>

          <div>
            <div className="text-sm font-semibold text-blue-700">
              Demandes à traiter
            </div>
            <div className="mt-1 text-2xl font-extrabold text-slate-900">
              {r.loading ? "…" : r.pendingCount}
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <div className="text-sm font-bold text-slate-900">
            Liste des demandes
          </div>
        </div>

        <div className="w-full overflow-x-auto">
          <table className="min-w-[900px] w-full">
            <thead className="bg-slate-50">
              <tr className="text-left text-xs font-bold text-slate-500">
                <th className="px-5 py-3">UTILISATEUR</th>
                <th className="px-5 py-3">EMAIL</th>
                <th className="px-5 py-3">RÔLE DEMANDÉ</th>
                <th className="px-5 py-3">DATE</th>
                <th className="px-5 py-3">STATUT</th>
                <th className="px-5 py-3 text-right">ACTIONS</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {r.loading ? (
                <tr>
                  <td className="px-5 py-6 text-sm text-slate-600" colSpan={6}>
                    Chargement…
                  </td>
                </tr>
              ) : r.rows.length === 0 ? (
                <tr>
                  <td className="px-5 py-6 text-sm text-slate-600" colSpan={6}>
                    Aucune demande en attente.
                  </td>
                </tr>
              ) : (
                r.rows.map((u) => (
                  <tr key={u.id} className="text-sm text-slate-800">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-600">
                          <User2 size={18} />
                        </div>
                        <div className="font-semibold">{u.fullName}</div>
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2 text-slate-700">
                        <Mail size={16} className="text-slate-400" />
                        <span>{u.email}</span>
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <RolePill role={u.roleRequested} />
                    </td>

                    <td className="px-5 py-4 text-slate-600">
                      {formatDate(u.createdAt)}
                    </td>

                    <td className="px-5 py-4">
                      <StatusPill status={u.status} />
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => r.onApprove(u.id)}
                          disabled={r.busyId === u.id}
                          className={[
                            "h-9 w-9 rounded-xl flex items-center justify-center",
                            "bg-green-100 text-green-700 hover:bg-green-200",
                            r.busyId === u.id ? "opacity-60 cursor-not-allowed" : "",
                          ].join(" ")}
                          title="Approuver"
                        >
                          <Check size={18} />
                        </button>

                        <button
                          onClick={() => r.onReject(u.id)}
                          disabled={r.busyId === u.id}
                          className={[
                            "h-9 w-9 rounded-xl flex items-center justify-center",
                            "bg-red-100 text-red-700 hover:bg-red-200",
                            r.busyId === u.id ? "opacity-60 cursor-not-allowed" : "",
                          ].join(" ")}
                          title="Rejeter"
                        >
                          <X size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}