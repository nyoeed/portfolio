import {
  Bell,
  AlertTriangle,
  CalendarDays,
  CreditCard,
  UserPlus,
  Settings as SettingsIcon,
  Mail,
  Check,
  Trash2,
  RefreshCw,
} from "lucide-react";

import { useNotifications } from "../hooks/useNotifications";
import { formatDateTimeFR } from "../../../../shared/utils/dates";

import StatCard from "../components/StatCard";
import PillTab from "../components/PillTab";
import TypeIcon from "../components/TypeIcon";
import UrgentBadge from "../components/UrgentBadge";
import SettingRow from "../components/SettingRow";
import ReminderCard from "../components/ReminderCard";
import ConfirmDeleteModal from "../modals/ConfirmDeleteModal";

export default function AdminNotificationsPage() {
  const n = useNotifications();

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-xs font-bold text-slate-500">Administration</div>
          <h1 className="mt-1 flex items-center gap-2 text-2xl font-extrabold text-slate-900">
            <Bell className="text-yellow-500" size={22} />
            Notifications
          </h1>
          <p className="mt-1 text-sm font-semibold text-slate-500">
            Gérez vos alertes et rappels système
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={n.onRefresh}
            className="rounded-xl border bg-white px-4 py-2 text-sm font-extrabold text-slate-700 hover:bg-slate-50 disabled:opacity-60"
            disabled={n.loadingList || n.loadingStats || n.loadingSettings}
            title="Rafraîchir"
          >
            <span className="inline-flex items-center gap-2">
              <RefreshCw size={16} />
              Rafraîchir
            </span>
          </button>

          <button
            type="button"
            onClick={n.onMarkAllRead}
            className="rounded-xl bg-white px-4 py-2 text-sm font-extrabold text-blue-700 hover:bg-blue-50 border disabled:opacity-60"
            disabled={n.busyAllRead || n.stats.unread === 0}
          >
            <span className="inline-flex items-center gap-2">
              <Check size={16} />
              Tout marquer comme lu
            </span>
          </button>
        </div>
      </div>

      {/* Error */}
      {n.error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
          {n.error}
        </div>
      ) : null}

      {/* Stats cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={Bell}
          label="Total"
          value={n.loadingStats ? "…" : n.stats.total}
          iconBg="bg-blue-50"
          iconColor="text-blue-600"
        />
        <StatCard
          icon={Bell}
          label="Non lues"
          value={n.loadingStats ? "…" : n.stats.unread}
          iconBg="bg-yellow-50"
          iconColor="text-yellow-600"
        />
        <StatCard
          icon={AlertTriangle}
          label="Priorité haute"
          value={n.loadingStats ? "…" : n.stats.highPriority}
          iconBg="bg-red-50"
          iconColor="text-red-600"
        />
        <StatCard
          icon={Mail}
          label="Email activé"
          value={n.loadingStats ? "…" : n.stats.emailEnabled}
          iconBg="bg-green-50"
          iconColor="text-green-600"
        />
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2">
        <PillTab active={n.tab === "all"} onClick={() => n.setTab("all")}>
          {n.tabLabels.all}
        </PillTab>
        <PillTab active={n.tab === "unread"} onClick={() => n.setTab("unread")}>
          {n.tabLabels.unread}
        </PillTab>
      </div>

      {/* List */}
      <div className="rounded-2xl border bg-white shadow-sm overflow-hidden">
        <div className="border-b px-5 py-4">
          <div className="text-sm font-extrabold text-slate-900">
            Alertes système
          </div>
        </div>

        {n.loadingList ? (
          <div className="p-6 text-sm font-semibold text-slate-600">
            Chargement…
          </div>
        ) : n.rows.length === 0 ? (
          <div className="p-6 text-sm font-semibold text-slate-600">
            {n.tab === "unread"
              ? "Aucune notification non lue."
              : "Aucune notification."}
          </div>
        ) : (
          <div className="divide-y">
            {n.rows.map((row) => {
              const isUrgent = row.priority === "urgent";
              const isRead = !!row.isRead;
              const rowBg = isRead ? "bg-white" : "bg-blue-50";

              return (
                <div
                  key={row.id}
                  className={`flex items-center gap-4 px-5 py-4 ${rowBg}`}
                >
                  <TypeIcon type={row.type} />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start gap-2">
                      <div className="min-w-0">
                        <div className="truncate text-sm font-extrabold text-slate-900">
                          {row.title}
                        </div>
                        <div className="mt-1 line-clamp-2 text-sm font-semibold text-slate-600">
                          {row.message}
                        </div>
                        <div className="mt-2 text-xs font-semibold text-slate-400">
                          {formatDateTimeFR(row.createdAt)}
                        </div>
                      </div>

                      <div className="ml-auto flex items-center gap-2">
                        {isUrgent ? <UrgentBadge /> : null}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {!isRead ? (
                      <button
                        type="button"
                        title="Marquer comme lu"
                        className="rounded-lg p-2 text-blue-700 hover:bg-blue-100 disabled:opacity-60"
                        onClick={() => n.onMarkRead(row.id)}
                        disabled={n.busyId === row.id}
                      >
                        <Check size={18} />
                      </button>
                    ) : (
                      <span className="text-xs font-bold text-slate-400">Lu</span>
                    )}

                    <button
                      type="button"
                      title="Supprimer"
                      className="rounded-lg p-2 text-red-600 hover:bg-red-50 disabled:opacity-60"
                      onClick={() => n.askDelete(row)}
                      disabled={n.busyId === row.id}
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Settings */}
      <div className="rounded-2xl border bg-white shadow-sm overflow-hidden">
        <div className="border-b px-5 py-4">
          <div className="flex items-center gap-2">
            <SettingsIcon size={16} className="text-slate-700" />
            <div className="text-sm font-extrabold text-slate-900">
              Paramètres Email
            </div>
          </div>
          <div className="mt-1 text-xs font-semibold text-slate-500">
            Choisissez les notifications que vous souhaitez recevoir par email
          </div>
        </div>

        <div className="p-5 space-y-3">
          {n.loadingSettings ? (
            <div className="text-sm font-semibold text-slate-600">
              Chargement…
            </div>
          ) : (
            <>
              <SettingRow
                icon={CalendarDays}
                title="Nouveaux événements"
                subtitle="Notifications pour chaque nouvel événement créé"
                checked={!!n.settings.notifEvents}
                disabled={n.savingSettingKey === "notifEvents"}
                onToggle={(v) => n.toggleSetting("notifEvents", v)}
              />
              <SettingRow
                icon={CreditCard}
                title="Paiements"
                subtitle="Alertes pour les paiements reçus et en retard"
                checked={!!n.settings.notifPayments}
                disabled={n.savingSettingKey === "notifPayments"}
                onToggle={(v) => n.toggleSetting("notifPayments", v)}
              />
              <SettingRow
                icon={UserPlus}
                title="Demandes d'inscription"
                subtitle="Notifications pour les nouvelles demandes utilisateurs"
                checked={!!n.settings.notifSignup}
                disabled={n.savingSettingKey === "notifSignup"}
                onToggle={(v) => n.toggleSetting("notifSignup", v)}
              />
              <SettingRow
                icon={AlertTriangle}
                title="Alertes système"
                subtitle="Notifications pour les conflits et problèmes techniques"
                checked={!!n.settings.notifSystem}
                disabled={n.savingSettingKey === "notifSystem"}
                onToggle={(v) => n.toggleSetting("notifSystem", v)}
              />
              <SettingRow
                icon={Mail}
                title="Résumé quotidien"
                subtitle="Recevoir un email récapitulatif chaque jour à 9h00"
                checked={!!n.settings.dailySummaryEnabled}
                disabled={n.savingSettingKey === "dailySummaryEnabled"}
                onToggle={(v) => n.toggleSetting("dailySummaryEnabled", v)}
              />
            </>
          )}
        </div>
      </div>

      {/* Reminders */}
      <div className="rounded-2xl border bg-white shadow-sm overflow-hidden">
        <div className="border-b px-5 py-4">
          <div className="text-sm font-extrabold text-slate-900">
            Rappels de paiement automatiques
          </div>
        </div>
        <div className="p-5 space-y-3">
          {n.reminders.map((r) => (
            <ReminderCard
              key={r.title}
              title={r.title}
              subtitle={r.subtitle}
              variant={r.variant}
              active={r.active}
            />
          ))}
        </div>
      </div>

      <ConfirmDeleteModal
        open={n.deleteOpen}
        title="Supprimer la notification"
        message={
          n.notifToDelete
            ? `Voulez-vous vraiment supprimer "${n.notifToDelete.title}" ?`
            : "Voulez-vous supprimer cette notification ?"
        }
        confirmText="Supprimer"
        loading={n.deleteLoading}
        onCancel={() => {
          if (n.deleteLoading) return;
          n.setDeleteOpen(false);
          n.setNotifToDelete(null);
        }}
        onConfirm={n.confirmDelete}
      />
    </div>
  );
}