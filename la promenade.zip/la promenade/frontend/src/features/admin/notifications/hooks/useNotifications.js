import { useEffect, useMemo, useState } from "react";
import {
  fetchAdminSettings,
  fetchNotificationStats,
  fetchNotifications,
  readAllNotifications,
  readNotification,
  removeNotification,
  saveAdminSettings,
} from "../api/notifications.api";

export function useNotifications() {
  const [tab, setTab] = useState("all"); // all | unread
  const [rows, setRows] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    unread: 0,
    highPriority: 0,
    emailEnabled: 0,
  });

  const [settings, setSettings] = useState({
    notifEvents: true,
    notifPayments: true,
    notifSignup: true,
    notifSystem: true,
    dailySummaryEnabled: false,

    hotelName: "",
    email: "",
    address: "",
    phone: "",
    website: "",
    taxRate: 0,
    paymentDelayDays: 0,
    onlinePaymentEnabled: true,
  });

  const [loadingList, setLoadingList] = useState(true);
  const [loadingStats, setLoadingStats] = useState(true);
  const [loadingSettings, setLoadingSettings] = useState(true);
  const [error, setError] = useState("");

  const [busyAllRead, setBusyAllRead] = useState(false);
  const [busyId, setBusyId] = useState(null);

  // delete modal
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [notifToDelete, setNotifToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // settings save state
  const [savingSettingKey, setSavingSettingKey] = useState(null);

  async function loadStats() {
    setLoadingStats(true);
    try {
      const data = await fetchNotificationStats();
      setStats({
        total: Number(data?.total || 0),
        unread: Number(data?.unread || 0),
        highPriority: Number(data?.highPriority || 0),
        emailEnabled: Number(data?.emailEnabled || 0),
      });
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur chargement stats.");
    } finally {
      setLoadingStats(false);
    }
  }

  async function loadList(nextTab = tab) {
    setLoadingList(true);
    try {
      const data = await fetchNotifications(nextTab);
      setRows(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(
        err?.response?.data?.message || "Erreur chargement notifications."
      );
      setRows([]);
    } finally {
      setLoadingList(false);
    }
  }

  async function loadSettings() {
    setLoadingSettings(true);
    try {
      const s = await fetchAdminSettings();
      setSettings((prev) => ({
        ...prev,
        ...s,
        notifEvents: !!s?.notifEvents,
        notifPayments: !!s?.notifPayments,
        notifSignup: !!s?.notifSignup,
        notifSystem: !!s?.notifSystem,
        dailySummaryEnabled: !!s?.dailySummaryEnabled,
      }));
    } catch (err) {
      setError(
        err?.response?.data?.message || "Erreur chargement paramètres email."
      );
    } finally {
      setLoadingSettings(false);
    }
  }

  async function loadAll(nextTab = tab) {
    setError("");
    await Promise.all([loadStats(), loadList(nextTab), loadSettings()]);
  }

  useEffect(() => {
    loadAll(tab);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const tabLabels = useMemo(() => {
    return {
      all: `Toutes (${stats.total})`,
      unread: `Non lues (${stats.unread})`,
    };
  }, [stats.total, stats.unread]);

  async function onMarkRead(id) {
    if (!id) return;
    setBusyId(id);

    // optimistic update
    setRows((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );

    try {
      await readNotification(id);
      await loadStats();
      if (tab === "unread") {
        setRows((prev) => prev.filter((n) => n.id !== id));
      }
    } catch (err) {
      setRows((prev) =>
        prev.map((n) => (n.id === id ? { ...n, isRead: false } : n))
      );
      setError(
        err?.response?.data?.message || "Erreur lors du marquage comme lu."
      );
    } finally {
      setBusyId(null);
    }
  }

  function askDelete(notif) {
    setNotifToDelete(notif);
    setDeleteOpen(true);
  }

  async function confirmDelete() {
    if (!notifToDelete?.id) return;

    const id = notifToDelete.id;
    setDeleteLoading(true);

    // optimistic remove
    const snapshot = rows;
    setRows((prev) => prev.filter((n) => n.id !== id));

    try {
      await removeNotification(id);
      await loadStats();
      setDeleteOpen(false);
      setNotifToDelete(null);
    } catch (err) {
      setRows(snapshot);
      setError(err?.response?.data?.message || "Erreur suppression notification.");
    } finally {
      setDeleteLoading(false);
    }
  }

  async function onMarkAllRead() {
    setBusyAllRead(true);

    // optimistic
    setRows((prev) => prev.map((n) => ({ ...n, isRead: true })));

    try {
      await readAllNotifications();
      await loadStats();
      if (tab === "unread") setRows([]);
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur: tout marquer comme lu.");
      await loadList(tab);
    } finally {
      setBusyAllRead(false);
    }
  }

  async function onRefresh() {
    await loadAll(tab);
  }

  async function toggleSetting(key, nextValue) {
    setError("");
    setSavingSettingKey(key);

    const snapshot = settings;
    setSettings((prev) => ({ ...prev, [key]: nextValue }));

    try {
      const payload = {
        hotelName: settings.hotelName,
        email: settings.email,
        address: settings.address,
        phone: settings.phone,
        website: settings.website,
        taxRate: settings.taxRate,
        paymentDelayDays: settings.paymentDelayDays,
        onlinePaymentEnabled: settings.onlinePaymentEnabled,

        notifEvents: key === "notifEvents" ? nextValue : settings.notifEvents,
        notifPayments:
          key === "notifPayments" ? nextValue : settings.notifPayments,
        notifSignup: key === "notifSignup" ? nextValue : settings.notifSignup,
        notifSystem: key === "notifSystem" ? nextValue : settings.notifSystem,
        dailySummaryEnabled:
          key === "dailySummaryEnabled" ? nextValue : settings.dailySummaryEnabled,
      };

      const updated = await saveAdminSettings(payload);

      setSettings((prev) => ({
        ...prev,
        ...updated,
        notifEvents: !!updated?.notifEvents,
        notifPayments: !!updated?.notifPayments,
        notifSignup: !!updated?.notifSignup,
        notifSystem: !!updated?.notifSystem,
        dailySummaryEnabled: !!updated?.dailySummaryEnabled,
      }));

      await loadStats();
    } catch (err) {
      setSettings(snapshot);
      setError(
        err?.response?.data?.message || "Erreur mise à jour paramètres email."
      );
    } finally {
      setSavingSettingKey(null);
    }
  }

  const reminders = useMemo(() => {
    return [
      {
        title: "7 jours avant échéance",
        subtitle: "Premier rappel automatique",
        variant: "info",
        active: true,
      },
      {
        title: "Le jour de l’échéance",
        subtitle: "Rappel le jour J",
        variant: "info",
        active: true,
      },
      {
        title: "Après retard de paiement",
        subtitle: "Relance tous les 3 jours",
        variant: "danger",
        active: true,
      },
    ];
  }, []);

  return {
    // state
    tab,
    setTab,
    rows,
    stats,
    settings,
    loadingList,
    loadingStats,
    loadingSettings,
    error,
    busyAllRead,
    busyId,
    savingSettingKey,

    // actions
    onRefresh,
    onMarkAllRead,
    onMarkRead,
    toggleSetting,

    // labels
    tabLabels,

    // reminders ui
    reminders,

    // delete modal
    deleteOpen,
    notifToDelete,
    deleteLoading,
    askDelete,
    setDeleteOpen,
    setNotifToDelete,
    confirmDelete,
  };
}