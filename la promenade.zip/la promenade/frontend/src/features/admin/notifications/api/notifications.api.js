import {
  getNotificationStats,
  getNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  deleteNotification,
  getAdminSettings,
  updateAdminSettings,
} from "../../api/adminApi";

export async function fetchNotificationStats() {
  return getNotificationStats();
}

export async function fetchNotifications(tab) {
  return getNotifications(tab);
}

export async function readNotification(id) {
  return markNotificationRead(id);
}

export async function readAllNotifications() {
  return markAllNotificationsRead();
}

export async function removeNotification(id) {
  return deleteNotification(id);
}

export async function fetchAdminSettings() {
  return getAdminSettings();
}

export async function saveAdminSettings(payload) {
  return updateAdminSettings(payload);
}