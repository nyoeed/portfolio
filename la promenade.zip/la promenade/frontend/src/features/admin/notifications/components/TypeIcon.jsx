import { AlertTriangle, CalendarDays, CreditCard, UserPlus } from "lucide-react";

export default function TypeIcon({ type }) {
  const base = "h-9 w-9 rounded-xl flex items-center justify-center";
  switch (type) {
    case "payment":
      return (
        <div className={`${base} bg-green-50`}>
          <CreditCard size={18} className="text-green-600" />
        </div>
      );
    case "event":
      return (
        <div className={`${base} bg-blue-50`}>
          <CalendarDays size={18} className="text-blue-600" />
        </div>
      );
    case "user":
      return (
        <div className={`${base} bg-purple-50`}>
          <UserPlus size={18} className="text-purple-600" />
        </div>
      );
    case "system":
    default:
      return (
        <div className={`${base} bg-red-50`}>
          <AlertTriangle size={18} className="text-red-600" />
        </div>
      );
  }
}