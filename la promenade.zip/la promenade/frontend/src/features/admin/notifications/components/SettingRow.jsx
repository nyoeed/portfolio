import Toggle from "./Toggle";

export default function SettingRow({
  icon: Icon,
  title,
  subtitle,
  checked,
  onToggle,
  disabled,
}) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border bg-white px-4 py-3">
      <div className="flex items-start gap-3">
        <div className="mt-0.5 h-9 w-9 rounded-xl bg-slate-50 flex items-center justify-center">
          <Icon size={18} className="text-slate-700" />
        </div>
        <div className="min-w-0">
          <div className="text-sm font-extrabold text-slate-900">{title}</div>
          <div className="mt-0.5 text-xs font-semibold text-slate-500">
            {subtitle}
          </div>
        </div>
      </div>
      <Toggle checked={checked} onChange={onToggle} disabled={disabled} />
    </div>
  );
}