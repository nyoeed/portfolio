export default function ReminderCard({ title, subtitle, variant, active }) {
  const base =
    "rounded-xl border px-4 py-3 flex items-center justify-between gap-4";
  const bg =
    variant === "danger" ? "bg-red-50 border-red-200" : "bg-blue-50 border-blue-200";
  const badge = variant === "danger" ? "bg-red-600 text-white" : "bg-blue-600 text-white";

  return (
    <div className={`${base} ${bg}`}>
      <div>
        <div className="text-sm font-extrabold text-slate-900">{title}</div>
        <div className="mt-0.5 text-xs font-semibold text-slate-600">{subtitle}</div>
      </div>
      <span className={`rounded-full px-3 py-1 text-[11px] font-extrabold ${badge}`}>
        {active ? "Actif" : "Inactif"}
      </span>
    </div>
  );
}