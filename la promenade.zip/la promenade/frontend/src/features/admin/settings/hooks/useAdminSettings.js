import { useEffect, useMemo, useState } from "react";
import { fetchAdminSettings, fetchRooms, patchRoom, saveAdminSettings } from "../api/settings.api";

export function useAdminSettings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [roomsLoading, setRoomsLoading] = useState(true);
  const [rooms, setRooms] = useState([]);

  const [error, setError] = useState("");
  const [settingsApiMissing, setSettingsApiMissing] = useState(false);

  const [settings, setSettings] = useState({
    hotelName: "Hôtel La Promenade",
    email: "contact@lapromenade.com",
    address: "",
    phone: "",
    website: "",

    taxRate: 20,
    paymentDelayDays: 30,
    onlinePaymentEnabled: true,

    notifEvents: true,
    notifPayments: true,
    notifSignup: true,
    notifSystem: true,
    dailySummaryEnabled: false,
  });

  // room price modal
  const [editOpen, setEditOpen] = useState(false);
  const [roomToEdit, setRoomToEdit] = useState(null);
  const [editSaving, setEditSaving] = useState(false);

  async function loadSettings() {
    setLoading(true);
    setError("");
    setSettingsApiMissing(false);

    try {
      const data = await fetchAdminSettings();
      if (data && typeof data === "object") {
        setSettings((s) => ({ ...s, ...data }));
      }
    } catch (err) {
      if (err?.response?.status === 404) setSettingsApiMissing(true);
      else setError(err?.response?.data?.message || "Erreur chargement paramètres.");
    } finally {
      setLoading(false);
    }
  }

  async function loadRooms() {
    setRoomsLoading(true);
    setError("");
    try {
      const data = await fetchRooms();
      setRooms(data);
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur chargement salles.");
    } finally {
      setRoomsLoading(false);
    }
  }

  async function loadAll() {
    await Promise.all([loadSettings(), loadRooms()]);
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const roomsSorted = useMemo(() => {
    return [...rooms].sort((a, b) =>
      String(a.name || "").localeCompare(String(b.name || ""), "fr")
    );
  }, [rooms]);

  async function save() {
    setSaving(true);
    setError("");
    setSettingsApiMissing(false);

    const payload = {
      ...settings,
      taxRate: Number(settings.taxRate),
      paymentDelayDays: Number(settings.paymentDelayDays),
      onlinePaymentEnabled: !!settings.onlinePaymentEnabled,
      notifEvents: !!settings.notifEvents,
      notifPayments: !!settings.notifPayments,
      notifSignup: !!settings.notifSignup,
      notifSystem: !!settings.notifSystem,
      dailySummaryEnabled: !!settings.dailySummaryEnabled,
    };

    try {
      await saveAdminSettings(payload);
    } catch (err) {
      if (err?.response?.status === 404) setSettingsApiMissing(true);
      else setError(err?.response?.data?.message || "Erreur lors de l’enregistrement.");
    } finally {
      setSaving(false);
    }
  }

  function openEditRoom(room) {
    setRoomToEdit(room);
    setEditOpen(true);
  }

  async function saveRoomPrice({ pricePerDay }) {
    if (!roomToEdit) return;
    if (!Number.isFinite(pricePerDay) || pricePerDay < 0) return;

    setEditSaving(true);
    try {
      const data = await patchRoom(roomToEdit.id, { pricePerDay });
      const updated = data?.room || data || { ...roomToEdit, pricePerDay };

      setRooms((list) =>
        list.map((r) => (r.id === roomToEdit.id ? { ...r, ...updated } : r))
      );

      setEditOpen(false);
      setRoomToEdit(null);
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur modification du tarif.");
    } finally {
      setEditSaving(false);
    }
  }

  return {
    // state
    loading,
    saving,
    roomsLoading,
    roomsSorted,
    error,
    settingsApiMissing,

    // settings
    settings,
    setSettings,

    // actions
    loadAll,
    save,

    // room modal
    editOpen,
    roomToEdit,
    editSaving,
    openEditRoom,
    setEditOpen,
    setRoomToEdit,
    saveRoomPrice,
  };
}
