import { useEffect, useState } from "react";
import Field from "../components/Field";
import Input from "../components/Input";

export default function EditRoomPriceModal({ open, room, onClose, onSave, loading }) {
  const [value, setValue] = useState("");

  useEffect(() => {
    if (!open || !room) return;
    setValue(room.pricePerDay == null ? "" : String(room.pricePerDay));
  }, [open, room]);

  if (!open || !room) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <div className="text-lg font-extrabold text-slate-900">Modifier le tarif</div>
          <button
            onClick={onClose}
            className="rounded-lg px-2 py-1 text-sm font-semibold text-slate-600 hover:bg-slate-100"
            type="button"
            disabled={loading}
          >
            Fermer
          </button>
        </div>

        <div className="space-y-4 px-5 py-4">
          <div className="rounded-xl bg-slate-50 px-4 py-3">
            <div className="text-sm font-extrabold text-slate-900">{room.name}</div>
            <div className="mt-1 text-xs font-semibold text-slate-500">
              {Number(room.capacity || 0)} personnes
            </div>
          </div>

          <Field label="Tarif / jour (CAD)">
            <Input
              type="number"
              step="0.01"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="Ex: 2500"
            />
          </Field>
        </div>

        <div className="flex justify-end gap-2 border-t px-5 py-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
            disabled={loading}
          >
            Annuler
          </button>
          <button
            type="button"
            onClick={() => onSave?.({ pricePerDay: Number(value) })}
            className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-blue-700 disabled:opacity-60"
            disabled={loading || value === "" || !Number.isFinite(Number(value))}
          >
            {loading ? "Enregistrement..." : "Enregistrer"}
          </button>
        </div>
      </div>
    </div>
  );
}