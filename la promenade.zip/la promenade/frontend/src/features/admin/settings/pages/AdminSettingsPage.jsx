import { Building2, Save, Pencil, Settings2, Bell, CreditCard } from "lucide-react";

import Section from "../components/Section";
import Field from "../components/Field";
import Input from "../components/Input";
import ToggleCard from "../components/ToggleCard";
import EditRoomPriceModal from "../modals/EditRoomPriceModal";

import { useAdminSettings } from "../hooks/useAdminSettings";
import { fmtMoneyCAD } from "../../../../shared/utils/money";

export default function AdminSettingsPage() {
  const s = useAdminSettings();

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4"><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Centre de gouvernance</div><div className="mt-2 text-lg font-extrabold text-slate-900">Paramètres pro</div><div className="mt-1 text-sm text-slate-500">Branding, paiement, notifications et pilotage.</div></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4"><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Email plateforme</div><div className="mt-2 text-lg font-extrabold text-slate-900">{s.settings.email || "—"}</div><div className="mt-1 text-sm text-slate-500">Adresse utilisée pour les communications.</div></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4"><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Paiement en ligne</div><div className="mt-2 text-lg font-extrabold text-slate-900">{s.settings.onlinePaymentEnabled ? "Activé" : "Désactivé"}</div><div className="mt-1 text-sm text-slate-500">Configuration marchande de la plateforme.</div></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4"><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Résumé quotidien</div><div className="mt-2 text-lg font-extrabold text-slate-900">{s.settings.dailySummaryEnabled ? "Actif" : "Off"}</div><div className="mt-1 text-sm text-slate-500">Cadence des rapports email.</div></div>
      </div>
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="text-xs font-bold text-slate-500">Administration</div>
          <h1 className="mt-1 text-2xl font-extrabold text-slate-900">Paramètres</h1>
          <p className="mt-1 text-sm font-semibold text-slate-500">
            Configurez votre plateforme
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={s.loadAll}
            type="button"
            className="rounded-xl border bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
            disabled={s.loading || s.roomsLoading}
          >
            Rafraîchir
          </button>

          <button
            onClick={s.save}
            type="button"
            className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-blue-700 disabled:opacity-60"
            disabled={s.saving}
          >
            <Save size={18} />
            {s.saving ? "Enregistrement..." : "Enregistrer les modifications"}
          </button>
        </div>
      </div>

      {s.error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
          {s.error}
        </div>
      ) : null}

      {s.settingsApiMissing ? (
        <div className="rounded-2xl border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm font-semibold text-yellow-800">
          ⚠️ Endpoint <span className="font-extrabold">/api/admin/settings</span> introuvable (404).
          <span className="ml-1">
            La page fonctionne, mais l’enregistrement des paramètres ne sera pas persistant tant que le backend n’est pas prêt.
          </span>
        </div>
      ) : null}

      {/* Informations générales */}
      <Section title="Informations générales" icon={Building2}>
        {s.loading ? (
          <div className="text-sm font-semibold text-slate-600">Chargement…</div>
        ) : (
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Field label="Nom de l’hôtel">
              <Input
                value={s.settings.hotelName}
                onChange={(e) =>
                  s.setSettings((prev) => ({ ...prev, hotelName: e.target.value }))
                }
              />
            </Field>

            <Field label="Email">
              <Input
                value={s.settings.email}
                onChange={(e) =>
                  s.setSettings((prev) => ({ ...prev, email: e.target.value }))
                }
              />
            </Field>

            <Field label="Adresse">
              <Input
                className="lg:col-span-2"
                value={s.settings.address}
                onChange={(e) =>
                  s.setSettings((prev) => ({ ...prev, address: e.target.value }))
                }
              />
            </Field>

            <Field label="Téléphone">
              <Input
                value={s.settings.phone}
                onChange={(e) =>
                  s.setSettings((prev) => ({ ...prev, phone: e.target.value }))
                }
              />
            </Field>

            <Field label="Site web">
              <Input
                value={s.settings.website}
                onChange={(e) =>
                  s.setSettings((prev) => ({ ...prev, website: e.target.value }))
                }
              />
            </Field>
          </div>
        )}
      </Section>

      {/* Salles disponibles */}
      <Section title="Salles disponibles" icon={Settings2}>
        {s.roomsLoading ? (
          <div className="text-sm font-semibold text-slate-600">Chargement…</div>
        ) : s.roomsSorted.length === 0 ? (
          <div className="text-sm font-semibold text-slate-600">Aucune salle.</div>
        ) : (
          <div className="space-y-3">
            {s.roomsSorted.map((r) => (
              <div
                key={r.id}
                className="flex items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white px-4 py-3"
              >
                <div>
                  <div className="text-sm font-extrabold text-slate-900">{r.name}</div>
                  <div className="mt-0.5 text-xs font-semibold text-slate-500">
                    {Number(r.capacity || 0)} personnes
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-sm font-extrabold text-slate-900">
                      {fmtMoneyCAD(r.pricePerDay)}
                      <span className="text-xs font-semibold text-slate-500">/jour</span>
                    </div>
                    <button
                      type="button"
                      className="mt-1 inline-flex items-center gap-1 text-xs font-extrabold text-blue-700 hover:underline"
                      onClick={() => s.openEditRoom(r)}
                    >
                      <Pencil size={14} />
                      Modifier
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Section>

      {/* Paiement */}
      <Section title="Paiement" icon={CreditCard}>
        {s.loading ? (
          <div className="text-sm font-semibold text-slate-600">Chargement…</div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <Field label="TVA (%)">
                <Input
                  type="number"
                  step="0.01"
                  value={s.settings.taxRate}
                  onChange={(e) =>
                    s.setSettings((prev) => ({ ...prev, taxRate: e.target.value }))
                  }
                />
              </Field>

              <Field label="Délai de paiement (jours)">
                <Input
                  type="number"
                  value={s.settings.paymentDelayDays}
                  onChange={(e) =>
                    s.setSettings((prev) => ({
                      ...prev,
                      paymentDelayDays: e.target.value,
                    }))
                  }
                />
              </Field>
            </div>

            <div className="rounded-xl border border-slate-200 bg-blue-50 px-4 py-3">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={!!s.settings.onlinePaymentEnabled}
                  onChange={(e) =>
                    s.setSettings((prev) => ({
                      ...prev,
                      onlinePaymentEnabled: e.target.checked,
                    }))
                  }
                />
                <div>
                  <div className="text-sm font-extrabold text-slate-900">
                    Activer le paiement en ligne
                  </div>
                  <div className="mt-0.5 text-xs font-semibold text-slate-600">
                    Permet le paiement par carte / virement via la plateforme.
                  </div>
                </div>
              </label>
            </div>
          </div>
        )}
      </Section>

      {/* Notifications */}
      <Section title="Notifications" icon={Bell}>
        {s.loading ? (
          <div className="text-sm font-semibold text-slate-600">Chargement…</div>
        ) : (
          <div className="space-y-3">
            <ToggleCard
              label="Nouveaux événements"
              desc="Recevoir une notification pour chaque nouvel événement créé"
              checked={!!s.settings.notifEvents}
              onChange={(v) => s.setSettings((prev) => ({ ...prev, notifEvents: v }))}
            />
            <ToggleCard
              label="Paiements"
              desc="Notifications pour les paiements reçus et en retard"
              checked={!!s.settings.notifPayments}
              onChange={(v) => s.setSettings((prev) => ({ ...prev, notifPayments: v }))}
            />
            <ToggleCard
              label="Demandes d’inscription"
              desc="Alertes pour les nouvelles demandes utilisateurs"
              checked={!!s.settings.notifSignup}
              onChange={(v) => s.setSettings((prev) => ({ ...prev, notifSignup: v }))}
            />
            <ToggleCard
              label="Alertes système"
              desc="Notifications pour les conflits et problèmes techniques"
              checked={!!s.settings.notifSystem}
              onChange={(v) => s.setSettings((prev) => ({ ...prev, notifSystem: v }))}
            />
            <ToggleCard
              label="Résumé quotidien"
              desc="Recevoir un email récapitulatif chaque jour à 9h00"
              checked={!!s.settings.dailySummaryEnabled}
              onChange={(v) =>
                s.setSettings((prev) => ({ ...prev, dailySummaryEnabled: v }))
              }
            />
          </div>
        )}
      </Section>

      <EditRoomPriceModal
        open={s.editOpen}
        room={s.roomToEdit}
        loading={s.editSaving}
        onClose={() => {
          s.setEditOpen(false);
          s.setRoomToEdit(null);
        }}
        onSave={s.saveRoomPrice}
      />
    </div>
  );
}