export default function Section({ title, icon: Icon, children, right }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
      <div className="flex items-center justify-between gap-3 border-b px-5 py-4">
        <div className="flex items-center gap-2">
          {Icon ? (
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100 text-slate-700">
              <Icon size={18} />
            </span>
          ) : null}
          <div className="text-base font-extrabold text-slate-900">{title}</div>
        </div>
        {right}
      </div>

      <div className="p-5">{children}</div>
    </div>
  );
}