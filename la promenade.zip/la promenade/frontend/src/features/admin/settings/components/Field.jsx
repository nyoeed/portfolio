export default function Field({ label, children }) {
  return (
    <div>
      <div className="text-xs font-bold text-slate-600">{label}</div>
      <div className="mt-1">{children}</div>
    </div>
  );
}