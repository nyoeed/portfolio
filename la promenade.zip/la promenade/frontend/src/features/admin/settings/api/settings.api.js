import { api } from "../../../../lib/api";

export async function fetchAdminSettings() {
  const { data } = await api.get("/api/admin/settings");
  return data;
}

export async function saveAdminSettings(payload) {
  const { data } = await api.put("/api/admin/settings", payload);
  return data;
}

export async function fetchRooms() {
  const { data } = await api.get("/api/admin/rooms");
  return Array.isArray(data) ? data : [];
}

export async function patchRoom(roomId, payload) {
  const { data } = await api.patch(`/api/admin/rooms/${roomId}`, payload);
  return data;
}