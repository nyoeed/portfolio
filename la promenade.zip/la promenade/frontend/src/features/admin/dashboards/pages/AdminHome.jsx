import { useEffect, useState } from "react";
import { Users, Clock3, CalendarDays, TrendingUp } from "lucide-react";
import { api } from "../../../../lib/api";

function StatCard({ icon: Icon, title, value, subtitle, color }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 flex items-center justify-between shadow-sm">
      <div>
        <div className="text-sm font-semibold text-slate-500">
          {title}
        </div>

        <div className="text-2xl font-extrabold text-slate-900 mt-1">
          {value}
        </div>

        <div className="text-xs text-slate-400 mt-1">
          {subtitle}
        </div>
      </div>

      <div
        className={`h-12 w-12 rounded-xl flex items-center justify-center ${color}`}
      >
        <Icon size={22} />
      </div>
    </div>
  );
}

export default function AdminHome() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    async function load() {
      const res = await api.get("/api/admin/stats");
      setStats(res.data);
    }
    load();
  }, []);

  if (!stats) return <div>Chargement...</div>;

  const approved =
    stats.statuses?.find((s) => s.status === "approved")?.count || 0;

  return (
    <div className="space-y-8">
      {/* HEADER */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">
          Tableau de bord
        </h1>
        <p className="text-sm text-slate-600 mt-1">
          Vue d'ensemble de votre plateforme
        </p>
      </div>

      {/* STATS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {/* UTILISATEURS */}
        <StatCard
          icon={Users}
          title="Total Utilisateurs"
          value={stats.totalUsers}
          subtitle={`+${stats.newUsersThisMonth} ce mois`}
          color="bg-blue-100 text-blue-700"
        />

        {/* DEMANDES */}
        <StatCard
          icon={Clock3}
          title="Demandes en attente"
          value={stats.pendingRequests}
          subtitle="À traiter"
          color="bg-yellow-100 text-yellow-700"
        />

        {/* EVENTS — ✅ branché backend */}
        <StatCard
          icon={CalendarDays}
          title="Événements actifs"
          value={stats.activeEvents}
          subtitle={`+${stats.newEventsThisWeek} cette semaine`}
          color="bg-green-100 text-green-700"
        />

        {/* REVENUS — ✅ % dynamique */}
        <StatCard
          icon={TrendingUp}
          title="Revenus ce mois"
          value={`${Number(stats.revenueThisMonth || 0).toFixed(2)} $`}
          subtitle={stats.revenueChangePct === null ? `Total: ${Number(stats.revenueLastMonth || 0).toFixed(2)} $ le mois dernier` : `${stats.revenueChangePct >= 0 ? "+" : ""}${stats.revenueChangePct.toFixed(1)}% vs mois dernier • Total cumulé dynamique`}
          color="bg-purple-100 text-purple-700"
        />
      </div>
    </div>
  );
}
