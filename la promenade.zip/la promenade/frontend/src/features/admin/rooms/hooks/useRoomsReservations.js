import { useEffect, useMemo, useState } from "react";
import { fetchReservations } from "../api/reservations.api";
import {
  deleteRoom,
  fetchRooms,
  fetchRoomsStats,
  uploadRoomImage,
} from "../api/rooms.api";

export function useRoomsReservations() {
  const [tab, setTab] = useState("rooms"); // rooms | calendar

  const [stats, setStats] = useState({ total: 0, available: 0, reserved: 0, totalCapacity: 0 });
  const [rooms, setRooms] = useState([]);
  const [reservations, setReservations] = useState([]);

  const [loadingStats, setLoadingStats] = useState(true);
  const [loadingRooms, setLoadingRooms] = useState(true);
  const [loadingRes, setLoadingRes] = useState(true);

  const [error, setError] = useState("");
  const [conflictBanner, setConflictBanner] = useState(null);

  // modals
  const [openAdd, setOpenAdd] = useState(false);

  const [editOpen, setEditOpen] = useState(false);
  const [roomToEdit, setRoomToEdit] = useState(null);

  const [deleteOpen, setDeleteOpen] = useState(false);
  const [roomToDelete, setRoomToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const [roomSearch, setRoomSearch] = useState("");
  const [roomStatus, setRoomStatus] = useState("");
  const [roomCapacityMin, setRoomCapacityMin] = useState("");
  const [reservationSearch, setReservationSearch] = useState("");
  const [reservationStatus, setReservationStatus] = useState("");
  const [reservationDate, setReservationDate] = useState("");

  async function loadStats() {
    setLoadingStats(true);
    try {
      const data = await fetchRoomsStats();
      setStats({
        total: Number(data?.total || 0),
        available: Number(data?.available || 0),
        reserved: Number(data?.reserved || 0),
        totalCapacity: Number(data?.totalCapacity || 0),
      });
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur chargement stats.");
    } finally {
      setLoadingStats(false);
    }
  }

  async function loadRooms() {
    setLoadingRooms(true);
    try {
      const data = await fetchRooms();
      setRooms(data);
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur chargement salles.");
    } finally {
      setLoadingRooms(false);
    }
  }

  async function loadReservations() {
    setLoadingRes(true);
    try {
      const data = await fetchReservations();
      setReservations(data);
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur chargement réservations.");
    } finally {
      setLoadingRes(false);
    }
  }

  async function loadAll() {
    setError("");
    await Promise.all([loadStats(), loadRooms(), loadReservations()]);
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filteredRooms = useMemo(() => rooms.filter((room) => {
    const q = roomSearch.trim().toLowerCase();
    const matchesQ = !q || room.name?.toLowerCase().includes(q) || (room.equipments || []).some((x) => String(x).toLowerCase().includes(q));
    const matchesStatus = !roomStatus || room.status === roomStatus;
    const minCap = Number(roomCapacityMin || 0);
    const matchesCap = !minCap || Number(room.capacity || 0) >= minCap;
    return matchesQ && matchesStatus && matchesCap;
  }), [rooms, roomSearch, roomStatus, roomCapacityMin]);

  const filteredReservations = useMemo(() => reservations.filter((r) => {
    const q = reservationSearch.trim().toLowerCase();
    const matchesQ = !q || [r.roomName, r.title, r.organizerName].some((x) => String(x || '').toLowerCase().includes(q));
    const matchesStatus = !reservationStatus || r.status === reservationStatus;
    const matchesDate = !reservationDate || String(r.startAt || '').slice(0, 10) === reservationDate;
    return matchesQ && matchesStatus && matchesDate;
  }), [reservations, reservationSearch, reservationStatus, reservationDate]);

  const totals = useMemo(() => {
    const confirmed = reservations.filter((r) => r.status === "confirmed").length;
    const pending = reservations.filter((r) => r.status === "pending").length;
    const conflicts = conflictBanner?.conflicts?.length ? 1 : 0;
    return { confirmed, pending, conflicts };
  }, [reservations, conflictBanner]);

  function askDelete(room) {
    setRoomToDelete(room);
    setDeleteOpen(true);
  }

  async function confirmDelete() {
    if (!roomToDelete) return;
    setDeleting(true);
    try {
      await deleteRoom(roomToDelete.id);
      setRooms((s) => s.filter((x) => x.id !== roomToDelete.id));
      await loadStats();
      setDeleteOpen(false);
      setRoomToDelete(null);
    } catch (err) {
      alert(err?.response?.data?.message || "Erreur suppression salle.");
    } finally {
      setDeleting(false);
    }
  }

  async function changeRoomImage(roomId, file) {
    if (!roomId || !file) return;
    try {
      const data = await uploadRoomImage(roomId, file);
      const updatedRoom = data?.room || data;

      if (updatedRoom?.id) {
        setRooms((list) => list.map((x) => (x.id === updatedRoom.id ? { ...x, ...updatedRoom } : x)));
      } else {
        // fallback: reload
        await loadRooms();
      }
    } catch (err) {
      alert(err?.response?.data?.message || "Erreur upload image.");
    }
  }

  return {
    // tab
    tab,
    setTab,

    // data
    stats,
    rooms,
    reservations,

    // loading
    loadingStats,
    loadingRooms,
    loadingRes,

    filteredRooms,
    filteredReservations,

    // ui
    error,
    conflictBanner,
    setConflictBanner,

    // totals
    totals,

    // actions
    loadAll,
    loadStats,
    loadRooms,
    loadReservations,

    // modals state
    openAdd,
    setOpenAdd,

    editOpen,
    setEditOpen,
    roomToEdit,
    setRoomToEdit,

    deleteOpen,
    setDeleteOpen,
    roomToDelete,
    setRoomToDelete,
    deleting,

    roomSearch, setRoomSearch, roomStatus, setRoomStatus, roomCapacityMin, setRoomCapacityMin,
    reservationSearch, setReservationSearch, reservationStatus, setReservationStatus, reservationDate, setReservationDate,
    resetRoomFilters: () => { setRoomSearch(""); setRoomStatus(""); setRoomCapacityMin(""); },
    resetReservationFilters: () => { setReservationSearch(""); setReservationStatus(""); setReservationDate(""); },

    // handlers
    askDelete,
    confirmDelete,
    changeRoomImage,
  };
}