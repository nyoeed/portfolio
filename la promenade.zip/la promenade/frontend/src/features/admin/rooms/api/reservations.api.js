import { api } from "../../../../lib/api";

export async function fetchReservations() {
  const { data } = await api.get("/api/admin/reservations");
  return Array.isArray(data) ? data : [];
}