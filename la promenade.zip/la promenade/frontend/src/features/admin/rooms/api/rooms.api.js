import { api } from "../../../../lib/api";

// rooms
export async function fetchRooms() {
  const { data } = await api.get("/api/admin/rooms");
  return Array.isArray(data) ? data : [];
}

export async function fetchRoomsStats() {
  const { data } = await api.get("/api/admin/rooms/stats");
  return data || {};
}

export async function createRoom(payload) {
  const { data } = await api.post("/api/admin/rooms", payload);
  return data;
}

export async function updateRoom(roomId, payload) {
  const { data } = await api.patch(`/api/admin/rooms/${roomId}`, payload);
  return data;
}

export async function deleteRoom(roomId) {
  const { data } = await api.delete(`/api/admin/rooms/${roomId}`);
  return data;
}

// image upload
export async function uploadRoomImage(roomId, file) {
  const fd = new FormData();
  fd.append("image", file);

  const { data } = await api.post(`/api/admin/rooms/${roomId}/image`, fd, {
    headers: { "Content-Type": "multipart/form-data" },
  });

  return data; // expects { room: {...} } or {...}
}