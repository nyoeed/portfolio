import { LayoutGrid, CalendarDays } from "lucide-react";

export default function RoomsTabs({ tab, setTab, onRefresh }) {
  return (
    <div className="flex items-center gap-2">
      <button
        onClick={() => setTab("rooms")}
        className={[
          "inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm font-extrabold",
          tab === "rooms" ? "bg-blue-600 text-white border-blue-600" : "bg-white text-slate-700 hover:bg-slate-50",
        ].join(" ")}
      >
        <LayoutGrid size={18} />
        Gestion des salles
      </button>

      <button
        onClick={() => setTab("calendar")}
        className={[
          "inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm font-extrabold",
          tab === "calendar" ? "bg-blue-600 text-white border-blue-600" : "bg-white text-slate-700 hover:bg-slate-50",
        ].join(" ")}
      >
        <CalendarDays size={18} />
        Calendrier & Réservations
      </button>

      <div className="ml-auto">
        <button
          onClick={onRefresh}
          className="rounded-xl border bg-white px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
        >
          Rafraîchir
        </button>
      </div>
    </div>
  );
}