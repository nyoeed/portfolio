export default function Badge({ status }) {
  const map = {
    available: { label: "Disponible", cls: "bg-green-100 text-green-700" },
    reserved: { label: "Réservée", cls: "bg-yellow-100 text-yellow-800" },
    maintenance: { label: "En maintenance", cls: "bg-red-100 text-red-700" },
    pending: { label: "En attente", cls: "bg-yellow-100 text-yellow-800" },
    confirmed: { label: "Confirmé", cls: "bg-green-100 text-green-700" },
    cancelled: { label: "Annulé", cls: "bg-red-100 text-red-700" },
  };

  const x = map[status] || { label: status || "-", cls: "bg-slate-100 text-slate-700" };
  return (
    <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-bold ${x.cls}`}>
      {x.label}
    </span>
  );
}