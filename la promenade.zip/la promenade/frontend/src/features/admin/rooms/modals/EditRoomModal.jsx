import { useEffect, useState } from "react";
import { updateRoom } from "../api/rooms.api";

export default function EditRoomModal({ open, room, onClose, onUpdated }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    name: "",
    capacity: "",
    surface: "",
    pricePerDay: "",
    status: "available",
    equipmentsText: "",
  });

  useEffect(() => {
    if (!open || !room) return;
    setError("");
    setLoading(false);
    setForm({
      name: room.name || "",
      capacity: String(room.capacity ?? ""),
      surface: room.surface == null ? "" : String(room.surface),
      pricePerDay: String(room.pricePerDay ?? ""),
      status: room.status || "available",
      equipmentsText: (room.equipments || []).join(", "),
    });
  }, [open, room]);

  if (!open || !room) return null;

  async function submit(e) {
    e.preventDefault();
    setError("");

    const name = form.name.trim();
    const capacity = Number(form.capacity);
    const surface = form.surface === "" ? null : Number(form.surface);
    const pricePerDay = Number(form.pricePerDay);

    if (!name || !Number.isFinite(capacity) || capacity <= 0 || !Number.isFinite(pricePerDay) || pricePerDay < 0) {
      setError("Veuillez remplir au minimum: nom, capacité (>0), tarif (>=0).");
      return;
    }

    const equipments = form.equipmentsText
      .split(",")
      .map((x) => x.trim())
      .filter(Boolean);

    setLoading(true);
    try {
      const data = await updateRoom(room.id, {
        name,
        capacity,
        surface,
        pricePerDay,
        status: form.status,
        equipments,
      });

      onUpdated?.(data);
      onClose?.();
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur lors de la modification.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <div className="text-lg font-extrabold text-slate-900">Modifier la salle</div>
          <button
            onClick={onClose}
            className="rounded-lg px-2 py-1 text-sm font-semibold text-slate-600 hover:bg-slate-100"
            type="button"
          >
            Fermer
          </button>
        </div>

        <form onSubmit={submit} className="space-y-4 p-5">
          {error ? (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
              {error}
            </div>
          ) : null}

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="text-xs font-bold text-slate-600">Nom</label>
              <input
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.name}
                onChange={(e) => setForm((s) => ({ ...s, name: e.target.value }))}
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600">Capacité (pers.)</label>
              <input
                type="number"
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.capacity}
                onChange={(e) => setForm((s) => ({ ...s, capacity: e.target.value }))}
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600">Surface (m²)</label>
              <input
                type="number"
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.surface}
                onChange={(e) => setForm((s) => ({ ...s, surface: e.target.value }))}
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600">Tarif / jour</label>
              <input
                type="number"
                step="0.01"
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.pricePerDay}
                onChange={(e) => setForm((s) => ({ ...s, pricePerDay: e.target.value }))}
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600">Statut</label>
              <select
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.status}
                onChange={(e) => setForm((s) => ({ ...s, status: e.target.value }))}
              >
                <option value="available">Disponible</option>
                <option value="maintenance">Maintenance</option>
                <option value="reserved">Réservée</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="text-xs font-bold text-slate-600">Équipements (séparés par virgule)</label>
              <input
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.equipmentsText}
                onChange={(e) => setForm((s) => ({ ...s, equipmentsText: e.target.value }))}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
              disabled={loading}
            >
              Annuler
            </button>
            <button
              disabled={loading}
              type="submit"
              className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-blue-700 disabled:opacity-60"
            >
              {loading ? "Enregistrement..." : "Enregistrer"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}