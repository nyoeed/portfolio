export default function ConfirmDeleteModal({
  open,
  title = "Confirmer",
  message,
  confirmText = "Supprimer",
  onCancel,
  onConfirm,
  loading,
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl">
        <div className="border-b px-5 py-4">
          <div className="text-lg font-extrabold text-slate-900">{title}</div>
        </div>

        <div className="px-5 py-4">
          <div className="text-sm font-semibold text-slate-700">{message}</div>
        </div>

        <div className="flex justify-end gap-2 border-t px-5 py-4">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-xl border px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50"
            disabled={loading}
          >
            Annuler
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="rounded-xl bg-red-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-red-700 disabled:opacity-60"
            disabled={loading}
          >
            {loading ? "Suppression..." : confirmText}
          </button>
        </div>
      </div>
    </div>
  );
}