import { Plus, Trash2, Pencil, AlertTriangle } from "lucide-react";
import StatCard from "../components/cards/StatCard";
import Badge from "../components/badges/Badge";
import RoomsTabs from "../components/tabs/RoomsTabs";
import AddRoomModal from "../modals/AddRoomModal";
import EditRoomModal from "../modals/EditRoomModal";
import ConfirmDeleteModal from "../modals/ConfirmDeleteModal";
import { useRoomsReservations } from "../hooks/useRoomsReservations";
import { fmtMoneyCAD } from "../../../../shared/utils/money";
import { fmtDateFR, fmtTimeFR } from "../../../../shared/utils/datetime";

export default function AdminRoomsReservationsPage() {
  const s = useRoomsReservations();

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="text-xs font-bold text-slate-500">Administration</div>
          <h1 className="mt-1 text-2xl font-extrabold text-slate-900">Salles & Réservations</h1>
          <p className="mt-1 text-sm font-semibold text-slate-500">Gérez vos espaces et supervisez les réservations</p>
        </div>
        <button onClick={() => s.setOpenAdd(true)} className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-blue-700"><Plus size={18} />Ajouter une salle</button>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total Salles" value={s.loadingStats ? "…" : s.stats.total} />
        <StatCard label="Disponibles" value={s.loadingStats ? "…" : s.stats.available} accent="text-green-700" />
        <StatCard label="Réservées" value={s.loadingStats ? "…" : s.stats.reserved} accent="text-yellow-800" />
        <StatCard label="Capacité totale" value={s.loadingStats ? "…" : s.stats.totalCapacity} accent="text-purple-700" />
      </div>

      <RoomsTabs tab={s.tab} setTab={s.setTab} onRefresh={s.loadAll} />

      {s.error ? <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{s.error}</div> : null}

      {s.tab === "rooms" ? (
        <>
          <div className="rounded-2xl border bg-white p-4">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-5">
              <input value={s.roomSearch} onChange={(e) => s.setRoomSearch(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500 md:col-span-2" placeholder="Rechercher une salle ou un équipement" />
              <select value={s.roomStatus} onChange={(e) => s.setRoomStatus(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500">
                <option value="">Tous les statuts</option>
                <option value="available">Disponible</option>
                <option value="maintenance">Maintenance</option>
                <option value="reserved">Réservée</option>
              </select>
              <select value={s.roomCapacityMin} onChange={(e) => s.setRoomCapacityMin(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500">
                <option value="">Capacité min.</option>
                <option value="20">20+</option>
                <option value="50">50+</option>
                <option value="100">100+</option>
                <option value="200">200+</option>
              </select>
              <button type="button" onClick={s.resetRoomFilters} className="rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold text-slate-700">Réinitialiser</button>
            </div>
          </div>

          {s.loadingRooms ? <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">Chargement…</div> : s.filteredRooms.length === 0 ? <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">Aucune salle pour le moment.</div> : (
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
              {s.filteredRooms.map((r) => (
                <div key={r.id} className="overflow-hidden rounded-2xl border bg-white shadow-sm">
                  <div className="relative h-40 overflow-hidden bg-gradient-to-r from-blue-500 to-purple-600">
                    {r.imageUrl ? <img src={`http://localhost:4000${r.imageUrl}`} alt={r.name} className="h-full w-full object-cover" /> : null}
                    <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" id={`roomimg-${r.id}`} onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; await s.changeRoomImage(r.id, file); e.target.value = ""; }} />
                    <div className="absolute left-3 top-3"><button className="rounded-lg px-3 py-1 text-xs font-extrabold text-white bg-black/40 hover:bg-black/60" onClick={() => document.getElementById(`roomimg-${r.id}`)?.click()} type="button">Changer image</button></div>
                    <div className="absolute right-3 top-3"><Badge status={r.status} /></div>
                  </div>
                  <div className="space-y-3 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div><div className="text-base font-extrabold text-slate-900">{r.name}</div><div className="mt-1 text-xs font-semibold text-slate-500">{Number(r.capacity || 0)} pers. • {r.surface ? `${r.surface} m²` : "—"}</div></div>
                      <div className="flex items-center gap-2">
                        <button title="Modifier" className="rounded-lg p-2 text-slate-600 hover:bg-slate-100" onClick={() => { s.setRoomToEdit(r); s.setEditOpen(true); }} type="button"><Pencil size={16} /></button>
                        <button title="Supprimer" className="rounded-lg p-2 text-red-600 hover:bg-red-50" onClick={() => s.askDelete(r)} type="button"><Trash2 size={16} /></button>
                      </div>
                    </div>
                    <div><div className="text-xs font-bold text-slate-500">Équipements</div><div className="mt-2 flex flex-wrap gap-2">{(r.equipments || []).length ? (r.equipments || []).slice(0, 4).map((e) => <span key={e} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-700">{e}</span>) : <span className="text-xs font-semibold text-slate-500">—</span>}</div></div>
                    <div className="grid grid-cols-2 gap-3 border-t pt-3"><div><div className="text-xs font-bold text-slate-500">Tarif journalier</div><div className="mt-1 text-sm font-extrabold text-slate-900">{fmtMoneyCAD(r.pricePerDay)}</div></div><div><div className="text-xs font-bold text-slate-500">Réservations</div><div className="mt-1 text-sm font-extrabold text-slate-900">{Number(r.reservationsCount || 0)}</div><div className="mt-1 text-xs font-semibold text-slate-500">Prochaine: {r.nextReservationAt ? fmtDateFR(r.nextReservationAt) : "—"}</div></div></div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      ) : (
        <div className="space-y-4">
          {s.conflictBanner ? <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-4"><div className="flex items-start gap-3"><div className="mt-0.5 text-red-600"><AlertTriangle size={18} /></div><div className="flex-1"><div className="font-extrabold text-red-700">Conflit de réservation détecté</div><div className="mt-1 text-sm font-semibold text-red-700">{s.conflictBanner.message || "Cette salle est déjà réservée sur ce créneau."}</div></div><button onClick={() => s.setConflictBanner(null)} className="rounded-lg px-3 py-1 text-sm font-bold text-red-700 hover:bg-red-100" type="button">Fermer</button></div></div> : null}
          <div className="rounded-2xl border bg-white p-4">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-5">
              <input value={s.reservationSearch} onChange={(e) => s.setReservationSearch(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500 md:col-span-2" placeholder="Rechercher salle, événement, organisateur" />
              <select value={s.reservationStatus} onChange={(e) => s.setReservationStatus(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500"><option value="">Tous les statuts</option><option value="confirmed">Confirmée</option><option value="pending">En attente</option><option value="cancelled">Annulée</option></select>
              <input type="date" value={s.reservationDate} onChange={(e) => s.setReservationDate(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500" />
              <button type="button" onClick={s.resetReservationFilters} className="rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold text-slate-700">Réinitialiser</button>
            </div>
          </div>
          <div className="rounded-2xl border bg-white shadow-sm">
            <div className="flex items-center justify-between border-b px-5 py-4"><div><div className="text-base font-extrabold text-slate-900">Calendrier global des réservations</div><div className="mt-1 text-xs font-semibold text-slate-500">Confirmées: {s.totals.confirmed} • En attente: {s.totals.pending}</div></div></div>
            {s.loadingRes ? <div className="p-6 text-sm font-semibold text-slate-600">Chargement…</div> : s.filteredReservations.length === 0 ? <div className="p-6 text-sm font-semibold text-slate-600">Aucune réservation.</div> : <div className="overflow-x-auto"><table className="min-w-full text-left text-sm"><thead className="bg-slate-50 text-xs font-extrabold text-slate-600"><tr><th className="px-5 py-3">Salle</th><th className="px-5 py-3">Événement</th><th className="px-5 py-3">Date</th><th className="px-5 py-3">Horaire</th><th className="px-5 py-3">Organisateur</th><th className="px-5 py-3">Participants</th><th className="px-5 py-3">Statut</th></tr></thead><tbody className="divide-y">{s.filteredReservations.map((r) => <tr key={r.id} className="hover:bg-slate-50"><td className="px-5 py-3 font-bold text-slate-900">{r.roomName}</td><td className="px-5 py-3 font-semibold text-slate-700">{r.title}</td><td className="px-5 py-3 font-semibold text-slate-700">{fmtDateFR(r.startAt)}</td><td className="px-5 py-3 font-semibold text-slate-700">{fmtTimeFR(r.startAt)} - {fmtTimeFR(r.endAt)}</td><td className="px-5 py-3 font-semibold text-slate-700">{r.organizerName || "—"}</td><td className="px-5 py-3 font-semibold text-slate-700">{r.participants} pers.</td><td className="px-5 py-3"><Badge status={r.status} /></td></tr>)}</tbody></table></div>}
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3"><div className="rounded-2xl border bg-white px-5 py-4 shadow-sm"><div className="text-xs font-bold text-slate-500">Réservations confirmées</div><div className="mt-2 text-2xl font-extrabold text-slate-900">{s.totals.confirmed}</div></div><div className="rounded-2xl border bg-white px-5 py-4 shadow-sm"><div className="text-xs font-bold text-slate-500">En attente de validation</div><div className="mt-2 text-2xl font-extrabold text-slate-900">{s.totals.pending}</div></div><div className="rounded-2xl border bg-white px-5 py-4 shadow-sm"><div className="text-xs font-bold text-slate-500">Conflits à résoudre</div><div className="mt-2 text-2xl font-extrabold text-slate-900">{s.totals.conflicts}</div></div></div>
        </div>
      )}

      <AddRoomModal open={s.openAdd} onClose={() => s.setOpenAdd(false)} onCreated={() => { s.loadRooms(); s.loadStats(); }} />
      <EditRoomModal open={s.editOpen} room={s.roomToEdit} onClose={() => { s.setEditOpen(false); s.setRoomToEdit(null); }} onUpdated={() => { s.loadRooms(); s.loadStats(); }} />
      <ConfirmDeleteModal open={s.deleteOpen} title="Supprimer la salle" message={s.roomToDelete ? `Voulez-vous vraiment supprimer "${s.roomToDelete.name}" ?` : "Voulez-vous supprimer cette salle ?"} confirmText="Supprimer" loading={s.deleting} onCancel={() => { s.setDeleteOpen(false); s.setRoomToDelete(null); }} onConfirm={s.confirmDelete} />
    </div>
  );
}
