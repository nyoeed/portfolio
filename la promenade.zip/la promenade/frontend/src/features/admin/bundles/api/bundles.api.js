import { api } from "../../../../lib/api";

export async function fetchBundles() {
  const { data } = await api.get("/api/admin/bundles");
  return Array.isArray(data) ? data : [];
}

export async function createBundle(payload) {
  const { data } = await api.post("/api/admin/bundles", payload);
  return data;
}

export async function updateBundle(bundleId, payload) {
  const { data } = await api.patch(`/api/admin/bundles/${bundleId}`, payload);
  return data;
}

export async function removeBundle(bundleId) {
  const { data } = await api.delete(`/api/admin/bundles/${bundleId}`);
  return data;
}