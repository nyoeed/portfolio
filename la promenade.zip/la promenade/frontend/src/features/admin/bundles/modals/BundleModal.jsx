import { useEffect, useMemo, useState } from "react";
import { createBundle, updateBundle } from "../api/bundles.api";
import { fmtPrice } from "../../services/utils/format";

export default function BundleModal({ open, mode, initial, services, onClose, onSaved }) {
  const isEdit = mode === "edit";
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    name: "",
    description: "",
    unitLabel: "par personne",
    price: "",
    availability: "available",
    serviceIds: [],
  });

  useEffect(() => {
    if (!open) return;
    setError("");
    setLoading(false);

    setForm({
      name: initial?.name || "",
      description: initial?.description || "",
      unitLabel: initial?.unitLabel || "par personne",
      price: initial?.price != null ? String(initial.price) : "",
      availability: initial?.availability || "available",
      serviceIds: (initial?.services || []).map((x) => x.id),
    });
  }, [open, initial]);

  if (!open) return null;

  function toggle(id) {
    setForm((s) => {
      const has = s.serviceIds.includes(id);
      return { ...s, serviceIds: has ? s.serviceIds.filter((x) => x !== id) : [...s.serviceIds, id] };
    });
  }

  const selected = useMemo(() => {
    const set = new Set(form.serviceIds);
    return services.filter((s) => set.has(s.id));
  }, [form.serviceIds, services]);

  async function submit(e) {
    e.preventDefault();
    setError("");

    const payload = {
      name: form.name.trim(),
      description: form.description.trim() || null,
      unitLabel: form.unitLabel,
      price: Number(form.price),
      availability: form.availability,
      serviceIds: form.serviceIds,
    };

    if (!payload.name || !Number.isFinite(payload.price) || payload.price < 0) {
      setError("Veuillez remplir: nom + prix (>=0).");
      return;
    }

    setLoading(true);
    try {
      const data = isEdit ? await updateBundle(initial.id, payload) : await createBundle(payload);
      onSaved?.(data);
      onClose?.();
    } catch (err) {
      setError(err?.response?.data?.message || "Erreur lors de l’enregistrement.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-3xl rounded-2xl bg-white shadow-xl">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <div className="text-lg font-extrabold text-slate-900">
            {isEdit ? "Modifier un forfait" : "Créer un forfait"}
          </div>
          <button onClick={onClose} className="rounded-lg px-2 py-1 text-sm font-semibold text-slate-600 hover:bg-slate-100" type="button">
            Fermer
          </button>
        </div>

        <form onSubmit={submit} className="grid grid-cols-1 gap-4 p-5 lg:grid-cols-2">
          {error ? (
            <div className="lg:col-span-2 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
              {error}
            </div>
          ) : null}

          <div className="space-y-3">
            <div>
              <label className="text-xs font-bold text-slate-600">Nom</label>
              <input
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.name}
                onChange={(e) => setForm((s) => ({ ...s, name: e.target.value }))}
                placeholder="Ex: Forfait Mariage"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600">Description</label>
              <textarea
                rows={3}
                className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                value={form.description}
                onChange={(e) => setForm((s) => ({ ...s, description: e.target.value }))}
                placeholder="Ex: Menu Prestige + Décoration + Photographe"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="text-xs font-bold text-slate-600">Tarif</label>
                <input
                  type="number"
                  step="0.01"
                  className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                  value={form.price}
                  onChange={(e) => setForm((s) => ({ ...s, price: e.target.value }))}
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600">Unité</label>
                <select
                  className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                  value={form.unitLabel}
                  onChange={(e) => setForm((s) => ({ ...s, unitLabel: e.target.value }))}
                >
                  <option value="par personne">par personne</option>
                  <option value="par jour">par jour</option>
                  <option value="forfait">forfait</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-slate-600">Disponibilité</label>
                <select
                  className="mt-1 w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2"
                  value={form.availability}
                  onChange={(e) => setForm((s) => ({ ...s, availability: e.target.value }))}
                >
                  <option value="available">Disponible</option>
                  <option value="unavailable">Indisponible</option>
                </select>
              </div>
            </div>

            <div>
              <div className="text-xs font-bold text-slate-600">Services inclus</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {selected.length === 0 ? (
                  <span className="text-sm font-semibold text-slate-400">Aucun service sélectionné</span>
                ) : (
                  selected.map((s) => (
                    <span key={s.id} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-700">
                      {s.name}
                    </span>
                  ))
                )}
              </div>
            </div>
          </div>

          <div className="rounded-2xl border bg-white p-4">
            <div className="text-sm font-extrabold text-slate-900">Choisir les services</div>
            <div className="mt-3 max-h-[340px] overflow-auto pr-2">
              {services.map((s) => (
                <label key={s.id} className="flex cursor-pointer items-start gap-3 rounded-xl px-3 py-2 hover:bg-slate-50">
                  <input
                    type="checkbox"
                    className="mt-1 h-4 w-4"
                    checked={form.serviceIds.includes(s.id)}
                    onChange={() => toggle(s.id)}
                  />
                  <div className="flex-1">
                    <div className="text-sm font-extrabold text-slate-900">{s.name}</div>
                    <div className="text-xs font-semibold text-slate-500">
                      {s.category} • {fmtPrice(s.price)}€ / {s.unitLabel}
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 flex justify-end gap-2 border-t pt-4">
            <button type="button" onClick={onClose} className="rounded-xl border px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50" disabled={loading}>
              Annuler
            </button>
            <button type="submit" className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-blue-700 disabled:opacity-60" disabled={loading}>
              {loading ? "Enregistrement..." : isEdit ? "Enregistrer" : "Créer"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}