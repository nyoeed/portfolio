export default function RolePill({ role }) {
  const map = {
    admin: "Admin",
    organizer: "Organisateur",
    coordinator: "Coordonnateur",
    accounting: "Comptabilité",
  };

  return (
    <span className="inline-flex items-center rounded-full bg-blue-100 px-3 py-1 text-xs font-semibold text-blue-700">
      {map[role] || "-"}
    </span>
  );
}