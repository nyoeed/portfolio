import { useState } from "react";
import { MoreVertical, Edit3, Trash2, ShieldCheck, ShieldX } from "lucide-react";
import { updateUserStatus } from "../api/users.api";

export default function ActionsMenu({ user, onRefresh, onAskDelete, onAskEdit }) {
  const [open, setOpen] = useState(false);

  async function doAction(fn) {
    try {
      await fn();
      await onRefresh?.();
    } finally {
      setOpen(false);
    }
  }

  return (
    <div className="relative flex justify-end">
      <button
        onClick={() => setOpen((v) => !v)}
        className="h-9 w-9 rounded-lg hover:bg-slate-100 flex items-center justify-center"
        type="button"
      >
        <MoreVertical size={18} className="text-slate-600" />
      </button>

      {open && (
        <>
          <button
            type="button"
            className="fixed inset-0 cursor-default"
            onClick={() => setOpen(false)}
          />

          <div className="absolute right-0 top-10 z-50 w-56 rounded-xl border border-slate-200 bg-white shadow-lg overflow-hidden">
            <div className="px-3 py-2 text-xs font-bold text-slate-500">
              Actions
            </div>

            <button
              type="button"
              disabled={user.status === "approved"}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-slate-50 disabled:opacity-40"
              onClick={() =>
                doAction(() => updateUserStatus(user.id, "approved"))
              }
            >
              <ShieldCheck size={16} className="text-green-600" />
              Activer
            </button>

            <button
              type="button"
              disabled={user.status === "rejected"}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-slate-50 disabled:opacity-40"
              onClick={() =>
                doAction(() => updateUserStatus(user.id, "rejected"))
              }
            >
              <ShieldX size={16} className="text-red-600" />
              Désactiver
            </button>

            <div className="h-px bg-slate-100" />

            <button
              type="button"
              className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-slate-50"
              onClick={() => {
                setOpen(false);
                onAskEdit?.(user);
              }}
            >
              <Edit3 size={16} />
              Modifier
            </button>

            <button
              type="button"
              className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-red-50 text-red-700"
              onClick={() => {
                setOpen(false);
                onAskDelete?.(user);
              }}
            >
              <Trash2 size={16} />
              Supprimer
            </button>
          </div>
        </>
      )}
    </div>
  );
}