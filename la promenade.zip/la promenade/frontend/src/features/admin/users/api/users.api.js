import { api } from "../../../../lib/api";

// GET list
export async function getUsers(params = {}) {
  const res = await api.get("/api/admin/users", { params });
  return res.data || [];
}

// GET meta
export async function getUsersMeta() {
  const res = await api.get("/api/admin/users/meta");
  return res.data || {};
}

// PATCH status
export async function updateUserStatus(userId, status) {
  return api.patch(`/api/admin/users/${userId}/status`, { status });
}

// DELETE
export async function deleteUser(userId) {
  return api.delete(`/api/admin/users/${userId}`);
}

// PATCH user info (edit)
export async function patchUser(userId, payload) {
  return api.patch(`/api/admin/users/${userId}`, payload);
}

// POST create
export async function createUser(payload) {
  return api.post("/api/admin/users", payload);
}