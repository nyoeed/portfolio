import RolePill from "../components/RolePill";
import StatusPill from "../components/StatusPill";
import ActionsMenu from "../components/ActionsMenu";
import { useUsers } from "../hooks/useUsers";
import { formatDate } from "../../../../shared/utils/dates";

import AddUserModal from "../modals/AddUserModal";
import DeleteUserModal from "../modals/DeleteUserModal";
import EditUserModal from "../modals/EditUserModal";

export default function AdminUsersPage() {
  const u = useUsers();

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Utilisateurs</h1>
          <p className="mt-1 text-sm text-slate-600">Gérez les utilisateurs de la plateforme</p>
        </div>

        <button onClick={() => u.setOpenAdd(true)} className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white">
          + Ajouter un utilisateur
        </button>
      </div>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
        <div className="rounded-2xl border bg-white p-4"><div className="text-xs font-bold text-slate-500">Affichés</div><div className="mt-2 text-2xl font-extrabold text-slate-900">{u.rows.length}</div></div>
        <div className="rounded-2xl border bg-white p-4"><div className="text-xs font-bold text-slate-500">Organisateurs</div><div className="mt-2 text-2xl font-extrabold text-slate-900">{u.totals.organizers}</div></div>
        <div className="rounded-2xl border bg-white p-4"><div className="text-xs font-bold text-slate-500">Coordonnateurs</div><div className="mt-2 text-2xl font-extrabold text-slate-900">{u.totals.coordinators}</div></div>
        <div className="rounded-2xl border bg-white p-4"><div className="text-xs font-bold text-slate-500">Approuvés</div><div className="mt-2 text-2xl font-extrabold text-slate-900">{u.totals.approved}</div></div>
      </div>

      <form onSubmit={u.onSubmit} className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-5">
          <input value={u.search} onChange={(e) => u.setSearch(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500 md:col-span-2" placeholder="Rechercher un nom ou un email" />
          <select value={u.role} onChange={(e) => u.setRole(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500">
            <option value="">Tous les rôles</option>
            <option value="admin">Admin</option>
            <option value="organizer">Organisateur</option>
            <option value="coordinator">Coordonnateur</option>
            <option value="accounting">Comptabilité</option>
          </select>
          <select value={u.status} onChange={(e) => u.setStatus(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500">
            <option value="">Tous les statuts</option>
            <option value="approved">Approuvé</option>
            <option value="pending">En attente</option>
            <option value="rejected">Rejeté</option>
          </select>
          <div className="flex gap-2">
            <button className="flex-1 rounded-xl bg-slate-900 px-4 py-3 text-sm font-extrabold text-white">Filtrer</button>
            <button type="button" onClick={u.resetFilters} className="rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold text-slate-700">Réinitialiser</button>
          </div>
        </div>
      </form>

      <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
        <div className="w-full overflow-x-auto">
          <table className="min-w-[980px] w-full">
            <thead className="bg-slate-50">
              <tr className="text-left text-xs font-bold text-slate-500">
                <th className="px-5 py-3">NOM</th>
                <th className="px-5 py-3">EMAIL</th>
                <th className="px-5 py-3">RÔLE</th>
                <th className="px-5 py-3">STATUT</th>
                <th className="px-5 py-3">INSCRIPTION</th>
                <th className="px-5 py-3">DERNIÈRE CONNEXION</th>
                <th className="px-5 py-3 text-right">ACTIONS</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {u.loading ? (
                <tr><td colSpan={7} className="px-5 py-6 text-sm text-slate-600">Chargement…</td></tr>
              ) : u.rows.length === 0 ? (
                <tr><td colSpan={7} className="px-5 py-6 text-sm text-slate-600">Aucun utilisateur trouvé.</td></tr>
              ) : (
                u.rows.map((row) => (
                  <tr key={row.id}>
                    <td className="px-5 py-4 font-semibold">{row.fullName}</td>
                    <td className="px-5 py-4">{row.email}</td>
                    <td className="px-5 py-4"><RolePill role={row.role} /></td>
                    <td className="px-5 py-4"><StatusPill status={row.status} /></td>
                    <td className="px-5 py-4">{formatDate(row.createdAt)}</td>
                    <td className="px-5 py-4">{formatDate(row.lastLoginAt)}</td>
                    <td className="px-5 py-4">
                      <ActionsMenu
                        user={row}
                        onRefresh={u.load}
                        onAskDelete={(user) => { u.setSelectedUser(user); u.setDeleteOpen(true); }}
                        onAskEdit={(user) => { u.setEditUser(user); u.setEditOpen(true); }}
                      />
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="px-5 py-4 text-sm text-slate-500 border-t">Affichage de {u.rows.length} utilisateur(s) sur {u.totalAll}</div>
      </div>

      <AddUserModal open={u.openAdd} onClose={() => u.setOpenAdd(false)} onCreated={u.load} />
      <DeleteUserModal open={u.deleteOpen} user={u.selectedUser} onClose={() => { u.setDeleteOpen(false); u.setSelectedUser(null); }} onConfirm={u.handleDelete} loading={u.deleteLoading} />
      <EditUserModal open={u.editOpen} user={u.editUser} onClose={() => { u.setEditOpen(false); u.setEditUser(null); }} onSave={u.handleEditSave} loading={u.editLoading} />
    </div>
  );
}
