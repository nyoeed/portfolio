import { useEffect, useMemo, useState } from "react";
import { deleteUser, getUsers, getUsersMeta, patchUser } from "../api/users.api";

export function useUsers() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState("");
  const [role, setRole] = useState("");
  const [status, setStatus] = useState("");

  const [totalAll, setTotalAll] = useState(0);

  const [openAdd, setOpenAdd] = useState(false);

  // delete
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // edit
  const [editOpen, setEditOpen] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [editLoading, setEditLoading] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const params = {};
      if (search.trim()) params.search = search.trim();
      if (role) params.role = role;
      if (status) params.status = status;

      const [list, meta] = await Promise.all([getUsers(params), getUsersMeta()]);

      setRows(list);
      setTotalAll(meta?.total || 0);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role, status]);

  function resetFilters() {
    setSearch("");
    setRole("");
    setStatus("");
    setTimeout(() => load(), 0);
  }

  const totals = useMemo(() => {
    return {
      total: rows.length,
      organizers: rows.filter((u) => u.role === "organizer").length,
      coordinators: rows.filter((u) => u.role === "coordinator").length,
      approved: rows.filter((u) => u.status === "approved").length,
    };
  }, [rows]);

  function onSubmit(e) {
    e?.preventDefault?.();
    load();
  }

  async function handleDelete() {
    if (!selectedUser) return;
    setDeleteLoading(true);
    try {
      await deleteUser(selectedUser.id);
      await load();
      setDeleteOpen(false);
      setSelectedUser(null);
    } finally {
      setDeleteLoading(false);
    }
  }

  async function handleEditSave(payload) {
    if (!editUser) return;
    setEditLoading(true);
    try {
      await patchUser(editUser.id, payload);
      await load();
      setEditOpen(false);
      setEditUser(null);
    } finally {
      setEditLoading(false);
    }
  }

  return {
    // data
    rows,
    loading,
    totalAll,
    totals,

    // filters
    search,
    setSearch,
    role,
    setRole,
    status,
    setStatus,
    onSubmit,
    resetFilters,

    // actions
    load,

    // add
    openAdd,
    setOpenAdd,

    // delete modal
    deleteOpen,
    setDeleteOpen,
    selectedUser,
    setSelectedUser,
    deleteLoading,
    handleDelete,

    // edit modal
    editOpen,
    setEditOpen,
    editUser,
    setEditUser,
    editLoading,
    handleEditSave,
  };
}