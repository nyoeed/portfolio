import { useEffect, useMemo, useState } from "react";
import { X } from "lucide-react";
import { createUser } from "../api/users.api";

function isEmailValid(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

function validatePassword(pwd) {
  return {
    length: (pwd || "").length >= 8,
    upper: /[A-Z]/.test(pwd || ""),
    lower: /[a-z]/.test(pwd || ""),
    number: /[0-9]/.test(pwd || ""),
    special: /[^A-Za-z0-9]/.test(pwd || ""),
  };
}

export default function AddUserModal({ open, onClose, onCreated }) {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("organizer");

  const [loading, setLoading] = useState(false);
  const [alert, setAlert] = useState(null);

  useEffect(() => {
    if (!open) return;
    setFullName("");
    setEmail("");
    setPassword("");
    setRole("organizer");
    setAlert(null);
    setLoading(false);
  }, [open]);

  const passwordChecks = useMemo(() => validatePassword(password), [password]);

  const canSubmit = useMemo(() => {
    if (!fullName.trim()) return false;
    if (!email.trim() || !isEmailValid(email.trim())) return false;

    if (
      !passwordChecks.length ||
      !passwordChecks.upper ||
      !passwordChecks.lower ||
      !passwordChecks.number ||
      !passwordChecks.special
    )
      return false;

    if (!role) return false;
    return true;
  }, [fullName, email, role, passwordChecks]);

  async function submit(e) {
    e.preventDefault();
    setAlert(null);

    if (!canSubmit) {
      setAlert({
        type: "error",
        text:
          "Vérifie les champs (email valide + mot de passe: 8 caractères, majuscule, minuscule, chiffre, spécial).",
      });
      return;
    }

    setLoading(true);
    try {
      const payload = {
        fullName: fullName.trim(),
        email: email.trim().toLowerCase(),
        password,
        role,
      };

      await createUser(payload);

      setAlert({ type: "success", text: "Utilisateur créé ✅" });
      onCreated?.();
      setTimeout(() => onClose?.(), 350);
    } catch (err) {
      const msg =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        "Erreur lors de la création.";
      setAlert({ type: "error", text: msg });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") onClose?.();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const ruleClass = (ok) => (ok ? "text-green-600" : "text-red-600");

  return (
    <div className="fixed inset-0 z-50">
      <div
        className="absolute inset-0 bg-black/30"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200 overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
            <div>
              <div className="text-lg font-extrabold text-slate-900">
                Ajouter un utilisateur
              </div>
              <div className="text-sm text-slate-500">
                Crée un compte directement (statut approuvé).
              </div>
            </div>

            <button
              onClick={onClose}
              className="rounded-xl p-2 text-slate-500 hover:bg-slate-100"
              aria-label="Fermer"
              type="button"
            >
              <X size={18} />
            </button>
          </div>

          <form onSubmit={submit} className="p-6 space-y-4">
            {alert ? (
              <div
                className={[
                  "rounded-xl border px-4 py-3 text-sm",
                  alert.type === "error"
                    ? "border-red-200 bg-red-50 text-red-800"
                    : "border-green-200 bg-green-50 text-green-800",
                ].join(" ")}
              >
                {alert.text}
              </div>
            ) : null}

            <div>
              <label className="text-sm font-semibold text-slate-800">
                Nom complet
              </label>
              <input
                className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                placeholder="Ex: Jean Dupont"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-slate-800">
                Email
              </label>
              <input
                className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                placeholder="ex: jean@domaine.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              {email && !isEmailValid(email) ? (
                <div className="mt-1 text-xs text-red-600">Email invalide.</div>
              ) : null}
            </div>

            <div>
              <label className="text-sm font-semibold text-slate-800">
                Mot de passe
              </label>
              <input
                className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                placeholder="Min 8 + Maj + Min + Chiffre + Spécial"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />

              <div className="mt-2 space-y-1 text-xs">
                <div className={ruleClass(passwordChecks.length)}>
                  • Minimum 8 caractères
                </div>
                <div className={ruleClass(passwordChecks.upper)}>
                  • Une majuscule (A-Z)
                </div>
                <div className={ruleClass(passwordChecks.lower)}>
                  • Une minuscule (a-z)
                </div>
                <div className={ruleClass(passwordChecks.number)}>
                  • Un chiffre (0-9)
                </div>
                <div className={ruleClass(passwordChecks.special)}>
                  • Un caractère spécial (ex: !@#$)
                </div>
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-slate-800">Rôle</label>
              <select
                className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 outline-none"
                value={role}
                onChange={(e) => setRole(e.target.value)}
              >
                <option value="organizer">Organisateur</option>
                <option value="coordinator">Coordonnateur</option>
                <option value="accounting">Comptabilité</option>
                <option value="admin">Admin</option>
              </select>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
              >
                Annuler
              </button>
              <button
                disabled={!canSubmit || loading}
                className={[
                  "rounded-xl px-5 py-3 text-sm font-semibold text-white",
                  "bg-blue-600 hover:opacity-95",
                  !canSubmit || loading ? "opacity-60 cursor-not-allowed" : "",
                ].join(" ")}
                type="submit"
              >
                {loading ? "Création…" : "Créer"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}