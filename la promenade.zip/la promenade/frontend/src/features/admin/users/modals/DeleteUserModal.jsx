import { Trash2, X } from "lucide-react";

export default function DeleteUserModal({
  open,
  user,
  onClose,
  onConfirm,
  loading,
}) {
  if (!open || !user) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />

      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="w-full max-w-md rounded-2xl bg-white shadow-xl border border-slate-200">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
            <div className="flex items-center gap-2 text-red-600 font-bold">
              <Trash2 size={18} />
              Supprimer utilisateur
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-slate-100"
            >
              <X size={16} />
            </button>
          </div>

          <div className="px-6 py-5 text-sm text-slate-700">
            Voulez-vous vraiment supprimer
            <span className="font-semibold"> {user.fullName}</span> ?
            <div className="mt-2 text-xs text-slate-500">
              Cette action est irréversible.
            </div>
          </div>

          <div className="flex justify-end gap-3 px-6 py-4 border-t border-slate-200">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-sm font-semibold hover:bg-slate-50"
            >
              Annuler
            </button>

            <button
              onClick={onConfirm}
              disabled={loading}
              className="px-4 py-2 rounded-xl bg-red-600 text-white text-sm font-semibold hover:opacity-95 disabled:opacity-60"
            >
              {loading ? "Suppression..." : "Supprimer"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}