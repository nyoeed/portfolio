import { useEffect, useMemo, useState } from "react";
import { Pencil, X } from "lucide-react";

const roles = [
  { value: "admin", label: "Admin" },
  { value: "organizer", label: "Organisateur" },
  { value: "coordinator", label: "Coordonnateur" },
  { value: "accounting", label: "Comptabilité" },
];

export default function EditUserModal({ open, user, onClose, onSave, loading }) {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("organizer");
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!open || !user) return;
    setFullName(user.fullName || "");
    setEmail(user.email || "");
    setRole(user.role || "organizer");
    setError(null);
  }, [open, user]);

  const emailValid = useMemo(() => {
    if (!email) return false;
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }, [email]);

  function submit() {
    setError(null);

    if (!fullName.trim()) return setError("Le nom est requis.");
    if (!emailValid) return setError("Email invalide.");
    if (!role) return setError("Rôle requis.");

    onSave({
      fullName: fullName.trim(),
      email: email.trim(),
      role,
    });
  }

  if (!open || !user) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />

      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold">
              <Pencil size={18} />
              Modifier utilisateur
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-slate-100"
            >
              <X size={16} />
            </button>
          </div>

          <div className="px-6 py-5 space-y-4">
            {error ? (
              <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            ) : null}

            <div>
              <label className="text-sm font-semibold text-slate-800">
                Nom complet
              </label>
              <input
                className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Ex: Jean Dupont"
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-slate-800">
                Email
              </label>
              <input
                className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ex: jean@email.com"
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-slate-800">Rôle</label>
              <select
                className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 outline-none"
                value={role}
                onChange={(e) => setRole(e.target.value)}
              >
                {roles.map((r) => (
                  <option key={r.value} value={r.value}>
                    {r.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-3 px-6 py-4 border-t border-slate-200">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-sm font-semibold hover:bg-slate-50"
            >
              Annuler
            </button>

            <button
              onClick={submit}
              disabled={loading}
              className="px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:opacity-95 disabled:opacity-60"
            >
              {loading ? "Enregistrement..." : "Enregistrer"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}