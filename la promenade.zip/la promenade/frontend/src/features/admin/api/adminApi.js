// frontend/src/lib/adminApi.js
import { api } from "../../../lib/api";

/* =========================
   PENDING REQUESTS
========================= */
export async function getPendingRequests() {
  const { data } = await api.get("/api/admin/pending");
  return data;
}

export async function approveRequest(id) {
  const { data } = await api.patch(`/api/admin/requests/${id}/approve`);
  return data;
}

export async function rejectRequest(id) {
  const { data } = await api.patch(`/api/admin/requests/${id}/reject`);
  return data;
}

/* =========================
   NOTIFICATIONS
========================= */
export async function getNotificationStats() {
  const { data } = await api.get("/api/admin/notifications/stats");
  return data;
}

export async function getNotifications(tab = "all") {
  const { data } = await api.get("/api/admin/notifications", { params: { tab } });
  return data;
}

export async function markNotificationRead(id) {
  const { data } = await api.patch(`/api/admin/notifications/${id}/read`);
  return data;
}

export async function markAllNotificationsRead() {
  const { data } = await api.post("/api/admin/notifications/mark-all-read");
  return data;
}

export async function deleteNotification(id) {
  const { data } = await api.delete(`/api/admin/notifications/${id}`);
  return data;
}

/* =========================
   SETTINGS (Email toggles)
========================= */
export async function getAdminSettings() {
  const { data } = await api.get("/api/admin/settings");
  return data;
}

export async function updateAdminSettings(payload) {
  const { data } = await api.put("/api/admin/settings", payload);
  return data;
}