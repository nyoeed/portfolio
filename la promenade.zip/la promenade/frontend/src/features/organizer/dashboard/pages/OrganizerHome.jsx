import { useEffect, useState } from 'react';
import { CalendarDays, CreditCard, TrendingUp, UsersRound } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { organizerApi } from '../../api/organizer.api';
import { PageHeader, ProgressBar, SectionCard, StatCard, PrimaryButton, SecondaryButton, StatusPill } from '../../components/OrganizerUi';
import { fmtMoneyCAD } from '@/shared/utils/money';

function formatDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('fr-CA', { dateStyle: 'medium', timeStyle: 'short' });
}

export default function OrganizerHome() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        setLoading(true);
        const res = await organizerApi.getDashboard();
        if (active) setData(res);
      } catch (e) {
        if (active) setError(e?.response?.data?.message || 'Impossible de charger le tableau de bord organisateur.');
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  const summary = data?.summary || {};
  const nextEvent = data?.nextEvent;
  const unpaidInvoices = data?.unpaidInvoices || [];
  const notifications = data?.notifications || [];

  return (
    <div className="space-y-6">
      <PageHeader title="Tableau de bord" subtitle="Bienvenue dans votre espace organisateur" />

      {error ? <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div> : null}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Événements totaux" value={loading ? '…' : Number(summary.totalEvents || 0)} icon={CalendarDays} accent="blue" />
        <StatCard label="Événements à venir" value={loading ? '…' : Number(summary.upcomingEvents || 0)} icon={TrendingUp} accent="green" />
        <StatCard label="Invités estimés" value={loading ? '…' : Number(summary.totalGuests || 0)} icon={UsersRound} accent="purple" />
        <StatCard label="Factures impayées" value={loading ? '…' : Number(summary.unpaidInvoices || 0)} icon={CreditCard} accent="orange" />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.5fr,1fr]">
        <SectionCard title="Prochain événement">
          {nextEvent ? (
            <div className="rounded-2xl border border-blue-200 bg-blue-50/70 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-2xl font-extrabold text-slate-900">{nextEvent.title}</div>
                  <div className="mt-1 text-sm text-slate-500">{formatDate(nextEvent.startAt)} → {formatDate(nextEvent.endAt)}</div>
                  <div className="mt-2 text-sm text-slate-600">📍 {nextEvent.roomName || 'Salle non assignée'}</div>
                  <div className="mt-1 text-sm text-slate-600">👥 {nextEvent.participants || 0} participants</div>
                </div>
                <StatusPill status={nextEvent.status} />
              </div>
              <div className="mt-4"><ProgressBar value={Number(nextEvent.progress || (nextEvent.status === 'confirmed' ? 85 : 40))} /></div>
              <div className="mt-4 flex gap-3">
                <NavLink to="/organizer/evenements" className="flex-1"><PrimaryButton className="w-full">Voir mes événements</PrimaryButton></NavLink>
              </div>
            </div>
          ) : (
            <div className="rounded-xl border border-dashed border-slate-300 px-4 py-6 text-sm text-slate-500">Aucun événement à venir pour le moment.</div>
          )}
        </SectionCard>

        <SectionCard title="Factures en attente">
          <div className="space-y-3">
            {unpaidInvoices.length ? unpaidInvoices.slice(0, 5).map((invoice) => (
              <div key={invoice.id} className="rounded-xl border border-orange-200 bg-orange-50/40 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-bold text-slate-900">{invoice.invoiceNumber} <span className="ml-2"><StatusPill status={invoice.status} /></span></div>
                    <div className="mt-1 text-sm text-slate-600">{invoice.eventTitle}</div>
                    <div className="mt-1 text-xs text-slate-500">Échéance: {formatDate(invoice.dueDate)}</div>
                  </div>
                  <div className="text-lg font-extrabold text-slate-900">{fmtMoneyCAD(invoice.total || 0)}</div>
                </div>
              </div>
            )) : <div className="rounded-xl border border-dashed border-slate-300 px-4 py-6 text-sm text-slate-500">Aucune facture en attente.</div>}
            <NavLink to="/organizer/facturation"><SecondaryButton className="w-full">Voir toute la facturation</SecondaryButton></NavLink>
          </div>
        </SectionCard>
      </div>

      <SectionCard title="Notifications importantes">
        <div className="space-y-3">
          {notifications.length ? notifications.slice(0, 6).map((n) => (
            <div key={n.id} className={`rounded-xl border px-4 py-3 text-sm ${n.priority === 'high' || n.priority === 'urgent' ? 'border-orange-200 bg-orange-50 text-orange-800' : n.isRead ? 'border-slate-200 bg-slate-50 text-slate-700' : 'border-blue-200 bg-blue-50 text-blue-800'}`}>
              <div className="font-semibold">{n.title}</div>
              <div className="mt-1 opacity-90">{n.message}</div>
              <div className="mt-1 text-xs opacity-70">{formatDate(n.createdAt)}</div>
            </div>
          )) : <div className="rounded-xl border border-dashed border-slate-300 px-4 py-6 text-sm text-slate-500">Aucune notification importante.</div>}
        </div>
      </SectionCard>
    </div>
  );
}
