import { api } from '@/lib/api';

export const organizerApi = {
  getDashboard: () => api.get('/api/organizer/dashboard').then((r) => r.data),
  listEvents: (params = {}) => api.get('/api/organizer/events', { params }).then((r) => r.data),
  getEvent: (id) => api.get(`/api/organizer/events/${id}`).then((r) => r.data),
  createEvent: (payload) => api.post('/api/organizer/events', payload).then((r) => r.data),
  updateEvent: (id, payload) => api.patch(`/api/organizer/events/${id}`, payload).then((r) => r.data),
  cancelEvent: (id) => api.delete(`/api/organizer/events/${id}`).then((r) => r.data),
  listRooms: (params = {}) => api.get('/api/organizer/rooms', { params }).then((r) => r.data),
  getCalendar: (params = {}) => api.get('/api/organizer/calendar', { params }).then((r) => r.data),
  listReservations: () => api.get('/api/organizer/reservations').then((r) => r.data),
  listServiceCatalog: (params = {}) => api.get('/api/organizer/services/catalog', { params }).then((r) => r.data),
  listServiceRequests: (params = {}) => api.get('/api/organizer/services/requests', { params }).then((r) => r.data),
  createServiceRequest: (payload) => api.post('/api/organizer/services/requests', payload).then((r) => r.data),
  listGuests: (params = {}) => api.get('/api/organizer/guests', { params }).then((r) => r.data),
  createGuest: (payload) => api.post('/api/organizer/guests', payload).then((r) => r.data),
  updateGuest: (id, payload) => api.patch(`/api/organizer/guests/${id}`, payload).then((r) => r.data),
  deleteGuest: (id) => api.delete(`/api/organizer/guests/${id}`).then((r) => r.data),
  listDocuments: (params = {}) => api.get('/api/organizer/documents', { params }).then((r) => r.data),
  uploadDocument: async ({ file, eventId, category, title }) => {
    const form = new FormData();
    form.append('file', file);
    form.append('eventId', eventId);
    if (category) form.append('category', category);
    if (title) form.append('title', title);
    const res = await api.post('/api/organizer/documents', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },
  deleteDocument: (id) => api.delete(`/api/organizer/documents/${id}`).then((r) => r.data),
  getBilling: () => api.get('/api/organizer/billing').then((r) => r.data),
  simulatePayment: (payload) => api.post('/api/organizer/billing/payments/simulate', payload).then((r) => r.data),
  getReports: (params = {}) => api.get('/api/organizer/reports', { params }).then((r) => r.data),
  getProfile: () => api.get('/api/organizer/profile').then((r) => r.data),
  updateProfile: (payload) => api.patch('/api/organizer/profile', payload).then((r) => r.data),
  listNotifications: () => api.get('/api/organizer/notifications').then((r) => r.data),
  markNotificationRead: (id) => api.patch(`/api/organizer/notifications/${id}/read`).then((r) => r.data),
};
