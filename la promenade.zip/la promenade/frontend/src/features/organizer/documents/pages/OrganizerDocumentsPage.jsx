import { useEffect, useState } from 'react';
import { organizerApi } from '../../api/organizer.api';
import { Alert, EmptyState, PageHeader, PrimaryButton, SectionCard, SelectInput } from '../../components/OrganizerUi';
import { toApiFileUrl } from '../../utils/apiFileUrl';

export default function OrganizerDocumentsPage() {
  const [events, setEvents] = useState([]);
  const [docs, setDocs] = useState([]);
  const [eventId, setEventId] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('piece_jointe');
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      setLoading(true);
      const [eventData, docData] = await Promise.all([
        organizerApi.listEvents(),
        organizerApi.listDocuments(),
      ]);
      setEvents(Array.isArray(eventData) ? eventData : []);
      setDocs(Array.isArray(docData) ? docData : []);
      setError('');
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger les documents.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function upload() {
    if (!file || !eventId) {
      setError('Choisis un événement et un fichier.');
      return;
    }
    try {
      await organizerApi.uploadDocument({ file, eventId, category, title });
      setMessage('Document envoyé.');
      setError('');
      setTitle('');
      setFile(null);
      await load();
    } catch (e) {
      setMessage('');
      setError(e?.response?.data?.message || 'Upload impossible.');
    }
  }

  async function removeDoc(id) {
    try {
      await organizerApi.deleteDocument(id);
      setMessage('Document supprimé.');
      setError('');
      await load();
    } catch (e) {
      setMessage('');
      setError(e?.response?.data?.message || 'Suppression impossible.');
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Documents" subtitle="Upload réel via multipart/form-data" />
      {message ? <Alert variant="success">{message}</Alert> : null}
      {error ? <Alert variant="error">{error}</Alert> : null}
      <SectionCard title="Ajouter un document">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          <SelectInput value={eventId} onChange={(e) => setEventId(e.target.value)}><option value="">Événement</option>{events.map((event) => <option key={event.id} value={event.id}>{event.title}</option>)}</SelectInput>
          <input value={title} onChange={(e) => setTitle(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" placeholder="Titre" />
          <SelectInput value={category} onChange={(e) => setCategory(e.target.value)}><option value="piece_jointe">Pièce jointe</option><option value="contrat">Contrat</option><option value="plan">Plan</option></SelectInput>
          <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="rounded-xl border border-slate-200 px-4 py-2 text-sm" />
        </div>
        <div className="mt-3"><PrimaryButton onClick={upload}>Téléverser</PrimaryButton></div>
      </SectionCard>
      <SectionCard title="Documents existants">
        {loading ? <div className="text-sm text-slate-500">Chargement…</div> : null}
        {!loading && !docs.length ? <EmptyState>Aucun document.</EmptyState> : null}
        <div className="space-y-3">
          {docs.map((doc) => { const fileUrl = toApiFileUrl(doc.filePath); return <div key={doc.id} className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-4"><div><div className="font-semibold text-slate-900">{doc.title}</div><div className="text-sm text-slate-500">{doc.eventTitle} · {doc.fileName}</div></div><div className="flex items-center gap-2"><a href={fileUrl} target="_blank" rel="noreferrer" className="rounded-lg border px-3 py-1 text-slate-700">Ouvrir</a><a href={fileUrl} download className="rounded-lg border px-3 py-1 text-slate-700">Télécharger</a><button onClick={() => removeDoc(doc.id)} className="rounded-lg border px-3 py-1 text-red-600">Supprimer</button></div></div>; })}
        </div>
      </SectionCard>
    </div>
  );
}
