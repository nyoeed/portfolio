import { useEffect, useMemo, useState } from 'react';
import { organizerApi } from '../../api/organizer.api';
import { PageHeader, PrimaryButton, SectionCard } from '../../components/OrganizerUi';

export default function OrganizerSettingsPage() {
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', organization: '', jobTitle: '', addressLine: '', postalCode: '', city: '', country: '', notificationEmailEnabled: true, notificationSmsEnabled: false, notificationInAppEnabled: true });
  const [message, setMessage] = useState('');

  useEffect(() => { organizerApi.getProfile().then((r) => setForm((prev) => ({ ...prev, ...r }))).catch(() => {}); }, []);

  async function save() {
    try {
      const updated = await organizerApi.updateProfile(form);
      setForm((prev) => ({ ...prev, ...updated }));
      setMessage('Profil mis à jour.');
    } catch (e) {
      setMessage(e?.response?.data?.message || 'Mise à jour impossible.');
    }
  }

  const initials = useMemo(() => (form.fullName || 'OR').split(' ').slice(0, 2).map((p) => p[0]?.toUpperCase()).join(''), [form.fullName]);
  const field = (label, key, type = 'text') => <div><label className="text-sm font-semibold text-slate-700">{label}</label><input type={type} value={form[key] || ''} onChange={(e) => setForm({ ...form, [key]: e.target.value })} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-500" /></div>;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title="Mon profil" subtitle="Paramètres reliés au backend" />
      {message ? <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700">{message}</div> : null}
      <SectionCard title="Photo de profil"><div className="flex items-center gap-4"><div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600 text-2xl font-extrabold text-white">{initials}</div><div className="text-sm text-slate-500">Le backend retourne le profil texte; pas d’upload photo branché ici.</div></div></SectionCard>
      <SectionCard title="Informations personnelles"><div className="grid gap-4 md:grid-cols-2">{field('Nom complet *', 'fullName')}{field('Email', 'email')}{field('Téléphone', 'phone')}{field('Fonction', 'jobTitle')}</div></SectionCard>
      <SectionCard title="Informations professionnelles"><div className="grid gap-4 md:grid-cols-2">{field('Organisation', 'organization')}{field('Adresse', 'addressLine')}</div><div className="mt-4 grid gap-4 md:grid-cols-3">{field('Code postal', 'postalCode')}{field('Ville', 'city')}{field('Pays', 'country')}</div></SectionCard>
      <SectionCard title="Notifications"><div className="space-y-3 text-sm"><label className="flex items-center gap-2"><input type="checkbox" checked={!!form.notificationEmailEnabled} onChange={(e) => setForm({ ...form, notificationEmailEnabled: e.target.checked })} /> Email</label><label className="flex items-center gap-2"><input type="checkbox" checked={!!form.notificationSmsEnabled} onChange={(e) => setForm({ ...form, notificationSmsEnabled: e.target.checked })} /> SMS</label><label className="flex items-center gap-2"><input type="checkbox" checked={!!form.notificationInAppEnabled} onChange={(e) => setForm({ ...form, notificationInAppEnabled: e.target.checked })} /> In-app</label></div></SectionCard>
      <div className="flex justify-end gap-3"><PrimaryButton onClick={save}>Enregistrer les modifications</PrimaryButton></div>
    </div>
  );
}
