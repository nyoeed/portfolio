import { useEffect, useState } from 'react';
import { organizerApi } from '../../api/organizer.api';
import { Alert, EmptyState, PageHeader, SectionCard, SelectInput } from '../../components/OrganizerUi';
import { fmtMoneyCAD } from '@/shared/utils/money';

export default function OrganizerReportsPage() {
  const [data, setData] = useState({ events: [], report: null });
  const [eventId, setEventId] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        setLoading(true);
        const response = await organizerApi.getReports(eventId ? { eventId } : {});
        if (!active) return;
        setData(response || { events: [], report: null });
        setError('');
      } catch (e) {
        if (!active) return;
        setData({ events: [], report: null });
        setError(e?.response?.data?.message || 'Impossible de charger les rapports.');
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, [eventId]);

  const report = data.report;
  const metrics = report?.metrics || {};
  const remaining = Number(metrics.invoicedTotal || 0) - Number(metrics.paidAmount || 0);

  return (
    <div className="space-y-6">
      <PageHeader title="Rapports" subtitle="Résumé post-événement basé sur les vraies données" />
      {error ? <Alert variant="error">{error}</Alert> : null}
      <SectionCard>
        <label className="mb-2 block text-sm font-semibold text-slate-700">Choisir un événement</label>
        <SelectInput value={eventId} onChange={(e) => setEventId(e.target.value)} className="w-full"><option value="">Le plus récent</option>{(data.events || []).map((event) => <option key={event.id} value={event.id}>{event.title}</option>)}</SelectInput>
      </SectionCard>
      {loading ? <SectionCard>Chargement…</SectionCard> : null}
      {!loading && report ? <div className="grid gap-6 xl:grid-cols-2"><SectionCard title="Événement"><div className="space-y-2 text-sm"><div><span className="font-semibold">Titre:</span> {report.event.title}</div><div><span className="font-semibold">Type:</span> {report.event.type || '—'}</div><div><span className="font-semibold">Budget:</span> {fmtMoneyCAD(report.event.budget || 0)}</div><div><span className="font-semibold">Participants prévus:</span> {report.event.participants || 0}</div></div></SectionCard><SectionCard title="Indicateurs"><div className="grid gap-2 text-sm md:grid-cols-2"><div>Invités: <span className="font-semibold">{metrics.invitedCount || 0}</span></div><div>Confirmés: <span className="font-semibold">{metrics.confirmedCount || 0}</span></div><div>Refusés: <span className="font-semibold">{metrics.declinedCount || 0}</span></div><div>Services estimés: <span className="font-semibold">{fmtMoneyCAD(metrics.serviceEstimated || 0)}</span></div><div>Payé: <span className="font-semibold">{fmtMoneyCAD(metrics.paidAmount || 0)}</span></div><div>Facturé: <span className="font-semibold">{fmtMoneyCAD(metrics.invoicedTotal || 0)}</span></div><div>Reste à payer: <span className="font-semibold">{fmtMoneyCAD(remaining || 0)}</span></div><div>Participants finaux: <span className="font-semibold">{metrics.finalParticipants || 0}</span></div><div>Satisfaction: <span className="font-semibold">{metrics.satisfactionScore || '—'}</span></div></div>{metrics.summaryText ? <div className="mt-4 rounded-xl bg-slate-50 p-4 text-sm text-slate-700">{metrics.summaryText}</div> : null}</SectionCard></div> : null}
      {!loading && !report ? <EmptyState>Aucun rapport disponible.</EmptyState> : null}
    </div>
  );
}
