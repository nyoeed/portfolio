import { useEffect, useState } from 'react';
import { organizerApi } from '../../api/organizer.api';
import { Alert, EmptyState, PageHeader, PrimaryButton, SectionCard } from '../../components/OrganizerUi';

function formatDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString('fr-CA', { dateStyle: 'medium', timeStyle: 'short' });
}

export default function OrganizerNotificationsPage() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      setLoading(true);
      const data = await organizerApi.listNotifications();
      setItems(Array.isArray(data) ? data : []);
      setError('');
    } catch (e) {
      setItems([]);
      setError(e?.response?.data?.message || 'Impossible de charger les notifications.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function markRead(id) {
    try {
      await organizerApi.markNotificationRead(id);
      await load();
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de marquer la notification comme lue.');
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Notifications" subtitle="Messages backend" action={<PrimaryButton onClick={load}>Actualiser</PrimaryButton>} />
      {error ? <Alert variant="error">{error}</Alert> : null}
      <SectionCard>
        {loading ? <div className="text-sm text-slate-500">Chargement…</div> : null}
        {!loading && !items.length ? <EmptyState>Aucune notification.</EmptyState> : null}
        <div className="space-y-3">
          {items.map((item) => <div key={item.id} className={`rounded-xl border p-4 ${item.isRead ? 'border-slate-200 bg-slate-50' : 'border-blue-200 bg-blue-50'}`}><div className="flex items-start justify-between gap-3"><div><div className="font-semibold text-slate-900">{item.title}</div><div className="mt-1 text-sm text-slate-700">{item.message}</div><div className="mt-1 text-xs text-slate-500">{formatDate(item.createdAt)}</div></div>{!item.isRead ? <button onClick={() => markRead(item.id)} className="rounded-lg border px-3 py-1 text-sm">Marquer lu</button> : null}</div></div>)}
        </div>
      </SectionCard>
    </div>
  );
}
