export const STATUS_META = {
  draft: { label: 'Brouillon', className: 'bg-slate-100 text-slate-700' },
  pending: { label: 'En attente', className: 'bg-amber-100 text-amber-700' },
  submitted: { label: 'Soumis', className: 'bg-amber-100 text-amber-700' },
  in_review: { label: 'En révision', className: 'bg-violet-100 text-violet-700' },
  validated: { label: 'Validé', className: 'bg-cyan-100 text-cyan-700' },
  confirmed: { label: 'Confirmé', className: 'bg-emerald-100 text-emerald-700' },
  in_coordination: { label: 'En coordination', className: 'bg-indigo-100 text-indigo-700' },
  in_progress: { label: 'En cours', className: 'bg-blue-100 text-blue-700' },
  completed: { label: 'Terminé', className: 'bg-green-100 text-green-700' },
  cancelled: { label: 'Annulé', className: 'bg-red-100 text-red-700' },
  requested: { label: 'Demandé', className: 'bg-slate-100 text-slate-700' },
  in_analysis: { label: 'En analyse', className: 'bg-amber-100 text-amber-700' },
  approved: { label: 'Approuvé', className: 'bg-emerald-100 text-emerald-700' },
  planned: { label: 'Planifié', className: 'bg-blue-100 text-blue-700' },
  paid: { label: 'Payée', className: 'bg-emerald-100 text-emerald-700' },
  partial: { label: 'Partiel', className: 'bg-yellow-100 text-yellow-700' },
  late: { label: 'En retard', className: 'bg-red-100 text-red-700' },
  rejected: { label: 'Refusé', className: 'bg-red-100 text-red-700' },
};

export function getStatusLabel(status) {
  return STATUS_META[status]?.label || status || '—';
}

export function getStatusClass(status) {
  return STATUS_META[status]?.className || 'bg-slate-100 text-slate-700';
}
