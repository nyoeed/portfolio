import { api } from '@/lib/api';

export function toApiFileUrl(filePath) {
  if (!filePath) return '';
  if (/^https?:\/\//i.test(filePath)) return filePath;
  const baseURL = (api.defaults.baseURL || '').replace(/\/$/, '');
  const normalized = String(filePath).startsWith('/') ? filePath : `/${filePath}`;
  return `${baseURL}${normalized}`;
}
