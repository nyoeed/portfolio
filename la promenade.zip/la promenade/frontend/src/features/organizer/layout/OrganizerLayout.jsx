import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  BadgeCheck, LayoutGrid, CalendarPlus2, CalendarCheck2, CalendarDays, BriefcaseBusiness,
  UsersRound, FolderOpen, Receipt, ChartColumn, Bell, Settings, LogOut, Search,
  ChevronDown, FileText, CreditCard, FileClock, Shield, ChefHat, ScreenShare, Upload,
} from 'lucide-react';
import { clearSession, getUser } from '@/lib/auth';
import { cn } from '../components/cn';

const menuGroups = [
  { title: '', items: [{ to: '/organizer', label: 'Tableau de bord', icon: LayoutGrid, end: true }] },
  {
    title: 'Mes événements', collapsible: true, items: [
      { to: '/organizer/evenements', label: 'Tous mes événements', icon: CalendarCheck2 },
      { to: '/organizer/evenements?status=draft', label: 'Brouillons', icon: FileClock },
      { to: '/organizer/evenements?status=submitted', label: 'Soumis', icon: FileClock },
    ],
  },
  { title: '', items: [{ to: '/organizer/creer-evenement', label: 'Créer un événement', icon: CalendarPlus2 }] },
  {
    title: 'Réservation d’espaces', collapsible: true, items: [
      { to: '/organizer/espaces/disponibilites', label: 'Disponibilités', icon: Search },
      { to: '/organizer/espaces/calendrier', label: 'Calendrier', icon: CalendarDays },
      { to: '/organizer/espaces/reservations', label: 'Mes réservations', icon: CalendarCheck2 },
    ],
  },
  {
    title: 'Services', collapsible: true, items: [
      { to: '/organizer/services/demandes', label: 'Mes demandes', icon: BriefcaseBusiness },
      { to: '/organizer/services/traiteur', label: 'Traiteur', icon: ChefHat },
      { to: '/organizer/services/audiovisuel', label: 'Audiovisuel', icon: ScreenShare },
      { to: '/organizer/services/securite', label: 'Sécurité', icon: Shield },
      { to: '/organizer/services/autres', label: 'Autres services', icon: BriefcaseBusiness },
      { to: '/organizer/services/devis-estimatif', label: 'Devis estimatif', icon: Receipt },
    ],
  },
  { title: '', items: [{ to: '/organizer/invites', label: 'Invités', icon: UsersRound }] },
  { title: '', items: [{ to: '/organizer/documents', label: 'Documents', icon: FolderOpen }] },
  {
    title: 'Facturation', collapsible: true, items: [
      { to: '/organizer/facturation', label: 'Mes devis', icon: FileText },
      { to: '/organizer/facturation?tab=factures', label: 'Mes factures', icon: Receipt },
      { to: '/organizer/facturation?tab=paiements', label: 'Paiements', icon: CreditCard },
      { to: '/organizer/facturation?tab=recus', label: 'Reçus', icon: Upload },
    ],
  },
  {
    title: 'Rapports', collapsible: true, items: [
      { to: '/organizer/rapports', label: 'Post-événement', icon: ChartColumn },
      { to: '/organizer/rapports?tab=stats', label: 'Statistiques', icon: ChartColumn },
      { to: '/organizer/rapports?tab=exports', label: 'Exports', icon: Upload },
    ],
  },
  { title: '', items: [{ to: '/organizer/notifications', label: 'Notifications', icon: Bell }] },
  {
    title: 'Paramètres', collapsible: true, items: [
      { to: '/organizer/parametres', label: 'Mon profil', icon: Settings, end: true },
      { to: '/organizer/parametres?tab=security', label: 'Sécurité', icon: Shield },
      { to: '/organizer/parametres?tab=preferences', label: 'Préférences', icon: Settings },
    ],
  },
];

function Item({ item }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.to}
      end={item.end}
      className={({ isActive }) => cn('flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition', isActive ? 'bg-blue-50 text-blue-700' : 'text-slate-700 hover:bg-slate-100')}
    >
      <Icon size={17} />
      <span className="flex-1">{item.label}</span>
      {item.badge ? <span className="rounded-full bg-blue-600 px-2 py-0.5 text-[10px] font-bold text-white">{item.badge}</span> : null}
    </NavLink>
  );
}

export default function OrganizerLayout() {
  const nav = useNavigate();
  const user = getUser();
  const displayName = user?.fullName || 'Organisateur';
  const initials = displayName.split(' ').slice(0, 2).map((p) => p[0]?.toUpperCase()).join('');

  function logout() {
    clearSession();
    nav('/login', { replace: true });
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="flex min-h-screen">
        <aside className="hidden w-80 border-r border-slate-200 bg-white xl:flex xl:flex-col">
          <div className="border-b border-slate-200 p-6">
            <div className="flex items-start gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-sm"><BadgeCheck size={20} /></div>
              <div>
                <div className="text-lg font-extrabold leading-tight text-slate-900">Hôtel La<br />Promenade</div>
                <div className="mt-1 text-xs font-semibold text-slate-500">Espace Organisateur</div>
              </div>
            </div>
            <NavLink to="/organizer/creer-evenement" className="mt-6 flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-700">
              <CalendarPlus2 size={18} /> Créer un événement
            </NavLink>
          </div>
          <div className="flex-1 overflow-y-auto px-4 py-5">
            <div className="space-y-5">
              {menuGroups.map((group, idx) => (
                <div key={idx}>
                  {group.title ? <button className="mb-2 flex w-full items-center justify-between px-2 text-xs font-extrabold uppercase tracking-wide text-slate-400"><span>{group.title}</span><ChevronDown size={14} /></button> : null}
                  <div className="space-y-1">{group.items.map((item) => <Item key={item.to} item={item} />)}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="border-t border-slate-200 p-4">
            <button onClick={logout} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-100"><LogOut size={18} /> Déconnexion</button>
          </div>
        </aside>
        <main className="flex-1">
          <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
            <div className="flex items-center justify-between px-4 py-4 sm:px-6">
              <div>
                <div className="text-2xl font-extrabold text-slate-900">Espace Organisateur</div>
                <div className="text-sm text-slate-500">Gérez vos événements et réservations</div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-sm font-extrabold text-white">{initials || 'OR'}</div>
                <div className="hidden sm:block">
                  <div className="text-sm font-bold text-slate-900">{displayName}</div>
                  <div className="text-xs text-slate-500">Organisateur</div>
                </div>
              </div>
            </div>
          </header>
          <div className="p-4 sm:p-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
