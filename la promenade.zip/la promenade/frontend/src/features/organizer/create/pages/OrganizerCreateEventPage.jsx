import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { organizerApi } from '../../api/organizer.api';
import { Alert, PageHeader, PrimaryButton, SecondaryButton, SectionCard, SelectInput, TextAreaInput } from '../../components/OrganizerUi';

const steps = ['Informations générales', 'Salle & Horaires', 'Services', 'Validation'];
const blankServiceRequest = { serviceId: '', quantity: 1, remarks: '' };

function toInputDateTimeParts(value) {
  if (!value) return { date: '', time: '' };
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return { date: '', time: '' };
  const iso = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString();
  return { date: iso.slice(0, 10), time: iso.slice(11, 16) };
}

function combineDateTime(date, time) {
  if (!date || !time) return '';
  return new Date(`${date}T${time}:00`).toISOString();
}

function buildServiceRows(serviceRequests = [], catalog = []) {
  const normalized = Array.isArray(serviceRequests) && serviceRequests.length
    ? serviceRequests.map((item) => ({
        serviceId: item.serviceId || '',
        quantity: Number(item.quantity || 1),
        remarks: item.remarks || '',
      }))
    : [];

  if (normalized.length) return normalized;
  return catalog.length ? [{ ...blankServiceRequest }] : [];
}

export default function OrganizerCreateEventPage() {
  const nav = useNavigate();
  const [params] = useSearchParams();
  const eventId = params.get('id');
  const [step, setStep] = useState(1);
  const [rooms, setRooms] = useState([]);
  const [services, setServices] = useState([]);
  const [serviceRequests, setServiceRequests] = useState([{ ...blankServiceRequest }]);
  const [loading, setLoading] = useState(false);
  const [bootstrapLoading, setBootstrapLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [form, setForm] = useState({ title: '', type: '', description: '', participants: '', budget: '', roomId: '', startDate: '', endDate: '', startTime: '', endTime: '' });

  const startAt = useMemo(() => combineDateTime(form.startDate, form.startTime), [form.startDate, form.startTime]);
  const endAt = useMemo(() => combineDateTime(form.endDate, form.endTime), [form.endDate, form.endTime]);
  const selectedRoom = useMemo(() => rooms.find((room) => room.id === form.roomId), [rooms, form.roomId]);
  const selectedServices = useMemo(() => serviceRequests.filter((item) => item.serviceId), [serviceRequests]);

  async function loadRooms(currentRoomId = '') {
    const roomParams = { startAt: startAt || undefined, endAt: endAt || undefined };
    const roomData = await organizerApi.listRooms(roomParams);
    const normalized = Array.isArray(roomData)
      ? roomData.map((room) => ({ ...room, isAvailable: currentRoomId && room.id === currentRoomId ? true : room.isAvailable }))
      : [];
    setRooms(normalized);
  }

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        setBootstrapLoading(true);
        setError('');
        const serviceData = await organizerApi.listServiceCatalog();
        if (!active) return;
        const catalog = Array.isArray(serviceData) ? serviceData : [];
        setServices(catalog);

        if (eventId) {
          const event = await organizerApi.getEvent(eventId);
          if (!active) return;
          const start = toInputDateTimeParts(event.startAt);
          const end = toInputDateTimeParts(event.endAt);
          setForm({
            title: event.title || '',
            type: event.type || '',
            description: event.description || '',
            participants: String(event.participants || ''),
            budget: String(event.budget || ''),
            roomId: event.roomId || '',
            startDate: start.date,
            startTime: start.time,
            endDate: end.date,
            endTime: end.time,
          });
          setServiceRequests(buildServiceRows(event.serviceRequests, catalog));
          const roomData = await organizerApi.listRooms({ startAt: event.startAt, endAt: event.endAt });
          if (!active) return;
          setRooms(Array.isArray(roomData) ? roomData.map((room) => ({ ...room, isAvailable: room.id === event.roomId ? true : room.isAvailable })) : []);
        } else {
          setServiceRequests(buildServiceRows([], catalog));
          const roomData = await organizerApi.listRooms();
          if (!active) return;
          setRooms(Array.isArray(roomData) ? roomData : []);
        }
      } catch (e) {
        if (active) setError(e?.response?.data?.message || 'Impossible de préparer le formulaire événement.');
      } finally {
        if (active) setBootstrapLoading(false);
      }
    })();
    return () => { active = false; };
  }, [eventId]);

  useEffect(() => {
    if (bootstrapLoading || !startAt || !endAt) return;
    loadRooms(form.roomId).catch(() => {});
  }, [bootstrapLoading, startAt, endAt, form.roomId]);

  function setServiceValue(index, patch) {
    setServiceRequests((prev) => prev.map((item, itemIndex) => (itemIndex === index ? { ...item, ...patch } : item)));
  }

  function addServiceRow() {
    setServiceRequests((prev) => [...prev, { ...blankServiceRequest }]);
  }

  function removeServiceRow(index) {
    setServiceRequests((prev) => (prev.length > 1 ? prev.filter((_, itemIndex) => itemIndex !== index) : [{ ...blankServiceRequest }]));
  }

  const field = (key, placeholder, type = 'text') => (
    <input
      type={type}
      value={form[key] || ''}
      onChange={(e) => setForm({ ...form, [key]: e.target.value })}
      placeholder={placeholder}
      className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-500"
    />
  );

  async function save(submit) {
    setError('');
    setSuccess('');
    if (!form.title || !form.startDate || !form.startTime || !form.endDate || !form.endTime) {
      setError('Titre, date et heure sont obligatoires.');
      return;
    }
    if (startAt && endAt && new Date(startAt) >= new Date(endAt)) {
      setError('La fin doit être après le début.');
      return;
    }
    if (selectedRoom && selectedRoom.isAvailable === false) {
      setError('La salle choisie n’est pas disponible sur ce créneau.');
      return;
    }

    const validServiceRequests = selectedServices.map((item) => ({
      serviceId: item.serviceId,
      quantity: Number(item.quantity || 1),
      remarks: item.remarks || '',
    }));

    const uniqueServiceIds = new Set(validServiceRequests.map((item) => item.serviceId));
    if (uniqueServiceIds.size !== validServiceRequests.length) {
      setError('Un service ne peut être ajouté qu’une seule fois dans le formulaire.');
      return;
    }

    const payload = {
      title: form.title,
      type: form.type,
      description: form.description,
      participants: Number(form.participants || 0),
      budget: Number(form.budget || 0),
      roomId: form.roomId || null,
      startAt,
      endAt,
      submit,
      serviceRequests: validServiceRequests,
    };

    try {
      setLoading(true);
      if (eventId) {
        await organizerApi.updateEvent(eventId, payload);
        setSuccess('Événement mis à jour avec succès.');
      } else {
        await organizerApi.createEvent(payload);
        setSuccess(submit ? 'Événement soumis avec succès.' : 'Brouillon enregistré avec succès.');
      }
      setTimeout(() => nav('/organizer/evenements'), 600);
    } catch (e) {
      setError(e?.response?.data?.message || 'Enregistrement impossible.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <PageHeader title={eventId ? 'Modifier un événement' : 'Créer un événement'} subtitle="Version optimisée et branchée au backend organisateur" />

      {error ? <Alert variant="error">{error}</Alert> : null}
      {success ? <Alert variant="success">{success}</Alert> : null}

      <SectionCard>
        <div className="flex items-center justify-between gap-3 overflow-x-auto">
          {steps.map((label, idx) => (
            <div key={label} className="flex min-w-[120px] items-center gap-3">
              <div className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold ${step >= idx + 1 ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500'}`}>{idx + 1}</div>
              <div className="text-xs font-semibold text-slate-500">{label}</div>
              {idx < steps.length - 1 ? <div className={`hidden h-0.5 w-12 md:block ${step > idx + 1 ? 'bg-blue-600' : 'bg-slate-200'}`} /> : null}
            </div>
          ))}
        </div>
      </SectionCard>

      <SectionCard>
        {bootstrapLoading ? <div>Chargement…</div> : null}

        {!bootstrapLoading && step === 1 ? (
          <div className="grid gap-4">
            <div><label className="text-sm font-semibold">Nom de l’événement *</label>{field('title', 'Nom')}</div>
            <div><label className="text-sm font-semibold">Type d’événement</label><SelectInput value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="mt-2 w-full"><option value="">Sélectionnez un type</option><option value="Mariage">Mariage</option><option value="Réunion">Réunion</option><option value="Séminaire">Séminaire</option><option value="Conférence">Conférence</option><option value="Gala">Gala</option><option value="Atelier">Atelier</option></SelectInput></div>
            <div><label className="text-sm font-semibold">Description</label><TextAreaInput value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={4} placeholder="Décrivez votre événement..." className="mt-2" /></div>
            <div className="grid gap-4 md:grid-cols-2"><div><label className="text-sm font-semibold">Nombre estimé de participants</label>{field('participants', '120', 'number')}</div><div><label className="text-sm font-semibold">Budget prévisionnel</label>{field('budget', '15000', 'number')}</div></div>
          </div>
        ) : null}

        {!bootstrapLoading && step === 2 ? (
          <div className="grid gap-4">
            <div><label className="text-sm font-semibold">Salle souhaitée</label><SelectInput value={form.roomId} onChange={(e) => setForm({ ...form, roomId: e.target.value })} className="mt-2 w-full"><option value="">Aucune salle</option>{rooms.map((room) => <option key={room.id} value={room.id} disabled={room.isAvailable === false && room.id !== form.roomId}>{room.name} ({room.capacity} pers.){room.isAvailable === false && room.id !== form.roomId ? ' — indisponible' : ''}</option>)}</SelectInput></div>
            <div className="grid gap-4 md:grid-cols-2"><div><label className="text-sm font-semibold">Date de début *</label>{field('startDate', '', 'date')}</div><div><label className="text-sm font-semibold">Heure de début *</label>{field('startTime', '', 'time')}</div></div>
            <div className="grid gap-4 md:grid-cols-2"><div><label className="text-sm font-semibold">Date de fin *</label>{field('endDate', '', 'date')}</div><div><label className="text-sm font-semibold">Heure de fin *</label>{field('endTime', '', 'time')}</div></div>
            {selectedRoom ? <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">Salle sélectionnée: <span className="font-semibold">{selectedRoom.name}</span> · capacité {selectedRoom.capacity || 0} · tarif {selectedRoom.pricePerDay || 0}</div> : null}
          </div>
        ) : null}

        {!bootstrapLoading && step === 3 ? (
          <div className="space-y-4">
            {serviceRequests.map((item, index) => {
              const selectedServiceIds = new Set(serviceRequests.filter((row, rowIndex) => rowIndex !== index && row.serviceId).map((row) => row.serviceId));
              return (
                <div key={`${index}-${item.serviceId || 'blank'}`} className="grid gap-3 rounded-xl border border-slate-200 p-4 md:grid-cols-12">
                  <div className="md:col-span-5">
                    <label className="text-sm font-semibold">Service</label>
                    <SelectInput value={item.serviceId} onChange={(e) => setServiceValue(index, { serviceId: e.target.value })} className="mt-2 w-full">
                      <option value="">Choisir un service</option>
                      {services.map((service) => <option key={service.id} value={service.id} disabled={selectedServiceIds.has(service.id)}>{service.name} · {service.category}</option>)}
                    </SelectInput>
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm font-semibold">Quantité</label>
                    <input type="number" min="1" value={item.quantity} onChange={(e) => setServiceValue(index, { quantity: Number(e.target.value) || 1 })} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm" />
                  </div>
                  <div className="md:col-span-4">
                    <label className="text-sm font-semibold">Remarques</label>
                    <input value={item.remarks} onChange={(e) => setServiceValue(index, { remarks: e.target.value })} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm" placeholder="Contraintes, options, précision..." />
                  </div>
                  <div className="md:col-span-1 md:self-end">
                    <SecondaryButton onClick={() => removeServiceRow(index)} className="w-full">—</SecondaryButton>
                  </div>
                </div>
              );
            })}
            <SecondaryButton onClick={addServiceRow}>Ajouter une ligne de service</SecondaryButton>
          </div>
        ) : null}

        {!bootstrapLoading && step === 4 ? (
          <div className="space-y-4 text-sm text-slate-700">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="font-semibold text-slate-900">Résumé</div>
              <div className="mt-2 grid gap-2 md:grid-cols-2">
                <div>Titre: <span className="font-semibold">{form.title || '—'}</span></div>
                <div>Type: <span className="font-semibold">{form.type || '—'}</span></div>
                <div>Participants: <span className="font-semibold">{form.participants || 0}</span></div>
                <div>Budget: <span className="font-semibold">{form.budget || 0}</span></div>
                <div>Salle: <span className="font-semibold">{selectedRoom?.name || 'Aucune'}</span></div>
                <div>Services: <span className="font-semibold">{selectedServices.length}</span></div>
              </div>
            </div>
          </div>
        ) : null}
      </SectionCard>

      <div className="flex justify-between gap-3">
        <SecondaryButton onClick={() => setStep((s) => Math.max(1, s - 1))} disabled={step === 1 || loading}>Précédent</SecondaryButton>
        <div className="flex gap-3">
          {step < steps.length ? <PrimaryButton onClick={() => setStep((s) => Math.min(steps.length, s + 1))}>Suivant</PrimaryButton> : null}
          <SecondaryButton onClick={() => save(false)} disabled={loading}>{loading ? 'Enregistrement…' : 'Enregistrer brouillon'}</SecondaryButton>
          <PrimaryButton onClick={() => save(true)} disabled={loading}>{loading ? 'Envoi…' : 'Soumettre la demande'}</PrimaryButton>
        </div>
      </div>
    </div>
  );
}
