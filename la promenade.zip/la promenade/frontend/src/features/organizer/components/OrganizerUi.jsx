import { cn } from './cn';
import { getStatusClass, getStatusLabel } from '../utils/statusMeta';

export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
      <div>
        <h1 className="text-3xl font-extrabold text-slate-900">{title}</h1>
        {subtitle ? <p className="mt-1 text-sm text-slate-500">{subtitle}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function Alert({ variant = 'info', children }) {
  const tone = {
    info: 'border-slate-200 bg-slate-50 text-slate-700',
    success: 'border-emerald-200 bg-emerald-50 text-emerald-700',
    error: 'border-red-200 bg-red-50 text-red-700',
    warning: 'border-amber-200 bg-amber-50 text-amber-700',
  }[variant];

  return <div className={cn('rounded-xl border px-4 py-3 text-sm', tone)}>{children}</div>;
}

export function EmptyState({ children }) {
  return <SectionCard className="text-sm text-slate-500">{children}</SectionCard>;
}

export function StatCard({ label, value, icon: Icon, accent = 'blue' }) {
  const bg = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-emerald-50 text-emerald-600',
    purple: 'bg-purple-50 text-purple-600',
    orange: 'bg-orange-50 text-orange-600',
  }[accent];

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-xs font-bold uppercase tracking-wide text-slate-400">{label}</div>
          <div className="mt-3 text-3xl font-extrabold text-slate-900">{value}</div>
        </div>
        {Icon ? (
          <div className={cn('flex h-12 w-12 items-center justify-center rounded-2xl', bg)}>
            <Icon size={22} />
          </div>
        ) : null}
      </div>
    </div>
  );
}

export function SectionCard({ title, right, children, className }) {
  return (
    <div className={cn('rounded-2xl border border-slate-200 bg-white p-5 shadow-sm', className)}>
      {(title || right) ? (
        <div className="mb-4 flex items-center justify-between gap-3">
          {title ? <h3 className="text-lg font-bold text-slate-900">{title}</h3> : <div />}
          {right}
        </div>
      ) : null}
      {children}
    </div>
  );
}

export function StatusPill({ status }) {
  return (
    <span className={cn('inline-flex rounded-full px-2.5 py-1 text-xs font-bold', getStatusClass(status))}>
      {getStatusLabel(status)}
    </span>
  );
}

export function Toolbar({ children }) {
  return <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">{children}</div>;
}

export function SearchInput(props) {
  return <input {...props} className={cn('w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm outline-none focus:border-blue-500', props.className)} />;
}

export function SelectInput(props) {
  return <select {...props} className={cn('rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm outline-none focus:border-blue-500', props.className)} />;
}

export function TextAreaInput(props) {
  return <textarea {...props} className={cn('w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-blue-500', props.className)} />;
}

export function PrimaryButton({ className, children, ...props }) {
  return <button {...props} className={cn('rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60', className)}>{children}</button>;
}

export function SecondaryButton({ className, children, ...props }) {
  return <button {...props} className={cn('rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60', className)}>{children}</button>;
}

export function ProgressBar({ value }) {
  return (
    <div>
      <div className="mb-2 flex items-center justify-between text-xs font-semibold text-slate-500"><span>Progression</span><span>{value}%</span></div>
      <div className="h-2 rounded-full bg-slate-100">
        <div className="h-2 rounded-full bg-blue-600" style={{ width: `${Math.min(100, Math.max(0, value || 0))}%` }} />
      </div>
    </div>
  );
}
