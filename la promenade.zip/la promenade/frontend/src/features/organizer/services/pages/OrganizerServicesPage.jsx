import { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { organizerApi } from '../../api/organizer.api';
import { Alert, EmptyState, PageHeader, PrimaryButton, SectionCard, StatusPill, SelectInput, TextAreaInput } from '../../components/OrganizerUi';
import { fmtMoneyCAD } from '@/shared/utils/money';

const routeCategoryMap = {
  '/organizer/services/traiteur': 'Traiteur',
  '/organizer/services/audiovisuel': 'Audiovisuel',
  '/organizer/services/securite': 'Sécurité',
  '/organizer/services/autres': 'Autres',
};

export default function OrganizerServicesPage() {
  const location = useLocation();
  const activeCategory = routeCategoryMap[location.pathname] || '';
  const [catalog, setCatalog] = useState([]);
  const [requests, setRequests] = useState([]);
  const [events, setEvents] = useState([]);
  const [payload, setPayload] = useState({ eventId: '', serviceId: '', quantity: 1, remarks: '' });
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function load() {
    try {
      setLoading(true);
      const params = activeCategory ? { category: activeCategory } : {};
      const [catalogData, requestsData, eventData] = await Promise.all([
        organizerApi.listServiceCatalog(params),
        organizerApi.listServiceRequests(params),
        organizerApi.listEvents(),
      ]);
      setCatalog(Array.isArray(catalogData) ? catalogData : []);
      setRequests(Array.isArray(requestsData) ? requestsData : []);
      setEvents(Array.isArray(eventData) ? eventData.filter((event) => event.status !== 'cancelled') : []);
      setError('');
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger les services.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [activeCategory]);

  const eligibleEvents = useMemo(
    () => events.filter((event) => !['draft', 'cancelled', 'completed'].includes(event.status)),
    [events],
  );

  const alreadyRequested = useMemo(() => new Set(
    requests.filter((request) => request.eventId === payload.eventId).map((request) => request.serviceId),
  ), [payload.eventId, requests]);

  async function submitRequest() {
    try {
      setMessage('');
      await organizerApi.createServiceRequest(payload);
      setMessage('Demande de service créée.');
      setPayload({ eventId: '', serviceId: '', quantity: 1, remarks: '' });
      await load();
    } catch (e) {
      setMessage(e?.response?.data?.message || 'Création impossible.');
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader title={activeCategory ? `Services · ${activeCategory}` : 'Services'} subtitle="Catalogue + demandes réelles" />
      {message ? <Alert variant="info">{message}</Alert> : null}
      {error ? <Alert variant="error">{error}</Alert> : null}
      <SectionCard title="Nouvelle demande de service">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          <SelectInput value={payload.eventId} onChange={(e) => setPayload({ ...payload, eventId: e.target.value, serviceId: '' })}><option value="">Choisir un événement soumis</option>{eligibleEvents.map((event) => <option key={event.id} value={event.id}>{event.title}</option>)}</SelectInput>
          <SelectInput value={payload.serviceId} onChange={(e) => setPayload({ ...payload, serviceId: e.target.value })}><option value="">Choisir un service</option>{catalog.map((service) => <option key={service.id} value={service.id} disabled={alreadyRequested.has(service.id)}>{service.name}</option>)}</SelectInput>
          <input type="number" min="1" value={payload.quantity} onChange={(e) => setPayload({ ...payload, quantity: Number(e.target.value) || 1 })} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" placeholder="Quantité" />
          <PrimaryButton onClick={submitRequest} disabled={loading}>Créer la demande</PrimaryButton>
        </div>
        <TextAreaInput value={payload.remarks} onChange={(e) => setPayload({ ...payload, remarks: e.target.value })} rows={3} className="mt-3" placeholder="Remarques" />
        {!eligibleEvents.length ? <div className="mt-3 text-sm text-amber-700">Soumets d’abord un événement pour créer une demande de service séparée.</div> : null}
      </SectionCard>
      <SectionCard title="Catalogue disponible">
        {loading ? <div className="text-sm text-slate-500">Chargement…</div> : null}
        {!loading && !catalog.length ? <EmptyState>Aucun service disponible.</EmptyState> : null}
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {catalog.map((service) => <div key={service.id} className="rounded-xl border border-slate-200 p-4"><div className="font-semibold text-slate-900">{service.name}</div><div className="mt-1 text-sm text-slate-500">{service.category}</div><div className="mt-2 text-sm text-slate-600">{service.description || 'Sans description.'}</div><div className="mt-3 text-sm font-semibold text-blue-700">{fmtMoneyCAD(service.price || 0)} / {service.unitLabel || 'unité'}</div></div>)}
        </div>
      </SectionCard>
      <SectionCard title="Mes demandes de services">
        {loading ? <div className="text-sm text-slate-500">Chargement…</div> : null}
        {!loading && !requests.length ? <EmptyState>Aucune demande de service.</EmptyState> : null}
        <div className="space-y-3">
          {requests.map((request) => <div key={request.id} className="rounded-xl border border-slate-200 p-4"><div className="flex items-start justify-between gap-3"><div><div className="text-lg font-bold text-slate-900">{request.serviceName}</div><div className="text-sm text-slate-500">{request.eventTitle}</div><div className="mt-2 text-sm text-slate-600">Quantité: {request.quantity} · Estimation: {fmtMoneyCAD(request.estimatedAmount || 0)}</div><div className="mt-1 text-sm text-slate-600">{request.remarks || 'Aucune remarque.'}</div></div><StatusPill status={request.status} /></div></div>)}
        </div>
      </SectionCard>
    </div>
  );
}
