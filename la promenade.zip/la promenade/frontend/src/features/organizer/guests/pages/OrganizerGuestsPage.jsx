import { useEffect, useMemo, useState } from 'react';
import { organizerApi } from '../../api/organizer.api';
import { Alert, EmptyState, PageHeader, PrimaryButton, SecondaryButton, SectionCard, SelectInput, StatusPill } from '../../components/OrganizerUi';

const blankGuest = { eventId: '', firstName: '', lastName: '', email: '', phone: '', company: '', rsvpStatus: 'pending', plusOne: false, notes: '' };

export default function OrganizerGuestsPage() {
  const [events, setEvents] = useState([]);
  const [guests, setGuests] = useState([]);
  const [form, setForm] = useState(blankGuest);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState('');
  const [filterEventId, setFilterEventId] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      setLoading(true);
      const [eventData, guestData] = await Promise.all([
        organizerApi.listEvents(),
        organizerApi.listGuests(filterEventId ? { eventId: filterEventId } : {}),
      ]);
      setEvents(Array.isArray(eventData) ? eventData : []);
      setGuests(Array.isArray(guestData) ? guestData : []);
      setError('');
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger les invités.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [filterEventId]);

  async function saveGuest() {
    try {
      if (editingId) {
        await organizerApi.updateGuest(editingId, form);
        setMessage('Invité mis à jour.');
      } else {
        await organizerApi.createGuest(form);
        setMessage('Invité ajouté.');
      }
      setForm(blankGuest);
      setEditingId('');
      await load();
    } catch (e) {
      setMessage('');
      setError(e?.response?.data?.message || 'Enregistrement impossible.');
    }
  }

  async function removeGuest(id) {
    try {
      await organizerApi.deleteGuest(id);
      setMessage('Invité supprimé.');
      await load();
    } catch (e) {
      setMessage('');
      setError(e?.response?.data?.message || 'Suppression impossible.');
    }
  }

  function startEdit(guest) {
    setEditingId(guest.id);
    setForm({
      eventId: guest.eventId || '',
      firstName: guest.firstName || '',
      lastName: guest.lastName || '',
      email: guest.email || '',
      phone: guest.phone || '',
      company: guest.company || '',
      rsvpStatus: guest.rsvpStatus || 'pending',
      plusOne: Boolean(guest.plusOne),
      notes: guest.notes || '',
    });
  }

  const stats = useMemo(() => ({
    total: guests.length,
    confirmed: guests.filter((guest) => guest.rsvpStatus === 'confirmed').length,
    declined: guests.filter((guest) => guest.rsvpStatus === 'declined').length,
  }), [guests]);

  return (
    <div className="space-y-6">
      <PageHeader title="Invités" subtitle={`Gestion réelle des invités · ${stats.total} invité(s)`} />
      {message ? <Alert variant="success">{message}</Alert> : null}
      {error ? <Alert variant="error">{error}</Alert> : null}
      <SectionCard title={editingId ? 'Modifier un invité' : 'Ajouter un invité'}>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          <SelectInput value={form.eventId} onChange={(e) => setForm({ ...form, eventId: e.target.value })}><option value="">Événement</option>{events.map((event) => <option key={event.id} value={event.id}>{event.title}</option>)}</SelectInput>
          <input value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" placeholder="Prénom" />
          <input value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" placeholder="Nom" />
          <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" placeholder="Email" />
          <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" placeholder="Téléphone" />
          <input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" placeholder="Organisation" />
          <SelectInput value={form.rsvpStatus} onChange={(e) => setForm({ ...form, rsvpStatus: e.target.value })}><option value="pending">En attente</option><option value="confirmed">Confirmé</option><option value="declined">Refusé</option></SelectInput>
          <label className="flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2.5 text-sm"><input type="checkbox" checked={Boolean(form.plusOne)} onChange={(e) => setForm({ ...form, plusOne: e.target.checked })} /> +1 autorisé</label>
        </div>
        <div className="mt-3 flex gap-3">
          <PrimaryButton onClick={saveGuest}>{editingId ? 'Mettre à jour' : 'Ajouter'}</PrimaryButton>
          {editingId ? <SecondaryButton onClick={() => { setEditingId(''); setForm(blankGuest); }}>Annuler</SecondaryButton> : null}
        </div>
      </SectionCard>
      <SectionCard title="Liste des invités" right={<SelectInput value={filterEventId} onChange={(e) => setFilterEventId(e.target.value)}><option value="">Tous les événements</option>{events.map((event) => <option key={event.id} value={event.id}>{event.title}</option>)}</SelectInput>}>
        {loading ? <div className="text-sm text-slate-500">Chargement…</div> : null}
        {!loading && !guests.length ? <EmptyState>Aucun invité.</EmptyState> : null}
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm"><thead className="bg-slate-50 text-left text-slate-500"><tr><th className="px-4 py-3">Nom</th><th className="px-4 py-3">Événement</th><th className="px-4 py-3">Email</th><th className="px-4 py-3">Statut</th><th className="px-4 py-3">Action</th></tr></thead><tbody>{guests.map((guest) => <tr key={guest.id} className="border-t border-slate-100"><td className="px-4 py-3 font-semibold">{guest.firstName} {guest.lastName}</td><td className="px-4 py-3">{guest.eventTitle}</td><td className="px-4 py-3">{guest.email || '—'}</td><td className="px-4 py-3"><StatusPill status={guest.rsvpStatus} /></td><td className="px-4 py-3"><div className="flex gap-2"><SecondaryButton onClick={() => startEdit(guest)}>Modifier</SecondaryButton><button onClick={() => removeGuest(guest.id)} className="rounded-lg border px-3 py-1 text-red-600">Supprimer</button></div></td></tr>)}</tbody></table>
        </div>
      </SectionCard>
    </div>
  );
}
