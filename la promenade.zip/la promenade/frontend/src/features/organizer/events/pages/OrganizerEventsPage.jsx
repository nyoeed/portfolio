import { Eye, Pencil, Trash2 } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { NavLink, useSearchParams } from 'react-router-dom';
import { organizerApi } from '../../api/organizer.api';
import { Alert, EmptyState, PageHeader, ProgressBar, SearchInput, SelectInput, SectionCard, StatusPill, Toolbar, PrimaryButton, SecondaryButton } from '../../components/OrganizerUi';
import { fmtMoneyCAD } from '@/shared/utils/money';

function formatDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString('fr-CA', { dateStyle: 'medium', timeStyle: 'short' });
}

export default function OrganizerEventsPage() {
  const [params] = useSearchParams();
  const initialStatus = params.get('status') || '';
  const [events, setEvents] = useState([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState(initialStatus);
  const [type, setType] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState('');
  const [expandedId, setExpandedId] = useState('');

  async function loadEvents() {
    try {
      setLoading(true);
      const rows = await organizerApi.listEvents({ status: status || undefined, search: search || undefined });
      setEvents(Array.isArray(rows) ? rows : []);
      setError('');
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger les événements.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadEvents(); }, [status]);

  const filtered = useMemo(() => events.filter((event) => {
    const hay = `${event.title || ''} ${event.type || ''} ${event.roomName || ''}`.toLowerCase();
    return hay.includes(search.toLowerCase()) && (!type || event.type === type);
  }), [events, search, type]);

  const types = [...new Set(events.map((e) => e.type).filter(Boolean))];

  async function onCancel(id) {
    if (!window.confirm('Annuler cet événement ?')) return;
    try {
      setBusyId(id);
      await organizerApi.cancelEvent(id);
      await loadEvents();
    } catch (e) {
      setError(e?.response?.data?.message || 'Annulation impossible.');
    } finally {
      setBusyId('');
    }
  }

  const counts = {
    total: events.length,
    draft: events.filter((e) => e.status === 'draft').length,
    submitted: events.filter((e) => ['submitted', 'in_review', 'validated'].includes(e.status)).length,
    confirmed: events.filter((e) => ['confirmed', 'in_coordination', 'in_progress'].includes(e.status)).length,
    completed: events.filter((e) => e.status === 'completed').length,
    cancelled: events.filter((e) => e.status === 'cancelled').length,
  };

  return (
    <div className="space-y-4">
      <PageHeader title="Mes événements" subtitle={`${filtered.length} événement(s)`} action={<NavLink to="/organizer/creer-evenement"><PrimaryButton>Créer un événement</PrimaryButton></NavLink>} />

      {error ? <Alert variant="error">{error}</Alert> : null}

      <SectionCard>
        <div className="flex flex-wrap gap-3 text-sm font-semibold text-slate-600">
          {[
            ['Tous', counts.total, ''],
            ['Brouillons', counts.draft, 'draft'],
            ['Soumis', counts.submitted, 'submitted'],
            ['Confirmés', counts.confirmed, 'confirmed'],
            ['Terminés', counts.completed, 'completed'],
            ['Annulés', counts.cancelled, 'cancelled'],
          ].map(([label, value, valueStatus], idx) => (
            <button key={label} onClick={() => setStatus(valueStatus)} className={`rounded-full px-3 py-1.5 ${status === valueStatus || (!status && idx === 0) ? 'bg-blue-50 text-blue-700' : 'bg-slate-100'}`}>{label}<span className="ml-2 text-xs">{value}</span></button>
          ))}
        </div>
      </SectionCard>

      <Toolbar>
        <SearchInput value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher un événement..." />
        <div className="flex flex-col gap-3 lg:flex-row">
          <SelectInput value={type} onChange={(e) => setType(e.target.value)} className="lg:w-56"><option value="">Tous les types</option>{types.map((value) => <option key={value}>{value}</option>)}</SelectInput>
          <PrimaryButton onClick={loadEvents}>Actualiser</PrimaryButton>
        </div>
      </Toolbar>

      <div className="space-y-4">
        {loading ? <SectionCard>Chargement…</SectionCard> : null}
        {!loading && !filtered.length ? <EmptyState>Aucun événement trouvé.</EmptyState> : null}
        {filtered.map((event) => (
          <SectionCard key={event.id}>
            <div className="flex items-start gap-4">
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-3"><div className="text-2xl font-bold text-slate-900">{event.title}</div><StatusPill status={event.status} /></div>
                <div className="mt-1 text-sm text-slate-500">{event.type || 'Sans type'} · {formatDate(event.startAt)}</div>
                <div className="mt-3 grid gap-3 text-sm text-slate-600 md:grid-cols-3">
                  <div>📍 {event.roomName || 'Salle non assignée'}</div>
                  <div>👥 {event.participants || 0} participants</div>
                  <div>💰 {fmtMoneyCAD(event.budget || 0)}</div>
                </div>
                <div className="mt-2 grid gap-3 text-xs text-slate-500 md:grid-cols-4">
                  <div>Invités: {event.guestCount || 0}</div>
                  <div>Services: {event.serviceCount || 0}</div>
                  <div>Documents: {event.documentCount || 0}</div>
                  <div>Payé: {fmtMoneyCAD(event.paidAmount || 0)}</div>
                </div>
                <div className="mt-4"><ProgressBar value={Number(event.progress || 0)} /></div>
                {expandedId === event.id ? (
                  <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
                    <div><span className="font-semibold">Début:</span> {formatDate(event.startAt)}</div>
                    <div><span className="font-semibold">Fin:</span> {formatDate(event.endAt)}</div>
                    <div><span className="font-semibold">Description:</span> {event.description || 'Aucune description.'}</div>
                  </div>
                ) : null}
              </div>
              <div className="flex flex-col gap-2 text-slate-500">
                <SecondaryButton title="Voir" onClick={() => setExpandedId((current) => current === event.id ? '' : event.id)} className="p-2"><Eye size={16} /></SecondaryButton>
                {['draft', 'submitted', 'in_review'].includes(event.status) ? <NavLink to={`/organizer/creer-evenement?id=${event.id}`} className="rounded-xl border border-slate-200 p-2 hover:bg-slate-50"><Pencil size={16} /></NavLink> : null}
                {!['cancelled', 'completed'].includes(event.status) ? <SecondaryButton disabled={busyId === event.id} onClick={() => onCancel(event.id)} className="p-2 text-red-600"><Trash2 size={16} /></SecondaryButton> : null}
              </div>
            </div>
          </SectionCard>
        ))}
      </div>
    </div>
  );
}
