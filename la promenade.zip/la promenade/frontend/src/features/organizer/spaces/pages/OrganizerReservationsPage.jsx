import { useEffect, useState } from 'react';
import { organizerApi } from '../../api/organizer.api';
import { PageHeader, SectionCard, StatusPill } from '../../components/OrganizerUi';

function formatDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString('fr-CA', { dateStyle: 'medium', timeStyle: 'short' });
}

export default function OrganizerReservationsPage() {
  const [rows, setRows] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    organizerApi.listReservations().then((r) => setRows(Array.isArray(r) ? r : [])).catch((e) => setError(e?.response?.data?.message || 'Impossible de charger les réservations.'));
  }, []);

  return (
    <div className="space-y-6">
      <PageHeader title="Mes réservations" subtitle="Vraie page de réservations, plus de copie de la page événements" />
      {error ? <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div> : null}
      <SectionCard>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-50 text-left text-slate-500"><tr><th className="px-4 py-3">Titre</th><th className="px-4 py-3">Salle</th><th className="px-4 py-3">Dates</th><th className="px-4 py-3">Participants</th><th className="px-4 py-3">Statut</th></tr></thead>
            <tbody>
              {rows.map((row) => <tr key={row.id} className="border-t border-slate-100"><td className="px-4 py-3 font-semibold">{row.title}</td><td className="px-4 py-3">{row.roomName}</td><td className="px-4 py-3">{formatDate(row.startAt)} → {formatDate(row.endAt)}</td><td className="px-4 py-3">{row.participants || 0}</td><td className="px-4 py-3"><StatusPill status={row.status} /></td></tr>)}
            </tbody>
          </table>
          {!rows.length ? <div className="px-4 py-4 text-sm text-slate-500">Aucune réservation trouvée.</div> : null}
        </div>
      </SectionCard>
    </div>
  );
}
