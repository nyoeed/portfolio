import { useEffect, useMemo, useState } from 'react';
import { Alert, EmptyState, PageHeader, SearchInput, SectionCard, PrimaryButton, StatusPill } from '../../components/OrganizerUi';
import { organizerApi } from '../../api/organizer.api';
import { fmtMoneyCAD } from '@/shared/utils/money';
import { toApiFileUrl } from '../../utils/apiFileUrl';

export default function OrganizerRoomsAvailabilityPage() {
  const [rooms, setRooms] = useState([]);
  const [search, setSearch] = useState('');
  const [minCapacity, setMinCapacity] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [startDate, setStartDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endDate, setEndDate] = useState('');
  const [endTime, setEndTime] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  function toIso(date, time) {
    if (!date || !time) return undefined;
    return new Date(`${date}T${time}:00`).toISOString();
  }

  async function load() {
    try {
      setLoading(true);
      const startAt = toIso(startDate, startTime);
      const endAt = toIso(endDate, endTime);
      const data = await organizerApi.listRooms({
        search: search || undefined,
        minCapacity: minCapacity || undefined,
        maxPrice: maxPrice || undefined,
        startAt,
        endAt,
      });
      setRooms(Array.isArray(data) ? data : []);
      setError('');
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger les salles.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => rooms, [rooms]);

  return (
    <div className="space-y-6">
      <PageHeader title="Disponibilités des salles" subtitle="Données réelles depuis /api/organizer/rooms" />
      {error ? <Alert variant="error">{error}</Alert> : null}
      <SectionCard title="Filtres">
        <div className="grid gap-3 lg:grid-cols-4">
          <SearchInput value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher..." />
          <SearchInput value={minCapacity} onChange={(e) => setMinCapacity(e.target.value)} placeholder="Capacité minimum" />
          <SearchInput value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} placeholder="Tarif maximum" />
          <PrimaryButton onClick={load}>Appliquer</PrimaryButton>
        </div>
        <div className="mt-3 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" />
          <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" />
          <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" />
          <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm" />
        </div>
      </SectionCard>
      <div className="grid gap-4 xl:grid-cols-2">
        {loading ? <SectionCard>Chargement…</SectionCard> : null}
        {!loading && !filtered.length ? <EmptyState>Aucune salle trouvée.</EmptyState> : null}
        {filtered.map((room) => (
          <SectionCard key={room.id} className="overflow-hidden p-0">
            {room.imageUrl ? <img src={toApiFileUrl(room.imageUrl)} alt={room.name} className="h-52 w-full object-cover" /> : <div className="flex h-52 items-center justify-center bg-slate-100 text-slate-400">Aucune image</div>}
            <div className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-2xl font-bold text-slate-900">{room.name}</div>
                  <div className="mt-1 text-sm text-slate-500">{room.surface || 0} m²</div>
                  <div className="mt-2 text-sm text-slate-600">👥 {room.capacity || 0} pers.</div>
                  <div className="mt-2 text-sm text-slate-600">Équipements: {room.equipments || '—'}</div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-extrabold text-blue-600">{fmtMoneyCAD(room.pricePerDay || 0)}</div>
                  <div className="text-xs text-slate-500">par jour</div>
                  <div className="mt-2"><StatusPill status={room.isAvailable === false ? 'cancelled' : (room.status === 'available' ? 'confirmed' : room.status)} /></div>
                </div>
              </div>
            </div>
          </SectionCard>
        ))}
      </div>
    </div>
  );
}
