import { useEffect, useState } from 'react';
import { organizerApi } from '../../api/organizer.api';
import { PageHeader, SectionCard, SelectInput } from '../../components/OrganizerUi';

function formatDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString('fr-CA', { dateStyle: 'medium', timeStyle: 'short' });
}

export default function OrganizerRoomsCalendarPage() {
  const [rooms, setRooms] = useState([]);
  const [roomId, setRoomId] = useState('');
  const [calendar, setCalendar] = useState([]);

  useEffect(() => {
    organizerApi.listRooms().then((r) => setRooms(Array.isArray(r) ? r : [])).catch(() => {});
  }, []);

  useEffect(() => {
    organizerApi.getCalendar({ roomId: roomId || undefined }).then((r) => setCalendar(Array.isArray(r) ? r : [])).catch(() => setCalendar([]));
  }, [roomId]);

  return (
    <div className="space-y-6">
      <PageHeader title="Calendrier des salles" subtitle="Réservations actives des salles" />
      <SectionCard>
        <label className="mb-2 block text-sm font-semibold text-slate-700">Filtrer par salle</label>
        <SelectInput value={roomId} onChange={(e) => setRoomId(e.target.value)} className="w-full">
          <option value="">Toutes les salles</option>
          {rooms.map((room) => <option key={room.id} value={room.id}>{room.name}</option>)}
        </SelectInput>
      </SectionCard>
      <SectionCard title="Réservations du calendrier">
        <div className="space-y-3">
          {calendar.map((item) => (
            <div key={item.id} className="rounded-xl border border-slate-200 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-slate-900">{item.title}</div>
                  <div className="text-sm text-slate-500">{item.roomName}</div>
                </div>
                <div className="text-sm text-slate-600">{item.status}</div>
              </div>
              <div className="mt-2 text-sm text-slate-600">{formatDate(item.startAt)} → {formatDate(item.endAt)}</div>
            </div>
          ))}
          {!calendar.length ? <div className="text-sm text-slate-500">Aucune réservation active.</div> : null}
        </div>
      </SectionCard>
    </div>
  );
}
