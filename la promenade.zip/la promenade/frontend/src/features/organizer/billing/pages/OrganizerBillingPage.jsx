import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { PageHeader, SectionCard, StatusPill } from '../../components/OrganizerUi';
import { fmtMoneyCAD } from '@/shared/utils/money';
import { organizerApi } from '../../api/organizer.api';

const PAYMENT_METHODS = ['Virement bancaire', 'Carte bancaire', 'Espèces', 'Chèque'];

function formatDate(value) {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('fr-CA');
}

export default function OrganizerBillingPage() {
  const [params] = useSearchParams();
  const tab = params.get('tab') || 'factures';
  const [data, setData] = useState({ invoices: [], payments: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [openModal, setOpenModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState(PAYMENT_METHODS[0]);
  const [reference, setReference] = useState('');
  const [saving, setSaving] = useState(false);

  async function loadBilling() {
    try {
      setLoading(true);
      setError('');
      const response = await organizerApi.getBilling();
      setData(response || { invoices: [], payments: [] });
    } catch (e) {
      console.error(e);
      setError('Impossible de charger la facturation.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadBilling(); }, []);

  const receipts = useMemo(() => (data.payments || []).filter((p) => p.status === 'completed'), [data]);
  const total = (data.invoices || []).reduce((sum, x) => sum + Number(x.total || 0), 0);
  const paid = (data.invoices || []).filter((x) => x.status === 'paid').length;
  const pending = (data.invoices || []).filter((x) => ['pending', 'partial'].includes(x.status)).length;
  const late = (data.invoices || []).filter((x) => x.status === 'late').length;

  function openSimulation(invoice) {
    setSelectedInvoice(invoice);
    setAmount(String(Number(invoice.remainingAmount || invoice.total || 0)));
    setMethod(PAYMENT_METHODS[0]);
    setReference(`SIM-${invoice.invoiceNumber}`);
    setError('');
    setSuccess('');
    setOpenModal(true);
  }

  async function submitSimulation(e) {
    e.preventDefault();
    if (!selectedInvoice) return;
    try {
      setSaving(true);
      setError('');
      setSuccess('');
      await organizerApi.simulatePayment({
        invoiceId: selectedInvoice.id,
        amount: Number(amount),
        method,
        reference,
      });
      setSuccess('Paiement simulé envoyé à la comptabilité pour validation.');
      setOpenModal(false);
      await loadBilling();
    } catch (e) {
      console.error(e);
      setError(e.message || 'Impossible d’envoyer ce paiement simulé.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Facturation" subtitle="Simulation professionnelle des factures et paiements" />

      {success ? <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">{success}</div> : null}
      {error && !openModal ? <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div> : null}

      <div className="grid gap-4 md:grid-cols-4">
        <SectionCard title="Montant total">{fmtMoneyCAD(total)}</SectionCard>
        <SectionCard title="Factures payées">{paid}</SectionCard>
        <SectionCard title="En attente / partiel">{pending}</SectionCard>
        <SectionCard title="En retard">{late}</SectionCard>
      </div>

      <SectionCard>
        <div className="mb-4 flex gap-3 text-sm font-semibold">
          <span className={tab === 'factures' ? 'text-blue-700' : 'text-slate-500'}>Factures</span>
          <span className={tab === 'paiements' ? 'text-blue-700' : 'text-slate-500'}>Paiements</span>
          <span className={tab === 'recus' ? 'text-blue-700' : 'text-slate-500'}>Reçus</span>
        </div>

        {loading ? <div className="rounded-xl border border-slate-200 p-6 text-sm text-slate-500">Chargement...</div> : null}

        {!loading && tab === 'factures' ? (
          <div className="space-y-3">
            {(data.invoices || []).map((row) => (
              <div key={row.id} className="rounded-xl border border-slate-200 p-4">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                  <div>
                    <div className="font-semibold text-slate-900">{row.invoiceNumber}</div>
                    <div className="text-sm text-slate-500">{row.eventLabel}</div>
                    <div className="mt-2 text-xs text-slate-500">Émise le {formatDate(row.issueDate)} • Échéance {formatDate(row.dueDate)}</div>
                    <div className="mt-1 text-xs text-blue-600">Restant à payer : {fmtMoneyCAD(row.remainingAmount || 0)}</div>
                    {Number(row.pendingPaymentRequests || 0) > 0 ? <div className="mt-1 text-xs text-amber-600">Un paiement simulé est déjà en attente de validation</div> : null}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="font-semibold">{fmtMoneyCAD(row.total || 0)}</div>
                      <StatusPill status={row.status} />
                    </div>
                    {['pending', 'partial', 'late'].includes(row.status) && Number(row.pendingPaymentRequests || 0) === 0 ? (
                      <button type="button" onClick={() => openSimulation(row)} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700">Simuler un paiement</button>
                    ) : null}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : null}

        {!loading && tab === 'paiements' ? (
          <div className="space-y-3">
            {(data.payments || []).map((row) => (
              <div key={row.id} className="rounded-xl border border-slate-200 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-slate-900">{row.paymentNumber || row.reference || row.id}</div>
                    <div className="text-sm text-slate-500">{row.eventLabel}</div>
                    <div className="mt-1 text-xs text-slate-500">{row.method || '-'} • demandé le {formatDate(row.createdAt || row.paidAt)}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{fmtMoneyCAD(row.amount || 0)}</div>
                    <StatusPill status={row.status || 'pending'} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : null}

        {!loading && tab === 'recus' ? (
          <div className="space-y-3">
            {receipts.map((row) => (
              <div key={row.id} className="rounded-xl border border-slate-200 p-4">
                <div className="font-semibold text-slate-900">Reçu {row.paymentNumber || row.reference || row.id}</div>
                <div className="text-sm text-slate-500">{row.eventLabel}</div>
                <div className="mt-1 text-xs text-slate-500">Validé le {formatDate(row.paidAt)}</div>
                <div className="mt-1 font-semibold">{fmtMoneyCAD(row.amount || 0)}</div>
              </div>
            ))}
          </div>
        ) : null}
      </SectionCard>

      {openModal && selectedInvoice ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/30" onClick={() => setOpenModal(false)} />
          <div className="relative z-10 w-full max-w-xl rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
            <div className="mb-4">
              <h2 className="text-xl font-bold text-slate-900">Simuler un paiement</h2>
              <p className="text-sm text-slate-500">Cette demande sera visible par la comptabilité, qui devra la valider manuellement.</p>
            </div>

            {error ? <div className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div> : null}

            <form className="space-y-4" onSubmit={submitSimulation}>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
                <div className="font-semibold text-slate-900">{selectedInvoice.invoiceNumber}</div>
                <div>{selectedInvoice.eventLabel}</div>
                <div className="mt-1 text-xs text-blue-600">Montant restant : {fmtMoneyCAD(selectedInvoice.remainingAmount || 0)}</div>
              </div>

              <label className="block">
                <div className="mb-2 text-sm font-semibold text-slate-700">Montant</div>
                <input type="number" min="0.01" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" />
              </label>

              <label className="block">
                <div className="mb-2 text-sm font-semibold text-slate-700">Méthode</div>
                <select value={method} onChange={(e) => setMethod(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500">
                  {PAYMENT_METHODS.map((item) => <option key={item}>{item}</option>)}
                </select>
              </label>

              <label className="block">
                <div className="mb-2 text-sm font-semibold text-slate-700">Référence</div>
                <input value={reference} onChange={(e) => setReference(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" />
              </label>

              <div className="flex justify-end gap-3 pt-2">
                <button type="button" onClick={() => setOpenModal(false)} className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50">Annuler</button>
                <button type="submit" disabled={saving} className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60">{saving ? 'Envoi...' : 'Envoyer à la comptabilité'}</button>
              </div>
            </form>
          </div>
        </div>
      ) : null}
    </div>
  );
}
