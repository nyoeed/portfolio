export default function AuthShell({ left, right }) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      <div className="mx-auto max-w-6xl px-4 py-10 lg:py-16">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          {left}
          <div className="flex justify-center lg:justify-end">{right}</div>
        </div>
      </div>
    </div>
  );
}
