export default function StatCards() {
  return (
    <div className="mt-10 grid grid-cols-2 gap-4 max-w-md">
      <div className="rounded-xl border border-slate-200 bg-white/70 p-4 shadow-sm">
        <div className="text-xl font-extrabold text-blue-600">500+</div>
        <div className="text-sm text-slate-600">Événements organisés</div>
      </div>
      <div className="rounded-xl border border-slate-200 bg-white/70 p-4 shadow-sm">
        <div className="text-xl font-extrabold text-blue-600">98%</div>
        <div className="text-sm text-slate-600">Satisfaction client</div>
      </div>
    </div>
  );
}
