import { Building2 } from "lucide-react";

export default function BrandPanel({ title, subtitle, children }) {
  return (
    <div className="hidden lg:flex lg:flex-col lg:justify-center lg:pr-12">
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow">
          <Building2 className="text-white" />
        </div>
        <div>
          <div className="text-2xl font-extrabold text-slate-900">Hôtel La Promenade</div>
          <div className="text-sm text-slate-500">Gestion des événements</div>
        </div>
      </div>

      <div className="mt-8">
        <div className="text-3xl font-extrabold text-slate-900 leading-tight">{title}</div>
        <p className="mt-3 text-slate-600 max-w-md">{subtitle}</p>
      </div>

      {children ? <div className="mt-8">{children}</div> : null}
    </div>
  );
}
