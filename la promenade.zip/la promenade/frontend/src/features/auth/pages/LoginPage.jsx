import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import AuthShell from "../components/AuthShell.jsx";
import BrandPanel from "../components/BrandPanel.jsx";
import StatCards from "../components/StatCards.jsx";
import { api } from "../../../lib/api";
import { saveSession, clearSession } from "../../../lib/auth";
import { Eye, EyeOff } from "lucide-react";


function roleToRoute(role) {
  if (role === "admin") return "/admin";
  if (role === "organizer") return "/organizer";
  if (role === "coordinator") return "/coordinator";
  if (role === "accounting") return "/accounting";
  return "/login";
}

export default function LoginPage() {
  const nav = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [alert, setAlert] = useState(null); // {type:'error'|'info', text:''}

  // ✅ sert à afficher/cacher le lien "Initialiser le système"
  const [initialized, setInitialized] = useState(null); // null=loading, true/false

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/api/system/init-status");
        setInitialized(!!res.data.initialized);
      } catch {
        // si backend indisponible, on choisit d'afficher le lien (false)
        // (tu peux mettre true si tu veux le cacher en cas d'erreur)
        setInitialized(false);
      }
    })();
  }, []);

  const emailValid = useMemo(() => {
    if (!email) return true;
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }, [email]);

  async function onSubmit(e) {
    e.preventDefault();
    setAlert(null);

    if (!email || !password) {
      setAlert({ type: "error", text: "Veuillez remplir tous les champs." });
      return;
    }
    if (!emailValid) {
      setAlert({ type: "error", text: "Veuillez entrer un email valide." });
      return;
    }

    setLoading(true);
    try {
      const res = await api.post("/api/auth/login", { email, password });
      const { token, user } = res.data;

      // status logic
      if (user.status === "pending") {
        clearSession();
        setAlert({ type: "info", text: "Votre compte est en attente d’approbation…" });
        nav("/pending-approval", { replace: true });
        return;
      }

      if (user.status === "rejected") {
        clearSession();
        setAlert({ type: "error", text: "Votre demande a été rejetée." });
        return;
      }

      // approved
      saveSession(token, user);
      nav(roleToRoute(user.role), { replace: true });
    } catch (err) {
      setAlert({ type: "error", text: "Email ou mot de passe incorrect." });
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell
      left={
        <BrandPanel
          title="Gérez vos événements en toute simplicité"
          subtitle="Planifiez, coordonnez et gérez vos événements professionnels et privés avec notre plateforme complète."
        >
          <StatCards />
        </BrandPanel>
      }
      right={
        <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200">
          <div className="px-8 pt-8 pb-6">
            <h1 className="text-2xl font-extrabold text-slate-900 text-center">Connexion</h1>
            <p className="mt-2 text-center text-sm text-slate-600">
              Accédez à votre espace de gestion des événements
            </p>

            {alert ? (
              <div
                className={[
                  "mt-5 rounded-xl border px-4 py-3 text-sm",
                  alert.type === "error"
                    ? "border-red-200 bg-red-50 text-red-800"
                    : "border-blue-200 bg-blue-50 text-blue-800",
                ].join(" ")}
              >
                {alert.text}
              </div>
            ) : null}

            <form className="mt-6 space-y-4" onSubmit={onSubmit}>
              <div>
                <label className="text-sm font-semibold text-slate-800">Adresse email</label>
                <input
                  className={[
                    "mt-2 w-full rounded-xl border bg-slate-50 px-4 py-3 outline-none",
                    emailValid ? "border-slate-200 focus:border-blue-500" : "border-red-300",
                  ].join(" ")}
                  placeholder="votre.email@exemple.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                />
                {!emailValid ? (
                  <div className="mt-1 text-xs text-red-600">Format email invalide.</div>
                ) : null}
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">Mot de passe</label>
                <div className="relative mt-2">
                  <input
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 pr-12 outline-none focus:border-blue-500"
                    placeholder="••••••••"
                    type={showPw ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    aria-label={showPw ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                    onClick={() => setShowPw((s) => !s)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-2 text-slate-500 hover:bg-slate-100"
                  >
                    {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end"><Link to="/forgot-password" className="text-sm font-semibold text-blue-600 hover:underline">Mot de passe oublié ?</Link></div>

              <button
                disabled={loading}
                className={[
                  "w-full rounded-xl py-3 font-semibold text-white shadow-sm",
                  "bg-gradient-to-r from-blue-600 to-indigo-600",
                  "hover:opacity-95 active:opacity-90",
                  loading ? "opacity-70 cursor-not-allowed" : "",
                ].join(" ")}
              >
                {loading ? "Connexion…" : "Se connecter"}
              </button>
            </form>

            <div className="mt-6 border-t pt-5 text-center text-sm text-slate-600">
              Pas encore de compte ?{" "}
              <Link className="font-semibold text-blue-600 hover:underline" to="/register">
                S’inscrire
              </Link>
            </div>

            {/* ✅ Afficher le lien init uniquement si le système N'EST PAS initialisé */}
            {initialized === false ? (
              <div className="mt-2 text-center text-xs text-slate-500">
                Premier démarrage ?{" "}
                <Link className="text-blue-600 hover:underline" to="/init-admin">
                  Initialiser le système
                </Link>
              </div>
            ) : null}
          </div>
        </div>
      }
    />
  );
}
