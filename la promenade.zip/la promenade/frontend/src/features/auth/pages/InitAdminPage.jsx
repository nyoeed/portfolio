import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, Shield } from "lucide-react";

import AuthShell from "@/features/auth/components/AuthShell.jsx";
import BrandPanel from "@/features/auth/components/BrandPanel.jsx";
import { api } from "@/lib/api.js";
import { saveSession } from "@/lib/auth.js";

export default function InitAdminPage() {
  const nav = useNavigate();

  const [initialized, setInitialized] = useState(null); // null loading / true / false
  const [loading, setLoading] = useState(false);
  const [alert, setAlert] = useState(null);

  const [fullName, setFullName] = useState("Administrateur Principal");
  const [email, setEmail] = useState("admin@hotellapromenade.com");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");
  const [secretKey, setSecretKey] = useState("");

  const [showPw, setShowPw] = useState(false);
  const [showPw2, setShowPw2] = useState(false);
  const [showSecret, setShowSecret] = useState(false);

  const emailValid = useMemo(() => {
    if (!email) return true;
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  }, [email]);

  // ✅ Mot de passe fort: min 8 + maj + min + chiffre + special
  const passwordStrong = useMemo(() => {
    if (!password) return true;
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/.test(password);
  }, [password]);

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/api/system/init-status");
        const init = !!res.data.initialized;

        setInitialized(init);

        // ✅ si admin existe -> page "disparaît"
        if (init) {
          nav("/login", { replace: true }); // ou "/admin"
        }
      } catch {
        setInitialized(false);
      }
    })();
  }, [nav]);

  async function onSubmit(e) {
    e.preventDefault();
    setAlert(null);

    const fullNameT = fullName.trim();
    const emailT = email.trim();
    const passwordT = password.trim();
    const password2T = password2.trim();
    const secretKeyT = secretKey.trim();

    if (!fullNameT && !emailT && !passwordT && !password2T && !secretKeyT) {
      setAlert({ type: "error", text: "Veuillez remplir tous les champs." });
      return;
    }

    if (!fullNameT) {
      setAlert({ type: "error", text: "Veuillez remplir votre nom complet." });
      return;
    }

    if (!emailT) {
      setAlert({ type: "error", text: "Veuillez renseigner votre adresse email." });
      return;
    }

    if (!emailValid) {
      setAlert({ type: "error", text: "Veuillez entrer un email valide." });
      return;
    }

    if (!passwordT) {
      setAlert({ type: "error", text: "Veuillez saisir votre mot de passe." });
      return;
    }

    if (passwordT.length < 8) {
      setAlert({ type: "error", text: "Mot de passe : minimum 8 caractères." });
      return;
    }

    if (!passwordStrong) {
      setAlert({
        type: "error",
        text:
          "Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule, un chiffre et un caractère spécial.",
      });
      return;
    }

    if (!password2T) {
      setAlert({ type: "error", text: "Veuillez confirmer votre mot de passe." });
      return;
    }

    if (passwordT !== password2T) {
      setAlert({ type: "error", text: "Les mots de passe ne correspondent pas." });
      return;
    }

    if (!secretKeyT) {
      setAlert({ type: "error", text: "Veuillez saisir votre clé secrète." });
      return;
    }

    setLoading(true);

    try {
      const res = await api.post("/api/system/init-admin", {
        fullName: fullNameT,
        email: emailT,
        password: passwordT,
        secretKey: secretKeyT,
      });

      const { token, user } = res.data;
      saveSession(token, user);
      nav("/admin", { replace: true });
    } catch (err) {
      const status = err?.response?.status;

      if (status === 409) {
        setInitialized(true);
        setAlert({
          type: "info",
          text:
            "Le premier administrateur a déjà été créé. La création de nouveaux admins se fait désormais en interne par un administrateur existant.",
        });
      } else if (status === 403) {
        setAlert({ type: "error", text: "Clé secrète invalide." });
      } else {
        setAlert({ type: "error", text: "Une erreur est survenue…" });
      }
    } finally {
      setLoading(false);
    }
  }

  // checklist helpers (UX)
  const hasMinLen = password.length >= 8;
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasDigit = /\d/.test(password);
  const hasSpecial = /[^A-Za-z\d]/.test(password);

  const left = (
    <BrandPanel
      title="Initialisation du système"
      subtitle="Cette page sert uniquement à créer le premier compte administrateur. Une fois le système initialisé, la création d’autres administrateurs se fera en interne."
    >
      <div className="mt-8 space-y-4 max-w-md">
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          <div className="font-semibold">Important</div>
          <div className="mt-1">
            Cette page doit être utilisée{" "}
            <span className="font-semibold">une seule fois</span> pour créer le premier compte
            administrateur.
          </div>
        </div>

        <div className="rounded-xl border border-blue-200 bg-blue-50 p-4 text-sm text-blue-900">
          <div className="font-semibold">Clé secrète</div>
          <div className="mt-1">
            La clé d’initialisation est configurée via la variable d’environnement{" "}
            <span className="font-mono font-semibold">INIT_ADMIN_SECRET</span> côté serveur.
          </div>
        </div>
      </div>
    </BrandPanel>
  );

  const card = (
    <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200">
      <div className="px-8 pt-8 pb-7">
        <div className="mx-auto h-12 w-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow">
          <Shield className="text-white" />
        </div>

        <h1 className="mt-4 text-2xl font-extrabold text-slate-900 text-center">
          Créer un administrateur
        </h1>

        <p className="mt-2 text-center text-sm text-slate-600">
          Initialisation du système avec le premier compte admin
        </p>

        {alert ? (
          <div
            className={[
              "mt-5 rounded-xl border px-4 py-3 text-sm",
              alert.type === "error"
                ? "border-red-200 bg-red-50 text-red-800"
                : "border-blue-200 bg-blue-50 text-blue-800",
            ].join(" ")}
          >
            {alert.text}
          </div>
        ) : null}

        {initialized === true ? (
          <div className="mt-6 space-y-4">
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
              <div className="font-semibold text-slate-900">Système déjà initialisé</div>
              <div className="mt-1">
                Le premier administrateur a déjà été créé. Pour créer un nouvel administrateur,
                connectez-vous avec un compte admin existant et faites-le depuis l’interface interne.
              </div>
            </div>

            <Link
              to="/login"
              className="inline-flex w-full items-center justify-center rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 py-3 font-semibold text-white hover:opacity-95"
            >
              Se connecter
            </Link>
          </div>
        ) : (
          <>
            <form className="mt-6 space-y-4" onSubmit={onSubmit}>
              <div>
                <label className="text-sm font-semibold text-slate-800">Nom complet</label>
                <input
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">Adresse email</label>
                <input
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                {!emailValid && email.trim() ? (
                  <div className="mt-2 text-xs text-red-600">Email invalide.</div>
                ) : null}
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">Mot de passe</label>
                <div className="relative mt-2">
                  <input
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 pr-12 outline-none focus:border-blue-500"
                    type={showPw ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw((s) => !s)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-2 text-slate-500 hover:bg-slate-100"
                    aria-label={showPw ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                  >
                    {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>

                {password.trim() ? (
                  <ul className="mt-2 text-xs text-slate-600 space-y-1">
                    <li className={hasMinLen ? "text-green-600" : ""}>• Minimum 8 caractères</li>
                    <li className={hasUpper ? "text-green-600" : ""}>• Une majuscule (A-Z)</li>
                    <li className={hasLower ? "text-green-600" : ""}>• Une minuscule (a-z)</li>
                    <li className={hasDigit ? "text-green-600" : ""}>• Un chiffre (0-9)</li>
                    <li className={hasSpecial ? "text-green-600" : ""}>
                      • Un caractère spécial (ex: !@#$)
                    </li>
                  </ul>
                ) : null}
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">
                  Confirmer le mot de passe
                </label>
                <div className="relative mt-2">
                  <input
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 pr-12 outline-none focus:border-blue-500"
                    type={showPw2 ? "text" : "password"}
                    value={password2}
                    onChange={(e) => setPassword2(e.target.value)}
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw2((s) => !s)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-2 text-slate-500 hover:bg-slate-100"
                    aria-label={showPw2 ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                  >
                    {showPw2 ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>

                {password2.trim() && password.trim() && password.trim() !== password2.trim() ? (
                  <div className="mt-2 text-xs text-red-600">
                    Les mots de passe ne correspondent pas.
                  </div>
                ) : null}
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">
                  Clé secrète d’initialisation
                </label>

                <div className="relative mt-2">
                  <input
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 pr-12 outline-none focus:border-blue-500"
                    type={showSecret ? "text" : "password"}
                    value={secretKey}
                    placeholder="Saisir la clé d’initialisation"
                    onChange={(e) => setSecretKey(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowSecret((s) => !s)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-2 text-slate-500 hover:bg-slate-100"
                    aria-label={showSecret ? "Masquer la clé" : "Afficher la clé"}
                  >
                    {showSecret ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>

                <div className="mt-2 text-xs text-slate-500">
                  Cette clé est définie côté serveur (variable{" "}
                  <span className="font-mono">INIT_ADMIN_SECRET</span>).
                </div>
              </div>

              <button
                disabled={loading}
                className={[
                  "w-full rounded-xl py-3 font-semibold text-white shadow-sm",
                  "bg-gradient-to-r from-blue-600 to-indigo-600",
                  loading ? "opacity-70 cursor-not-allowed" : "hover:opacity-95 active:opacity-90",
                ].join(" ")}
              >
                {loading ? "Création…" : "Créer l’administrateur"}
              </button>
            </form>

            <div className="mt-6 border-t pt-5 text-center text-sm text-slate-600">
              Déjà configuré ?{" "}
              <Link className="font-semibold text-blue-600 hover:underline" to="/login">
                Se connecter
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );

  return <AuthShell left={left} right={card} />;
}
