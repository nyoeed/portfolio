import { useState } from "react";
import { Link } from "react-router-dom";
import AuthShell from "../components/AuthShell.jsx";
import BrandPanel from "../components/BrandPanel.jsx";
import StatCards from "../components/StatCards.jsx";
import { api } from "../../../lib/api";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [token, setToken] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    setMessage("");
    setToken("");
    try {
      const { data } = await api.post("/api/auth/forgot-password", { email });
      setMessage(data?.message || "Demande envoyée.");
      setToken(data?.resetToken || "");
    } catch (err) {
      setError(err?.response?.data?.message || "Impossible d’envoyer la demande.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell
      left={<BrandPanel title="Récupérez l’accès à votre compte" subtitle="Demandez un lien de réinitialisation sécurisé pour continuer votre gestion des événements."><StatCards /></BrandPanel>}
      right={<div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200 px-8 py-8">
        <h1 className="text-2xl font-extrabold text-slate-900 text-center">Mot de passe oublié</h1>
        <p className="mt-2 text-center text-sm text-slate-600">Entrez votre email pour recevoir un lien de réinitialisation.</p>
        {error ? <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div> : null}
        {message ? <div className="mt-4 rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">{message}</div> : null}
        {token ? <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900 break-all"><div className="font-extrabold mb-1">Jeton de réinitialisation</div>{token}</div> : null}
        <form className="mt-6 space-y-4" onSubmit={onSubmit}>
          <div>
            <label className="text-sm font-semibold text-slate-800">Adresse email</label>
            <input className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="votre.email@exemple.com" />
          </div>
          <button disabled={loading} className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 py-3 font-semibold text-white disabled:opacity-70">{loading ? 'Envoi…' : 'Envoyer le lien'}</button>
        </form>
        <div className="mt-6 text-center text-sm text-slate-600">Déjà un jeton ? <Link className="font-semibold text-blue-600 hover:underline" to="/reset-password">Réinitialiser le mot de passe</Link></div>
        <div className="mt-2 text-center text-sm text-slate-600"><Link className="font-semibold text-slate-700 hover:underline" to="/login">Retour à la connexion</Link></div>
      </div>}
    />
  );
}
