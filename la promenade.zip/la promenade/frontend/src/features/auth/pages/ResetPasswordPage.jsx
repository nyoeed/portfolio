import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AuthShell from "../components/AuthShell.jsx";
import BrandPanel from "../components/BrandPanel.jsx";
import StatCards from "../components/StatCards.jsx";
import { api } from "../../../lib/api";

export default function ResetPasswordPage() {
  const nav = useNavigate();
  const [token, setToken] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    setMessage("");
    if (!token || !password || !confirmPassword) return setError("Tous les champs sont requis.");
    if (password !== confirmPassword) return setError("Les mots de passe ne correspondent pas.");
    setLoading(true);
    try {
      const { data } = await api.post("/api/auth/reset-password", { token, password });
      setMessage(data?.message || "Mot de passe mis à jour.");
      setTimeout(() => nav("/login"), 800);
    } catch (err) {
      setError(err?.response?.data?.message || "Impossible de réinitialiser le mot de passe.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell
      left={<BrandPanel title="Créez un nouveau mot de passe" subtitle="Entrez le jeton reçu et définissez un nouveau mot de passe sécurisé."><StatCards /></BrandPanel>}
      right={<div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200 px-8 py-8">
        <h1 className="text-2xl font-extrabold text-slate-900 text-center">Réinitialiser le mot de passe</h1>
        {error ? <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div> : null}
        {message ? <div className="mt-4 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">{message}</div> : null}
        <form className="mt-6 space-y-4" onSubmit={onSubmit}>
          <textarea rows={4} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" placeholder="Collez ici le jeton de réinitialisation" value={token} onChange={(e) => setToken(e.target.value)} />
          <input type="password" className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" placeholder="Nouveau mot de passe" value={password} onChange={(e) => setPassword(e.target.value)} />
          <input type="password" className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500" placeholder="Confirmer le mot de passe" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
          <button disabled={loading} className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 py-3 font-semibold text-white disabled:opacity-70">{loading ? 'Enregistrement…' : 'Mettre à jour le mot de passe'}</button>
        </form>
        <div className="mt-6 text-center text-sm text-slate-600"><Link className="font-semibold text-slate-700 hover:underline" to="/login">Retour à la connexion</Link></div>
      </div>}
    />
  );
}
