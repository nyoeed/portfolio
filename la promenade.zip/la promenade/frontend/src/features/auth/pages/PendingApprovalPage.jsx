import { Link } from "react-router-dom";
import { Clock, Mail, Building2 } from "lucide-react";

export default function PendingApprovalPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 flex items-center justify-center px-4">
      <div className="w-full max-w-xl rounded-2xl bg-white shadow-xl border border-slate-200">
        <div className="px-8 pt-8 pb-7 text-center">
          <div className="mx-auto h-14 w-14 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow">
            <Building2 className="text-white" />
          </div>

          <div className="mt-4 text-2xl font-extrabold text-slate-900">Hôtel La Promenade</div>
          <div className="text-sm text-slate-500">Gestion des événements</div>

          <div className="mt-6 mx-auto h-16 w-16 rounded-full bg-amber-50 flex items-center justify-center border border-amber-200">
            <Clock className="text-amber-600" />
          </div>

          <h1 className="mt-6 text-xl font-extrabold text-slate-900">
            Compte en attente d&apos;approbation
          </h1>

          <p className="mt-2 text-sm text-slate-600">
            Votre demande de compte a été enregistrée avec succès et est actuellement en cours
            d&apos;examen par notre équipe d&apos;administration.
          </p>

          <div className="mt-6 rounded-xl border border-blue-200 bg-blue-50 p-4 text-left">
            <div className="flex items-start gap-3">
              <div className="mt-1">
                <Mail className="text-blue-700" size={18} />
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-900">
                  Que se passe-t-il maintenant ?
                </div>
                <div className="mt-1 text-sm text-slate-700">
                  Vous recevrez une notification par email dès que votre compte sera approuvé.
                  Ce processus prend généralement 24 à 48 heures.
                </div>
              </div>
            </div>
          </div>

          <div className="mt-5 text-sm text-slate-600">
            Si vous avez des questions, contactez notre équipe :
            <div className="mt-1 font-semibold text-blue-700">support@hotellapromenade.com</div>
          </div>

          <div className="mt-7 border-t pt-5">
            <Link
              to="/login"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 font-semibold text-slate-800 hover:bg-slate-50"
            >
              ← Retour à la page de connexion
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
