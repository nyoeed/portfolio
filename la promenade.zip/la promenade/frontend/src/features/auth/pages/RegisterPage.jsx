import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";

import AuthShell from "@/features/auth/components/AuthShell.jsx";
import BrandPanel from "@/features/auth/components/BrandPanel.jsx";
import { api } from "@/lib/api.js";

export default function RegisterPage() {
  const nav = useNavigate();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [roleRequested, setRoleRequested] = useState("");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");

  const [showPw1, setShowPw1] = useState(false);
  const [showPw2, setShowPw2] = useState(false);

  const [loading, setLoading] = useState(false);
  const [alert, setAlert] = useState(null);

  const emailValid = useMemo(() => {
    if (!email) return true;
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  }, [email]);

  // ✅ Mot de passe fort: min 8 + maj + min + chiffre + special
  const passwordStrong = useMemo(() => {
    if (!password) return true; // l'erreur "vide" gérée ailleurs
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/.test(password);
  }, [password]);

  async function onSubmit(e) {
    e.preventDefault();
    setAlert(null);

    const fullNameT = fullName.trim();
    const emailT = email.trim();
    const passwordT = password.trim();
    const password2T = password2.trim();
    const roleT = roleRequested.trim();

    if (!fullNameT && !emailT && !roleT && !passwordT && !password2T) {
      setAlert({ type: "error", text: "Veuillez remplir tous les champs." });
      return;
    }

    if (!fullNameT) {
      setAlert({ type: "error", text: "Veuillez remplir votre nom complet." });
      return;
    }

    if (!emailT) {
      setAlert({ type: "error", text: "Veuillez renseigner votre adresse email." });
      return;
    }

    if (!emailValid) {
      setAlert({ type: "error", text: "Veuillez entrer un email valide." });
      return;
    }

    if (!roleT) {
      setAlert({ type: "error", text: "Veuillez sélectionner un rôle." });
      return;
    }

    if (!passwordT) {
      setAlert({ type: "error", text: "Veuillez saisir votre mot de passe." });
      return;
    }

    if (passwordT.length < 8) {
      setAlert({ type: "error", text: "Mot de passe : minimum 8 caractères." });
      return;
    }

    if (!passwordStrong) {
      setAlert({
        type: "error",
        text:
          "Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule, un chiffre et un caractère spécial.",
      });
      return;
    }

    if (!password2T) {
      setAlert({ type: "error", text: "Veuillez confirmer votre mot de passe." });
      return;
    }

    if (passwordT !== password2T) {
      setAlert({ type: "error", text: "Les mots de passe ne correspondent pas." });
      return;
    }

    setLoading(true);
    try {
      await api.post("/api/auth/register", {
        fullName: fullNameT,
        email: emailT,
        password: passwordT,
        roleRequested: roleT,
      });

      nav("/pending-approval", { replace: true });
    } catch (err) {
      const msg =
        err?.response?.status === 409
          ? "Cet email est déjà enregistré."
          : "Une erreur est survenue…";
      setAlert({ type: "error", text: msg });
    } finally {
      setLoading(false);
    }
  }

  // helpers checklist (pour UX)
  const hasMinLen = password.length >= 8;
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasDigit = /\d/.test(password);
  const hasSpecial = /[^A-Za-z\d]/.test(password);

  return (
    <AuthShell
      left={
        <BrandPanel
          title="Rejoignez notre plateforme"
          subtitle="Créez votre compte pour accéder à notre plateforme de gestion d’événements. Votre demande sera examinée par notre équipe."
        >
          <div className="mt-10 rounded-xl border border-slate-200 bg-white/70 p-4 text-sm text-slate-700 max-w-md">
            <div className="font-semibold mb-2">Rôles disponibles :</div>
            <ul className="list-disc pl-5 space-y-1">
              <li>
                <span className="font-semibold">Organisateur</span> : Créer et gérer vos événements
              </li>
              <li>
                <span className="font-semibold">Coordonnateur</span> : Coordonner les services de
                l’hôtel
              </li>
              <li>
                <span className="font-semibold">Comptabilité</span> : Gérer la facturation et les
                paiements
              </li>
            </ul>
          </div>
        </BrandPanel>
      }
      right={
        <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl border border-slate-200">
          <div className="px-8 pt-8 pb-7">
            <h1 className="text-2xl font-extrabold text-slate-900 text-center">Inscription</h1>
            <p className="mt-2 text-center text-sm text-slate-600">
              Créez votre compte pour commencer
            </p>

            {alert ? (
              <div className="mt-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
                {alert.text}
              </div>
            ) : null}

            <form className="mt-6 space-y-4" onSubmit={onSubmit}>
              <div>
                <label className="text-sm font-semibold text-slate-800">Nom complet</label>
                <input
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                  placeholder="Jean Dupont"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">Adresse email</label>
                <input
                  className={[
                    "mt-2 w-full rounded-xl border bg-slate-50 px-4 py-3 outline-none",
                    emailValid ? "border-slate-200 focus:border-blue-500" : "border-red-300",
                  ].join(" ")}
                  placeholder="jean.dupont@exemple.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                />
                {!emailValid && email.trim() ? (
                  <div className="mt-1 text-xs text-red-600">Format email invalide.</div>
                ) : null}
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">Rôle</label>
                <select
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-500"
                  value={roleRequested}
                  onChange={(e) => setRoleRequested(e.target.value)}
                >
                  <option value="">Sélectionnez votre rôle</option>
                  <option value="organizer">Organisateur</option>
                  <option value="coordinator">Coordonnateur</option>
                  <option value="accounting">Comptabilité</option>
                </select>
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">Mot de passe</label>
                <div className="relative mt-2">
                  <input
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 pr-12 outline-none focus:border-blue-500"
                    type={showPw1 ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="new-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw1((s) => !s)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-2 text-slate-500 hover:bg-slate-100"
                    aria-label={showPw1 ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                  >
                    {showPw1 ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>

                {/* ✅ Checklist pro */}
                {password.trim() ? (
                  <ul className="mt-2 text-xs text-slate-600 space-y-1">
                    <li className={hasMinLen ? "text-green-600" : ""}>• Minimum 8 caractères</li>
                    <li className={hasUpper ? "text-green-600" : ""}>• Une majuscule (A-Z)</li>
                    <li className={hasLower ? "text-green-600" : ""}>• Une minuscule (a-z)</li>
                    <li className={hasDigit ? "text-green-600" : ""}>• Un chiffre (0-9)</li>
                    <li className={hasSpecial ? "text-green-600" : ""}>
                      • Un caractère spécial (ex: !@#$)
                    </li>
                  </ul>
                ) : null}
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">
                  Confirmer le mot de passe
                </label>
                <div className="relative mt-2">
                  <input
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 pr-12 outline-none focus:border-blue-500"
                    type={showPw2 ? "text" : "password"}
                    placeholder="••••••••"
                    value={password2}
                    onChange={(e) => setPassword2(e.target.value)}
                    autoComplete="new-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw2((s) => !s)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-2 text-slate-500 hover:bg-slate-100"
                    aria-label={showPw2 ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                  >
                    {showPw2 ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>

                {password2.trim() && password.trim() && password !== password2 ? (
                  <div className="mt-2 text-xs text-red-600">Les mots de passe ne correspondent pas.</div>
                ) : null}
              </div>

              <button
                disabled={loading}
                className={[
                  "w-full rounded-xl py-3 font-semibold text-white shadow-sm",
                  "bg-gradient-to-r from-blue-600 to-indigo-600",
                  loading ? "opacity-70 cursor-not-allowed" : "hover:opacity-95 active:opacity-90",
                ].join(" ")}
              >
                {loading ? "Inscription…" : "S’inscrire"}
              </button>

              <div className="text-xs text-slate-500 text-center">
                Votre demande sera examinée par l’administrateur.
              </div>
            </form>

            <div className="mt-6 border-t pt-5 text-center text-sm text-slate-600">
              Vous avez déjà un compte ?{" "}
              <Link className="font-semibold text-blue-600 hover:underline" to="/login">
                Se connecter
              </Link>
            </div>
          </div>
        </div>
      }
    />
  );
}
