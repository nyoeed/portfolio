import { api } from '@/lib/api';

export async function getMyAccount() {
  const res = await api.get('/api/auth/me');
  return res.data || {};
}

export async function updateMyAccount(payload) {
  const res = await api.patch('/api/auth/me', payload);
  return res.data || {};
}
