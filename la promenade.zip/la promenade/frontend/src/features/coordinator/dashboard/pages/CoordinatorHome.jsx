export default function CoordinatorHome() {
  return <div className="p-6 text-xl font-bold">Coordinator Dashboard ✅</div>;
}
