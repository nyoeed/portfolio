import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutGrid, CalendarRange, Bell, BriefcaseBusiness, FileText,
  CalendarDays, LogOut, BadgeCheck, Search, Building2, Settings,
} from 'lucide-react';
import { clearSession, getUser } from '@/lib/auth';

const groups = [
  {
    title: 'Principal',
    items: [
      { to: '/coordinator', label: 'Vue générale', icon: LayoutGrid, end: true },
      { to: '/coordinator/evenements', label: 'Événements', icon: CalendarDays },
      { to: '/coordinator/salles', label: 'Réservations & salles', icon: Building2 },
      { to: '/coordinator/services', label: 'Services', icon: BriefcaseBusiness },
    ],
  },
  {
    title: 'Support',
    items: [
      { to: '/coordinator/alertes', label: 'Alertes & notifications', icon: Bell },
      { to: '/coordinator/rapports', label: 'Rapports', icon: FileText },
      { to: '/coordinator/parametres', label: 'Paramètres', icon: Settings },
    ],
  },
];

function SideItem({ to, icon: Icon, label, end }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        [
          'flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-semibold transition',
          isActive ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-700 hover:bg-slate-100',
        ].join(' ')
      }
    >
      <Icon size={18} />
      <span>{label}</span>
    </NavLink>
  );
}

export default function CoordinatorLayout() {
  const nav = useNavigate();
  const user = getUser();
  const initials = (user?.fullName || 'Coordonnateur')
    .split(' ')
    .slice(0, 2)
    .map((x) => x[0]?.toUpperCase())
    .join('');

  function logout() {
    clearSession();
    nav('/login', { replace: true });
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="flex min-h-screen">
        <aside className="hidden w-80 border-r border-slate-200 bg-white xl:flex xl:flex-col">
          <div className="border-b border-slate-200 p-6">
            <div className="flex items-start gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-sm">
                <BadgeCheck size={20} />
              </div>
              <div>
                <div className="text-lg font-extrabold leading-tight text-slate-900">Hôtel La<br />Promenade</div>
                <div className="mt-1 text-xs font-semibold text-slate-500">Espace coordonnateur</div>
              </div>
            </div>

            <div className="mt-5 flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2">
              <Search size={16} className="text-slate-400" />
              <input className="w-full bg-transparent text-sm outline-none" placeholder="Recherche rapide dans le menu" />
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2 text-xs font-bold">
              <NavLink to="/coordinator/evenements" className="rounded-xl bg-blue-600 px-3 py-2 text-center text-white">Événements</NavLink>
              <NavLink to="/coordinator/salles" className="rounded-xl bg-slate-100 px-3 py-2 text-center text-slate-700">Calendrier</NavLink>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-5">
            <div className="space-y-6">
              {groups.map((group) => (
                <div key={group.title}>
                  <div className="px-3 pb-2 text-xs font-extrabold uppercase tracking-wide text-slate-400">{group.title}</div>
                  <div className="space-y-1">
                    {group.items.map((item) => <SideItem key={item.to} {...item} />)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-slate-200 p-4">
            <button onClick={logout} className="flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-100">
              <LogOut size={18} />
              Déconnexion
            </button>
          </div>
        </aside>

        <main className="flex-1">
          <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
            <div className="flex items-center justify-between px-4 py-4 sm:px-6">
              <div>
                <div className="text-xs font-bold uppercase tracking-wide text-slate-400">Coordination événementielle</div>
                <div className="mt-1 flex items-center gap-2 text-2xl font-extrabold text-slate-900">
                  <CalendarRange size={24} className="text-blue-600" />
                  Pilotage opérationnel
                </div>
              </div>

              <div className="flex items-center gap-3">
                <NavLink to="/coordinator/alertes" className="relative rounded-2xl border border-slate-200 p-2.5 text-slate-600 hover:bg-slate-100">
                  <Bell size={18} />
                </NavLink>
                <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-3 py-2 shadow-sm">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-sm font-extrabold text-white">{initials || 'CO'}</div>
                  <div className="hidden sm:block">
                    <div className="text-sm font-bold text-slate-900">{user?.fullName || 'Coordonnateur'}</div>
                    <div className="text-xs text-slate-500">{user?.email || '—'}</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2 border-t border-slate-100 px-4 py-3 text-xs font-bold text-slate-500 sm:px-6 xl:hidden">
              <NavLink to="/coordinator" end className="rounded-xl bg-slate-100 px-2 py-2 text-center">Dashboard</NavLink>
              <NavLink to="/coordinator/evenements" className="rounded-xl bg-slate-100 px-2 py-2 text-center">Événements</NavLink>
              <NavLink to="/coordinator/salles" className="rounded-xl bg-slate-100 px-2 py-2 text-center">Salles</NavLink>
              <NavLink to="/coordinator/services" className="rounded-xl bg-slate-100 px-2 py-2 text-center">Services</NavLink>
            </div>
          </header>

          <div className="p-4 sm:p-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
