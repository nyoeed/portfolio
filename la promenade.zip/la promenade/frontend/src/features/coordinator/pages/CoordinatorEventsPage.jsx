import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Filter, Search } from 'lucide-react';
import { coordinatorApi } from '../api/coordinator.api';
import { fmtDateFR, fmtTimeFR } from '@/shared/utils/datetime';

const statuses = ['', 'submitted', 'in_review', 'validated', 'confirmed', 'in_coordination', 'in_progress', 'completed', 'cancelled'];

export default function CoordinatorEventsPage() {
  const [items, setItems] = useState([]);
  const [filters, setFilters] = useState({ search: '', status: '' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function load() {
    setLoading(true);
    setError('');
    try {
      const data = await coordinatorApi.listEvents(filters);
      setItems(data);
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger les événements.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [filters.status]);

  const filteredItems = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    if (!q) return items;
    return items.filter((x) => [x.title, x.organizerName, x.roomName, x.type].filter(Boolean).join(' ').toLowerCase().includes(q));
  }, [items, filters.search]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="text-xs font-bold uppercase tracking-wide text-blue-600">Événements</div>
          <h1 className="mt-1 text-3xl font-extrabold text-slate-900">Tous les événements</h1>
          <p className="mt-2 text-sm text-slate-500">Filtre par statut, retrouve un événement et ouvre sa fiche opérationnelle détaillée.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 rounded-3xl border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-[1fr_220px]">
        <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
          <Search size={18} className="text-slate-400" />
          <input value={filters.search} onChange={(e) => setFilters((s) => ({ ...s, search: e.target.value }))} placeholder="Rechercher par événement, organisateur ou salle" className="w-full bg-transparent text-sm outline-none" />
        </div>
        <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
          <Filter size={18} className="text-slate-400" />
          <select value={filters.status} onChange={(e) => setFilters((s) => ({ ...s, status: e.target.value }))} className="w-full bg-transparent text-sm outline-none">
            <option value="">Tous les statuts</option>
            {statuses.filter(Boolean).map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {error ? <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</div> : null}

      <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs font-extrabold uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-5 py-4">Événement</th>
                <th className="px-5 py-4">Date</th>
                <th className="px-5 py-4">Salle</th>
                <th className="px-5 py-4">Organisateur</th>
                <th className="px-5 py-4">Suivi</th>
                <th className="px-5 py-4">Statut</th>
                <th className="px-5 py-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr><td colSpan="7" className="px-5 py-8 text-center text-sm font-semibold text-slate-500">Chargement…</td></tr>
              ) : filteredItems.length === 0 ? (
                <tr><td colSpan="7" className="px-5 py-8 text-center text-sm font-semibold text-slate-500">Aucun événement trouvé.</td></tr>
              ) : filteredItems.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/80">
                  <td className="px-5 py-4 align-top">
                    <div className="flex flex-wrap items-center gap-2"><div className="font-extrabold text-slate-900">{item.title}</div>{item.needsClaim ? <span className="rounded-full bg-cyan-50 px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wide text-cyan-700">À prendre en charge</span> : null}</div>
                    <div className="mt-1 text-xs font-semibold uppercase tracking-wide text-slate-400">{item.type || 'type non défini'} • Budget {Number(item.budget || 0).toFixed(2)} $</div>
                  </td>
                  <td className="px-5 py-4 align-top text-sm font-semibold text-slate-600">{fmtDateFR(item.startAt)}<br />{fmtTimeFR(item.startAt)} → {fmtTimeFR(item.endAt)}</td>
                  <td className="px-5 py-4 align-top text-sm font-semibold text-slate-600">{item.roomName || 'À confirmer'}<br /><span className="text-xs text-slate-400">Capacité {item.roomCapacity || '—'}</span></td>
                  <td className="px-5 py-4 align-top text-sm font-semibold text-slate-600">{item.organizerName}<br /><span className="text-xs text-slate-400">{item.organizerEmail}</span></td>
                  <td className="px-5 py-4 align-top text-sm font-semibold text-slate-600">Invités {item.guestCount} • Docs {item.documentCount}<br /><span className="text-xs text-slate-400">Services {item.serviceCount} • Tâches {item.openTaskCount}</span></td>
                  <td className="px-5 py-4 align-top"><span className="inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-extrabold uppercase tracking-wide text-slate-700">{item.status}</span></td>
                  <td className="px-5 py-4 align-top text-right">
                    <Link to={`/coordinator/evenements/${item.id}`} className="inline-flex rounded-xl bg-blue-600 px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-white hover:bg-blue-700">Ouvrir</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
