import { useEffect, useMemo, useState } from 'react';
import { ShieldCheck, BellRing, Mail, UserCircle2 } from 'lucide-react';
import { getMyAccount, updateMyAccount } from '@/features/auth/api/account.api';

function Card({ title, subtitle, children, icon: Icon }) {
  return (
    <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-5 py-4">
        <div className="flex items-center gap-2 text-lg font-extrabold text-slate-900">{Icon ? <Icon size={18} className="text-blue-600" /> : null}{title}</div>
        {subtitle ? <div className="mt-1 text-sm text-slate-500">{subtitle}</div> : null}
      </div>
      <div className="p-5">{children}</div>
    </section>
  );
}

export default function CoordinatorSettingsPage() {
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', organization: '', jobTitle: '', city: '', country: '', notificationEmailEnabled: true, notificationSmsEnabled: false, notificationInAppEnabled: true });
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const initials = useMemo(() => (form.fullName || 'CO').split(' ').slice(0,2).map((x) => x[0]?.toUpperCase()).join(''), [form.fullName]);

  useEffect(() => {
    getMyAccount().then((data) => setForm((prev) => ({ ...prev, ...data }))).catch((e) => setStatus(e?.response?.data?.message || 'Impossible de charger le profil.')).finally(() => setLoading(false));
  }, []);

  async function save() {
    try {
      const updated = await updateMyAccount(form);
      setForm((prev) => ({ ...prev, ...updated }));
      setStatus('Profil coordonnateur mis à jour.');
    } catch (e) {
      setStatus(e?.response?.data?.message || 'Mise à jour impossible.');
    }
  }

  const input = (label, key, type = 'text') => (
    <label className="block"><div className="text-sm font-semibold text-slate-700">{label}</div><input type={type} value={form[key] || ''} onChange={(e) => setForm((s) => ({ ...s, [key]: e.target.value }))} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500" /></label>
  );

  if (loading) return <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">Chargement…</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="text-xs font-bold uppercase tracking-wide text-blue-600">Compte coordonnateur</div>
          <h1 className="mt-1 text-3xl font-extrabold text-slate-900">Profil & préférences</h1>
          <p className="mt-2 text-sm text-slate-500">Régle les notifications email / internes et les infos visibles par l’organisation.</p>
        </div>
        <button onClick={save} className="rounded-2xl bg-blue-600 px-4 py-3 text-sm font-extrabold text-white hover:bg-blue-700">Enregistrer</button>
      </div>

      {status ? <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700">{status}</div> : null}

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1fr_0.7fr]">
        <Card title="Identité professionnelle" subtitle="Coordonnées utilisées dans le suivi des événements et la communication avec les organisateurs." icon={UserCircle2}>
          <div className="grid gap-4 md:grid-cols-2">{input('Nom complet', 'fullName')}{input('Email', 'email', 'email')}{input('Téléphone', 'phone')}{input('Fonction', 'jobTitle')}{input('Organisation', 'organization')}{input('Ville', 'city')}{input('Pays', 'country')}</div>
        </Card>
        <Card title="Aperçu du compte" subtitle="Informations de rôle et de sécurité basiques." icon={ShieldCheck}>
          <div className="flex items-center gap-4"><div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600 text-2xl font-extrabold text-white">{initials || 'CO'}</div><div><div className="text-lg font-extrabold text-slate-900">{form.fullName || 'Coordonnateur'}</div><div className="text-sm text-slate-500">{form.email || '—'}</div></div></div>
          <div className="mt-5 grid gap-3 text-sm"><div className="rounded-2xl bg-slate-50 px-4 py-3"><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Canal interne</div><div className="mt-1 font-semibold text-slate-700">{form.notificationInAppEnabled ? 'Activé' : 'Désactivé'}</div></div><div className="rounded-2xl bg-slate-50 px-4 py-3"><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Email</div><div className="mt-1 font-semibold text-slate-700">{form.notificationEmailEnabled ? 'Activé' : 'Désactivé'}</div></div></div>
        </Card>
      </div>

      <Card title="Préférences de notification" subtitle="Décide comment tu veux être alerté pour les changements de statut, services et documents." icon={BellRing}>
        <div className="grid gap-3 md:grid-cols-3 text-sm">
          <label className="rounded-2xl border border-slate-200 px-4 py-4 font-semibold text-slate-700"><div className="flex items-center gap-2 text-slate-900"><BellRing size={16} className="text-blue-600" /> Notifications internes</div><div className="mt-2 text-slate-500">Centre de notifications dans la plateforme.</div><input className="mt-4" type="checkbox" checked={!!form.notificationInAppEnabled} onChange={(e) => setForm((s) => ({ ...s, notificationInAppEnabled: e.target.checked }))} /></label>
          <label className="rounded-2xl border border-slate-200 px-4 py-4 font-semibold text-slate-700"><div className="flex items-center gap-2 text-slate-900"><Mail size={16} className="text-blue-600" /> Emails</div><div className="mt-2 text-slate-500">Copies email des alertes importantes.</div><input className="mt-4" type="checkbox" checked={!!form.notificationEmailEnabled} onChange={(e) => setForm((s) => ({ ...s, notificationEmailEnabled: e.target.checked }))} /></label>
          <label className="rounded-2xl border border-slate-200 px-4 py-4 font-semibold text-slate-700"><div className="flex items-center gap-2 text-slate-900"><ShieldCheck size={16} className="text-blue-600" /> SMS (préparé)</div><div className="mt-2 text-slate-500">Canal prévu pour les urgences critiques.</div><input className="mt-4" type="checkbox" checked={!!form.notificationSmsEnabled} onChange={(e) => setForm((s) => ({ ...s, notificationSmsEnabled: e.target.checked }))} /></label>
        </div>
      </Card>
    </div>
  );
}
