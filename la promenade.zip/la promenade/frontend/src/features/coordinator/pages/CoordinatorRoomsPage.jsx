import { useEffect, useMemo, useState } from 'react';
import { coordinatorApi } from '../api/coordinator.api';
import { fmtDateFR, fmtTimeFR } from '@/shared/utils/datetime';

const daysWindow = 10;

export default function CoordinatorRoomsPage() {
  const [calendar, setCalendar] = useState(null);
  const [conflicts, setConflicts] = useState([]);
  const [error, setError] = useState('');

  async function load() {
    try {
      const now = new Date();
      const to = new Date(now.getTime() + daysWindow * 24 * 60 * 60 * 1000);
      const [c, conf] = await Promise.all([
        coordinatorApi.getRoomsCalendar({ from: now.toISOString(), to: to.toISOString() }),
        coordinatorApi.getConflicts(),
      ]);
      setCalendar(c);
      setConflicts(conf);
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger les salles.');
    }
  }

  useEffect(() => { load(); }, []);

  const grouped = useMemo(() => {
    const map = new Map();
    (calendar?.reservations || []).forEach((item) => {
      if (!map.has(item.roomId)) map.set(item.roomId, []);
      map.get(item.roomId).push(item);
    });
    return map;
  }, [calendar]);

  async function changeReservationStatus(id, status) {
    await coordinatorApi.updateReservationStatus(id, status);
    await load();
  }

  if (error) return <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</div>;
  if (!calendar) return <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">Chargement…</div>;

  return (
    <div className="space-y-6">
      <div>
        <div className="text-xs font-bold uppercase tracking-wide text-blue-600">Réservations</div>
        <h1 className="mt-1 text-3xl font-extrabold text-slate-900">Disponibilités et conflits de salles</h1>
        <p className="mt-2 text-sm text-slate-500">Vue synthétique des salles, créneaux réservés et conflits détectés automatiquement.</p>
      </div>

      <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-5 py-4 text-lg font-extrabold text-slate-900">Conflits détectés</div>
        <div className="divide-y">
          {conflicts.length === 0 ? <div className="p-5 text-sm font-semibold text-slate-500">Aucun conflit de salle détecté.</div> : conflicts.map((c) => (
            <div key={`${c.reservationAId}-${c.reservationBId}`} className="grid gap-3 p-5 md:grid-cols-[1fr_auto] md:items-center">
              <div>
                <div className="font-extrabold text-slate-900">{c.roomName}</div>
                <div className="mt-1 text-sm text-slate-600">{c.titleA} ({fmtDateFR(c.startA)} {fmtTimeFR(c.startA)}–{fmtTimeFR(c.endA)})</div>
                <div className="mt-1 text-sm text-slate-600">{c.titleB} ({fmtDateFR(c.startB)} {fmtTimeFR(c.startB)}–{fmtTimeFR(c.endB)})</div>
              </div>
              <span className={`rounded-full px-3 py-1 text-xs font-extrabold uppercase tracking-wide ${c.capacityConflict ? 'bg-red-50 text-red-700' : 'bg-amber-50 text-amber-700'}`}>{c.capacityConflict ? 'capacité + horaire' : 'horaire'}</span>
            </div>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        {(calendar.rooms || []).map((room) => {
          const reservations = grouped.get(room.id) || [];
          return (
            <section key={room.id} className="rounded-3xl border border-slate-200 bg-white shadow-sm">
              <div className="border-b border-slate-100 px-5 py-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-lg font-extrabold text-slate-900">{room.name}</div>
                    <div className="mt-1 text-sm text-slate-500">Capacité {room.capacity} • {room.surface ? `${room.surface} m² • ` : ''}{room.equipments || 'Sans équipement listé'}</div>
                  </div>
                  <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-extrabold uppercase tracking-wide text-slate-700">{room.status}</span>
                </div>
              </div>
              <div className="p-5 space-y-3">
                {reservations.length === 0 ? <div className="text-sm font-semibold text-slate-500">Aucune réservation sur les {daysWindow} prochains jours.</div> : reservations.map((res) => (
                  <div key={res.id} className="rounded-2xl border border-slate-200 p-4">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                      <div>
                        <div className="font-extrabold text-slate-900">{res.title}</div>
                        <div className="mt-1 text-sm text-slate-500">{fmtDateFR(res.startAt)} • {fmtTimeFR(res.startAt)} → {fmtTimeFR(res.endAt)} • {res.participants} participants</div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <button onClick={() => changeReservationStatus(res.id, 'locked')} className="rounded-xl bg-slate-900 px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-white">Verrouiller</button>
                        <button onClick={() => changeReservationStatus(res.id, 'confirmed')} className="rounded-xl bg-blue-600 px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-white">Confirmer</button>
                        <span className="rounded-xl bg-slate-100 px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-slate-700">{res.status}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
