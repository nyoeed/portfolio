import { useEffect, useState } from 'react';
import { coordinatorApi } from '../api/coordinator.api';
import { fmtDateTimeFR } from '@/shared/utils/datetime';

export default function CoordinatorAlertsPage() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');
  const [unreadOnly, setUnreadOnly] = useState(false);

  async function load() {
    try {
      setItems(await coordinatorApi.listNotifications({ unreadOnly }));
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger les notifications.');
    }
  }

  useEffect(() => { load(); }, [unreadOnly]);

  return (
    <div className="space-y-6">
      <div>
        <div className="text-xs font-bold uppercase tracking-wide text-blue-600">Alertes</div>
        <h1 className="mt-1 text-3xl font-extrabold text-slate-900">Centre de notifications</h1>
        <p className="mt-2 text-sm text-slate-500">Alertes de validation, rappels, blocages financiers et modifications critiques.</p>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button onClick={() => setUnreadOnly((v) => !v)} className={`rounded-2xl px-4 py-2 text-sm font-extrabold ${unreadOnly ? 'bg-slate-900 text-white' : 'border border-slate-200 bg-white text-slate-700'}`}>{unreadOnly ? 'Voir toutes' : 'Voir non lues'}</button>
        <button onClick={load} className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-extrabold text-slate-700">Rafraîchir</button>
      </div>

      {error ? <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</div> : null}

      <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="divide-y">
          {items.length === 0 ? <div className="p-5 text-sm font-semibold text-slate-500">Aucune notification.</div> : items.map((item) => (
            <div key={item.id} className="grid gap-4 p-5 md:grid-cols-[1fr_auto] md:items-center">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <div className="font-extrabold text-slate-900">{item.title}</div>
                  <span className={`rounded-full px-2.5 py-1 text-[11px] font-extrabold uppercase ${item.priority === 'urgent' ? 'bg-red-50 text-red-700' : 'bg-slate-100 text-slate-700'}`}>{item.priority}</span>
                  <span className="rounded-full bg-blue-50 px-2.5 py-1 text-[11px] font-extrabold uppercase text-blue-700">{item.type}</span>
                </div>
                <div className="mt-2 text-sm text-slate-600">{item.message}</div>
                <div className="mt-2 text-xs font-semibold text-slate-400">{fmtDateTimeFR(item.createdAt)}</div>
              </div>
              <div>
                {!item.isRead ? <button onClick={() => coordinatorApi.markNotificationRead(item.id).then(load)} className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-extrabold uppercase tracking-wide text-white">Marquer lu</button> : <span className="rounded-xl bg-emerald-50 px-4 py-2 text-xs font-extrabold uppercase tracking-wide text-emerald-700">Lu</span>}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
