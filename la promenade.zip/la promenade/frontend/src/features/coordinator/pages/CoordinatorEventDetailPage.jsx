import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { coordinatorApi } from '../api/coordinator.api';
import { fmtDateFR, fmtDateTimeFR, fmtTimeFR } from '@/shared/utils/datetime';

const eventStatuses = ['submitted', 'in_review', 'validated', 'confirmed', 'in_coordination', 'in_progress', 'completed', 'cancelled'];
const serviceStatuses = ['requested', 'in_analysis', 'approved', 'planned', 'in_progress', 'completed', 'refused', 'cancelled'];

function Section({ title, subtitle, right, children }) {
  return (
    <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
      <div className="flex flex-col gap-3 border-b border-slate-100 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="text-lg font-extrabold text-slate-900">{title}</div>
          {subtitle ? <div className="mt-1 text-sm text-slate-500">{subtitle}</div> : null}
        </div>
        {right}
      </div>
      <div className="p-5">{children}</div>
    </section>
  );
}

export default function CoordinatorEventDetailPage() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [newTask, setNewTask] = useState({ title: '', dueAt: '', priority: 'medium', category: 'checklist' });
  const [report, setReport] = useState({ finalParticipants: 0, serviceExecutionScore: 0, incidentCount: 0, operationsComment: '', incidentsComment: '', satisfactionComment: '' });
  const [uploading, setUploading] = useState(false);

  async function load() {
    try {
      const detail = await coordinatorApi.getEvent(id);
      setData(detail);
      if (detail.report) setReport({
        finalParticipants: detail.report.finalParticipants || 0,
        serviceExecutionScore: detail.report.serviceExecutionScore || 0,
        incidentCount: detail.report.incidentCount || 0,
        operationsComment: detail.report.operationsComment || '',
        incidentsComment: detail.report.incidentsComment || '',
        satisfactionComment: detail.report.satisfactionComment || '',
      });
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger la fiche événement.');
    }
  }

  useEffect(() => { load(); }, [id]);

  const guestStats = useMemo(() => {
    const guests = data?.guests || [];
    return {
      total: guests.length,
      confirmed: guests.filter((g) => g.rsvpStatus === 'confirmed').length,
      declined: guests.filter((g) => g.rsvpStatus === 'declined').length,
      pending: guests.filter((g) => g.rsvpStatus === 'pending' || g.rsvpStatus === 'invited').length,
    };
  }, [data]);

  if (error) return <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</div>;
  if (!data?.event) return <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">Chargement…</div>;

  const e = data.event;

  async function onChangeEventStatus(status) {
    await coordinatorApi.updateEventStatus(id, status);
    await load();
  }
  async function onUpdateService(serviceId, patch) {
    await coordinatorApi.updateService(serviceId, patch);
    await load();
  }
  async function onAddNote() {
    if (!note.trim()) return;
    await coordinatorApi.addEventNote(id, { content: note.trim() });
    setNote('');
    await load();
  }
  async function onCreateTask() {
    if (!newTask.title.trim()) return;
    await coordinatorApi.createTask({ eventId: id, ...newTask });
    setNewTask({ title: '', dueAt: '', priority: 'medium', category: 'checklist' });
    await load();
  }
  async function onSaveReport() {
    await coordinatorApi.saveReport(id, report);
    await load();
  }
  async function onUploadDoc(file) {
    if (!file) return;
    setUploading(true);
    try {
      await coordinatorApi.uploadEventDocument(id, { file, title: file.name, category: 'piece_jointe' });
      await load();
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
        <div>
          <div className="text-xs font-bold uppercase tracking-wide text-blue-600">Fiche événement</div>
          <h1 className="mt-1 text-3xl font-extrabold text-slate-900">{e.title}</h1>
          <p className="mt-2 text-sm text-slate-500">{e.type || 'Type non défini'} • {fmtDateFR(e.startAt)} • {fmtTimeFR(e.startAt)} → {fmtTimeFR(e.endAt)}</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <select value={e.status} onChange={(evt) => onChangeEventStatus(evt.target.value)} className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold outline-none">
            {eventStatuses.map((status) => <option key={status} value={status}>{status}</option>)}
          </select>
          <Link to="/coordinator/evenements" className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-extrabold text-slate-700 hover:bg-slate-50">Retour liste</Link>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1.3fr_0.7fr]">
        <Section title="Informations générales" subtitle="Vue d'ensemble pour la coordination, la faisabilité et le suivi financier partiel.">
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-4">
            <div><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Organisateur</div><div className="mt-2 font-extrabold text-slate-900">{e.organizerName}</div><div className="text-sm text-slate-500">{e.organizerEmail}</div></div>
            <div><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Salle</div><div className="mt-2 font-extrabold text-slate-900">{e.roomName || 'À confirmer'}</div><div className="text-sm text-slate-500">Capacité {e.roomCapacity || '—'} pers.</div></div>
            <div><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Participants estimés</div><div className="mt-2 font-extrabold text-slate-900">{e.participants}</div></div>
            <div><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Budget</div><div className="mt-2 font-extrabold text-slate-900">{Number(e.budget || 0).toFixed(2)} $</div></div>
          </div>
          <div className="mt-5 rounded-2xl bg-slate-50 p-4 text-sm text-slate-700">{e.description || 'Aucune description fournie.'}</div>
        </Section>

        <Section title="Vue coordination" subtitle="Progression des invités et blocages financiers.">
          <div className="space-y-4 text-sm font-semibold text-slate-600">
            <div className="rounded-2xl bg-slate-50 p-4">
              <div className="text-xs font-bold uppercase tracking-wide text-slate-400">Invités</div>
              <div className="mt-2">Total {guestStats.total} • Confirmés {guestStats.confirmed} • Refusés {guestStats.declined} • En attente {guestStats.pending}</div>
            </div>
            <div className="rounded-2xl bg-slate-50 p-4">
              <div className="text-xs font-bold uppercase tracking-wide text-slate-400">Facturation liée</div>
              {data.invoice ? <div className="mt-2">{data.invoice.invoiceNumber} • Statut {data.invoice.status} • Total {Number(data.invoice.total || 0).toFixed(2)} $</div> : <div className="mt-2">Aucune facture liée.</div>}
            </div>
            <div className="rounded-2xl bg-slate-50 p-4">
              <div className="text-xs font-bold uppercase tracking-wide text-slate-400">Réservation</div>
              {data.reservations[0] ? <div className="mt-2">Statut {data.reservations[0].status} • créneau {fmtDateTimeFR(data.reservations[0].startAt)}</div> : <div className="mt-2">Aucune réservation liée.</div>}
            </div>
          </div>
        </Section>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Section title="Services demandés" subtitle="Valider, planifier ou compléter chaque service.">
          <div className="space-y-4">
            {data.services.length === 0 ? <div className="text-sm font-semibold text-slate-500">Aucun service demandé.</div> : data.services.map((s) => (
              <div key={s.id} className="rounded-2xl border border-slate-200 p-4">
                <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                  <div>
                    <div className="font-extrabold text-slate-900">{s.serviceName}</div>
                    <div className="mt-1 text-sm text-slate-500">{s.category} • Qté {s.quantity} • {s.locationNote || 'Lieu non défini'}</div>
                    <div className="mt-1 text-sm text-slate-500">Prévu {fmtDateTimeFR(s.plannedStartAt)} → {fmtTimeFR(s.plannedEndAt)}</div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <select value={s.status} onChange={(evt) => onUpdateService(s.id, { status: evt.target.value })} className="rounded-xl border border-slate-200 px-3 py-2 text-sm font-semibold outline-none">
                      {serviceStatuses.map((status) => <option key={status} value={status}>{status}</option>)}
                    </select>
                    <button onClick={() => onUpdateService(s.id, { status: 'planned' })} className="rounded-xl bg-blue-600 px-3 py-2 text-sm font-extrabold text-white hover:bg-blue-700">Planifier</button>
                    <button onClick={() => onUpdateService(s.id, { status: 'completed' })} className="rounded-xl bg-emerald-600 px-3 py-2 text-sm font-extrabold text-white hover:bg-emerald-700">Compléter</button>
                  </div>
                </div>
                <div className="mt-3 grid gap-3 md:grid-cols-3 text-sm">
                  <div className="rounded-xl bg-slate-50 px-3 py-2"><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Priorité</div><div className="mt-1 font-bold text-slate-700">{s.priority}</div></div>
                  <div className="rounded-xl bg-slate-50 px-3 py-2"><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Coût estimé</div><div className="mt-1 font-bold text-slate-700">{Number(s.estimatedAmount || 0).toFixed(2)} $</div></div>
                  <div className="rounded-xl bg-slate-50 px-3 py-2"><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Responsable</div><div className="mt-1 font-bold text-slate-700">{s.assignedToName || 'Non assigné'}</div></div>
                </div>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Tâches opérationnelles" subtitle="Checklist, assignations et suivi d'exécution.">
          <div className="space-y-4">
            <div className="grid gap-3 md:grid-cols-[1fr_180px_160px_auto]">
              <input value={newTask.title} onChange={(e2) => setNewTask((s) => ({ ...s, title: e2.target.value }))} className="rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none" placeholder="Nouvelle tâche" />
              <input type="datetime-local" value={newTask.dueAt} onChange={(e2) => setNewTask((s) => ({ ...s, dueAt: e2.target.value }))} className="rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none" />
              <select value={newTask.priority} onChange={(e2) => setNewTask((s) => ({ ...s, priority: e2.target.value }))} className="rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none">
                <option value="medium">medium</option><option value="high">high</option><option value="critical">critical</option><option value="low">low</option>
              </select>
              <button onClick={onCreateTask} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-extrabold text-white">Ajouter</button>
            </div>
            <div className="space-y-3">
              {data.tasks.length === 0 ? <div className="text-sm font-semibold text-slate-500">Aucune tâche.</div> : data.tasks.map((task) => (
                <div key={task.id} className="flex flex-col gap-3 rounded-2xl border border-slate-200 p-4 lg:flex-row lg:items-center lg:justify-between">
                  <div>
                    <div className="font-extrabold text-slate-900">{task.title}</div>
                    <div className="mt-1 text-sm text-slate-500">{task.description || 'Sans description'} • Échéance {fmtDateTimeFR(task.dueAt)}</div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <select value={task.status} onChange={(evt) => { coordinatorApi.updateTask(task.id, { status: evt.target.value }).then(load); }} className="rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none">
                      <option value="todo">todo</option><option value="in_progress">in_progress</option><option value="blocked">blocked</option><option value="done">done</option><option value="cancelled">cancelled</option>
                    </select>
                    <span className="rounded-xl bg-slate-100 px-3 py-2 text-sm font-bold text-slate-700">{task.priority}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Section>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Section title="Invités" subtitle="Statuts RSVP et besoins particuliers utiles à la coordination.">
          <div className="space-y-3">
            {data.guests.length === 0 ? <div className="text-sm font-semibold text-slate-500">Aucun invité.</div> : data.guests.map((g) => (
              <div key={g.id} className="grid gap-2 rounded-2xl border border-slate-200 p-4 md:grid-cols-[1fr_auto] md:items-center">
                <div>
                  <div className="font-extrabold text-slate-900">{g.firstName} {g.lastName}</div>
                  <div className="mt-1 text-sm text-slate-500">{g.email || '—'} • {g.dietaryNotes || 'Aucun régime particulier'} • {g.specialNeeds || 'Aucun besoin spécial'}</div>
                </div>
                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-extrabold uppercase tracking-wide text-slate-700">{g.rsvpStatus}</span>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Documents & notes internes" subtitle="Pièces jointes sécurisées, plans et historique opérationnel." right={
          <label className="cursor-pointer rounded-2xl bg-blue-600 px-4 py-2 text-sm font-extrabold text-white hover:bg-blue-700">
            {uploading ? 'Téléversement…' : 'Ajouter un document'}
            <input type="file" className="hidden" onChange={(evt) => onUploadDoc(evt.target.files?.[0])} />
          </label>
        }>
          <div className="space-y-4">
            <div className="space-y-3">
              {data.documents.length === 0 ? <div className="text-sm font-semibold text-slate-500">Aucun document.</div> : data.documents.map((d) => (
                <a key={d.id} href={`http://localhost:4000${d.filePath}`} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-2xl border border-slate-200 px-4 py-3 hover:bg-slate-50">
                  <div>
                    <div className="font-extrabold text-slate-900">{d.title}</div>
                    <div className="mt-1 text-sm text-slate-500">{d.category} • v{d.versionNo} • {fmtDateTimeFR(d.createdAt)}</div>
                  </div>
                  <span className="text-sm font-bold text-blue-700">Ouvrir</span>
                </a>
              ))}
            </div>
            <div className="rounded-2xl bg-slate-50 p-4">
              <div className="text-sm font-extrabold text-slate-900">Ajouter une note interne</div>
              <textarea value={note} onChange={(evt) => setNote(evt.target.value)} rows={4} className="mt-3 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none" placeholder="Observation, incident, blocage, suivi logistique…" />
              <div className="mt-3 flex justify-end"><button onClick={onAddNote} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-extrabold text-white">Enregistrer la note</button></div>
            </div>
            <div className="space-y-3">
              {data.notes.map((n) => (
                <div key={n.id} className="rounded-2xl border border-slate-200 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="font-extrabold text-slate-900">{n.authorName || 'Utilisateur'}</div>
                    <div className="text-xs font-bold uppercase tracking-wide text-slate-400">{fmtDateTimeFR(n.createdAt)}</div>
                  </div>
                  <div className="mt-2 text-sm text-slate-600">{n.content}</div>
                </div>
              ))}
            </div>
          </div>
        </Section>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Section title="Rapport post-événement" subtitle="Bilan opérationnel, incidents et satisfaction.">
          <div className="grid gap-3 md:grid-cols-3">
            <input type="number" value={report.finalParticipants} onChange={(e2) => setReport((s) => ({ ...s, finalParticipants: Number(e2.target.value) }))} className="rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none" placeholder="Participants finaux" />
            <input type="number" min="0" max="10" value={report.serviceExecutionScore} onChange={(e2) => setReport((s) => ({ ...s, serviceExecutionScore: Number(e2.target.value) }))} className="rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none" placeholder="Score service /10" />
            <input type="number" value={report.incidentCount} onChange={(e2) => setReport((s) => ({ ...s, incidentCount: Number(e2.target.value) }))} className="rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none" placeholder="Incidents" />
          </div>
          <div className="mt-3 space-y-3">
            <textarea rows={3} value={report.operationsComment} onChange={(e2) => setReport((s) => ({ ...s, operationsComment: e2.target.value }))} className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none" placeholder="Bilan opérationnel" />
            <textarea rows={3} value={report.incidentsComment} onChange={(e2) => setReport((s) => ({ ...s, incidentsComment: e2.target.value }))} className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none" placeholder="Incidents / remarques" />
            <textarea rows={3} value={report.satisfactionComment} onChange={(e2) => setReport((s) => ({ ...s, satisfactionComment: e2.target.value }))} className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none" placeholder="Satisfaction opérationnelle" />
          </div>
          <div className="mt-4 flex justify-end"><button onClick={onSaveReport} className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-extrabold text-white">Sauvegarder le rapport</button></div>
        </Section>

        <Section title="Historique d'audit" subtitle="Traçabilité des statuts, services, notes et rapports.">
          <div className="space-y-3">
            {data.audit.length === 0 ? <div className="text-sm font-semibold text-slate-500">Aucun historique disponible.</div> : data.audit.map((a) => (
              <div key={a.id} className="rounded-2xl border border-slate-200 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-extrabold text-slate-900">{a.summary}</div>
                    <div className="mt-1 text-sm text-slate-500">{a.actorName || 'Système'} • {a.actorRole || '—'}</div>
                  </div>
                  <div className="text-xs font-bold uppercase tracking-wide text-slate-400">{fmtDateTimeFR(a.createdAt)}</div>
                </div>
              </div>
            ))}
          </div>
        </Section>
      </div>
    </div>
  );
}
