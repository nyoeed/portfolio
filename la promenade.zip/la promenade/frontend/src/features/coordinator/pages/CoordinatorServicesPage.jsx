import { useEffect, useMemo, useState } from 'react';
import { coordinatorApi } from '../api/coordinator.api';
import { fmtDateTimeFR } from '@/shared/utils/datetime';

const categories = ['', 'Traiteur', 'Audiovisuel', 'Sécurité', 'Logistique', 'Décoration'];
const statuses = ['', 'requested', 'in_analysis', 'approved', 'planned', 'in_progress', 'completed', 'refused', 'cancelled'];

export default function CoordinatorServicesPage() {
  const [rows, setRows] = useState([]);
  const [filters, setFilters] = useState({ category: '', status: '', search: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const data = await coordinatorApi.listServices(filters);
      setRows(data);
    } catch (e) {
      setError(e?.response?.data?.message || 'Impossible de charger les services.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [filters.category, filters.status]);

  const visibleRows = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((item) => [item.serviceName, item.eventTitle, item.organizerName, item.roomName, item.category].filter(Boolean).join(' ').toLowerCase().includes(q));
  }, [rows, filters.search]);

  const totals = useMemo(() => ({
    total: rows.length,
    requested: rows.filter((r) => ['requested', 'in_analysis'].includes(r.status)).length,
    planned: rows.filter((r) => r.status === 'planned').length,
    critical: rows.filter((r) => r.priority === 'critical' || r.priority === 'high').length,
  }), [rows]);

  async function quickPlan(item) {
    await coordinatorApi.updateService(item.id, { status: 'planned', plannedStartAt: item.requestedStartAt, plannedEndAt: item.requestedEndAt });
    await load();
  }

  return (
    <div className="space-y-6">
      <div>
        <div className="text-xs font-bold uppercase tracking-wide text-blue-600">Services</div>
        <h1 className="mt-1 text-3xl font-extrabold text-slate-900">Coordination des services</h1>
        <p className="mt-2 text-sm text-slate-500">Traiteur, audiovisuel, sécurité, logistique et autres besoins spéciaux.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        {[
          ['Demandes totales', totals.total],
          ['À analyser', totals.requested],
          ['Planifiées', totals.planned],
          ['Priorité haute', totals.critical],
        ].map(([label, value]) => (
          <div key={label} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"><div className="text-sm font-semibold text-slate-500">{label}</div><div className="mt-2 text-3xl font-extrabold text-slate-900">{value}</div></div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 rounded-3xl border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-3">
        <input value={filters.search} onChange={(e) => setFilters((s) => ({ ...s, search: e.target.value }))} placeholder="Rechercher par service, événement, organisateur ou salle" className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none" />
        <select value={filters.category} onChange={(e) => setFilters((s) => ({ ...s, category: e.target.value }))} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none">
          <option value="">Toutes les catégories</option>
          {categories.filter(Boolean).map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select value={filters.status} onChange={(e) => setFilters((s) => ({ ...s, status: e.target.value }))} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none">
          <option value="">Tous les statuts</option>
          {statuses.filter(Boolean).map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {error ? <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</div> : null}

      <div className="space-y-4">
        {loading ? <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">Chargement…</div> : visibleRows.length === 0 ? <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">Aucune demande de service.</div> : visibleRows.map((item) => (
          <div key={item.id} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr_auto] xl:items-center">
              <div>
                <div className="text-lg font-extrabold text-slate-900">{item.serviceName}</div>
                <div className="mt-1 text-sm text-slate-500">{item.eventTitle} • {item.roomName || 'Salle à confirmer'} • {item.organizerName}</div>
                <div className="mt-3 flex flex-wrap gap-2 text-xs font-extrabold uppercase tracking-wide">
                  <span className="rounded-full bg-slate-100 px-2.5 py-1 text-slate-700">{item.category}</span>
                  <span className="rounded-full bg-blue-50 px-2.5 py-1 text-blue-700">{item.status}</span>
                  <span className="rounded-full bg-amber-50 px-2.5 py-1 text-amber-700">{item.priority}</span>
                </div>
              </div>
              <div className="text-sm font-semibold text-slate-600">
                <div>Demandé: {fmtDateTimeFR(item.requestedStartAt)} → {fmtDateTimeFR(item.requestedEndAt)}</div>
                <div className="mt-1">Planifié: {fmtDateTimeFR(item.plannedStartAt)} → {fmtDateTimeFR(item.plannedEndAt)}</div>
                <div className="mt-1">Qté {item.quantity} • Coût estimé {Number(item.estimatedAmount || 0).toFixed(2)} $</div>
              </div>
              <div className="flex flex-wrap gap-2 xl:justify-end">
                <button onClick={() => coordinatorApi.updateService(item.id, { status: 'in_analysis' }).then(load)} className="rounded-xl bg-slate-900 px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-white hover:bg-slate-800">Analyser</button>
                <button onClick={() => quickPlan(item)} className="rounded-xl bg-blue-600 px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-white hover:bg-blue-700">Planifier</button>
                <button onClick={() => coordinatorApi.updateService(item.id, { status: 'completed' }).then(load)} className="rounded-xl bg-emerald-600 px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-white hover:bg-emerald-700">Compléter</button>
                <button onClick={() => coordinatorApi.updateService(item.id, { status: 'refused' }).then(load)} className="rounded-xl bg-rose-600 px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-white hover:bg-rose-700">Refuser</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
