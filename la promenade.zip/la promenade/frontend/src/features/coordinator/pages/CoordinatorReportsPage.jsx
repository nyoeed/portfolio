import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { coordinatorApi } from '../api/coordinator.api';
import { fmtDateFR, fmtDateTimeFR } from '@/shared/utils/datetime';

export default function CoordinatorReportsPage() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    coordinatorApi.listReports().then(setItems).catch((e) => setError(e?.response?.data?.message || 'Impossible de charger les rapports.'));
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <div className="text-xs font-bold uppercase tracking-wide text-blue-600">Rapports</div>
        <h1 className="mt-1 text-3xl font-extrabold text-slate-900">Post-événement & bilan opérationnel</h1>
        <p className="mt-2 text-sm text-slate-500">Historique des rapports, incidents, participation finale et qualité d'exécution.</p>
      </div>

      {error ? <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</div> : null}

      <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs font-extrabold uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-5 py-4">Événement</th>
                <th className="px-5 py-4">Date</th>
                <th className="px-5 py-4">Participants finaux</th>
                <th className="px-5 py-4">Incidents</th>
                <th className="px-5 py-4">Score service</th>
                <th className="px-5 py-4">Dernière mise à jour</th>
                <th className="px-5 py-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {items.length === 0 ? <tr><td colSpan="7" className="px-5 py-8 text-center text-sm font-semibold text-slate-500">Aucun rapport disponible.</td></tr> : items.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50">
                  <td className="px-5 py-4"><div className="font-extrabold text-slate-900">{item.eventTitle}</div><div className="mt-1 text-xs text-slate-400">{item.roomName || 'Salle à confirmer'} • {item.status}</div></td>
                  <td className="px-5 py-4 font-semibold text-slate-600">{fmtDateFR(item.startAt)}</td>
                  <td className="px-5 py-4 font-semibold text-slate-600">{item.finalParticipants}</td>
                  <td className="px-5 py-4 font-semibold text-slate-600">{item.incidentCount}</td>
                  <td className="px-5 py-4 font-semibold text-slate-600">{item.serviceExecutionScore ?? '—'}</td>
                  <td className="px-5 py-4 font-semibold text-slate-600">{fmtDateTimeFR(item.updatedAt)}</td>
                  <td className="px-5 py-4 text-right"><Link to={`/coordinator/evenements/${item.eventId}`} className="rounded-xl bg-blue-600 px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-white">Ouvrir</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
