import { useEffect, useState } from 'react';
import { AlertTriangle, BellRing, CalendarDays, CircleDollarSign, Clock3, Layers3, UserCheck } from 'lucide-react';
import { coordinatorApi } from '../api/coordinator.api';
import { fmtDateFR, fmtDateTimeFR, fmtTimeFR } from '@/shared/utils/datetime';

function KpiCard({ icon: Icon, label, value, accent }) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm font-semibold text-slate-500">{label}</div>
          <div className="mt-2 text-3xl font-extrabold text-slate-900">{value}</div>
        </div>
        <div className={`rounded-2xl p-3 ${accent}`}><Icon size={20} /></div>
      </div>
    </div>
  );
}

const progressTone = (n) => (n >= 70 ? 'bg-green-500' : n >= 40 ? 'bg-amber-500' : 'bg-slate-400');

export default function CoordinatorDashboardPage() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    coordinatorApi.getDashboard().then(setData).catch((e) => setError(e?.response?.data?.message || 'Chargement impossible.'));
  }, []);

  if (error) return <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</div>;
  if (!data) return <div className="rounded-2xl border bg-white p-6 text-sm font-semibold text-slate-600">Chargement…</div>;

  const s = data.summary || {};

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <div className="text-xs font-bold uppercase tracking-wide text-blue-600">Vue générale</div>
          <h1 className="mt-1 text-3xl font-extrabold text-slate-900">Tableau de bord coordonnateur</h1>
          <p className="mt-2 text-sm font-medium text-slate-500">Suivi des événements, priorités du jour, services à confirmer et alertes critiques.</p>
        </div>
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-800">
          {s.urgentAlerts || 0} alerte(s) urgente(s) nécessitent une action.
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-7">
        <KpiCard icon={CalendarDays} label="Événements aujourd'hui" value={s.eventsToday || 0} accent="bg-blue-50 text-blue-700" />
        <KpiCard icon={Clock3} label="Cette semaine" value={s.eventsThisWeek || 0} accent="bg-indigo-50 text-indigo-700" />
        <KpiCard icon={Layers3} label="Services à confirmer" value={s.servicesToConfirm || 0} accent="bg-amber-50 text-amber-700" />
        <KpiCard icon={UserCheck} label="À prendre en charge" value={s.eventsUnassigned || 0} accent="bg-cyan-50 text-cyan-700" />
        <KpiCard icon={CalendarDays} label="Réservations en attente" value={s.pendingReservations || 0} accent="bg-slate-100 text-slate-700" />
        <KpiCard icon={CircleDollarSign} label="Factures critiques" value={s.overdueInvoices || 0} accent="bg-rose-50 text-rose-700" />
        <KpiCard icon={AlertTriangle} label="Alertes urgentes" value={s.urgentAlerts || 0} accent="bg-red-50 text-red-700" />
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1.6fr_1fr]">
        <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
          <div className="border-b border-slate-100 px-5 py-4">
            <div className="text-lg font-extrabold text-slate-900">Timeline des événements proches</div>
            <div className="mt-1 text-sm text-slate-500">Vision immédiate des prochains événements assignés.</div>
          </div>
          <div className="divide-y">
            {(data.upcomingEvents || []).length === 0 ? (
              <div className="p-6 text-sm font-semibold text-slate-500">Aucun événement assigné pour le moment.</div>
            ) : data.upcomingEvents.map((item) => (
              <div key={item.id} className="grid gap-4 p-5 md:grid-cols-[190px_1fr_160px] md:items-center">
                <div>
                  <div className="text-sm font-extrabold text-slate-900">{fmtDateFR(item.startAt)}</div>
                  <div className="mt-1 text-sm font-semibold text-slate-500">{fmtTimeFR(item.startAt)} → {fmtTimeFR(item.endAt)}</div>
                </div>
                <div>
                  <div className="text-base font-extrabold text-slate-900">{item.title}</div>
                  <div className="mt-1 text-sm text-slate-500">{item.organizerName} • {item.roomName || 'Salle à confirmer'} • {item.participants} pers.</div>
                  <div className="mt-3 h-2 rounded-full bg-slate-100">
                    <div className={`h-2 rounded-full ${progressTone(item.progressPct || 0)}`} style={{ width: `${Math.min(item.progressPct || 0, 100)}%` }} />
                  </div>
                  <div className="mt-2 text-xs font-bold uppercase tracking-wide text-slate-400">Avancement {item.progressPct || 0}%</div>
                </div>
                <div className="md:text-right">
                  <div className="inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-extrabold uppercase tracking-wide text-slate-700">{item.status}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <div className="space-y-6">
          <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 px-5 py-4">
              <div className="flex items-center gap-2 text-lg font-extrabold text-slate-900"><BellRing size={18} className="text-blue-600" /> Alertes critiques</div>
            </div>
            <div className="divide-y">
              {(data.alerts || []).length === 0 ? (
                <div className="p-5 text-sm font-semibold text-slate-500">Aucune alerte.</div>
              ) : data.alerts.map((n) => (
                <div key={n.id} className="p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-sm font-extrabold text-slate-900">{n.title}</div>
                      <div className="mt-1 text-sm text-slate-600">{n.message}</div>
                    </div>
                    <span className={`rounded-full px-2.5 py-1 text-[11px] font-extrabold uppercase ${n.priority === 'urgent' ? 'bg-red-50 text-red-700' : 'bg-slate-100 text-slate-700'}`}>{n.priority}</span>
                  </div>
                  <div className="mt-2 text-xs font-semibold text-slate-400">{fmtDateTimeFR(n.createdAt)}</div>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 px-5 py-4 text-lg font-extrabold text-slate-900">Services en file d'attente</div>
            <div className="divide-y">
              {(data.serviceQueue || []).length === 0 ? (
                <div className="p-5 text-sm font-semibold text-slate-500">Aucune demande de service.</div>
              ) : data.serviceQueue.map((item) => (
                <div key={item.id} className="p-5">
                  <div className="text-sm font-extrabold text-slate-900">{item.serviceName}</div>
                  <div className="mt-1 text-sm text-slate-600">{item.eventTitle}</div>
                  <div className="mt-2 flex flex-wrap gap-2 text-xs font-bold uppercase tracking-wide">
                    <span className="rounded-full bg-slate-100 px-2.5 py-1 text-slate-700">{item.category}</span>
                    <span className="rounded-full bg-blue-50 px-2.5 py-1 text-blue-700">{item.status}</span>
                    <span className="rounded-full bg-amber-50 px-2.5 py-1 text-amber-700">{item.priority}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
