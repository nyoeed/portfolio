import { api } from '@/lib/api';

export const coordinatorApi = {
  getDashboard: () => api.get('/api/coordinator/dashboard').then((r) => r.data),
  listEvents: (params = {}) => api.get('/api/coordinator/events', { params }).then((r) => r.data),
  getEvent: (id) => api.get(`/api/coordinator/events/${id}`).then((r) => r.data),
  updateEventStatus: (id, status) => api.patch(`/api/coordinator/events/${id}/status`, { status }).then((r) => r.data),
  addEventNote: (id, payload) => api.post(`/api/coordinator/events/${id}/notes`, payload).then((r) => r.data),
  uploadEventDocument: async (id, { file, title, category }) => {
    const form = new FormData();
    form.append('file', file);
    if (title) form.append('title', title);
    if (category) form.append('category', category);
    const res = await api.post(`/api/coordinator/events/${id}/documents`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },
  getRoomsCalendar: (params = {}) => api.get('/api/coordinator/rooms/calendar', { params }).then((r) => r.data),
  getConflicts: () => api.get('/api/coordinator/rooms/conflicts').then((r) => r.data),
  updateReservationStatus: (id, status) => api.patch(`/api/coordinator/reservations/${id}/status`, { status }).then((r) => r.data),
  listServices: (params = {}) => api.get('/api/coordinator/services', { params }).then((r) => r.data),
  updateService: (id, payload) => api.patch(`/api/coordinator/services/${id}`, payload).then((r) => r.data),
  createTask: (payload) => api.post('/api/coordinator/tasks', payload).then((r) => r.data),
  updateTask: (id, payload) => api.patch(`/api/coordinator/tasks/${id}`, payload).then((r) => r.data),
  listNotifications: (params = {}) => api.get('/api/coordinator/notifications', { params }).then((r) => r.data),
  markNotificationRead: (id) => api.patch(`/api/coordinator/notifications/${id}/read`).then((r) => r.data),
  listReports: () => api.get('/api/coordinator/reports').then((r) => r.data),
  saveReport: (eventId, payload) => api.put(`/api/coordinator/reports/${eventId}`, payload).then((r) => r.data),
};
