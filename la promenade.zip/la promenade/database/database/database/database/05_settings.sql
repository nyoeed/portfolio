/* =========================================================
   07) Settings (AdminSettings) + default row
========================================================= */

USE LaPromenadeDB;
GO

IF OBJECT_ID('dbo.AdminSettings', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.AdminSettings (
    id INT IDENTITY(1,1) PRIMARY KEY,

    hotelName NVARCHAR(120) NOT NULL DEFAULT 'Hôtel La Promenade',
    email NVARCHAR(120) NOT NULL DEFAULT 'contact@lapromenade.com',
    address NVARCHAR(200) NULL,
    phone NVARCHAR(40) NULL,
    website NVARCHAR(200) NULL,

    taxRate DECIMAL(5,2) NOT NULL DEFAULT 20.00,
    paymentDelayDays INT NOT NULL DEFAULT 30,
    onlinePaymentEnabled BIT NOT NULL DEFAULT 1,

    notifEvents BIT NOT NULL DEFAULT 1,
    notifPayments BIT NOT NULL DEFAULT 1,
    notifSignup BIT NOT NULL DEFAULT 1,
    notifSystem BIT NOT NULL DEFAULT 1,
    dailySummaryEnabled BIT NOT NULL DEFAULT 0,

    updatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    createdAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
  );
END
GO

-- S'assurer qu'il y a 1 ligne de settings
IF OBJECT_ID('dbo.AdminSettings', 'U') IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.AdminSettings)
BEGIN
  INSERT INTO dbo.AdminSettings (
    hotelName, email, address, phone, website,
    taxRate, paymentDelayDays, onlinePaymentEnabled,
    notifEvents, notifPayments, notifSignup, notifSystem, dailySummaryEnabled
  )
  VALUES (
    'Hôtel La Promenade', 'contact@lapromenade.com', NULL, NULL, NULL,
    20.00, 30, 1,
    1, 1, 1, 1, 0
  );
END
GO