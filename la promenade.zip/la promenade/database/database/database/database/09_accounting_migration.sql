/* =========================================================
   MIGRATION COMPTABILITÉ - LaPromenadeDB
   À exécuter après 07_billing.sql
   ========================================================= */

SET XACT_ABORT ON;
BEGIN TRY
  BEGIN TRAN;

  /* =========================
     1. Invoices
     ========================= */
  IF OBJECT_ID('dbo.Invoices', 'U') IS NULL
  BEGIN
    RAISERROR('La table dbo.Invoices est introuvable.', 16, 1);
  END

  IF COL_LENGTH('dbo.Invoices', 'clientEmail') IS NULL
    ALTER TABLE dbo.Invoices ADD clientEmail NVARCHAR(255) NULL;

  IF COL_LENGTH('dbo.Invoices', 'eventTitle') IS NULL
    ALTER TABLE dbo.Invoices ADD eventTitle NVARCHAR(200) NULL;

  IF COL_LENGTH('dbo.Invoices', 'eventType') IS NULL
    ALTER TABLE dbo.Invoices ADD eventType NVARCHAR(100) NULL;

  IF COL_LENGTH('dbo.Invoices', 'paidAt') IS NULL
    ALTER TABLE dbo.Invoices ADD paidAt DATE NULL;

  UPDATE dbo.Invoices
  SET status = 'late'
  WHERE status = 'overdue';

  /* =========================
     2. Payments
     ========================= */
  IF OBJECT_ID('dbo.Payments', 'U') IS NULL
  BEGIN
    RAISERROR('La table dbo.Payments est introuvable.', 16, 1);
  END

  IF COL_LENGTH('dbo.Payments', 'paymentNumber') IS NULL
    ALTER TABLE dbo.Payments ADD paymentNumber NVARCHAR(30) NULL;

  IF COL_LENGTH('dbo.Payments', 'status') IS NULL
    ALTER TABLE dbo.Payments ADD status NVARCHAR(20) NOT NULL CONSTRAINT DF_Payments_Status DEFAULT('completed');

  ;WITH cte AS (
    SELECT id, ROW_NUMBER() OVER (ORDER BY createdAt, id) AS rn
    FROM dbo.Payments
    WHERE paymentNumber IS NULL
  )
  UPDATE p
  SET paymentNumber = CONCAT('PAY-', YEAR(GETDATE()), '-', RIGHT('000' + CAST(cte.rn AS VARCHAR(10)), 3))
  FROM dbo.Payments p
  INNER JOIN cte ON cte.id = p.id;

  UPDATE dbo.Payments
  SET status = 'completed'
  WHERE status IS NULL OR LTRIM(RTRIM(status)) = '';

  /* =========================
     3. Refunds
     ========================= */
  IF OBJECT_ID('dbo.Refunds', 'U') IS NULL
  BEGIN
    RAISERROR('La table dbo.Refunds est introuvable.', 16, 1);
  END

  IF COL_LENGTH('dbo.Refunds', 'refundNumber') IS NULL
    ALTER TABLE dbo.Refunds ADD refundNumber NVARCHAR(30) NULL;

  ;WITH cte AS (
    SELECT id, ROW_NUMBER() OVER (ORDER BY createdAt, id) AS rn
    FROM dbo.Refunds
    WHERE refundNumber IS NULL
  )
  UPDATE r
  SET refundNumber = CONCAT('REM-', YEAR(GETDATE()), '-', RIGHT('000' + CAST(cte.rn AS VARCHAR(10)), 3))
  FROM dbo.Refunds r
  INNER JOIN cte ON cte.id = r.id;

  UPDATE dbo.Refunds
  SET status = 'processed'
  WHERE status IS NULL OR LTRIM(RTRIM(status)) = '';

  /* =========================
     4. Contraintes de statuts
     ========================= */
  IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Invoices_Status')
    ALTER TABLE dbo.Invoices DROP CONSTRAINT CK_Invoices_Status;

  ALTER TABLE dbo.Invoices
  ADD CONSTRAINT CK_Invoices_Status
  CHECK (status IN ('pending', 'partial', 'paid', 'late', 'cancelled'));

  IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Payments_Status')
    ALTER TABLE dbo.Payments DROP CONSTRAINT CK_Payments_Status;

  ALTER TABLE dbo.Payments
  ADD CONSTRAINT CK_Payments_Status
  CHECK (status IN ('pending', 'completed', 'failed', 'cancelled'));

  IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Refunds_Status')
    ALTER TABLE dbo.Refunds DROP CONSTRAINT CK_Refunds_Status;

  ALTER TABLE dbo.Refunds
  ADD CONSTRAINT CK_Refunds_Status
  CHECK (status IN ('pending', 'approved', 'processed', 'rejected'));

  /* =========================
     5. Index utiles
     ========================= */
  IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_Invoices_IssueDate_Status' AND object_id = OBJECT_ID('dbo.Invoices')
  )
    CREATE INDEX IX_Invoices_IssueDate_Status ON dbo.Invoices(issueDate, status);

  IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_Payments_InvoiceId_Status_PaidAt' AND object_id = OBJECT_ID('dbo.Payments')
  )
    CREATE INDEX IX_Payments_InvoiceId_Status_PaidAt ON dbo.Payments(invoiceId, status, paidAt);

  IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_Refunds_InvoiceId_Status_RefundDate' AND object_id = OBJECT_ID('dbo.Refunds')
  )
    CREATE INDEX IX_Refunds_InvoiceId_Status_RefundDate ON dbo.Refunds(invoiceId, status, refundDate);

  COMMIT TRAN;
END TRY
BEGIN CATCH
  IF @@TRANCOUNT > 0 ROLLBACK TRAN;
  THROW;
END CATCH;
GO
