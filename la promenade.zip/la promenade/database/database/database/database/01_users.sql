/* =========================================================
   01) Users
========================================================= */

USE LaPromenadeDB;
GO

IF OBJECT_ID('dbo.Users', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Users (
    id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
    fullName NVARCHAR(120) NOT NULL,
    email NVARCHAR(255) NOT NULL UNIQUE,
    passwordHash NVARCHAR(255) NOT NULL,

    role NVARCHAR(30) NULL,
    roleRequested NVARCHAR(30) NULL,

    status NVARCHAR(30) NOT NULL DEFAULT 'pending',

    createdAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    lastLoginAt DATETIME2 NULL
  );
END
GO

-- CHECK status
IF NOT EXISTS (
  SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Users_Status'
)
BEGIN
  ALTER TABLE dbo.Users
  ADD CONSTRAINT CK_Users_Status
  CHECK (status IN ('pending','approved','rejected'));
END
GO

-- CHECK role
IF NOT EXISTS (
  SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Users_Role'
)
BEGIN
  ALTER TABLE dbo.Users
  ADD CONSTRAINT CK_Users_Role
  CHECK (
    role IS NULL OR role IN ('admin','organizer','coordinator','accounting')
  );
END
GO

-- CHECK roleRequested
IF NOT EXISTS (
  SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Users_RoleRequested'
)
BEGIN
  ALTER TABLE dbo.Users
  ADD CONSTRAINT CK_Users_RoleRequested
  CHECK (
    roleRequested IS NULL OR roleRequested IN ('organizer','coordinator','accounting')
  );
END
GO