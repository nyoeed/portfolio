-- ====== BILLING / FACTURATION ======

IF OBJECT_ID('dbo.Invoices', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Invoices (
    id INT IDENTITY(1,1) PRIMARY KEY,
    invoiceNumber NVARCHAR(30) NOT NULL UNIQUE,   -- INV-2026-001
    eventName NVARCHAR(200) NOT NULL,
    clientName NVARCHAR(200) NOT NULL,
    issueDate DATE NOT NULL,
    dueDate DATE NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
    taxRate DECIMAL(5,2) NOT NULL DEFAULT 0,      -- ex 13.00
    taxAmount AS (ROUND(subtotal * (taxRate/100.0), 2)) PERSISTED,
    total AS (ROUND(subtotal + (subtotal * (taxRate/100.0)), 2)) PERSISTED,
    status NVARCHAR(20) NOT NULL DEFAULT 'pending', -- pending | paid | overdue | cancelled
    createdAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
  );
END
GO

IF OBJECT_ID('dbo.Payments', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Payments (
    id INT IDENTITY(1,1) PRIMARY KEY,
    invoiceId INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    method NVARCHAR(40) NOT NULL,                 -- Virement bancaire / Carte bancaire / Chèque
    paidAt DATE NOT NULL,
    reference NVARCHAR(100) NULL,
    createdAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Payments_Invoices FOREIGN KEY (invoiceId) REFERENCES dbo.Invoices(id)
  );
END
GO

IF OBJECT_ID('dbo.Refunds', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Refunds (
    id INT IDENTITY(1,1) PRIMARY KEY,
    invoiceId INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,                -- négatif recommandé
    reason NVARCHAR(200) NOT NULL,
    refundDate DATE NOT NULL,
    status NVARCHAR(20) NOT NULL DEFAULT 'processed', -- processed | pending
    createdAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Refunds_Invoices FOREIGN KEY (invoiceId) REFERENCES dbo.Invoices(id)
  );
END
GO

-- Optionnel mais utile: index pour filtres
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Invoices_Status' AND object_id = OBJECT_ID('dbo.Invoices'))
  CREATE INDEX IX_Invoices_Status ON dbo.Invoices(status);
GO

-- =========================================
-- SEED FACTURATION - La Promenade
-- =========================================

-- Nettoyage (optionnel)
-- ATTENTION: ça efface les données facturation
DELETE FROM dbo.Refunds;
DELETE FROM dbo.Payments;
DELETE FROM dbo.Invoices;

-- Dates utiles
DECLARE @today DATE = CAST(GETDATE() AS DATE);
DECLARE @startThisMonth DATE = DATEFROMPARTS(YEAR(@today), MONTH(@today), 1);
DECLARE @startNextMonth DATE = DATEADD(MONTH, 1, @startThisMonth);
DECLARE @startLastMonth DATE = DATEADD(MONTH, -1, @startThisMonth);

-- -------------------------
-- Invoices (factures)
-- -------------------------
INSERT INTO dbo.Invoices (
  invoiceNumber, eventName, clientName, issueDate, dueDate, subtotal, taxRate, status
)
VALUES
-- ✅ Ce mois-ci
('INV-2026-101', 'Mariage Dupont-Martin', 'Alice Dupont', DATEADD(DAY, 2, @startThisMonth), DATEADD(DAY, 10, @startThisMonth), 15000, 13.00, 'paid'),
('INV-2026-102', 'Séminaire TechCorp', 'Marc Laurent', DATEADD(DAY, 5, @startThisMonth), DATEADD(DAY, 15, @startThisMonth), 8500, 13.00, 'pending'),
('INV-2026-103', 'Conférence AI Summit', 'Thomas Bernard', DATEADD(DAY, 8, @startThisMonth), DATEADD(DAY, 18, @startThisMonth), 25000, 13.00, 'paid'),
('INV-2026-104', 'Gala de Charité', 'Chloé Dubois', DATEADD(DAY, 12, @startThisMonth), DATEADD(DAY, 13, @startThisMonth), 22000, 13.00, 'overdue'),
('INV-2026-105', 'Formation RH', 'Julie Moreau', DATEADD(DAY, 1, @startThisMonth), DATEADD(DAY, 2, @startThisMonth), 3500, 13.00, 'overdue'),

-- ✅ Mois passé (pour vérifier KPI “Ce mois”)
('INV-2026-090', 'Réunion Conseil', 'Nadia Kone', DATEADD(DAY, 10, @startLastMonth), DATEADD(DAY, 20, @startLastMonth), 1200, 13.00, 'paid'),
('INV-2026-091', 'Anniversaire Entreprise', 'Lucas Martin', DATEADD(DAY, 15, @startLastMonth), DATEADD(DAY, 25, @startLastMonth), 18000, 13.00, 'paid');

-- -------------------------
-- Payments (paiements)
-- -------------------------
DECLARE @inv101 INT = (SELECT id FROM dbo.Invoices WHERE invoiceNumber='INV-2026-101');
DECLARE @inv103 INT = (SELECT id FROM dbo.Invoices WHERE invoiceNumber='INV-2026-103');
DECLARE @inv090 INT = (SELECT id FROM dbo.Invoices WHERE invoiceNumber='INV-2026-090');
DECLARE @inv091 INT = (SELECT id FROM dbo.Invoices WHERE invoiceNumber='INV-2026-091');

INSERT INTO dbo.Payments (invoiceId, amount, method, paidAt, reference)
VALUES
(@inv101, (SELECT total FROM dbo.Invoices WHERE id=@inv101), 'Virement bancaire', DATEADD(DAY, 9, @startThisMonth), 'PAY-TRF-101'),
(@inv103, (SELECT total FROM dbo.Invoices WHERE id=@inv103), 'Carte bancaire', DATEADD(DAY, 17, @startThisMonth), 'PAY-CC-103'),
(@inv090, (SELECT total FROM dbo.Invoices WHERE id=@inv090), 'Chèque', DATEADD(DAY, 19, @startLastMonth), 'PAY-CHK-090'),
(@inv091, (SELECT total FROM dbo.Invoices WHERE id=@inv091), 'Virement bancaire', DATEADD(DAY, 24, @startLastMonth), 'PAY-TRF-091');

-- -------------------------
-- Refunds (remboursements)
-- -------------------------
DECLARE @inv101b INT = (SELECT id FROM dbo.Invoices WHERE invoiceNumber='INV-2026-101');

INSERT INTO dbo.Refunds (invoiceId, amount, refundDate, reason, status)
VALUES
(@inv101b, -2500, DATEADD(DAY, 12, @startThisMonth), 'Ajustement - annulation partielle', 'processed');

-- -------------------------
-- Vérification rapide
-- -------------------------
SELECT TOP 20 invoiceNumber, eventName, clientName, issueDate, dueDate, subtotal, taxRate, total, status
FROM dbo.Invoices
ORDER BY issueDate DESC;

SELECT TOP 20 p.id, i.invoiceNumber, i.clientName, p.amount, p.method, p.paidAt
FROM dbo.Payments p
JOIN dbo.Invoices i ON i.id = p.invoiceId
ORDER BY p.paidAt DESC;

SELECT TOP 20 r.id, i.invoiceNumber, i.clientName, r.amount, r.reason, r.refundDate, r.status
FROM dbo.Refunds r
JOIN dbo.Invoices i ON i.id = r.invoiceId
ORDER BY r.refundDate DESC;