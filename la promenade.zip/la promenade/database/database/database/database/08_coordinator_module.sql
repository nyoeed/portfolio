USE LaPromenadeDB;
GO

/* =========================================================
   Coordinator module - schema extensions
========================================================= */

-- ---------------------------------------------------------
-- Events extensions
-- ---------------------------------------------------------
IF COL_LENGTH('dbo.Events', 'description') IS NULL
  ALTER TABLE dbo.Events ADD description NVARCHAR(1200) NULL;
GO
IF COL_LENGTH('dbo.Events', 'budget') IS NULL
  ALTER TABLE dbo.Events ADD budget DECIMAL(12,2) NOT NULL CONSTRAINT DF_Events_Budget DEFAULT 0;
GO
IF COL_LENGTH('dbo.Events', 'organizerId') IS NULL
  ALTER TABLE dbo.Events ADD organizerId UNIQUEIDENTIFIER NULL;
GO
IF COL_LENGTH('dbo.Events', 'roomId') IS NULL
  ALTER TABLE dbo.Events ADD roomId UNIQUEIDENTIFIER NULL;
GO
IF COL_LENGTH('dbo.Events', 'assignedCoordinatorId') IS NULL
  ALTER TABLE dbo.Events ADD assignedCoordinatorId UNIQUEIDENTIFIER NULL;
GO
IF COL_LENGTH('dbo.Events', 'submittedAt') IS NULL
  ALTER TABLE dbo.Events ADD submittedAt DATETIME2 NULL;
GO
IF COL_LENGTH('dbo.Events', 'updatedAt') IS NULL
  ALTER TABLE dbo.Events ADD updatedAt DATETIME2 NOT NULL CONSTRAINT DF_Events_UpdatedAt DEFAULT SYSUTCDATETIME();
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Events_Organizer')
BEGIN
  ALTER TABLE dbo.Events ADD CONSTRAINT FK_Events_Organizer
  FOREIGN KEY (organizerId) REFERENCES dbo.Users(id);
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Events_Room')
BEGIN
  ALTER TABLE dbo.Events ADD CONSTRAINT FK_Events_Room
  FOREIGN KEY (roomId) REFERENCES dbo.Rooms(id);
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Events_AssignedCoordinator')
BEGIN
  ALTER TABLE dbo.Events ADD CONSTRAINT FK_Events_AssignedCoordinator
  FOREIGN KEY (assignedCoordinatorId) REFERENCES dbo.Users(id);
END
GO

IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Events_Status')
BEGIN
  ALTER TABLE dbo.Events DROP CONSTRAINT CK_Events_Status;
END
GO
ALTER TABLE dbo.Events ADD CONSTRAINT CK_Events_Status
CHECK (status IN ('draft','submitted','in_review','validated','confirmed','in_coordination','in_progress','completed','cancelled'));
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Events_DateRange')
BEGIN
  ALTER TABLE dbo.Events ADD CONSTRAINT CK_Events_DateRange CHECK (endAt IS NULL OR endAt > startAt);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Events_Status_StartAt' AND object_id = OBJECT_ID('dbo.Events'))
  CREATE INDEX IX_Events_Status_StartAt ON dbo.Events(status, startAt);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Events_RoomId_StartAt' AND object_id = OBJECT_ID('dbo.Events'))
  CREATE INDEX IX_Events_RoomId_StartAt ON dbo.Events(roomId, startAt);
GO

-- ---------------------------------------------------------
-- Reservations extensions for event linkage + lock status
-- ---------------------------------------------------------
IF COL_LENGTH('dbo.Reservations', 'eventId') IS NULL
  ALTER TABLE dbo.Reservations ADD eventId UNIQUEIDENTIFIER NULL;
GO
IF COL_LENGTH('dbo.Reservations', 'lockedByCoordinatorId') IS NULL
  ALTER TABLE dbo.Reservations ADD lockedByCoordinatorId UNIQUEIDENTIFIER NULL;
GO

IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Reservations_Status')
BEGIN
  ALTER TABLE dbo.Reservations DROP CONSTRAINT CK_Reservations_Status;
END
GO
ALTER TABLE dbo.Reservations ADD CONSTRAINT CK_Reservations_Status
CHECK (status IN ('pending','locked','confirmed','cancelled'));
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Reservations_Events')
BEGIN
  ALTER TABLE dbo.Reservations ADD CONSTRAINT FK_Reservations_Events
  FOREIGN KEY (eventId) REFERENCES dbo.Events(id);
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Reservations_LockedByCoordinator')
BEGIN
  ALTER TABLE dbo.Reservations ADD CONSTRAINT FK_Reservations_LockedByCoordinator
  FOREIGN KEY (lockedByCoordinatorId) REFERENCES dbo.Users(id);
END
GO

-- ---------------------------------------------------------
-- Event guests
-- ---------------------------------------------------------
IF OBJECT_ID('dbo.EventGuests', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.EventGuests (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_EventGuests PRIMARY KEY DEFAULT NEWID(),
    eventId UNIQUEIDENTIFIER NOT NULL,
    firstName NVARCHAR(80) NOT NULL,
    lastName NVARCHAR(80) NOT NULL,
    email NVARCHAR(255) NULL,
    phone NVARCHAR(40) NULL,
    company NVARCHAR(120) NULL,
    rsvpStatus NVARCHAR(20) NOT NULL CONSTRAINT DF_EventGuests_RsvpStatus DEFAULT 'pending',
    dietaryNotes NVARCHAR(300) NULL,
    specialNeeds NVARCHAR(300) NULL,
    invitationSentAt DATETIME2 NULL,
    respondedAt DATETIME2 NULL,
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_EventGuests_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_EventGuests_Events FOREIGN KEY (eventId) REFERENCES dbo.Events(id) ON DELETE CASCADE,
    CONSTRAINT CK_EventGuests_RsvpStatus CHECK (rsvpStatus IN ('invited','confirmed','declined','pending'))
  );
  CREATE INDEX IX_EventGuests_EventId ON dbo.EventGuests(eventId);
END
GO

-- ---------------------------------------------------------
-- Event documents
-- ---------------------------------------------------------
IF OBJECT_ID('dbo.EventDocuments', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.EventDocuments (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_EventDocuments PRIMARY KEY DEFAULT NEWID(),
    eventId UNIQUEIDENTIFIER NOT NULL,
    uploadedByUserId UNIQUEIDENTIFIER NULL,
    category NVARCHAR(50) NOT NULL CONSTRAINT DF_EventDocuments_Category DEFAULT 'piece_jointe',
    title NVARCHAR(180) NOT NULL,
    fileName NVARCHAR(260) NOT NULL,
    filePath NVARCHAR(400) NOT NULL,
    mimeType NVARCHAR(120) NULL,
    fileSizeBytes BIGINT NULL,
    versionNo INT NOT NULL CONSTRAINT DF_EventDocuments_VersionNo DEFAULT 1,
    isCoordinatorVisible BIT NOT NULL CONSTRAINT DF_EventDocuments_CoordVisible DEFAULT 1,
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_EventDocuments_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_EventDocuments_Events FOREIGN KEY (eventId) REFERENCES dbo.Events(id) ON DELETE CASCADE,
    CONSTRAINT FK_EventDocuments_UploadedBy FOREIGN KEY (uploadedByUserId) REFERENCES dbo.Users(id)
  );
  CREATE INDEX IX_EventDocuments_EventId ON dbo.EventDocuments(eventId);
END
GO

-- ---------------------------------------------------------
-- Event service requests
-- ---------------------------------------------------------
IF OBJECT_ID('dbo.EventServiceRequests', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.EventServiceRequests (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_EventServiceRequests PRIMARY KEY DEFAULT NEWID(),
    eventId UNIQUEIDENTIFIER NOT NULL,
    serviceId UNIQUEIDENTIFIER NOT NULL,
    requestedByUserId UNIQUEIDENTIFIER NULL,
    assignedToUserId UNIQUEIDENTIFIER NULL,
    quantity DECIMAL(10,2) NOT NULL CONSTRAINT DF_EventServiceRequests_Quantity DEFAULT 1,
    requestedStartAt DATETIME2 NULL,
    requestedEndAt DATETIME2 NULL,
    plannedStartAt DATETIME2 NULL,
    plannedEndAt DATETIME2 NULL,
    priority NVARCHAR(20) NOT NULL CONSTRAINT DF_EventServiceRequests_Priority DEFAULT 'medium',
    status NVARCHAR(20) NOT NULL CONSTRAINT DF_EventServiceRequests_Status DEFAULT 'requested',
    locationNote NVARCHAR(180) NULL,
    remarks NVARCHAR(800) NULL,
    estimatedAmount DECIMAL(12,2) NOT NULL CONSTRAINT DF_EventServiceRequests_EstimatedAmount DEFAULT 0,
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_EventServiceRequests_CreatedAt DEFAULT SYSUTCDATETIME(),
    updatedAt DATETIME2 NOT NULL CONSTRAINT DF_EventServiceRequests_UpdatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_EventServiceRequests_Event FOREIGN KEY (eventId) REFERENCES dbo.Events(id) ON DELETE CASCADE,
    CONSTRAINT FK_EventServiceRequests_Service FOREIGN KEY (serviceId) REFERENCES dbo.Services(id),
    CONSTRAINT FK_EventServiceRequests_RequestedBy FOREIGN KEY (requestedByUserId) REFERENCES dbo.Users(id),
    CONSTRAINT FK_EventServiceRequests_AssignedTo FOREIGN KEY (assignedToUserId) REFERENCES dbo.Users(id),
    CONSTRAINT CK_EventServiceRequests_Priority CHECK (priority IN ('low','medium','high','critical')),
    CONSTRAINT CK_EventServiceRequests_Status CHECK (status IN ('requested','in_analysis','approved','planned','in_progress','completed','refused','cancelled'))
  );
  CREATE INDEX IX_EventServiceRequests_EventId ON dbo.EventServiceRequests(eventId);
  CREATE INDEX IX_EventServiceRequests_Status ON dbo.EventServiceRequests(status);
END
GO

-- ---------------------------------------------------------
-- Event tasks / checklist
-- ---------------------------------------------------------
IF OBJECT_ID('dbo.EventTasks', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.EventTasks (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_EventTasks PRIMARY KEY DEFAULT NEWID(),
    eventId UNIQUEIDENTIFIER NOT NULL,
    createdByUserId UNIQUEIDENTIFIER NULL,
    assignedToUserId UNIQUEIDENTIFIER NULL,
    title NVARCHAR(180) NOT NULL,
    description NVARCHAR(900) NULL,
    dueAt DATETIME2 NULL,
    priority NVARCHAR(20) NOT NULL CONSTRAINT DF_EventTasks_Priority DEFAULT 'medium',
    status NVARCHAR(20) NOT NULL CONSTRAINT DF_EventTasks_Status DEFAULT 'todo',
    category NVARCHAR(40) NOT NULL CONSTRAINT DF_EventTasks_Category DEFAULT 'checklist',
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_EventTasks_CreatedAt DEFAULT SYSUTCDATETIME(),
    updatedAt DATETIME2 NOT NULL CONSTRAINT DF_EventTasks_UpdatedAt DEFAULT SYSUTCDATETIME(),
    completedAt DATETIME2 NULL,
    CONSTRAINT FK_EventTasks_Event FOREIGN KEY (eventId) REFERENCES dbo.Events(id) ON DELETE CASCADE,
    CONSTRAINT FK_EventTasks_CreatedBy FOREIGN KEY (createdByUserId) REFERENCES dbo.Users(id),
    CONSTRAINT FK_EventTasks_AssignedTo FOREIGN KEY (assignedToUserId) REFERENCES dbo.Users(id),
    CONSTRAINT CK_EventTasks_Priority CHECK (priority IN ('low','medium','high','critical')),
    CONSTRAINT CK_EventTasks_Status CHECK (status IN ('todo','in_progress','blocked','done','cancelled'))
  );
  CREATE INDEX IX_EventTasks_EventId ON dbo.EventTasks(eventId);
  CREATE INDEX IX_EventTasks_Status ON dbo.EventTasks(status);
END
GO

-- ---------------------------------------------------------
-- Notes / internal comments
-- ---------------------------------------------------------
IF OBJECT_ID('dbo.EventNotes', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.EventNotes (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_EventNotes PRIMARY KEY DEFAULT NEWID(),
    eventId UNIQUEIDENTIFIER NOT NULL,
    authorUserId UNIQUEIDENTIFIER NULL,
    noteType NVARCHAR(30) NOT NULL CONSTRAINT DF_EventNotes_NoteType DEFAULT 'internal',
    content NVARCHAR(MAX) NOT NULL,
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_EventNotes_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_EventNotes_Event FOREIGN KEY (eventId) REFERENCES dbo.Events(id) ON DELETE CASCADE,
    CONSTRAINT FK_EventNotes_Author FOREIGN KEY (authorUserId) REFERENCES dbo.Users(id)
  );
  CREATE INDEX IX_EventNotes_EventId ON dbo.EventNotes(eventId);
END
GO

-- ---------------------------------------------------------
-- Reports / closure
-- ---------------------------------------------------------
IF OBJECT_ID('dbo.EventReports', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.EventReports (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_EventReports PRIMARY KEY DEFAULT NEWID(),
    eventId UNIQUEIDENTIFIER NOT NULL,
    createdByUserId UNIQUEIDENTIFIER NULL,
    finalParticipants INT NOT NULL CONSTRAINT DF_EventReports_FinalParticipants DEFAULT 0,
    serviceExecutionScore INT NULL,
    incidentCount INT NOT NULL CONSTRAINT DF_EventReports_IncidentCount DEFAULT 0,
    operationsComment NVARCHAR(1200) NULL,
    incidentsComment NVARCHAR(1200) NULL,
    satisfactionComment NVARCHAR(1200) NULL,
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_EventReports_CreatedAt DEFAULT SYSUTCDATETIME(),
    updatedAt DATETIME2 NOT NULL CONSTRAINT DF_EventReports_UpdatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_EventReports_Event FOREIGN KEY (eventId) REFERENCES dbo.Events(id) ON DELETE CASCADE,
    CONSTRAINT FK_EventReports_User FOREIGN KEY (createdByUserId) REFERENCES dbo.Users(id),
    CONSTRAINT UQ_EventReports_Event UNIQUE (eventId)
  );
END
GO

-- ---------------------------------------------------------
-- Audit log
-- ---------------------------------------------------------
IF OBJECT_ID('dbo.AuditLogs', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.AuditLogs (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_AuditLogs PRIMARY KEY DEFAULT NEWID(),
    entityType NVARCHAR(50) NOT NULL,
    entityId UNIQUEIDENTIFIER NULL,
    actionType NVARCHAR(50) NOT NULL,
    actorUserId UNIQUEIDENTIFIER NULL,
    actorRole NVARCHAR(30) NULL,
    summary NVARCHAR(240) NOT NULL,
    detailsJson NVARCHAR(MAX) NULL,
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_AuditLogs_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_AuditLogs_Users FOREIGN KEY (actorUserId) REFERENCES dbo.Users(id)
  );
  CREATE INDEX IX_AuditLogs_Entity ON dbo.AuditLogs(entityType, entityId, createdAt DESC);
END
GO

-- ---------------------------------------------------------
-- Notifications extensions
-- ---------------------------------------------------------
IF COL_LENGTH('dbo.Notifications', 'recipientUserId') IS NULL
  ALTER TABLE dbo.Notifications ADD recipientUserId UNIQUEIDENTIFIER NULL;
GO
IF COL_LENGTH('dbo.Notifications', 'category') IS NULL
  ALTER TABLE dbo.Notifications ADD category NVARCHAR(40) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Notifications_RecipientUser')
BEGIN
  ALTER TABLE dbo.Notifications ADD CONSTRAINT FK_Notifications_RecipientUser
  FOREIGN KEY (recipientUserId) REFERENCES dbo.Users(id);
END
GO

-- ---------------------------------------------------------
-- Helpful seed data when tables are empty
-- ---------------------------------------------------------
IF EXISTS (SELECT 1 FROM dbo.Users WHERE role = 'coordinator' AND status = 'approved')
BEGIN
  DECLARE @coordinatorId UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.Users WHERE role = 'coordinator' AND status = 'approved' ORDER BY createdAt ASC);
  DECLARE @organizerId UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.Users WHERE role = 'organizer' AND status = 'approved' ORDER BY createdAt ASC);
  DECLARE @roomId UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.Rooms ORDER BY createdAt ASC);
  DECLARE @serviceId UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.Services ORDER BY createdAt ASC);

  IF @organizerId IS NOT NULL AND @roomId IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Events)
  BEGIN
    INSERT INTO dbo.Events (title, type, description, startAt, endAt, participants, budget, status, organizerId, roomId, assignedCoordinatorId, submittedAt)
    VALUES
      (N'Mariage Harmonie', N'mariage', N'Configuration banquet et piste de danse.', DATEADD(DAY, 2, SYSUTCDATETIME()), DATEADD(DAY, 2, DATEADD(HOUR, 8, SYSUTCDATETIME())), 160, 22000, 'submitted', @organizerId, @roomId, @coordinatorId, SYSUTCDATETIME()),
      (N'Séminaire Horizon', N'séminaire', N'Séminaire avec projection et pauses café.', DATEADD(DAY, 4, SYSUTCDATETIME()), DATEADD(DAY, 4, DATEADD(HOUR, 6, SYSUTCDATETIME())), 80, 9500, 'in_coordination', @organizerId, @roomId, @coordinatorId, SYSUTCDATETIME());
  END

  DECLARE @event1 UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.Events ORDER BY createdAt ASC);
  DECLARE @event2 UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.Events ORDER BY createdAt DESC);

  IF @event1 IS NOT NULL AND @serviceId IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.EventServiceRequests)
  BEGIN
    INSERT INTO dbo.EventServiceRequests (eventId, serviceId, requestedByUserId, assignedToUserId, quantity, requestedStartAt, requestedEndAt, plannedStartAt, plannedEndAt, priority, status, locationNote, remarks, estimatedAmount)
    VALUES
      (@event1, @serviceId, @organizerId, @coordinatorId, 120, DATEADD(HOUR, 1, (SELECT startAt FROM dbo.Events WHERE id=@event1)), DATEADD(HOUR, 5, (SELECT startAt FROM dbo.Events WHERE id=@event1)), DATEADD(HOUR, 1, (SELECT startAt FROM dbo.Events WHERE id=@event1)), DATEADD(HOUR, 5, (SELECT startAt FROM dbo.Events WHERE id=@event1)), 'high', 'requested', N'Salle principale', N'Prévoir installation complète.', 1800),
      (@event2, @serviceId, @organizerId, @coordinatorId, 2, DATEADD(HOUR, -1, (SELECT startAt FROM dbo.Events WHERE id=@event2)), DATEADD(HOUR, 1, (SELECT startAt FROM dbo.Events WHERE id=@event2)), DATEADD(HOUR, -1, (SELECT startAt FROM dbo.Events WHERE id=@event2)), DATEADD(HOUR, 1, (SELECT startAt FROM dbo.Events WHERE id=@event2)), 'medium', 'planned', N'Zone accueil', N'Verification technique la veille.', 650);
  END

  IF @event1 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.EventTasks)
  BEGIN
    INSERT INTO dbo.EventTasks (eventId, createdByUserId, assignedToUserId, title, description, dueAt, priority, status, category)
    VALUES
      (@event1, @coordinatorId, @coordinatorId, N'Confirmer le menu final', N'Valider les régimes spéciaux avec le traiteur.', DATEADD(DAY, 1, SYSUTCDATETIME()), 'high', 'todo', 'checklist'),
      (@event1, @coordinatorId, @coordinatorId, N'Tester le projecteur', N'Verifier la fiche technique audio/vidéo.', DATEADD(DAY, 1, SYSUTCDATETIME()), 'medium', 'in_progress', 'audiovisuel');
  END

  IF @event1 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.EventGuests)
  BEGIN
    INSERT INTO dbo.EventGuests (eventId, firstName, lastName, email, rsvpStatus, dietaryNotes)
    VALUES
      (@event1, N'Alice', N'Dupont', 'alice@example.com', 'confirmed', N'Vegétarien'),
      (@event1, N'Karim', N'Benali', 'karim@example.com', 'pending', NULL),
      (@event1, N'Sarah', N'Moreau', 'sarah@example.com', 'declined', N'Sans gluten');
  END
END
GO
