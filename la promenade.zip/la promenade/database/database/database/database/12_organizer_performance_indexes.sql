USE LaPromenadeDB;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Events_Organizer_Status_StartAt' AND object_id = OBJECT_ID('dbo.Events'))
  CREATE INDEX IX_Events_Organizer_Status_StartAt ON dbo.Events(organizerId, status, startAt DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Reservations_Room_Time_Status' AND object_id = OBJECT_ID('dbo.Reservations'))
  CREATE INDEX IX_Reservations_Room_Time_Status ON dbo.Reservations(roomId, startAt, endAt, status);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_EventServiceRequests_Event_Service' AND object_id = OBJECT_ID('dbo.EventServiceRequests'))
  CREATE INDEX IX_EventServiceRequests_Event_Service ON dbo.EventServiceRequests(eventId, serviceId, createdAt DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_EventGuests_Event_Rsvp' AND object_id = OBJECT_ID('dbo.EventGuests'))
  CREATE INDEX IX_EventGuests_Event_Rsvp ON dbo.EventGuests(eventId, rsvpStatus, createdAt DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_EventDocuments_Event_CreatedAt' AND object_id = OBJECT_ID('dbo.EventDocuments'))
  CREATE INDEX IX_EventDocuments_Event_CreatedAt ON dbo.EventDocuments(eventId, createdAt DESC);
GO
