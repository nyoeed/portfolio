USE LaPromenadeDB;
GO

IF COL_LENGTH('dbo.Users', 'updatedAt') IS NULL
  ALTER TABLE dbo.Users ADD updatedAt DATETIME2 NOT NULL CONSTRAINT DF_Users_UpdatedAt DEFAULT SYSUTCDATETIME();
GO

IF COL_LENGTH('dbo.Users', 'phone') IS NULL ALTER TABLE dbo.Users ADD phone NVARCHAR(40) NULL;
GO
IF COL_LENGTH('dbo.Users', 'organization') IS NULL ALTER TABLE dbo.Users ADD organization NVARCHAR(160) NULL;
GO
IF COL_LENGTH('dbo.Users', 'jobTitle') IS NULL ALTER TABLE dbo.Users ADD jobTitle NVARCHAR(120) NULL;
GO
IF COL_LENGTH('dbo.Users', 'addressLine') IS NULL ALTER TABLE dbo.Users ADD addressLine NVARCHAR(220) NULL;
GO
IF COL_LENGTH('dbo.Users', 'postalCode') IS NULL ALTER TABLE dbo.Users ADD postalCode NVARCHAR(40) NULL;
GO
IF COL_LENGTH('dbo.Users', 'city') IS NULL ALTER TABLE dbo.Users ADD city NVARCHAR(100) NULL;
GO
IF COL_LENGTH('dbo.Users', 'country') IS NULL ALTER TABLE dbo.Users ADD country NVARCHAR(100) NULL;
GO
IF COL_LENGTH('dbo.Users', 'notificationEmailEnabled') IS NULL ALTER TABLE dbo.Users ADD notificationEmailEnabled BIT NOT NULL CONSTRAINT DF_Users_NotificationEmailEnabled DEFAULT 1;
GO
IF COL_LENGTH('dbo.Users', 'notificationSmsEnabled') IS NULL ALTER TABLE dbo.Users ADD notificationSmsEnabled BIT NOT NULL CONSTRAINT DF_Users_NotificationSmsEnabled DEFAULT 0;
GO
IF COL_LENGTH('dbo.Users', 'notificationInAppEnabled') IS NULL ALTER TABLE dbo.Users ADD notificationInAppEnabled BIT NOT NULL CONSTRAINT DF_Users_NotificationInAppEnabled DEFAULT 1;
GO
IF COL_LENGTH('dbo.Notifications', 'recipientUserId') IS NULL ALTER TABLE dbo.Notifications ADD recipientUserId UNIQUEIDENTIFIER NULL;
GO
IF COL_LENGTH('dbo.Notifications', 'category') IS NULL ALTER TABLE dbo.Notifications ADD category NVARCHAR(40) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name='FK_Notifications_RecipientUserId')
BEGIN
  ALTER TABLE dbo.Notifications WITH NOCHECK
  ADD CONSTRAINT FK_Notifications_RecipientUserId FOREIGN KEY (recipientUserId) REFERENCES dbo.Users(id);
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Notifications_RecipientUserId')
  CREATE INDEX IX_Notifications_RecipientUserId ON dbo.Notifications(recipientUserId, createdAt DESC);
GO
