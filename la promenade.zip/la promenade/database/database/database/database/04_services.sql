/* =========================================================
   05) Services
========================================================= */

USE LaPromenadeDB;
GO

IF OBJECT_ID('dbo.Services', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Services (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Services PRIMARY KEY DEFAULT NEWID(),
    name NVARCHAR(150) NOT NULL,
    category NVARCHAR(60) NOT NULL,        -- Traiteur / Audiovisuel / Sécurité / Logistique / Autres
    description NVARCHAR(500) NULL,

    unitLabel NVARCHAR(30) NOT NULL,       -- par personne | par jour | par heure | forfait | par unité
    price DECIMAL(10,2) NOT NULL,

    availability NVARCHAR(20) NOT NULL CONSTRAINT DF_Services_Availability DEFAULT 'available',
    imageUrl NVARCHAR(300) NULL,           -- /uploads/services/xxx.jpg

    createdAt DATETIME2 NOT NULL CONSTRAINT DF_Services_CreatedAt DEFAULT SYSUTCDATETIME(),

    CONSTRAINT CK_Services_Availability CHECK (availability IN ('available','unavailable')),
    CONSTRAINT CK_Services_UnitLabel CHECK (unitLabel IN ('par personne','par jour','par heure','forfait','par unité'))
  );
END
GO