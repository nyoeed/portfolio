USE LaPromenadeDB;
GO

/* =========================================================
   Organizer module - schema extensions
   À exécuter après 08_coordinator_module.sql et 09_accounting_migration.sql
========================================================= */

-- ---------------------------------------------------------
-- Users profile / preferences
-- ---------------------------------------------------------
IF COL_LENGTH('dbo.Users', 'phone') IS NULL
  ALTER TABLE dbo.Users ADD phone NVARCHAR(40) NULL;
GO
IF COL_LENGTH('dbo.Users', 'organization') IS NULL
  ALTER TABLE dbo.Users ADD organization NVARCHAR(150) NULL;
GO
IF COL_LENGTH('dbo.Users', 'jobTitle') IS NULL
  ALTER TABLE dbo.Users ADD jobTitle NVARCHAR(120) NULL;
GO
IF COL_LENGTH('dbo.Users', 'photoUrl') IS NULL
  ALTER TABLE dbo.Users ADD photoUrl NVARCHAR(300) NULL;
GO
IF COL_LENGTH('dbo.Users', 'addressLine') IS NULL
  ALTER TABLE dbo.Users ADD addressLine NVARCHAR(200) NULL;
GO
IF COL_LENGTH('dbo.Users', 'postalCode') IS NULL
  ALTER TABLE dbo.Users ADD postalCode NVARCHAR(30) NULL;
GO
IF COL_LENGTH('dbo.Users', 'city') IS NULL
  ALTER TABLE dbo.Users ADD city NVARCHAR(100) NULL;
GO
IF COL_LENGTH('dbo.Users', 'country') IS NULL
  ALTER TABLE dbo.Users ADD country NVARCHAR(100) NULL;
GO
IF COL_LENGTH('dbo.Users', 'notificationEmailEnabled') IS NULL
  ALTER TABLE dbo.Users ADD notificationEmailEnabled BIT NOT NULL CONSTRAINT DF_Users_NotificationEmail DEFAULT 1;
GO
IF COL_LENGTH('dbo.Users', 'notificationSmsEnabled') IS NULL
  ALTER TABLE dbo.Users ADD notificationSmsEnabled BIT NOT NULL CONSTRAINT DF_Users_NotificationSms DEFAULT 0;
GO
IF COL_LENGTH('dbo.Users', 'notificationInAppEnabled') IS NULL
  ALTER TABLE dbo.Users ADD notificationInAppEnabled BIT NOT NULL CONSTRAINT DF_Users_NotificationInApp DEFAULT 1;
GO

-- ---------------------------------------------------------
-- Notifications targeted to a user
-- ---------------------------------------------------------
IF COL_LENGTH('dbo.Notifications', 'recipientUserId') IS NULL
  ALTER TABLE dbo.Notifications ADD recipientUserId UNIQUEIDENTIFIER NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Notifications_RecipientUser')
BEGIN
  ALTER TABLE dbo.Notifications ADD CONSTRAINT FK_Notifications_RecipientUser
  FOREIGN KEY (recipientUserId) REFERENCES dbo.Users(id);
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Notifications_RecipientUserId' AND object_id = OBJECT_ID('dbo.Notifications'))
  CREATE INDEX IX_Notifications_RecipientUserId ON dbo.Notifications(recipientUserId, createdAt DESC);
GO

-- ---------------------------------------------------------
-- Event guests organizer-specific fields
-- ---------------------------------------------------------
IF COL_LENGTH('dbo.EventGuests', 'plusOne') IS NULL
  ALTER TABLE dbo.EventGuests ADD plusOne BIT NOT NULL CONSTRAINT DF_EventGuests_PlusOne DEFAULT 0;
GO
IF COL_LENGTH('dbo.EventGuests', 'notes') IS NULL
  ALTER TABLE dbo.EventGuests ADD notes NVARCHAR(400) NULL;
GO

-- ---------------------------------------------------------
-- Event reports organizer analytics
-- ---------------------------------------------------------
IF COL_LENGTH('dbo.EventReports', 'satisfactionScore') IS NULL
  ALTER TABLE dbo.EventReports ADD satisfactionScore DECIMAL(3,2) NULL;
GO
IF COL_LENGTH('dbo.EventReports', 'summaryText') IS NULL
  ALTER TABLE dbo.EventReports ADD summaryText NVARCHAR(2000) NULL;
GO
IF COL_LENGTH('dbo.EventReports', 'budgetVariance') IS NULL
  ALTER TABLE dbo.EventReports ADD budgetVariance DECIMAL(12,2) NULL;
GO

-- ---------------------------------------------------------
-- Optional direct link invoice -> event
-- ---------------------------------------------------------
IF COL_LENGTH('dbo.Invoices', 'eventId') IS NULL
  ALTER TABLE dbo.Invoices ADD eventId UNIQUEIDENTIFIER NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Invoices_Event')
BEGIN
  ALTER TABLE dbo.Invoices ADD CONSTRAINT FK_Invoices_Event
  FOREIGN KEY (eventId) REFERENCES dbo.Events(id);
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Invoices_EventId' AND object_id = OBJECT_ID('dbo.Invoices'))
  CREATE INDEX IX_Invoices_EventId ON dbo.Invoices(eventId);
GO

/* =========================================================
   Seed minimal organizer demo data (safe / optional)
========================================================= */
IF EXISTS (SELECT 1 FROM dbo.Users WHERE role = 'organizer')
BEGIN
  UPDATE TOP (1) dbo.Users
  SET organization = ISNULL(organization, N'Entreprise ABC'),
      jobTitle = ISNULL(jobTitle, N'Responsable événements'),
      phone = ISNULL(phone, N'+1 613 555 1000'),
      addressLine = ISNULL(addressLine, N'123 Rue de la République'),
      city = ISNULL(city, N'Ottawa'),
      country = ISNULL(country, N'Canada'),
      postalCode = ISNULL(postalCode, N'K1A 0A1')
  WHERE id = (SELECT TOP 1 id FROM dbo.Users WHERE role = 'organizer' ORDER BY createdAt ASC);
END
GO
