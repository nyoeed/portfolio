/* =========================================================
   04) Rooms + Equipments + Reservations
========================================================= */

USE LaPromenadeDB;
GO

-- Rooms
IF OBJECT_ID('dbo.Rooms', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Rooms (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Rooms PRIMARY KEY DEFAULT NEWID(),
    name NVARCHAR(150) NOT NULL,
    capacity INT NOT NULL,
    surface INT NULL,
    pricePerDay DECIMAL(10,2) NOT NULL,
    status NVARCHAR(20) NOT NULL CONSTRAINT DF_Rooms_Status DEFAULT 'available',
    imageUrl NVARCHAR(300) NULL, -- ✅ IMPORTANT pour ton backend (/uploads/rooms/...)
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_Rooms_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Rooms_Status CHECK (status IN ('available','reserved','maintenance'))
  );
END
GO

-- Equipments
IF OBJECT_ID('dbo.RoomEquipments', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.RoomEquipments (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_RoomEquipments PRIMARY KEY DEFAULT NEWID(),
    roomId UNIQUEIDENTIFIER NOT NULL,
    label NVARCHAR(100) NOT NULL,
    CONSTRAINT FK_RoomEquipments_Rooms FOREIGN KEY (roomId)
      REFERENCES dbo.Rooms(id) ON DELETE CASCADE
  );
END
GO

-- Reservations
IF OBJECT_ID('dbo.Reservations', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Reservations (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Reservations PRIMARY KEY DEFAULT NEWID(),
    roomId UNIQUEIDENTIFIER NOT NULL,
    organizerId UNIQUEIDENTIFIER NOT NULL,
    title NVARCHAR(200) NOT NULL,
    startAt DATETIME2 NOT NULL,
    endAt DATETIME2 NOT NULL,
    participants INT NOT NULL,
    status NVARCHAR(20) NOT NULL CONSTRAINT DF_Reservations_Status DEFAULT 'pending',
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_Reservations_CreatedAt DEFAULT SYSUTCDATETIME(),

    CONSTRAINT FK_Reservations_Rooms FOREIGN KEY (roomId)
      REFERENCES dbo.Rooms(id) ON DELETE CASCADE,

    CONSTRAINT FK_Reservations_Users FOREIGN KEY (organizerId)
      REFERENCES dbo.Users(id),

    CONSTRAINT CK_Reservations_Status CHECK (status IN ('pending','confirmed','cancelled')),
    CONSTRAINT CK_Reservations_Dates CHECK (endAt > startAt)
  );
END
GO