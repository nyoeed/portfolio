/* =========================================================
   08) Notifications + indexes
========================================================= */

USE LaPromenadeDB;
GO

IF OBJECT_ID('dbo.Notifications', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Notifications (
    id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,

    type VARCHAR(20) NOT NULL,                -- payment | event | user | system
    priority VARCHAR(10) NOT NULL DEFAULT 'normal', -- normal | urgent

    title NVARCHAR(160) NOT NULL,
    message NVARCHAR(600) NULL,

    isRead BIT NOT NULL DEFAULT 0,

    relatedEntity VARCHAR(30) NULL,
    relatedId UNIQUEIDENTIFIER NULL,

    createdAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
  );

  CREATE INDEX IX_Notifications_CreatedAt ON dbo.Notifications(createdAt DESC);
  CREATE INDEX IX_Notifications_IsRead ON dbo.Notifications(isRead);
  CREATE INDEX IX_Notifications_Priority ON dbo.Notifications(priority);
  CREATE INDEX IX_Notifications_Type ON dbo.Notifications(type);
END
GO

/* =========================================================
   99) Seed (dev) - Notifications only
========================================================= */

USE LaPromenadeDB;
GO

IF OBJECT_ID('dbo.Notifications', 'U') IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Notifications)
BEGIN
  INSERT INTO dbo.Notifications (type, priority, title, message, isRead, createdAt)
  VALUES
  ('payment','urgent', N'Paiement en retard', N'La facture INV-2026-005 (Formation RH - 3 500€) est en retard depuis 2 jours.', 0, DATEADD(HOUR,-2, SYSUTCDATETIME())),
  ('user','normal', N'Nouvelle demande d''inscription', N'Sophie Martin a demandé un compte Organisateur.', 0, DATEADD(DAY,-1, SYSUTCDATETIME())),
  ('event','normal', N'Événement confirmé', N'Le Mariage Dupont-Martin (25 Fév 2026) a été confirmé.', 1, DATEADD(DAY,-2, SYSUTCDATETIME())),
  ('system','urgent', N'Conflit de réservation', N'La Grande Salle de Bal est réservée deux fois le 28 Février 2026.', 0, DATEADD(DAY,-2, SYSUTCDATETIME())),
  ('payment','normal', N'Paiement reçu', N'Paiement de 25 000€ reçu pour la facture INV-2026-003 (AI Summit).', 1, DATEADD(DAY,-3, SYSUTCDATETIME())),
  ('payment','normal', N'Rappel de paiement', N'La facture INV-2026-002 (8 500€) arrive à échéance dans 7 jours.', 0, DATEADD(DAY,-4, SYSUTCDATETIME())),
  ('event','normal', N'Nouvel événement créé', N'Formation RH a été créé pour le 20 Mars 2026.', 1, DATEADD(DAY,-5, SYSUTCDATETIME())),
  ('user','normal', N'Compte approuvé', N'Le compte de Marc Laurent (Coordonnateur) a été approuvé.', 1, DATEADD(DAY,-6, SYSUTCDATETIME()));
END
GO