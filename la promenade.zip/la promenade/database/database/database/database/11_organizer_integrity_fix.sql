USE LaPromenadeDB;
GO

/* =========================================================
   Organizer integrity fix
   - backfill invoice.eventId
   - normalize document paths if needed
========================================================= */

IF COL_LENGTH('dbo.Invoices', 'eventId') IS NOT NULL
BEGIN
  UPDATE i
  SET eventId = e.id
  FROM dbo.Invoices i
  INNER JOIN dbo.Events e
    ON COALESCE(i.eventTitle, i.eventName) = e.title
  WHERE i.eventId IS NULL;
END
GO

IF OBJECT_ID('dbo.EventDocuments', 'U') IS NOT NULL
BEGIN
  UPDATE dbo.EventDocuments
  SET filePath = REPLACE(filePath, '\\', '/')
  WHERE filePath LIKE '%\\uploads\\%';
END
GO
