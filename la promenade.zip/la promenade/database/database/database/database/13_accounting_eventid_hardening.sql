USE LaPromenadeDB;
GO

/* =========================================================
   Accounting hardening: invoices linked by eventId
========================================================= */

IF COL_LENGTH('dbo.Invoices', 'eventId') IS NULL
BEGIN
  ALTER TABLE dbo.Invoices ADD eventId UNIQUEIDENTIFIER NULL;
END
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Invoices_Event'
)
BEGIN
  ALTER TABLE dbo.Invoices ADD CONSTRAINT FK_Invoices_Event
  FOREIGN KEY (eventId) REFERENCES dbo.Events(id);
END
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.indexes WHERE name = 'IX_Invoices_EventId' AND object_id = OBJECT_ID('dbo.Invoices')
)
BEGIN
  CREATE INDEX IX_Invoices_EventId ON dbo.Invoices(eventId);
END
GO

UPDATE i
SET i.eventId = e.id,
    i.eventTitle = COALESCE(i.eventTitle, e.title),
    i.eventName = COALESCE(i.eventName, e.title),
    i.eventType = COALESCE(i.eventType, e.type)
FROM dbo.Invoices i
INNER JOIN dbo.Events e
  ON COALESCE(i.eventTitle, i.eventName) = e.title
WHERE i.eventId IS NULL;
GO
