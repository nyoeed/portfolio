/* =========================================================
   00) Base + USE
========================================================= */

IF DB_ID('LaPromenadeDB') IS NULL
BEGIN
  CREATE DATABASE LaPromenadeDB;
END
GO

USE LaPromenadeDB;
GO