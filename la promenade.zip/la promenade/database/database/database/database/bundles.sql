/* =========================================================
   06) Bundles + BundleItems
========================================================= */

USE LaPromenadeDB;
GO

IF OBJECT_ID('dbo.Bundles', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Bundles (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Bundles PRIMARY KEY DEFAULT NEWID(),
    name NVARCHAR(150) NOT NULL,
    description NVARCHAR(500) NULL,
    unitLabel NVARCHAR(30) NOT NULL,      -- par personne | par jour | forfait
    price DECIMAL(10,2) NOT NULL,
    availability NVARCHAR(20) NOT NULL CONSTRAINT DF_Bundles_Availability DEFAULT 'available',
    createdAt DATETIME2 NOT NULL CONSTRAINT DF_Bundles_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Bundles_Availability CHECK (availability IN ('available','unavailable')),
    CONSTRAINT CK_Bundles_UnitLabel CHECK (unitLabel IN ('par personne','par jour','forfait'))
  );
END
GO

IF OBJECT_ID('dbo.BundleItems', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.BundleItems (
    id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_BundleItems PRIMARY KEY DEFAULT NEWID(),
    bundleId UNIQUEIDENTIFIER NOT NULL,
    serviceId UNIQUEIDENTIFIER NOT NULL,

    CONSTRAINT FK_BundleItems_Bundles FOREIGN KEY (bundleId)
      REFERENCES dbo.Bundles(id) ON DELETE CASCADE,

    CONSTRAINT FK_BundleItems_Services FOREIGN KEY (serviceId)
      REFERENCES dbo.Services(id)
  );
END
GO