USE LaPromenadeDB;
GO

/*
  Coordinator workflow upgrade
  - backfills coordinator assignment on active events
  - backfills service request assignees
  - adds helpful indexes for coordinator dashboards
*/

IF NOT EXISTS (
  SELECT 1 FROM sys.indexes WHERE name = 'IX_Events_AssignedCoordinator_Status_StartAt' AND object_id = OBJECT_ID('dbo.Events')
)
BEGIN
  CREATE INDEX IX_Events_AssignedCoordinator_Status_StartAt
    ON dbo.Events(assignedCoordinatorId, status, startAt);
END
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.indexes WHERE name = 'IX_EventServiceRequests_AssignedTo_Status' AND object_id = OBJECT_ID('dbo.EventServiceRequests')
)
BEGIN
  CREATE INDEX IX_EventServiceRequests_AssignedTo_Status
    ON dbo.EventServiceRequests(assignedToUserId, status, plannedStartAt);
END
GO

DECLARE @defaultCoordinatorId UNIQUEIDENTIFIER;
SELECT TOP 1 @defaultCoordinatorId = u.id
FROM dbo.Users u
OUTER APPLY (
  SELECT COUNT(*) AS activeEvents
  FROM dbo.Events e
  WHERE e.assignedCoordinatorId = u.id
    AND e.status IN ('submitted','in_review','validated','confirmed','in_coordination','in_progress')
) loadInfo
WHERE u.role = 'coordinator'
  AND u.status = 'approved'
ORDER BY loadInfo.activeEvents ASC, u.createdAt ASC;

IF @defaultCoordinatorId IS NOT NULL
BEGIN
  UPDATE dbo.Events
  SET assignedCoordinatorId = @defaultCoordinatorId,
      updatedAt = SYSUTCDATETIME()
  WHERE assignedCoordinatorId IS NULL
    AND status IN ('submitted','in_review','validated','confirmed','in_coordination','in_progress','completed');

  UPDATE sr
  SET assignedToUserId = COALESCE(sr.assignedToUserId, e.assignedCoordinatorId),
      requestedStartAt = COALESCE(sr.requestedStartAt, e.startAt),
      requestedEndAt = COALESCE(sr.requestedEndAt, e.endAt),
      updatedAt = SYSUTCDATETIME()
  FROM dbo.EventServiceRequests sr
  JOIN dbo.Events e ON e.id = sr.eventId
  WHERE sr.assignedToUserId IS NULL
     OR sr.requestedStartAt IS NULL
     OR sr.requestedEndAt IS NULL;
END
GO

IF EXISTS (SELECT 1 FROM dbo.Users WHERE role='coordinator' AND status='approved')
BEGIN
  INSERT INTO dbo.Notifications (id, type, priority, title, message, isRead, relatedEntity, relatedId, recipientUserId, category, createdAt)
  SELECT NEWID(), 'event', 'high', N'Événement à prendre en charge',
         N'Un événement actif a été rattaché à votre file de coordination lors de la mise à niveau du module coordonnateur.',
         0, 'event', e.id, e.assignedCoordinatorId, 'coordination', SYSUTCDATETIME()
  FROM dbo.Events e
  WHERE e.assignedCoordinatorId IS NOT NULL
    AND e.status IN ('submitted','in_review','validated','confirmed','in_coordination','in_progress')
    AND NOT EXISTS (
      SELECT 1
      FROM dbo.Notifications n
      WHERE n.relatedEntity = 'event'
        AND n.relatedId = e.id
        AND n.recipientUserId = e.assignedCoordinatorId
        AND n.title = N'Événement à prendre en charge'
    );
END
GO
