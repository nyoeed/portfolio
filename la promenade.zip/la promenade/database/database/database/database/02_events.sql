/* =========================================================
   02) Events
========================================================= */

USE LaPromenadeDB;
GO

IF OBJECT_ID('dbo.Events', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Events (
    id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,

    title NVARCHAR(200) NOT NULL,
    type NVARCHAR(50) NULL,

    startAt DATETIME2 NOT NULL,
    endAt DATETIME2 NULL,

    participants INT NOT NULL DEFAULT 0,

    status NVARCHAR(30) NOT NULL DEFAULT 'draft', -- draft, pending, confirmed, cancelled
    createdAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
  );
END
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Events_Status'
)
BEGIN
  ALTER TABLE dbo.Events
  ADD CONSTRAINT CK_Events_Status
  CHECK (status IN ('draft','pending','confirmed','cancelled'));
END
GO