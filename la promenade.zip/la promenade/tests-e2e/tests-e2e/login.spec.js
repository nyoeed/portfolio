const { test, expect } = require('@playwright/test');

test('Login admin', async ({ page }) => {
  await page.goto('/login');

  await page.fill('input[name="email"]', 'admin@test.com');
  await page.fill('input[name="password"]', 'password123');

  await page.click('button[type="submit"]');

  await expect(page).toHaveURL(/dashboard/);
});
