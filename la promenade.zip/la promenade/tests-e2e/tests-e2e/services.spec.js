const { test, expect } = require('@playwright/test');

test('Create service', async ({ page }) => {
  await page.goto('/login');

  await page.fill('input[name="email"]', 'admin@test.com');
  await page.fill('input[name="password"]', 'password123');
  await page.click('button[type="submit"]');

  await page.goto('/admin/services');

  await page.fill('input[name="name"]', 'Service Test');
  await page.fill('input[name="price"]', '100');

  await page.click('button:has-text("Ajouter")');

  await expect(page.locator('text=Service Test')).toBeVisible();
});
