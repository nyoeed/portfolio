const { test, expect } = require('@playwright/test');

test('Create reservation', async ({ page }) => {
  await page.goto('/login');

  await page.fill('input[name="email"]', 'admin@test.com');
  await page.fill('input[name="password"]', 'password123');
  await page.click('button[type="submit"]');

  await page.goto('/admin/reservations');

  await page.click('button:has-text("Ajouter")');

  await page.fill('input[name="title"]', 'Event Test');

  await page.click('button:has-text("Enregistrer")');

  await expect(page.locator('text=Event Test')).toBeVisible();
});
