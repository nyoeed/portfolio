const { test, expect } = require('@playwright/test');

test('User list visible', async ({ page }) => {
  await page.goto('/login');

  await page.fill('input[name="email"]', 'admin@test.com');
  await page.fill('input[name="password"]', 'password123');
  await page.click('button[type="submit"]');

  await page.goto('/admin/users');

  await expect(page.locator('table')).toBeVisible();
});
