const { test, expect } = require('@playwright/test');

test('Create room', async ({ page }) => {
  await page.goto('/login');

  await page.fill('input[name="email"]', 'admin@test.com');
  await page.fill('input[name="password"]', 'password123');
  await page.click('button[type="submit"]');

  await page.goto('/admin/rooms');

  await page.fill('input[name="name"]', 'Room Test');
  await page.fill('input[name="capacity"]', '50');

  await page.click('button:has-text("Ajouter")');

  await expect(page.locator('text=Room Test')).toBeVisible();
});
