// src/server.js
require("dotenv").config();

const { loadEnv } = require("./config/env");
loadEnv(); // valide les variables au démarrage

const { createApp } = require("./app");

const app = createApp();

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`API running on http://localhost:${port}`));