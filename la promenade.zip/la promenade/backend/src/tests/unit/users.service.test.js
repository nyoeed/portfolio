jest.mock('../../repositories/admin/users.repo', () => ({ listPending: jest.fn(), approveRequest: jest.fn(), rejectRequest: jest.fn(), listUsers: jest.fn(), existsByEmail: jest.fn(), createUser: jest.fn(), countAll: jest.fn(), updateUserStatus: jest.fn(), updateUserRole: jest.fn(), emailTakenByAnotherUser: jest.fn(), updateUser: jest.fn(), deleteUser: jest.fn() }));
jest.mock('bcryptjs', () => ({ hash: jest.fn() }));
const repo = require('../../repositories/admin/users.repo'); const bcrypt = require('bcryptjs'); const service = require('../../services/admin/users.service');
describe('users.service', () => {
  beforeEach(() => jest.clearAllMocks());
  test('user service main flows work', async () => {
    repo.existsByEmail.mockResolvedValue(false); bcrypt.hash.mockResolvedValue('hash'); repo.createUser.mockResolvedValue({ id: 'u1' });
    await expect(service.createUser({ fullName: ' Amadou ', email: 'A@TEST.COM ', password: 'Strong1!', role: 'admin' })).resolves.toEqual({ id: 'u1' });
    repo.approveRequest.mockResolvedValue(false); await expect(service.approveRequest({ id: 'u1' })).rejects.toMatchObject({ code: 'NOT_FOUND' });
    repo.updateUserStatus.mockResolvedValue(true); await expect(service.updateUserStatus({ id: 'u1', status: 'approved' })).resolves.toBe(true);
    repo.updateUserRole.mockResolvedValue({ id: 'u1', role: 'coordinator' }); await expect(service.updateUserRole({ id: 'u1', role: 'coordinator' })).resolves.toMatchObject({ role: 'coordinator' });
    repo.emailTakenByAnotherUser.mockResolvedValue(false); repo.updateUser.mockResolvedValue({ id: 'u1' }); await expect(service.updateUser({ id: 'u1', body: { fullName: 'Amadou', email: 'a@test.com', role: 'admin' } })).resolves.toEqual({ id: 'u1' });
    await expect(service.deleteUser({ id: 'u1', requesterId: 'u1' })).rejects.toMatchObject({ code: 'SELF_DELETE' });
  });
});
