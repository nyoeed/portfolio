jest.mock("../../repositories/system.repo", () => ({
  hasAnyAdmin: jest.fn(),
  existsByEmail: jest.fn(),
  insertAdmin: jest.fn(),
}));

jest.mock("bcrypt", () => ({
  hash: jest.fn(),
}));

jest.mock("../../utils/jwt", () => ({
  signToken: jest.fn(),
}));

const systemRepo = require("../../repositories/system.repo");
const bcrypt = require("bcrypt");
const { signToken } = require("../../utils/jwt");
const systemService = require("../../services/system.service");

describe("system.service", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    process.env.INIT_ADMIN_SECRET = "init-secret";
  });

  describe("isInitialized", () => {
    it("should return true when an admin exists", async () => {
      systemRepo.hasAnyAdmin.mockResolvedValue(true);

      const result = await systemService.isInitialized();

      expect(result).toBe(true);
    });

    it("should return false when no admin exists", async () => {
      systemRepo.hasAnyAdmin.mockResolvedValue(false);

      const result = await systemService.isInitialized();

      expect(result).toBe(false);
    });
  });

  describe("initAdmin", () => {
    it("should create the first admin", async () => {
      systemRepo.hasAnyAdmin.mockResolvedValueOnce(false);
      systemRepo.existsByEmail.mockResolvedValue(false);
      bcrypt.hash.mockResolvedValue("hashed-password");
      systemRepo.insertAdmin.mockResolvedValue({
        id: "u1",
        fullName: "Admin User",
        email: "admin@test.com",
        role: "admin",
        status: "approved",
      });
      signToken.mockReturnValue("signed-token");

      const result = await systemService.initAdmin({
        fullName: "Admin User",
        email: "admin@test.com",
        password: "password123",
        secretKey: "init-secret",
      });

      expect(bcrypt.hash).toHaveBeenCalledWith("password123", 12);
      expect(systemRepo.insertAdmin).toHaveBeenCalledWith({
        fullName: "Admin User",
        email: "admin@test.com",
        passwordHash: "hashed-password",
      });
      expect(signToken).toHaveBeenCalled();
      expect(result).toEqual({
        token: "signed-token",
        user: {
          id: "u1",
          fullName: "Admin User",
          email: "admin@test.com",
          role: "admin",
          status: "approved",
        },
      });
    });

    it("should throw BAD_DATA if payload is invalid", async () => {
      await expect(
        systemService.initAdmin({
          fullName: "A",
          email: "bad-email",
          password: "123",
          secretKey: "",
        })
      ).rejects.toMatchObject({
        code: "BAD_DATA",
      });
    });

    it("should throw BAD_SECRET if secret is invalid", async () => {
      await expect(
        systemService.initAdmin({
          fullName: "Admin User",
          email: "admin@test.com",
          password: "password123",
          secretKey: "wrong-secret",
        })
      ).rejects.toMatchObject({
        code: "BAD_SECRET",
      });
    });

    it("should throw ALREADY_INIT if system already initialized", async () => {
      systemRepo.hasAnyAdmin.mockResolvedValue(true);

      await expect(
        systemService.initAdmin({
          fullName: "Admin User",
          email: "admin@test.com",
          password: "password123",
          secretKey: "init-secret",
        })
      ).rejects.toMatchObject({
        code: "ALREADY_INIT",
      });
    });

    it("should throw EMAIL_EXISTS if email already exists", async () => {
      systemRepo.hasAnyAdmin.mockResolvedValue(false);
      systemRepo.existsByEmail.mockResolvedValue(true);

      await expect(
        systemService.initAdmin({
          fullName: "Admin User",
          email: "admin@test.com",
          password: "password123",
          secretKey: "init-secret",
        })
      ).rejects.toMatchObject({
        code: "EMAIL_EXISTS",
      });
    });
  });
});