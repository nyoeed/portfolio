jest.mock('../../repositories/admin/invoices.repo', () => ({ getStats: jest.fn(), listInvoices: jest.fn(), listPayments: jest.fn(), listRefunds: jest.fn(), getInvoiceDetails: jest.fn(), generateInvoiceForEvent: jest.fn(), createPayment: jest.fn(), createRefund: jest.fn(), createOnlineCheckout: jest.fn(), confirmOnlineCheckout: jest.fn(), getInvoiceForPdf: jest.fn(), getReceiptForPdf: jest.fn() }));
const repo = require('../../repositories/admin/invoices.repo'); const service = require('../../services/admin/invoices.service');
describe('invoices.service', () => {
  test('invoice service maps statuses and validates', async () => {
    repo.listInvoices.mockResolvedValue([{ id: 'g1', invoiceNumber: 'INV-1', eventTitle: 'Conf', clientName: 'Client', issuedAt: '2026-03-10T00:00:00Z', dueAt: '2026-03-20T00:00:00Z', amount: 100, statusComputed: 'late' }]);
    repo.listRefunds.mockResolvedValue([{ id: 'r1', invoiceId: 'g1', invoiceNumber: 'INV-1', clientName: 'Client', amount: 10, createdAt: '2026-03-10T00:00:00Z', reason: 'test', status: 'processed' }]);
    const invoices = await service.listInvoices({}); expect(invoices[0].status).toBe('overdue');
    const refunds = await service.listRefunds({}); expect(refunds[0].amount).toBe(-10);
    repo.getInvoiceDetails.mockResolvedValue(null); await expect(service.getInvoiceDetails('g1')).rejects.toMatchObject({ status: 404 });
  });
});
