const { loadEnv } = require("../../config/env");

describe("config/env", () => {
  const ORIGINAL_ENV = process.env;

  beforeEach(() => {
    jest.resetModules();
    process.env = { ...ORIGINAL_ENV };
  });

  afterAll(() => {
    process.env = ORIGINAL_ENV;
  });

  it("should load env with defaults", () => {
    process.env.DB_SERVER = "localhost";
    process.env.DB_DATABASE = "testdb";
    process.env.DB_USER = "sa";
    process.env.DB_PASSWORD = "Password123!";
    process.env.JWT_SECRET = "secret";
    process.env.INIT_ADMIN_SECRET = "init-secret";

    const env = loadEnv();

    expect(env).toEqual({
      PORT: 4000,
      CORS_ORIGIN: "http://localhost:5173",
      JWT_SECRET: "secret",
      JWT_EXPIRES_IN: "7d",
      INIT_ADMIN_SECRET: "init-secret",
      DB_SERVER: "localhost",
      DB_PORT: 1433,
      DB_DATABASE: "testdb",
      DB_USER: "sa",
      DB_PASSWORD: "Password123!",
      DB_ENCRYPT: false,
    });
  });

  it("should parse explicit values", () => {
    process.env.DB_SERVER = "localhost";
    process.env.DB_DATABASE = "testdb";
    process.env.DB_USER = "sa";
    process.env.DB_PASSWORD = "Password123!";
    process.env.DB_PORT = "1444";
    process.env.DB_ENCRYPT = "true";
    process.env.PORT = "5000";
    process.env.JWT_SECRET = "secret";
    process.env.JWT_EXPIRES_IN = "2d";
    process.env.INIT_ADMIN_SECRET = "init-secret";
    process.env.CORS_ORIGIN = "http://localhost:3000";

    const env = loadEnv();

    expect(env.DB_PORT).toBe(1444);
    expect(env.DB_ENCRYPT).toBe(true);
    expect(env.PORT).toBe(5000);
    expect(env.JWT_EXPIRES_IN).toBe("2d");
    expect(env.CORS_ORIGIN).toBe("http://localhost:3000");
  });

  it("should throw if required env is missing", () => {
    delete process.env.DB_SERVER;
    process.env.DB_DATABASE = "testdb";
    process.env.DB_USER = "sa";
    process.env.DB_PASSWORD = "Password123!";
    process.env.JWT_SECRET = "secret";
    process.env.INIT_ADMIN_SECRET = "init-secret";

    expect(() => loadEnv()).toThrow("Missing environment variable: DB_SERVER");
  });

  it("should throw if numeric env is invalid", () => {
    process.env.DB_SERVER = "localhost";
    process.env.DB_DATABASE = "testdb";
    process.env.DB_USER = "sa";
    process.env.DB_PASSWORD = "Password123!";
    process.env.DB_PORT = "abc";
    process.env.JWT_SECRET = "secret";
    process.env.INIT_ADMIN_SECRET = "init-secret";

    expect(() => loadEnv()).toThrow("Invalid number env var: DB_PORT");
  });
});