jest.mock("../../utils/jwt", () => ({
  verifyToken: jest.fn(),
}));

const { verifyToken } = require("../../utils/jwt");
const {
  requireAuth,
  requireApproved,
  requireRole,
} = require("../../middleware/auth");

function mockRes() {
  return {
    status: jest.fn().mockReturnThis(),
    json: jest.fn(),
  };
}

describe("auth middleware", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("requireAuth", () => {
    it("should return 401 if no bearer token", () => {
      const req = { headers: {} };
      const res = mockRes();
      const next = jest.fn();

      requireAuth(req, res, next);

      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({ message: "Unauthorized" });
      expect(next).not.toHaveBeenCalled();
    });

    it("should call next if token is valid", () => {
      const req = {
        headers: {
          authorization: "Bearer valid-token",
        },
      };
      const res = mockRes();
      const next = jest.fn();

      verifyToken.mockReturnValue({
        id: "u1",
        role: "admin",
        status: "approved",
      });

      requireAuth(req, res, next);

      expect(req.user).toEqual({
        id: "u1",
        role: "admin",
        status: "approved",
      });
      expect(next).toHaveBeenCalled();
    });

    it("should return 401 if token is invalid", () => {
      const req = {
        headers: {
          authorization: "Bearer bad-token",
        },
      };
      const res = mockRes();
      const next = jest.fn();

      verifyToken.mockImplementation(() => {
        throw new Error("bad token");
      });

      requireAuth(req, res, next);

      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({ message: "Unauthorized" });
      expect(next).not.toHaveBeenCalled();
    });
  });

  describe("requireApproved", () => {
    it("should return 403 if account is not approved", () => {
      const req = { user: { status: "pending" } };
      const res = mockRes();
      const next = jest.fn();

      requireApproved(req, res, next);

      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({
        message: "Account not approved",
      });
      expect(next).not.toHaveBeenCalled();
    });

    it("should call next if account is approved", () => {
      const req = { user: { status: "approved" } };
      const res = mockRes();
      const next = jest.fn();

      requireApproved(req, res, next);

      expect(next).toHaveBeenCalled();
    });
  });

  describe("requireRole", () => {
    it("should return 403 if role is forbidden", () => {
      const req = { user: { role: "organizer" } };
      const res = mockRes();
      const next = jest.fn();

      requireRole("admin")(req, res, next);

      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({ message: "Forbidden" });
      expect(next).not.toHaveBeenCalled();
    });

    it("should call next if role is allowed", () => {
      const req = { user: { role: "admin" } };
      const res = mockRes();
      const next = jest.fn();

      requireRole("admin", "accounting")(req, res, next);

      expect(next).toHaveBeenCalled();
    });
  });
});