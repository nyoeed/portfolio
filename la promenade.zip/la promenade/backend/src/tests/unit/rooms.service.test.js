jest.mock('../../repositories/admin/rooms.repo', () => ({ getStats: jest.fn(), listWithDetails: jest.fn(), createRoomWithEquipments: jest.fn(), updateRoomAndMaybeEquipments: jest.fn(), remove: jest.fn() }));
const repo = require('../../repositories/admin/rooms.repo'); const service = require('../../services/admin/rooms.service');
describe('rooms.service', () => {
  test('rooms service normalizes and throws on missing', async () => {
    repo.createRoomWithEquipments.mockResolvedValue({ id: 'r1' });
    await service.create({ name: ' Salle A ', capacity: '10', surface: '20', pricePerDay: '100', equipments: [' Wifi ', '', 'Projecteur'] });
    expect(repo.createRoomWithEquipments).toHaveBeenCalledWith(expect.objectContaining({ name: 'Salle A', equipments: ['Wifi', 'Projecteur'] }));
    repo.updateRoomAndMaybeEquipments.mockResolvedValue(null); await expect(service.update({ id: 'r1', body: {} })).rejects.toThrow('Salle introuvable');
    repo.remove.mockResolvedValue(false); await expect(service.remove({ id: 'r1' })).rejects.toThrow('Salle introuvable');
  });
});
