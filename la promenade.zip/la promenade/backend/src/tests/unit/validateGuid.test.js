const { isGuid, validateGuid } = require("../../middleware/validateGuid");

function mockRes() {
  return {
    status: jest.fn().mockReturnThis(),
    json: jest.fn(),
  };
}

describe("validateGuid middleware", () => {
  describe("isGuid", () => {
    it("should return true for a valid GUID", () => {
      expect(isGuid("550e8400-e29b-41d4-a716-446655440000")).toBe(true);
    });

    it("should return false for an invalid GUID", () => {
      expect(isGuid("123")).toBe(false);
    });
  });

  describe("validateGuid", () => {
    it("should call next when GUID is valid", () => {
      const req = {
        params: { id: "550e8400-e29b-41d4-a716-446655440000" },
      };
      const res = mockRes();
      const next = jest.fn();

      validateGuid("id")(req, res, next);

      expect(next).toHaveBeenCalled();
    });

    it("should return 400 when GUID is invalid", () => {
      const req = { params: { id: "bad-id" } };
      const res = mockRes();
      const next = jest.fn();

      validateGuid("id")(req, res, next);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        message: "ID invalide (GUID attendu): id",
      });
      expect(next).not.toHaveBeenCalled();
    });

    it("should validate a custom param name", () => {
      const req = { params: { userId: "bad-id" } };
      const res = mockRes();
      const next = jest.fn();

      validateGuid("userId")(req, res, next);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        message: "ID invalide (GUID attendu): userId",
      });
    });
  });
});