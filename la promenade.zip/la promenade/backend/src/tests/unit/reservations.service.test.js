jest.mock('../../repositories/admin/reservations.repo', () => ({ list: jest.fn(), createWithConflictCheck: jest.fn(), updateStatus: jest.fn(), remove: jest.fn() }));
const repo = require('../../repositories/admin/reservations.repo'); const service = require('../../services/admin/reservations.service');
describe('reservations.service', () => {
  test('reservations service validates and passes filters', async () => {
    repo.list.mockResolvedValue([]); await service.list({ from: '2026-03-01', to: 'bad-date' }); expect(repo.list).toHaveBeenCalledWith(expect.objectContaining({ from: expect.any(Date), to: null }));
    repo.createWithConflictCheck.mockResolvedValue({ id: 'res1' }); await expect(service.create({ roomId: 'r1', organizerId: 'u1', title: ' Event ', startAt: '2026-03-10T10:00:00Z', endAt: '2026-03-10T11:00:00Z', participants: 10 })).resolves.toEqual({ id: 'res1' });
  });
});
