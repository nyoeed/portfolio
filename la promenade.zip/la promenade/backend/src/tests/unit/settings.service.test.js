jest.mock('../../repositories/admin/settings.repo', () => ({ getFirst: jest.fn(), upsertOne: jest.fn() }));
const repo = require('../../repositories/admin/settings.repo'); const service = require('../../services/admin/settings.service');
describe('settings.service', () => {
  test('settings service defaults and clamps values', async () => {
    repo.getFirst.mockResolvedValue(null); const defaults = await service.get(); expect(defaults.hotelName).toBe('Hôtel La Promenade');
    repo.upsertOne.mockImplementation(async row => ({ ...row, updatedAt: 'now', createdAt: 'earlier' })); const data = await service.upsert({ hotelName: '', email: 'contact@test.com', taxRate: 120, paymentDelayDays: 999, onlinePaymentEnabled: 'true' }); expect(data.taxRate).toBe(100);
  });
});
