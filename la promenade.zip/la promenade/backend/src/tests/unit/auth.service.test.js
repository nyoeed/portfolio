jest.mock("../../repositories/auth.repo", () => ({
  userExistsByEmail: jest.fn(),
  insertPendingUser: jest.fn(),
  findUserForLogin: jest.fn(),
  updateLastLogin: jest.fn(),
}));

jest.mock("bcrypt", () => ({
  hash: jest.fn(),
  compare: jest.fn(),
}));

jest.mock("../../utils/jwt", () => ({
  signToken: jest.fn(),
}));

const authRepo = require("../../repositories/auth.repo");
const { signToken } = require("../../utils/jwt");
const authService = require("../../services/auth.service");
const bcrypt = require("bcrypt");


describe("auth.service", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("register", () => {
    it("should register a pending user", async () => {
      authRepo.userExistsByEmail.mockResolvedValue(false);
      bcrypt.hash.mockResolvedValue("hashed-password");
      authRepo.insertPendingUser.mockResolvedValue();

      const result = await authService.register({
        fullName: "Amadou Gueye",
        email: "amadou@test.com",
        password: "password123",
        roleRequested: "organizer",
      });

      expect(authRepo.userExistsByEmail).toHaveBeenCalledWith({
        email: "amadou@test.com",
      });
      expect(bcrypt.hash).toHaveBeenCalledWith("password123", 12);
      expect(authRepo.insertPendingUser).toHaveBeenCalledWith({
        fullName: "Amadou Gueye",
        email: "amadou@test.com",
        passwordHash: "hashed-password",
        roleRequested: "organizer",
      });
      expect(result).toEqual({
        message: "Registered. Pending approval.",
      });
    });

    it("should throw EMAIL_EXISTS if email is already used", async () => {
      authRepo.userExistsByEmail.mockResolvedValue(true);

      await expect(
        authService.register({
          fullName: "Amadou Gueye",
          email: "amadou@test.com",
          password: "password123",
          roleRequested: "organizer",
        })
      ).rejects.toMatchObject({
        code: "EMAIL_EXISTS",
      });
    });

    it("should throw BAD_DATA if payload is invalid", async () => {
      await expect(
        authService.register({
          fullName: "A",
          email: "not-an-email",
          password: "123",
          roleRequested: "bad-role",
        })
      ).rejects.toMatchObject({
        code: "BAD_DATA",
      });
    });
  });

  describe("login", () => {
    it("should return token and user when credentials are valid", async () => {
      authRepo.findUserForLogin.mockResolvedValue({
        id: "u1",
        email: "amadou@test.com",
        fullName: "Amadou Gueye",
        passwordHash: "stored-hash",
        role: "admin",
        status: "approved",
      });

      bcrypt.compare.mockResolvedValue(true);
      authRepo.updateLastLogin.mockResolvedValue();
      signToken.mockReturnValue("signed-token");

      const result = await authService.login({
        email: "amadou@test.com",
        password: "password123",
      });

      expect(authRepo.findUserForLogin).toHaveBeenCalledWith({
        email: "amadou@test.com",
      });
      expect(bcrypt.compare).toHaveBeenCalledWith(
        "password123",
        "stored-hash"
      );
      expect(authRepo.updateLastLogin).toHaveBeenCalledWith({ id: "u1" });
      expect(signToken).toHaveBeenCalled();
      expect(result).toEqual({
        token: "signed-token",
        user: {
          id: "u1",
          email: "amadou@test.com",
          fullName: "Amadou Gueye",
          role: "admin",
          status: "approved",
        },
      });
    });

    it("should throw INVALID_CREDENTIALS if user does not exist", async () => {
      authRepo.findUserForLogin.mockResolvedValue(null);

      await expect(
        authService.login({
          email: "amadou@test.com",
          password: "password123",
        })
      ).rejects.toMatchObject({
        code: "INVALID_CREDENTIALS",
      });
    });

    it("should throw INVALID_CREDENTIALS if password is wrong", async () => {
      authRepo.findUserForLogin.mockResolvedValue({
        id: "u1",
        email: "amadou@test.com",
        fullName: "Amadou Gueye",
        passwordHash: "stored-hash",
        role: "admin",
        status: "approved",
      });

      bcrypt.compare.mockResolvedValue(false);

      await expect(
        authService.login({
          email: "amadou@test.com",
          password: "wrong-password",
        })
      ).rejects.toMatchObject({
        code: "INVALID_CREDENTIALS",
      });
    });
  });
});