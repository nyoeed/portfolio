jest.mock('../../repositories/admin/stats.repo', () => ({ getDashboardStats: jest.fn() }));
const repo = require('../../repositories/admin/stats.repo'); const service = require('../../services/admin/stats.service');
describe('stats.service', () => {
  test('stats service computes revenueChangePct', async () => { repo.getDashboardStats.mockResolvedValue({ totalUsers: 1, pendingRequests: 0, roles: [], statuses: [], newUsersThisMonth: 1, newUsersLastMonth: 2, activeEvents: 1, newEventsThisWeek: 1, revenueThisMonth: 150, revenueLastMonth: 100 }); const data = await service.get(); expect(data.revenueChangePct).toBe(50); });
});
