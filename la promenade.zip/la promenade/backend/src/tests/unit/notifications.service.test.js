jest.mock('../../repositories/admin/notifications.repo', () => ({ list: jest.fn(), getStats: jest.fn(), markRead: jest.fn(), markAllRead: jest.fn(), remove: jest.fn(), create: jest.fn() }));
const repo = require('../../repositories/admin/notifications.repo'); const service = require('../../services/admin/notifications.service');
describe('notifications.service', () => {
  test('notifications service validates ids and sanitizes create', async () => {
    repo.list.mockResolvedValue([]); await service.list({ tab: 'unread', limit: 999 }); expect(repo.list).toHaveBeenCalledWith({ unreadOnly: true, limit: 500 });
    await expect(service.markRead({ id: 'bad' })).rejects.toMatchObject({ code: 'BAD_ID' });
    repo.create.mockResolvedValue({ id: 'n1' }); await service.create({ type: 'bad', priority: 'bad', title: ' Hi ', relatedId: 'bad-guid' }); expect(repo.create).toHaveBeenCalledWith(expect.objectContaining({ type: 'system', priority: 'normal', title: 'Hi', relatedId: null }));
  });
});
