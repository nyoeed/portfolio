jest.mock("jsonwebtoken", () => ({
  sign: jest.fn(),
  verify: jest.fn(),
}));

const jwt = require("jsonwebtoken");
const { signToken, verifyToken } = require("../../utils/jwt");

describe("utils/jwt", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    process.env.JWT_SECRET = "test-secret";
    process.env.JWT_EXPIRES_IN = "1d";
  });

  it("signToken should call jwt.sign with env values", () => {
    jwt.sign.mockReturnValue("signed-token");

    const payload = { id: "u1", role: "admin" };
    const result = signToken(payload);

    expect(jwt.sign).toHaveBeenCalledWith(payload, "test-secret", {
      expiresIn: "1d",
    });
    expect(result).toBe("signed-token");
  });

  it("verifyToken should call jwt.verify with env secret", () => {
    jwt.verify.mockReturnValue({ id: "u1" });

    const result = verifyToken("abc");

    expect(jwt.verify).toHaveBeenCalledWith("abc", "test-secret");
    expect(result).toEqual({ id: "u1" });
  });
});