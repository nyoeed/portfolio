const { errorHandler } = require("../../middleware/errorHandler");

function mockRes() {
  return {
    headersSent: false,
    status: jest.fn().mockReturnThis(),
    json: jest.fn(),
  };
}

describe("errorHandler middleware", () => {
  it("should delegate to next if headers were already sent", () => {
    const err = new Error("boom");
    const req = {};
    const res = { headersSent: true };
    const next = jest.fn();

    errorHandler(err, req, res, next);

    expect(next).toHaveBeenCalledWith(err);
  });

  it("should handle MulterError", () => {
    const err = { name: "MulterError", message: "File too large" };
    const req = {};
    const res = mockRes();
    const next = jest.fn();

    errorHandler(err, req, res, next);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({
      message: "File too large",
    });
  });

  it("should handle custom statusCode", () => {
    const err = {
      message: "Forbidden",
      statusCode: 403,
      error: "NO_ACCESS",
    };
    const req = {};
    const res = mockRes();
    const next = jest.fn();

    errorHandler(err, req, res, next);

    expect(res.status).toHaveBeenCalledWith(403);
    expect(res.json).toHaveBeenCalledWith({
      message: "Forbidden",
      error: "NO_ACCESS",
    });
  });

  it("should default to 500", () => {
    const err = new Error("Server exploded");
    const req = {};
    const res = mockRes();
    const next = jest.fn();

    errorHandler(err, req, res, next);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({
      message: "Server exploded",
      error: undefined,
    });
  });
});