jest.mock('../../repositories/admin/services.repo', () => ({ getStats: jest.fn(), list: jest.fn(), create: jest.fn(), update: jest.fn(), remove: jest.fn() }));
const repo = require('../../repositories/admin/services.repo'); const service = require('../../services/admin/services.service');
describe('services.service', () => {
  test('services service validates and normalizes', async () => {
    repo.create.mockResolvedValue({ id: 's1' }); await service.create({ body: { name: ' Traiteur ', category: 'Traiteur', unitLabel: 'forfait', price: '22' }, file: { filename: 'pic.jpg' } }); expect(repo.create).toHaveBeenCalledWith(expect.objectContaining({ imageUrl: '/uploads/services/pic.jpg' }));
    await expect(service.create({ body: { name: 'x', category: 'Bad', unitLabel: 'forfait', price: 2 } })).rejects.toThrow('Catégorie invalide');
  });
});
