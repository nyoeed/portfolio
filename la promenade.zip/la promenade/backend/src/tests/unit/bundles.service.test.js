jest.mock('../../repositories/admin/bundles.repo', () => ({ listWithServices: jest.fn(), createBundleAndItems: jest.fn(), updateBundleAndMaybeItems: jest.fn(), remove: jest.fn() }));
const repo = require('../../repositories/admin/bundles.repo'); const service = require('../../services/admin/bundles.service');
describe('bundles.service', () => {
  test('bundles service validates and handles missing bundle', async () => {
    repo.createBundleAndItems.mockResolvedValue({ id: 'b1' }); await service.create({ name: ' Pack ', unitLabel: 'forfait', price: '50', serviceIds: ['s1'] }); expect(repo.createBundleAndItems).toHaveBeenCalledWith(expect.objectContaining({ name: 'Pack', price: 50 }));
    repo.updateBundleAndMaybeItems.mockResolvedValue(null); await expect(service.update({ id: 'b1', body: {} })).rejects.toThrow('Forfait introuvable');
  });
});
