jest.mock('../../repositories/admin/uploads.repo', () => ({ updateRoomImage: jest.fn() }));
const repo = require('../../repositories/admin/uploads.repo'); const service = require('../../services/admin/uploads.service');
describe('uploads.service', () => {
  test('uploads service builds room URL', async () => { repo.updateRoomImage.mockResolvedValue({ id: 'r1' }); await service.updateRoomImage({ id: 'r1', filename: 'abc.jpg' }); expect(repo.updateRoomImage).toHaveBeenCalledWith({ id: 'r1', imageUrl: '/uploads/rooms/abc.jpg' }); });
});
