let mockHasAdmin = false; let mockExists = false; let mockPool;
jest.mock('../../config/db', () => {
  const { createPool } = require('../helpers/mockDb');
  mockPool = createPool(({ sqlText }) => {
    if (sqlText.includes('COUNT(*) AS c')) return { recordset: [{ c: mockHasAdmin ? 1 : 0 }] };
    if (sqlText.includes('SELECT 1 FROM dbo.Users WHERE email=@email')) return { recordset: mockExists ? [{ ok: 1 }] : [] };
    if (sqlText.includes('INSERT INTO dbo.Users')) return { recordset: [{ id: 'a1', fullName: 'Admin', email: 'admin@test.com', role: 'admin', status: 'approved' }] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool) };
});
const repo = require('../../repositories/system.repo');
describe('system.repo (DB mocked)', () => {
  test('system repo methods work', async () => {
    mockHasAdmin = false; await expect(repo.hasAnyAdmin()).resolves.toBe(false);
    mockHasAdmin = true; await expect(repo.hasAnyAdmin()).resolves.toBe(true);
    mockExists = true; await expect(repo.existsByEmail({ email: 'x@test.com' })).resolves.toBe(true);
    await expect(repo.insertAdmin({ fullName: 'Admin', email: 'admin@test.com', passwordHash: 'hash' })).resolves.toMatchObject({ role: 'admin' });
  });
});
