let mockPool;
jest.mock('../../config/db', () => {
  const { createPool } = require('../helpers/mockDb');
  let i = 0; const replies = [
    { recordset: [{ totalUsers: 10 }] }, { recordset: [{ pendingRequests: 2 }] }, { recordset: [{ role: 'admin', count: 1 }] }, { recordset: [{ status: 'approved', count: 8 }] },
    { recordset: [{ newUsersThisMonth: 3 }] }, { recordset: [{ newUsersLastMonth: 4 }] }, { recordset: [{ activeEvents: 5 }] }, { recordset: [{ newEventsThisWeek: 2 }] }
  ];
  mockPool = createPool(() => replies[i++] || { recordset: [] });
  return { getPool: jest.fn(async () => mockPool) };
});
const repo = require('../../repositories/admin/stats.repo');
describe('stats.repo (DB mocked)', () => {
  test('getDashboardStats aggregates values', async () => {
    await expect(repo.getDashboardStats()).resolves.toMatchObject({ totalUsers: 10, pendingRequests: 2, activeEvents: 5, revenueThisMonth: 0, revenueLastMonth: 0 });
  });
});
