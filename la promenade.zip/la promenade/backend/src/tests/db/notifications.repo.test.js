let mockState = {}; let mockPool;
jest.mock('../../config/db', () => {
  const { createPool } = require('../helpers/mockDb');
  mockPool = createPool(({ sqlText }) => { sqlText = sqlText.toLowerCase();
    if (sqlText.includes('insert into dbo.notifications')) return { recordset: [{ id: 'n1', title: 'Hello', isRead: false }] };
    if (sqlText.includes('order by createdat desc')) return { recordset: [{ id: 'n1', title: 'Hello' }] };
    if (sqlText.includes('output inserted.id, inserted.isread')) return { recordset: mockState.markReadFound ? [{ id: 'n1', isRead: true }] : [] };
    if (sqlText.includes('set isread = 1') && sqlText.includes('where isread = 0')) return { recordset: [] };
    if (sqlText.includes('select') && sqlText.includes('count(*) as total') && sqlText.includes('from dbo.notifications')) return { recordset: [{ total: 2, unread: 1, highPriority: 1 }] };
    if (sqlText.includes('from dbo.adminsettings')) return { recordset: [{ notifEvents: 1, notifPayments: 0, notifSignup: 0, notifSystem: 0 }] };
    if (sqlText.includes('output deleted.id')) return { recordset: mockState.removeFound ? [{ id: 'n1' }] : [] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool), sql: { UniqueIdentifier: 'UniqueIdentifier', VarChar: (n)=>`VarChar(${n})`, NVarChar: (n)=>`NVarChar(${n})` } };
});
const repo = require('../../repositories/admin/notifications.repo');
describe('notifications.repo (DB mocked)', () => {
  beforeEach(() => { mockState = { markReadFound: true, removeFound: true }; });
  test('notifications repo methods work', async () => {
    await expect(repo.create({ type: 'system', priority: 'normal', title: 'Hello', message: null, relatedEntity: null, relatedId: null })).resolves.toMatchObject({ title: 'Hello' });
    await expect(repo.list({ unreadOnly: false, limit: 10 })).resolves.toHaveLength(1);
    await expect(repo.markRead({ id: 'x' })).resolves.toMatchObject({ isRead: true });
    await expect(repo.markAllRead()).resolves.toBeUndefined();
    await expect(repo.getStats()).resolves.toMatchObject({ total: 2, unread: 1 });
    await expect(repo.remove({ id: 'x' })).resolves.toBe('n1');
  });
});
