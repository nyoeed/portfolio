require("dotenv").config({ quiet: true });

const sql = require("mssql");

let pool;

async function getTestPool() {
  if (pool) return pool;

  if (!process.env.DB_SERVER) {
    throw new Error("DB_SERVER manquant dans les variables d'environnement");
  }

  pool = await sql.connect({
    server: process.env.DB_SERVER,
    port: Number(process.env.DB_PORT || 1433),
    database: process.env.DB_DATABASE,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    options: {
      encrypt: String(process.env.DB_ENCRYPT) === "true",
      trustServerCertificate: true,
    },
  });

  return pool;
}

async function closeTestPool() {
  if (pool) {
    await pool.close();
    pool = null;
  }
}

module.exports = {
  getTestPool,
  closeTestPool,
};