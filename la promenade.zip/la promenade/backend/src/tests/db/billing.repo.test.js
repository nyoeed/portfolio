let mockState = {}; let mockPool;
jest.mock('../../config/db', () => {
  const { createPool } = require('../helpers/mockDb');
  mockPool = createPool(({ sqlText }) => {
    if (sqlText.includes('SUM(CASE WHEN status=')) return { recordset: [{ totalPaid: 100, totalPending: 20, totalOverdue: 5, totalInvoicesThisMonth: 3 }] };
    if (sqlText.includes('invoiceNumber AS number')) return { recordset: [{ id: 1, number: 'INV-1' }] };
    if (sqlText.includes('FROM dbo.Payments p')) return { recordset: [{ id: 1, invoiceNumber: 'INV-1' }] };
    if (sqlText.includes('FROM dbo.Refunds r')) return { recordset: [{ id: 1, invoiceNumber: 'INV-1' }] };
    if (sqlText.includes('SELECT TOP 1 id, invoiceNumber, clientName FROM dbo.Invoices')) return { recordset: mockState.invoiceFound ? [{ id: 'i1', invoiceNumber: 'INV-1', clientName: 'Client' }] : [] };
    if (sqlText.includes('INSERT INTO dbo.Refunds')) return { recordset: [{ id: 'ref1' }] };
    if (sqlText.includes('SELECT TOP 1 id, invoiceNumber, eventName')) return { recordset: mockState.invoiceByIdFound ? [{ id: 1, invoiceNumber: 'INV-1' }] : [] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool) };
});
const repo = require('../../repositories/admin/billing.repo');
describe('billing.repo (DB mocked)', () => {
  beforeEach(() => { mockState = { invoiceFound: true, invoiceByIdFound: true }; });
  test('billing repo methods work', async () => {
    await expect(repo.getSummary()).resolves.toMatchObject({ totalPaid: 100, totalInvoicesThisMonth: 3 });
    await expect(repo.listInvoices({ q: '', status: '', from: '', to: '' })).resolves.toHaveLength(1);
    await expect(repo.listPayments({ q: '', from: '', to: '' })).resolves.toHaveLength(1);
    await expect(repo.listRefunds({ q: '', from: '', to: '' })).resolves.toHaveLength(1);
    await expect(repo.createRefund({ invoiceNumber: 'INV-1', amount: -10, refundDate: '2026-03-10', reason: 'test', status: 'processed' })).resolves.toMatchObject({ id: 'ref1' });
    await expect(repo.getInvoiceById(1)).resolves.toMatchObject({ invoiceNumber: 'INV-1' });
  });
});
