let mockFound = true; let mockPool;
jest.mock('../../config/db', () => {
  const { createPool } = require('../helpers/mockDb');
  mockPool = createPool(() => ({ recordset: mockFound ? [{ id: 'r1', imageUrl: '/uploads/rooms/x.jpg' }] : [] }));
  return { getPool: jest.fn(async () => mockPool), sql: { UniqueIdentifier: 'UniqueIdentifier', NVarChar: 'NVarChar' } };
});
const repo = require('../../repositories/admin/uploads.repo');
describe('uploads.repo (DB mocked)', () => {
  test('updateRoomImage returns row or null', async () => {
    mockFound = true; await expect(repo.updateRoomImage({ id: 'r1', imageUrl: '/uploads/rooms/x.jpg' })).resolves.toMatchObject({ id: 'r1' });
    mockFound = false; await expect(repo.updateRoomImage({ id: 'missing', imageUrl: '/uploads/rooms/x.jpg' })).resolves.toBeNull();
  });
});
