let mockState = {}; let mockPool;
jest.mock('../../config/db', () => {
  const { createPool } = require('../helpers/mockDb');
  mockPool = createPool(({ sqlText }) => {
    if (sqlText.includes("WHERE status = 'pending'")) return { recordset: [{ id: 'u1', status: 'pending' }] };
    if (sqlText.includes('SELECT TOP 1 id FROM dbo.Users WHERE email = @email')) return { recordset: mockState.existsByEmail ? [{ id: 'u1' }] : [] };
    if (sqlText.includes('SELECT COUNT(*) AS total')) return { recordset: [{ total: 7 }] };
    if (sqlText.includes('WHERE email = @email AND id <> @id')) return { recordset: mockState.emailTaken ? [{ id: 'u2' }] : [] };
    if (sqlText.includes("VALUES (NEWID()")) return { recordset: [{ id: 'u3', fullName: 'New', email: 'new@test.com', role: 'admin', status: 'approved' }] };
    if (sqlText.includes('SET role = @role') && sqlText.includes('OUTPUT inserted.id')) return { recordset: mockState.updateRoleFound ? [{ id: 'u1', role: 'coordinator' }] : [] };
    if (sqlText.includes('SET fullName = @fullName')) return { recordset: mockState.updateUserFound ? [{ id: 'u1', fullName: 'Updated', email: 'u@test.com', role: 'admin' }] : [] };
    if (sqlText.includes('SELECT id, fullName, email, role, status, createdAt, lastLoginAt')) return { recordset: [{ id: 'u1', email: 'a@test.com' }] };
    if (sqlText.includes('SELECT @@ROWCOUNT AS affectedRows')) return { recordset: [{ affectedRows: mockState.affectedRows ?? 1 }] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool), sql: { UniqueIdentifier: 'UniqueIdentifier', VarChar: 'VarChar', NVarChar: 'NVarChar' } };
});
const repo = require('../../repositories/admin/users.repo');
describe('users.repo (DB mocked)', () => {
  beforeEach(() => { mockState = { existsByEmail: false, emailTaken: false, affectedRows: 1, updateRoleFound: true, updateUserFound: true }; });
  test('users repo methods work', async () => {
    await expect(repo.listPending()).resolves.toHaveLength(1);
    await expect(repo.approveRequest({ id: 'u1' })).resolves.toBe(true);
    mockState.affectedRows = 0; await expect(repo.rejectRequest({ id: 'u1' })).resolves.toBe(false);
    await expect(repo.listUsers({ search: 'a', role: 'admin', status: 'approved' })).resolves.toHaveLength(1);
    mockState.existsByEmail = true; await expect(repo.existsByEmail({ email: 'a@test.com' })).resolves.toBe(true);
    await expect(repo.createUser({ fullName: 'New', email: 'new@test.com', passwordHash: 'h', role: 'admin' })).resolves.toMatchObject({ status: 'approved' });
    await expect(repo.countAll()).resolves.toBe(7);
    mockState.affectedRows = 1; await expect(repo.updateUserStatus({ id: 'u1', status: 'approved' })).resolves.toBe(true);
    await expect(repo.updateUserRole({ id: 'u1', role: 'coordinator' })).resolves.toMatchObject({ role: 'coordinator' });
    mockState.emailTaken = true; await expect(repo.emailTakenByAnotherUser({ id: 'u1', email: 'used@test.com' })).resolves.toBe(true);
    await expect(repo.updateUser({ id: 'u1', fullName: 'Updated', email: 'u@test.com', role: 'admin' })).resolves.toMatchObject({ fullName: 'Updated' });
    await expect(repo.deleteUser({ id: 'u1' })).resolves.toBe(true);
  });
});
