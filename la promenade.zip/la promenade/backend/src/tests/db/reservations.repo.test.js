let mockPool; let mockState = {};
jest.mock('../../config/db', () => {
  const { createPool, createSqlForTransactions } = require('../helpers/mockDb');
  const tx = createSqlForTransactions(({ sqlText }) => {
    if (sqlText.includes('FROM dbo.Reservations WITH')) return { recordset: mockState.conflict ? [{ id: 'existing', startAt: new Date('2026-03-11T10:00:00Z'), endAt: new Date('2026-03-11T11:00:00Z'), title: 'Busy', status: 'confirmed' }] : [] };
    if (sqlText.includes('INSERT INTO dbo.Reservations')) return { recordset: [{ id: 'res1', status: 'pending' }] };
    return { recordset: [] };
  });
  mockPool = createPool(({ sqlText }) => {
    if (sqlText.includes('FROM dbo.Reservations r')) return { recordset: [{ id: 'res1', title: 'Event' }] };
    if (sqlText.includes('UPDATE dbo.Reservations') && sqlText.includes('OUTPUT inserted.*')) return { recordset: mockState.updateFound ? [{ id: 'res1', status: 'confirmed' }] : [] };
    if (sqlText.includes('DELETE FROM dbo.Reservations')) return { recordset: [{ affectedRows: mockState.removeAffected ?? 1 }] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool), sql: { ...tx.sql, ISOLATION_LEVEL: { SERIALIZABLE: 'SERIALIZABLE' } } };
});
const repo = require('../../repositories/admin/reservations.repo');
describe('reservations.repo (DB mocked)', () => {
  beforeEach(() => { mockState = { conflict: false, updateFound: true, removeAffected: 1 }; });
  test('reservations repo methods work', async () => {
    await expect(repo.createWithConflictCheck({ roomId: 'r1', organizerId: 'u1', title: 'Event', startAt: new Date(), endAt: new Date(Date.now()+3600000), participants: 10, status: 'pending', toIso: d => d.toISOString() })).resolves.toMatchObject({ id: 'res1' });
    mockState.conflict = true;
    await expect(repo.createWithConflictCheck({ roomId: 'r1', organizerId: 'u1', title: 'Event', startAt: new Date(), endAt: new Date(Date.now()+3600000), participants: 10, status: 'pending', toIso: d => d.toISOString() })).rejects.toMatchObject({ code: 'RESERVATION_CONFLICT' });
    await expect(repo.list({})).resolves.toHaveLength(1);
    await expect(repo.updateStatus({ id: 'res1', status: 'confirmed' })).resolves.toMatchObject({ status: 'confirmed' });
    await expect(repo.remove({ id: 'res1' })).resolves.toBe(true);
  });
});
