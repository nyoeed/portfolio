let mockPool;
jest.mock('../../config/db', () => {
  const { createPool } = require('../helpers/mockDb');
  mockPool = createPool(({ sqlText }) => {
    if (sqlText.includes('SELECT 1 FROM dbo.Users')) return { recordset: [] };
    if (sqlText.includes('SELECT TOP 1 id, email, fullName')) return { recordset: [{ id: 'u1', email: 'a@test.com', fullName: 'A', passwordHash: 'h', role: 'admin', status: 'approved' }] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool), sql: { VarChar: 'VarChar', NVarChar: 'NVarChar', UniqueIdentifier: 'UniqueIdentifier' } };
});
const repo = require('../../repositories/auth.repo');
describe('auth.repo (DB mocked)', () => {
  test('core auth repo methods work', async () => {
    await expect(repo.userExistsByEmail({ email: 'a@test.com' })).resolves.toBe(false);
    await expect(repo.insertPendingUser({ fullName: 'A', email: 'a@test.com', passwordHash: 'h', roleRequested: 'organizer' })).resolves.toBeUndefined();
    await expect(repo.findUserForLogin({ email: 'a@test.com' })).resolves.toMatchObject({ email: 'a@test.com' });
    await expect(repo.updateLastLogin({ id: 'u1' })).resolves.toBeUndefined();
  });
});
