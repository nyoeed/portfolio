let mockState = {}; let mockPool;
jest.mock('../../config/db', () => {
  const { createPool } = require('../helpers/mockDb');
  mockPool = createPool(({ sqlText }) => {
    if (sqlText.includes('COUNT(*) AS total FROM dbo.Services')) return { recordset: [{ total: 3 }] };
    if (sqlText.includes('GROUP BY category')) return { recordset: [{ category: 'Traiteur', count: 2 }] };
    if (sqlText.includes('FROM dbo.Services') && sqlText.includes('ORDER BY createdAt DESC')) return { recordset: [{ id: 's1', name: 'Traiteur', category: 'Traiteur' }] };
    if (sqlText.includes('INSERT INTO dbo.Services')) return { recordset: [{ id: 's1', name: 'Traiteur' }] };
    if (sqlText.includes('UPDATE dbo.Services')) return { recordset: mockState.updateFound ? [{ id: 's1', name: 'Maj' }] : [] };
    if (sqlText.includes('DELETE FROM dbo.Services')) return { recordset: [{ affectedRows: mockState.removeAffected ?? 1 }] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool), sql: { UniqueIdentifier: 'UniqueIdentifier', NVarChar: 'NVarChar', VarChar: 'VarChar', Decimal: ()=> 'Decimal' } };
});
const repo = require('../../repositories/admin/services.repo');
describe('services.repo (DB mocked)', () => {
  beforeEach(() => { mockState = { updateFound: true, removeAffected: 1 }; });
  test('services repo methods work', async () => {
    await expect(repo.getStats()).resolves.toMatchObject({ total: 3, byCategory: [{ category: 'Traiteur', count: 2 }] });
    await expect(repo.list({ category: 'Traiteur' })).resolves.toHaveLength(1);
    await expect(repo.create({ name: 'Traiteur', category: 'Traiteur', description: null, unitLabel: 'forfait', price: 10, availability: 'available', imageUrl: null })).resolves.toMatchObject({ id: 's1' });
    await expect(repo.update({ id: 's1', name: 'Maj' })).resolves.toMatchObject({ name: 'Maj' });
    await expect(repo.remove({ id: 's1' })).resolves.toBe(true);
  });
});
