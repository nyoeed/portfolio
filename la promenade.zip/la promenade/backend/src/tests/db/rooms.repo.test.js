let mockPool; let mockState = {};
jest.mock('../../config/db', () => {
  const { createPool, createSqlForTransactions } = require('../helpers/mockDb');
  const tx = createSqlForTransactions(({ sqlText }) => {
    if (sqlText.includes('INSERT INTO dbo.Rooms')) return { recordset: [{ id: 'r1', name: 'Salle A', status: 'available' }] };
    if (sqlText.includes('UPDATE dbo.Rooms')) return { recordset: mockState.updateFound ? [{ id: 'r1', name: 'Salle B', status: 'maintenance' }] : [] };
    return { recordset: [] };
  });
  mockPool = createPool(({ sqlText }) => {
    if (sqlText.includes('COUNT(*) AS total FROM dbo.Rooms')) return { recordset: [{ total: 2 }] };
    if (sqlText.includes("COUNT(*) AS available")) return { recordset: [{ available: 1 }] };
    if (sqlText.includes("COUNT(DISTINCT r.id) AS reserved")) return { recordset: [{ reserved: 1 }] };
    if (sqlText.includes("SUM(capacity)")) return { recordset: [{ totalCapacity: 100 }] };
    if (sqlText.includes('FROM dbo.Rooms') && sqlText.includes('ORDER BY createdAt DESC')) return { recordset: [{ id: 'r1', name: 'Salle A', capacity: 10 }] };
    if (sqlText.includes('FROM dbo.RoomEquipments')) return { recordset: [{ roomId: 'r1', label: 'Projecteur' }] };
    if (sqlText.includes('FROM dbo.Reservations')) return { recordset: [{ roomId: 'r1', reservationsCount: 2, nextStartAt: '2026-03-11T10:00:00Z' }] };
    if (sqlText.includes('DELETE FROM dbo.Rooms')) return { recordset: [{ affectedRows: mockState.removeAffected ?? 1 }] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool), sql: { ...tx.sql, ISOLATION_LEVEL: { READ_COMMITTED: 'READ_COMMITTED' } } };
});
const repo = require('../../repositories/admin/rooms.repo');
describe('rooms.repo (DB mocked)', () => {
  beforeEach(() => { mockState = { updateFound: true, removeAffected: 1 }; });
  test('rooms repo methods work', async () => {
    await expect(repo.getStats()).resolves.toMatchObject({ total: 2, available: 1, reserved: 1, totalCapacity: 100 });
    const rows = await repo.listWithDetails(); expect(rows[0].equipments).toContain('Projecteur');
    await expect(repo.createRoomWithEquipments({ name: 'Salle A', capacity: 10, surface: 20, pricePerDay: 100, status: 'available', equipments: ['Projecteur'] })).resolves.toMatchObject({ id: 'r1' });
    await expect(repo.updateRoomAndMaybeEquipments({ id: 'r1', name: 'Salle B', capacity: 11, surface: 21, pricePerDay: 120, status: 'maintenance', equipments: ['Wifi'] })).resolves.toMatchObject({ status: 'maintenance' });
    await expect(repo.remove({ id: 'r1' })).resolves.toBe(true);
  });
});
