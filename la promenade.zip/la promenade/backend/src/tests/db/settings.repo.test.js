let mockRow = null; let mockPool;
jest.mock('../../config/db', () => {
  const { createPool } = require('../helpers/mockDb');
  mockPool = createPool(({ sqlText }) => {
    if (sqlText.includes('SELECT TOP 1 id FROM dbo.AdminSettings')) return { recordset: mockRow ? [{ id: 1 }] : [] };
    if (sqlText.includes('SELECT TOP 1') && sqlText.includes('hotelName')) return { recordset: mockRow ? [mockRow] : [] };
    if (sqlText.includes('INSERT INTO dbo.AdminSettings') || sqlText.includes('UPDATE dbo.AdminSettings')) return { recordset: [mockRow] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool), sql: { NVarChar: (n)=>`NVarChar(${n})`, Decimal: (p,s)=>`Decimal(${p},${s})`, Int: 'Int', Bit: 'Bit' } };
});
const repo = require('../../repositories/admin/settings.repo');
describe('settings.repo (DB mocked)', () => {
  test('settings repo methods work', async () => {
    mockRow = null; await expect(repo.getFirst()).resolves.toBeNull();
    mockRow = { hotelName: 'LP', email: 'x@test.com', taxRate: 20, paymentDelayDays: 30, onlinePaymentEnabled: true, notifEvents: true, notifPayments: true, notifSignup: true, notifSystem: true, dailySummaryEnabled: false };
    await expect(repo.getFirst()).resolves.toMatchObject({ hotelName: 'LP' });
    await expect(repo.upsertOne(mockRow)).resolves.toMatchObject({ email: 'x@test.com' });
  });
});
