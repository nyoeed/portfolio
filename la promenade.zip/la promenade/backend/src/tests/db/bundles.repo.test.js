let mockPool; let mockState = {};
jest.mock('../../config/db', () => {
  const { createPool, createSqlForTransactions } = require('../helpers/mockDb');
  const tx = createSqlForTransactions(({ sqlText }) => {
    if (sqlText.includes('INSERT INTO dbo.Bundles')) return { recordset: [{ id: 'b1', name: 'Pack Conf' }] };
    if (sqlText.includes('UPDATE dbo.Bundles')) return { recordset: mockState.updateFound ? [{ id: 'b1', name: 'Pack Maj' }] : [] };
    return { recordset: [] };
  });
  mockPool = createPool(({ sqlText }) => {
    if (sqlText.includes('DELETE FROM dbo.Bundles')) return { recordset: [{ affectedRows: mockState.removeAffected ?? 1 }] };
    if (sqlText.includes('FROM dbo.Bundles')) return { recordset: [{ id: 'b1', name: 'Pack Conf' }] };
    if (sqlText.includes('FROM dbo.BundleItems bi') && sqlText.includes('JOIN dbo.Services')) return { recordset: [{ bundleId: 'b1', serviceId: 's1', serviceName: 'Traiteur' }] };
    return { recordset: [] };
  });
  return { getPool: jest.fn(async () => mockPool), sql: { ...tx.sql } };
});
const repo = require('../../repositories/admin/bundles.repo');
describe('bundles.repo (DB mocked)', () => {
  beforeEach(() => { mockState = { updateFound: true, removeAffected: 1 }; });
  test('bundles repo methods work', async () => {
    const rows = await repo.listWithServices(); expect(rows[0].services[0].name).toBe('Traiteur');
    await expect(repo.createBundleAndItems({ name: 'Pack Conf', description: null, unitLabel: 'forfait', price: 100, availability: 'available', serviceIds: ['s1'] })).resolves.toMatchObject({ id: 'b1' });
    await expect(repo.updateBundleAndMaybeItems({ id: 'b1', name: 'Pack Maj', serviceIds: ['s1'] })).resolves.toMatchObject({ name: 'Pack Maj' });
    await expect(repo.remove({ id: 'b1' })).resolves.toBe(true);
  });
});
