const request = require('supertest');
jest.mock('../../repositories/admin/billing.repo', () => ({ getSummary: jest.fn(), listInvoices: jest.fn(), listPayments: jest.fn(), listRefunds: jest.fn(), createRefund: jest.fn(), getInvoiceById: jest.fn() }));
const repo = require('../../repositories/admin/billing.repo'); const express = require('express'); const router = require('../../routes/admin/billing.routes'); const { errorHandler } = require('../../middleware/errorHandler');
describe('billing routes integration', () => {
  let app; beforeAll(() => { app = express(); app.use(express.json()); app.use('/api/admin/billing', router); app.use(errorHandler); }); beforeEach(() => jest.clearAllMocks());
  test('billing routes work', async () => {
    repo.getSummary.mockResolvedValue({ totalPaid: 10 }); repo.listInvoices.mockResolvedValue([{ id: 1 }]); repo.listPayments.mockResolvedValue([{ id: 1 }]); repo.listRefunds.mockResolvedValue([{ id: 1 }]); repo.createRefund.mockResolvedValue({ id: 'ref1' }); repo.getInvoiceById.mockResolvedValue({ invoiceNumber: 'INV-1' });
    expect((await request(app).get('/api/admin/billing/summary')).body.totalPaid).toBe(10); expect((await request(app).get('/api/admin/billing/invoices')).body).toHaveLength(1); expect((await request(app).get('/api/admin/billing/payments')).body).toHaveLength(1); expect((await request(app).get('/api/admin/billing/refunds')).body).toHaveLength(1); expect((await request(app).post('/api/admin/billing/refunds').send({ invoiceNumber: 'INV-1', amount: -10, date: '2026-03-11', reason: 'test' })).status).toBe(201); expect((await request(app).get('/api/admin/billing/invoices/1/pdf')).headers['content-type']).toContain('application/pdf');
  });
});
