const request = require("supertest");

jest.mock("../../services/auth.service", () => ({
  register: jest.fn(),
  login: jest.fn(),
}));

const authService = require("../../services/auth.service");
const { createApp } = require("../../app");

describe("Auth routes", () => {
  let consoleErrorSpy;

  beforeAll(() => {
    process.env.PORT = "4000";
    process.env.DB_SERVER = "localhost";
    process.env.DB_PORT = "1433";
    process.env.DB_DATABASE = "testdb";
    process.env.DB_USER = "sa";
    process.env.DB_PASSWORD = "Password123!";
    process.env.DB_ENCRYPT = "false";
    process.env.JWT_SECRET = "test-secret";
    process.env.JWT_EXPIRES_IN = "1d";
    process.env.INIT_ADMIN_SECRET = "init-secret";
  });

  beforeEach(() => {
    jest.clearAllMocks();
    consoleErrorSpy = jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    consoleErrorSpy.mockRestore();
  });

  it("POST /api/auth/register should return 201", async () => {
    authService.register.mockResolvedValue({
      message: "Registered. Pending approval.",
    });

    const app = createApp();

    const res = await request(app).post("/api/auth/register").send({
      fullName: "Amadou Gueye",
      email: "amadou@test.com",
      password: "password123",
      roleRequested: "organizer",
    });

    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      message: "Registered. Pending approval.",
    });
    expect(authService.register).toHaveBeenCalledTimes(1);
  });

  it("POST /api/auth/register should return 409 if email already exists", async () => {
    const err = new Error("Email already used");
    err.code = "EMAIL_EXISTS";
    authService.register.mockRejectedValue(err);

    const app = createApp();

    const res = await request(app).post("/api/auth/register").send({
      fullName: "Amadou Gueye",
      email: "amadou@test.com",
      password: "password123",
      roleRequested: "organizer",
    });

    expect(res.status).toBe(409);
    expect(res.body).toEqual({
      message: "Email already used",
    });
  });

  it("POST /api/auth/login should return token and user", async () => {
    authService.login.mockResolvedValue({
      token: "fake-jwt-token",
      user: {
        id: "123",
        email: "amadou@test.com",
        fullName: "Amadou Gueye",
        role: "admin",
        status: "approved",
      },
    });

    const app = createApp();

    const res = await request(app).post("/api/auth/login").send({
      email: "amadou@test.com",
      password: "password123",
    });

    expect(res.status).toBe(200);
    expect(res.body.token).toBe("fake-jwt-token");
    expect(res.body.user.email).toBe("amadou@test.com");
    expect(authService.login).toHaveBeenCalledTimes(1);
  });

  it("POST /api/auth/login should return 401 for invalid credentials", async () => {
    const err = new Error("Invalid credentials");
    err.code = "INVALID_CREDENTIALS";
    authService.login.mockRejectedValue(err);

    const app = createApp();

    const res = await request(app).post("/api/auth/login").send({
      email: "amadou@test.com",
      password: "wrong-password",
    });

    expect(res.status).toBe(401);
    expect(res.body).toEqual({
      message: "Invalid credentials",
    });
  });
});