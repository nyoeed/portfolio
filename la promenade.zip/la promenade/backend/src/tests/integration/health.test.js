const request = require("supertest");
const { createApp } = require("../../app");
describe("GET /health", () => {
  beforeAll(() => {
    process.env.PORT = "4000";
    process.env.DB_SERVER = "localhost";
    process.env.DB_PORT = "1433";
    process.env.DB_DATABASE = "testdb";
    process.env.DB_USER = "sa";
    process.env.DB_PASSWORD = "Password123!";
    process.env.DB_ENCRYPT = "false";
    process.env.JWT_SECRET = "test-secret";
    process.env.JWT_EXPIRES_IN = "1d";
    process.env.INIT_ADMIN_SECRET = "init-secret";
  });

  it("should return 200 and { ok: true }", async () => {
    const app = createApp();

    const res = await request(app).get("/health");

    expect(res.status).toBe(200);
    expect(res.body).toEqual({ ok: true });
  });
});