const request = require("supertest");

jest.mock("../../services/system.service", () => ({
  isInitialized: jest.fn(),
  initAdmin: jest.fn(),
}));

const systemService = require("../../services/system.service");
const { createApp } = require("../../app");

describe("System routes", () => {
  let consoleErrorSpy;

  beforeAll(() => {
    process.env.PORT = "4000";
    process.env.DB_SERVER = "localhost";
    process.env.DB_PORT = "1433";
    process.env.DB_DATABASE = "testdb";
    process.env.DB_USER = "sa";
    process.env.DB_PASSWORD = "Password123!";
    process.env.DB_ENCRYPT = "false";
    process.env.JWT_SECRET = "test-secret";
    process.env.JWT_EXPIRES_IN = "1d";
    process.env.INIT_ADMIN_SECRET = "init-secret";
  });

  beforeEach(() => {
    jest.clearAllMocks();
    consoleErrorSpy = jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    consoleErrorSpy.mockRestore();
  });

  it("GET /api/system/init-status should return initialized flag", async () => {
    systemService.isInitialized.mockResolvedValue(true);

    const app = createApp();
    const res = await request(app).get("/api/system/init-status");

    expect(res.status).toBe(200);
    expect(res.body).toEqual({ initialized: true });
  });

  it("POST /api/system/init-admin should return 201", async () => {
    systemService.initAdmin.mockResolvedValue({
      token: "signed-token",
      user: {
        id: "u1",
        email: "admin@test.com",
        fullName: "Admin User",
        role: "admin",
        status: "approved",
      },
    });

    const app = createApp();
    const res = await request(app).post("/api/system/init-admin").send({
      fullName: "Admin User",
      email: "admin@test.com",
      password: "password123",
      secretKey: "init-secret",
    });

    expect(res.status).toBe(201);
    expect(res.body.token).toBe("signed-token");
    expect(res.body.user.role).toBe("admin");
  });

  it("POST /api/system/init-admin should return 400 on invalid data", async () => {
    const err = new Error("Invalid data");
    err.code = "BAD_DATA";
    systemService.initAdmin.mockRejectedValue(err);

    const app = createApp();
    const res = await request(app).post("/api/system/init-admin").send({});

    expect(res.status).toBe(400);
    expect(res.body).toEqual({ message: "Invalid data" });
  });

  it("POST /api/system/init-admin should return 403 on invalid secret", async () => {
    const err = new Error("Invalid secret key");
    err.code = "BAD_SECRET";
    systemService.initAdmin.mockRejectedValue(err);

    const app = createApp();
    const res = await request(app).post("/api/system/init-admin").send({
      fullName: "Admin User",
      email: "admin@test.com",
      password: "password123",
      secretKey: "wrong-secret",
    });

    expect(res.status).toBe(403);
    expect(res.body).toEqual({ message: "Invalid secret key" });
  });

  it("POST /api/system/init-admin should return 409 if already initialized", async () => {
    const err = new Error("Already initialized");
    err.code = "ALREADY_INIT";
    systemService.initAdmin.mockRejectedValue(err);

    const app = createApp();
    const res = await request(app).post("/api/system/init-admin").send({
      fullName: "Admin User",
      email: "admin@test.com",
      password: "password123",
      secretKey: "init-secret",
    });

    expect(res.status).toBe(409);
    expect(res.body.message).toMatch(/already initialized/i);
  });

  it("POST /api/system/init-admin should return 409 if email already used", async () => {
    const err = new Error("Email already used");
    err.code = "EMAIL_EXISTS";
    systemService.initAdmin.mockRejectedValue(err);

    const app = createApp();
    const res = await request(app).post("/api/system/init-admin").send({
      fullName: "Admin User",
      email: "admin@test.com",
      password: "password123",
      secretKey: "init-secret",
    });

    expect(res.status).toBe(409);
    expect(res.body).toEqual({ message: "Email already used" });
  });
});