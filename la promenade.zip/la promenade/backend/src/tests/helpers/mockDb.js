function addInput(inputs, args) {
  if (args.length === 2) {
    const [name, value] = args;
    inputs.push({ name, type: undefined, value });
  } else {
    const [name, type, value] = args;
    inputs.push({ name, type, value });
  }
}
function createRequest(handler) {
  const inputs = [];
  return {
    inputs,
    input: jest.fn(function (...args) { addInput(inputs, args); return this; }),
    query: jest.fn(async function (sqlText) { return handler({ sqlText, inputs }); }),
  };
}
function createPool(handler) {
  const requests = [];
  return { requests, request: jest.fn(() => { const req = createRequest(handler); requests.push(req); return req; }) };
}
function createSqlForTransactions(handler) {
  class Transaction {
    constructor(pool) { this.pool = pool; this.begin = jest.fn(async()=>{}); this.commit = jest.fn(async()=>{}); this.rollback = jest.fn(async()=>{}); }
  }
  class Request {
    constructor(tx) { this.tx = tx; this.inputs = []; this.input = jest.fn((...args)=>{ addInput(this.inputs,args); return this;}); this.query = jest.fn(async(sqlText)=> handler({ sqlText, inputs: this.inputs, tx })); }
  }
  return { sql: { VarChar:'VarChar', NVarChar:'NVarChar', UniqueIdentifier:'UniqueIdentifier', DateTime2:'DateTime2', Decimal:(p,s)=>`Decimal(${p},${s})`, Int:'Int', Bit:'Bit', Transaction, Request } };
}
module.exports = { createPool, createSqlForTransactions };
