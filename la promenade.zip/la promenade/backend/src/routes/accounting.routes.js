const express = require("express");
const router = express.Router();

const ctrl = require("../controllers/accounting/accounting.controller");
const { requireAuth, requireApproved, requireRole } = require("../middleware/auth");

router.use(requireAuth, requireApproved, requireRole("accounting", "admin"));

router.get("/dashboard", ctrl.getDashboard);

router.get("/invoices", ctrl.listInvoices);
router.get("/invoiceable-events", ctrl.listInvoiceableEvents);
router.post("/invoices", ctrl.createInvoice);
router.patch("/invoices/:id/status", ctrl.updateInvoiceStatus);
router.delete("/invoices/:id", ctrl.deleteInvoice);

router.get("/notifications", ctrl.listNotifications);
router.patch("/notifications/:id/read", ctrl.markNotificationRead);

router.get("/payments", ctrl.listPayments);
router.patch("/payments/:id/status", ctrl.updatePaymentStatus);
router.post("/payments", ctrl.createPayment);

router.get("/refunds", ctrl.listRefunds);
router.post("/refunds", ctrl.createRefund);
router.patch("/refunds/:id/status", ctrl.updateRefundStatus);
router.delete("/refunds/:id", ctrl.deleteRefund);

router.get("/reports", ctrl.getReports);

module.exports = router;
