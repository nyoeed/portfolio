// src/routes/admin/index.js
const express = require("express");
const router = express.Router();

const { requireAuth, requireApproved, requireRole } = require("../../middleware/auth");

const usersRoutes = require("./users.routes");
const roomsRoutes = require("./rooms.routes");
const reservationsRoutes = require("./reservations.routes");
const servicesRoutes = require("./services.routes");
const bundlesRoutes = require("./bundles.routes");
const settingsRoutes = require("./settings.routes");
const notificationsRoutes = require("./notifications.routes");
const statsRoutes = require("./stats.routes");
const uploadsRoutes = require("./uploads.routes");


// Protection admin (comme avant)
router.use(requireAuth, requireApproved, requireRole("admin"));

// Modules
router.use("/", uploadsRoutes);         // car on a /rooms/:id/image (pas un /uploads/...)
router.use("/", usersRoutes);           // car endpoints /pending, /requests/... et /users...
router.use("/rooms", roomsRoutes);
router.use("/reservations", reservationsRoutes);
router.use("/services", servicesRoutes);
router.use("/bundles", bundlesRoutes);
router.use("/settings", settingsRoutes);
router.use("/notifications", notificationsRoutes);
router.use("/stats", statsRoutes);
router.use("/billing", require("./billing.routes"));

module.exports = router;