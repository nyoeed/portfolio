// src/routes/admin/uploads.routes.js
const express = require("express");
const router = express.Router();

const uploadsController = require("../../controllers/admin/uploads.controller");
const { validateGuid } = require("../../middleware/validateGuid");

// POST /api/admin/rooms/:id/image
router.post("/rooms/:id/image", validateGuid("id"), uploadsController.uploadRoomImage);

module.exports = router;