// src/routes/admin/bundles.routes.js
const express = require("express");
const router = express.Router();

const { validateGuid } = require("../../middleware/validateGuid");
const bundlesController = require("../../controllers/admin/bundles.controller");

router.get("/", bundlesController.list);
router.post("/", bundlesController.create);
router.patch("/:id", bundlesController.update);
router.delete("/:id", bundlesController.remove);

router.patch("/:id", validateGuid("id"), bundlesController.update);
router.delete("/:id", validateGuid("id"), bundlesController.remove);
module.exports = router;