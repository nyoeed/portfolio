// src/routes/admin/reservations.routes.js
const express = require("express");
const router = express.Router();

const reservationsController = require("../../controllers/admin/reservations.controller");

const { validateGuid } = require("../../middleware/validateGuid");

router.patch("/reservations/:id/status", validateGuid("id"), reservationsController.updateStatus);
router.delete("/reservations/:id", validateGuid("id"), reservationsController.remove);
// GET /api/admin/reservations
router.get("/", reservationsController.list);

// POST /api/admin/reservations
router.post("/", reservationsController.create);

// PATCH /api/admin/reservations/:id/status
router.patch("/:id/status", reservationsController.updateStatus);

// DELETE /api/admin/reservations/:id
router.delete("/:id", reservationsController.remove);

module.exports = router;