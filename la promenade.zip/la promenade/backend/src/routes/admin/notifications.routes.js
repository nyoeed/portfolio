// src/routes/admin/notifications.routes.js
const express = require("express");
const router = express.Router();

const notificationsController = require("../../controllers/admin/notifications.controller");

const { validateGuid } = require("../../middleware/validateGuid");

router.get("/", notificationsController.list);
router.get("/stats", notificationsController.getStats);

router.patch("/:id/read", notificationsController.markRead);
router.post("/mark-all-read", notificationsController.markAllRead);

router.delete("/:id", notificationsController.remove);

// optionnel (tu l’as dans l’ancien)
router.post("/", notificationsController.create);

router.patch("/:id/read", validateGuid("id"), notificationsController.markRead);
router.delete("/:id", validateGuid("id"), notificationsController.remove);

module.exports = router;