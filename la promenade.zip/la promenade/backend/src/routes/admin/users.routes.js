// src/routes/admin/users.routes.js
const express = require("express");
const router = express.Router();

const usersController = require("../../controllers/admin/users.controller");

const { validateGuid } = require("../../middleware/validateGuid");
// pending requests
router.get("/pending", usersController.listPending);
router.patch("/requests/:id/approve", usersController.approveRequest);
router.patch("/requests/:id/reject", usersController.rejectRequest);

// users
router.get("/users", usersController.listUsers);
router.post("/users", usersController.createUser);
router.get("/users/meta", usersController.getUsersMeta);

router.patch("/users/:id/status", usersController.updateUserStatus);
router.patch("/users/:id/role", usersController.updateUserRole);
router.patch("/users/:id", usersController.updateUser);
router.delete("/users/:id", usersController.deleteUser);

// pending requests
router.patch("/requests/:id/approve", validateGuid("id"), usersController.approveRequest);
router.patch("/requests/:id/reject", validateGuid("id"), usersController.rejectRequest);

// users
router.patch("/users/:id/status", validateGuid("id"), usersController.updateUserStatus);
router.patch("/users/:id/role", validateGuid("id"), usersController.updateUserRole);
router.patch("/users/:id", validateGuid("id"), usersController.updateUser);
router.delete("/users/:id", validateGuid("id"), usersController.deleteUser);
module.exports = router;