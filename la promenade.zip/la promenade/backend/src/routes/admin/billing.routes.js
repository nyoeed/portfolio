// src/routes/admin/billing.routes.js
const express = require("express");
const router = express.Router();

const billingCtrl = require("../../controllers/admin/billing.controller");

// déjà protégé par requireAuth/requireRole dans admin/index.js
router.get("/summary", billingCtrl.getSummary);
router.get("/invoices", billingCtrl.listInvoices);
router.get("/payments", billingCtrl.listPayments);
router.get("/refunds", billingCtrl.listRefunds);
router.post("/refunds", billingCtrl.createRefund);
router.get("/invoices/:id/pdf", billingCtrl.downloadInvoicePdf);

module.exports = router;