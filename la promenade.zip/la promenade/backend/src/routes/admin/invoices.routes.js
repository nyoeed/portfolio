// src/routes/admin/invoices.routes.js
const express = require("express");
const router = express.Router();

const invoicesController = require("../../controllers/admin/invoices.controller");
const { validateGuid } = require("../../middleware/validateGuid");

// --- Stats cards ---
// GET /api/admin/invoices/stats?from=...&to=...
router.get("/stats", invoicesController.getStats);

// --- Automated invoice generation ---
// POST /api/admin/invoices/generate
// body: { eventId, clientName?, dueAt? }
router.post("/generate", invoicesController.generateInvoiceForEvent);

// --- Lists (tabs) ---
// GET /api/admin/invoices?from=&to=&eventId=&status=
router.get("/", invoicesController.listInvoices);
router.get("/payments", invoicesController.listPayments);
router.get("/refunds", invoicesController.listRefunds);

// --- Details ---
router.get("/:id", validateGuid("id"), invoicesController.getInvoiceDetails);

// --- Actions ---
router.post("/:id/payments", validateGuid("id"), invoicesController.createPayment);
router.post("/:id/refunds", validateGuid("id"), invoicesController.createRefund);

// Online payment (mock checkout + confirm)
router.post("/:id/online/checkout", validateGuid("id"), invoicesController.createOnlineCheckout);
router.post("/online/confirm", invoicesController.confirmOnlineCheckout);

// --- PDF ---
router.get("/:id/pdf", validateGuid("id"), invoicesController.downloadInvoicePdf);
router.get("/:id/receipt", validateGuid("id"), invoicesController.downloadReceiptPdf);

module.exports = router;
