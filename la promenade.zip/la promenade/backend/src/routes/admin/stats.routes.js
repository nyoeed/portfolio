// src/routes/admin/stats.routes.js
const express = require("express");
const router = express.Router();

const statsController = require("../../controllers/admin/stats.controller");

router.get("/", statsController.get);

module.exports = router;