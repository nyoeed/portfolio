// src/routes/admin/settings.routes.js
const express = require("express");
const router = express.Router();

const settingsController = require("../../controllers/admin/settings.controller");

router.get("/", settingsController.get);
router.put("/", settingsController.upsert);

module.exports = router;