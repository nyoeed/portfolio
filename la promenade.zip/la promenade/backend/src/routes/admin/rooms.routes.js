// src/routes/admin/rooms.routes.js
const express = require("express");
const router = express.Router();

const roomsController = require("../../controllers/admin/rooms.controller");
const { validateGuid } = require("../../middleware/validateGuid");
// GET /api/admin/rooms/stats
router.get("/stats", roomsController.getStats);

// GET /api/admin/rooms
router.get("/", roomsController.list);

// POST /api/admin/rooms
router.post("/", roomsController.create);

// PATCH /api/admin/rooms/:id
router.patch("/:id", roomsController.update);

// DELETE /api/admin/rooms/:id
router.delete("/:id", roomsController.remove);

module.exports = router;



router.patch("/rooms/:id", validateGuid("id"), roomsController.update);
router.delete("/rooms/:id", validateGuid("id"), roomsController.remove);