// src/routes/admin/services.routes.js
const express = require("express");
const router = express.Router();

const servicesController = require("../../controllers/admin/services.controller");

const { validateGuid } = require("../../middleware/validateGuid");
// stats
router.get("/stats", servicesController.getStats);

// list
router.get("/", servicesController.list);

// create (multipart)
router.post("/", servicesController.create);

// update (multipart possible)
router.patch("/:id", servicesController.update);

// delete
router.delete("/:id", servicesController.remove);

router.patch("/services/:id", validateGuid("id"), servicesController.update);
router.delete("/services/:id", validateGuid("id"), servicesController.remove);

module.exports = router;