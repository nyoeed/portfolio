// src/routes/system.routes.js
const express = require("express");
const router = express.Router();

const systemController = require("../controllers/system.controller");

router.get("/init-status", systemController.getInitStatus);
router.post("/init-admin", systemController.initAdmin);

module.exports = router;