const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const controller = require('../controllers/organizer.controller');
const { requireAuth, requireApproved, requireRole } = require('../middleware/auth');

const router = express.Router();

const docsDir = path.join(__dirname, '..', '..', 'uploads', 'organizer-documents');
const allowedMimeTypes = new Set([
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/jpg',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'text/plain',
]);

fs.mkdirSync(docsDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, docsDir),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, '_')}`),
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (allowedMimeTypes.has(file.mimetype)) {
      cb(null, true);
      return;
    }
    cb(new Error('Type de document non autorisé.'));
  },
});

router.use(requireAuth, requireApproved, requireRole('organizer', 'admin'));

router.get('/dashboard', controller.getDashboard);

router.get('/events', controller.listEvents);
router.get('/events/:id', controller.getEvent);
router.post('/events', controller.createEvent);
router.patch('/events/:id', controller.updateEvent);
router.delete('/events/:id', controller.cancelEvent);

router.get('/rooms', controller.listRooms);
router.get('/calendar', controller.getCalendar);
router.get('/reservations', controller.listReservations);

router.get('/services/catalog', controller.listServiceCatalog);
router.get('/services/requests', controller.listServices);
router.post('/services/requests', controller.createServiceRequest);

router.get('/guests', controller.listGuests);
router.post('/guests', controller.createGuest);
router.patch('/guests/:id', controller.updateGuest);
router.delete('/guests/:id', controller.deleteGuest);

router.get('/documents', controller.listDocuments);
router.post('/documents', upload.single('file'), controller.uploadDocument);
router.delete('/documents/:id', controller.deleteDocument);

router.get('/billing', controller.getBilling);
router.post('/billing/payments/simulate', controller.createSimulatedPayment);
router.get('/reports', controller.getReports);

router.get('/profile', controller.getProfile);
router.patch('/profile', controller.updateProfile);

router.get('/notifications', controller.listNotifications);
router.patch('/notifications/:id/read', controller.markNotificationRead);

module.exports = router;
