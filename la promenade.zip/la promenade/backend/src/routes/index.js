// src/routes/index.js
const express = require("express");
const router = express.Router();

const authRoutes = require("./auth.routes");
const systemRoutes = require("./system.routes");
const adminRoutes = require("./admin");
const coordinatorRoutes = require("./coordinator.routes");
const accountingRoutes = require("./accounting.routes");
const organizerRoutes = require("./organizer.routes");

router.use("/auth", authRoutes);
router.use("/system", systemRoutes);
router.use("/admin", adminRoutes);
router.use("/coordinator", coordinatorRoutes);
router.use("/accounting", accountingRoutes);
router.use("/organizer", organizerRoutes);

module.exports = router;