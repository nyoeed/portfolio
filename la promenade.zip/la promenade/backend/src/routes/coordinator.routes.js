const express = require('express');
const router = express.Router();
const c = require('../controllers/coordinator/coordinator.controller');
const { requireAuth, requireApproved, requireRole } = require('../middleware/auth');
const { validateGuid } = require('../middleware/validateGuid');

router.use(requireAuth, requireApproved, requireRole('coordinator'));

router.get('/dashboard', c.dashboard);
router.get('/events', c.listEvents);
router.get('/events/:id', validateGuid('id'), c.getEventDetail);
router.patch('/events/:id/status', validateGuid('id'), c.updateEventStatus);
router.post('/events/:id/notes', validateGuid('id'), c.addEventNote);
router.post('/events/:id/documents', validateGuid('id'), c.uploadEventDocument);

router.get('/rooms/calendar', c.listRoomsCalendar);
router.get('/rooms/conflicts', c.listConflicts);
router.patch('/reservations/:id/status', validateGuid('id'), c.updateReservationStatus);

router.get('/services', c.listServiceRequests);
router.patch('/services/:id', validateGuid('id'), c.updateServiceRequest);

router.post('/tasks', c.createTask);
router.patch('/tasks/:id', validateGuid('id'), c.updateTask);

router.get('/notifications', c.listNotifications);
router.patch('/notifications/:id/read', validateGuid('id'), c.markNotificationRead);

router.get('/reports', c.listReports);
router.put('/reports/:eventId', validateGuid('eventId'), c.upsertReport);

module.exports = router;
