const { getPool, sql } = require("../../config/db");

function normalizeInvoiceStatus(status) {
  if (status === "overdue") return "late";
  return status;
}


async function getInvoiceableEvents() {
  const pool = await getPool();
  const result = await pool.request().query(`
    WITH serviceAgg AS (
      SELECT es.eventId, ISNULL(SUM(es.estimatedAmount), 0) AS serviceEstimated
      FROM dbo.EventServiceRequests es
      GROUP BY es.eventId
    ),
    invoiceAgg AS (
      SELECT i.eventId, COUNT(*) AS invoiceCount
      FROM dbo.Invoices i
      WHERE i.eventId IS NOT NULL
        AND i.status <> 'cancelled'
      GROUP BY i.eventId
    )
    SELECT
      e.id,
      e.title,
      e.type,
      e.startAt,
      e.endAt,
      e.status,
      e.budget,
      u.fullName AS clientName,
      u.email AS clientEmail,
      r.name AS roomName,
      ISNULL(sa.serviceEstimated, 0) AS serviceEstimated,
      CASE
        WHEN ISNULL(e.budget, 0) > 0 THEN e.budget
        ELSE ISNULL(sa.serviceEstimated, 0)
      END AS suggestedSubtotal,
      ISNULL(ia.invoiceCount, 0) AS invoiceCount
    FROM dbo.Events e
    LEFT JOIN dbo.Users u ON u.id = e.organizerId
    LEFT JOIN dbo.Rooms r ON r.id = e.roomId
    LEFT JOIN serviceAgg sa ON sa.eventId = e.id
    LEFT JOIN invoiceAgg ia ON ia.eventId = e.id
    WHERE e.status IN ('submitted', 'validated', 'confirmed', 'in_coordination', 'in_progress')
    ORDER BY
      CASE WHEN ISNULL(ia.invoiceCount, 0) = 0 THEN 0 ELSE 1 END,
      e.startAt DESC,
      e.createdAt DESC;
  `);

  return result.recordset;
}

async function getEventForInvoice(eventId) {
  const pool = await getPool();
  const result = await pool.request().input('eventId', sql.UniqueIdentifier, eventId).query(`
    WITH serviceAgg AS (
      SELECT es.eventId, ISNULL(SUM(es.estimatedAmount), 0) AS serviceEstimated
      FROM dbo.EventServiceRequests es
      WHERE es.eventId = @eventId
      GROUP BY es.eventId
    )
    SELECT TOP 1
      e.id,
      e.title,
      e.type,
      e.startAt,
      e.endAt,
      e.status,
      e.budget,
      u.fullName AS clientName,
      u.email AS clientEmail,
      ISNULL(sa.serviceEstimated, 0) AS serviceEstimated,
      CASE
        WHEN ISNULL(e.budget, 0) > 0 THEN e.budget
        ELSE ISNULL(sa.serviceEstimated, 0)
      END AS suggestedSubtotal
    FROM dbo.Events e
    LEFT JOIN dbo.Users u ON u.id = e.organizerId
    LEFT JOIN serviceAgg sa ON sa.eventId = e.id
    WHERE e.id = @eventId;
  `);

  return result.recordset?.[0] || null;
}

async function getDashboard() {
  const pool = await getPool();

  const [
    totalRevenueR,
    lateInvoicesR,
    pendingPaymentsR,
    revenueThisMonthR,
    lateInvoicesListR,
    recentPaymentsR,
    pendingInvoiceRequestsR,
    notificationsR,
  ] = await Promise.all([
    pool.request().query(`
      SELECT ISNULL(SUM(amount), 0) AS totalRevenue
      FROM dbo.Payments
      WHERE status = 'completed';
    `),

    pool.request().query(`
      SELECT COUNT(*) AS lateInvoicesCount
      FROM dbo.Invoices
      WHERE status = 'late';
    `),

    pool.request().query(`
      SELECT COUNT(*) AS pendingPaymentsCount
      FROM dbo.Payments
      WHERE status = 'pending';
    `),

    pool.request().query(`
      SELECT ISNULL(SUM(amount), 0) AS revenueThisMonth
      FROM dbo.Payments
      WHERE status = 'completed'
        AND YEAR(paidAt) = YEAR(GETDATE())
        AND MONTH(paidAt) = MONTH(GETDATE());
    `),

    pool.request().query(`
      SELECT TOP 5
        i.id,
        i.invoiceNumber,
        i.clientName,
        COALESCE(i.eventTitle, i.eventName) AS eventTitle,
        i.total,
        i.dueDate,
        DATEDIFF(DAY, i.dueDate, CAST(GETDATE() AS DATE)) AS lateDays
      FROM dbo.Invoices i
      WHERE i.status = 'late'
      ORDER BY i.dueDate ASC, i.id DESC;
    `),

    pool.request().query(`
      SELECT TOP 5
        p.id,
        p.paymentNumber,
        p.amount,
        p.method,
        p.paidAt,
        i.clientName,
        COALESCE(i.eventTitle, i.eventName) AS eventTitle
      FROM dbo.Payments p
      INNER JOIN dbo.Invoices i ON i.id = p.invoiceId
      WHERE p.status = 'completed'
      ORDER BY p.paidAt DESC, p.id DESC;
    `),

    pool.request().query(`
      WITH invoiceAgg AS (
        SELECT i.eventId, COUNT(*) AS invoiceCount
        FROM dbo.Invoices i
        WHERE i.eventId IS NOT NULL AND i.status <> 'cancelled'
        GROUP BY i.eventId
      )
      SELECT TOP 5
        e.id,
        e.title,
        e.type,
        e.startAt,
        u.fullName AS clientName,
        u.email AS clientEmail,
        ISNULL(e.budget, 0) AS budget,
        ISNULL(ia.invoiceCount, 0) AS invoiceCount
      FROM dbo.Events e
      LEFT JOIN dbo.Users u ON u.id = e.organizerId
      LEFT JOIN invoiceAgg ia ON ia.eventId = e.id
      WHERE e.status IN ('submitted', 'validated', 'confirmed', 'in_coordination', 'in_progress')
        AND ISNULL(ia.invoiceCount, 0) = 0
      ORDER BY e.submittedAt DESC, e.startAt DESC;
    `),

    pool.request().query(`
      SELECT TOP 5 id, type, priority, title, message, relatedEntity, relatedId, createdAt, isRead
      FROM dbo.Notifications
      WHERE recipientUserId IN (SELECT id FROM dbo.Users WHERE role IN ('accounting', 'admin') AND status='approved')
         OR recipientUserId IS NULL
      ORDER BY isRead ASC, createdAt DESC;
    `),
  ]);

  return {
    totalRevenue: Number(totalRevenueR.recordset?.[0]?.totalRevenue || 0),
    lateInvoicesCount: Number(lateInvoicesR.recordset?.[0]?.lateInvoicesCount || 0),
    pendingPaymentsCount: Number(pendingPaymentsR.recordset?.[0]?.pendingPaymentsCount || 0),
    revenueThisMonth: Number(revenueThisMonthR.recordset?.[0]?.revenueThisMonth || 0),
    lateInvoices: lateInvoicesListR.recordset || [],
    recentPayments: recentPaymentsR.recordset || [],
    pendingInvoiceRequests: pendingInvoiceRequestsR.recordset || [],
    notifications: notificationsR.recordset || [],
  };
}

async function listInvoices({ search = "", status = "" }) {
  const pool = await getPool();
  const req = pool.request();

  let where = "WHERE 1=1";

  if (search.trim()) {
    where += `
      AND (
        i.invoiceNumber LIKE @search
        OR i.clientName LIKE @search
        OR i.eventName LIKE @search
        OR i.eventTitle LIKE @search
        OR i.clientEmail LIKE @search
      )
    `;
    req.input("search", sql.NVarChar, `%${search.trim()}%`);
  }

  if (status.trim()) {
    req.input("status", sql.NVarChar, normalizeInvoiceStatus(status.trim()));
    where += ` AND i.status = @status`;
  }

  const result = await req.query(`
    SELECT
      i.id,
      i.invoiceNumber,
      i.clientName,
      i.clientEmail,
      i.eventName,
      i.eventTitle,
      i.eventType,
      i.issueDate,
      i.dueDate,
      i.subtotal,
      i.taxRate,
      i.taxAmount,
      i.total,
      i.status,
      i.createdAt,
      i.paidAt,

      ISNULL((
        SELECT SUM(p.amount)
        FROM dbo.Payments p
        WHERE p.invoiceId = i.id
          AND p.status = 'completed'
      ), 0) AS paidSum,

      (
        i.total - ISNULL((
          SELECT SUM(p.amount)
          FROM dbo.Payments p
          WHERE p.invoiceId = i.id
            AND p.status = 'completed'
        ), 0)
      ) AS remainingAmount
    FROM dbo.Invoices i
    ${where}
    ORDER BY i.issueDate DESC, i.id DESC;
  `);

  return result.recordset;
}

async function createInvoice(payload) {
  const pool = await getPool();

  const {
    eventId,
    clientName,
    clientEmail,
    eventName,
    eventTitle,
    eventType,
    issueDate,
    dueDate,
    subtotal,
    taxRate,
  } = payload;

  const event = await getEventForInvoice(eventId);
  if (!event) {
    const err = new Error("Événement introuvable.");
    err.statusCode = 404;
    throw err;
  }

  const allowedStatuses = ["submitted", "validated", "confirmed", "in_coordination", "in_progress"];
  if (!allowedStatuses.includes(event.status)) {
    const err = new Error("Cet événement ne peut pas encore être facturé.");
    err.statusCode = 400;
    throw err;
  }

  const duplicateR = await pool
    .request()
    .input("eventId", sql.UniqueIdentifier, eventId)
    .query(`
      SELECT TOP 1 id, invoiceNumber
      FROM dbo.Invoices
      WHERE eventId = @eventId
        AND status <> 'cancelled'
      ORDER BY id DESC;
    `);

  if (duplicateR.recordset.length) {
    const err = new Error(`Une facture existe déjà pour cet événement (${duplicateR.recordset[0].invoiceNumber}).`);
    err.statusCode = 409;
    throw err;
  }

  const countR = await pool.request().query(`
    SELECT COUNT(*) + 1 AS nextNum
    FROM dbo.Invoices
    WHERE YEAR(issueDate) = YEAR(GETDATE());
  `);

  const nextNum = String(countR.recordset[0]?.nextNum || 1).padStart(3, "0");
  const invoiceNumber = `FACT-${new Date().getFullYear()}-${nextNum}`;

  const resolvedClientName = (clientName || event.clientName || '').trim();
  if (!resolvedClientName) {
    const err = new Error("Impossible de déterminer le client de cette facture.");
    err.statusCode = 400;
    throw err;
  }

  const resolvedClientEmail = (clientEmail || event.clientEmail || null);
  const resolvedEventTitle = event.title || eventTitle || eventName || null;
  const resolvedEventName = eventName || event.title || eventTitle || null;
  const resolvedEventType = eventType || event.type || null;

  const result = await pool
    .request()
    .input("invoiceNumber", sql.NVarChar, invoiceNumber)
    .input("eventId", sql.UniqueIdentifier, event.id)
    .input("eventName", sql.NVarChar, resolvedEventName)
    .input("clientName", sql.NVarChar, resolvedClientName)
    .input("clientEmail", sql.NVarChar, resolvedClientEmail)
    .input("eventTitle", sql.NVarChar, resolvedEventTitle)
    .input("eventType", sql.NVarChar, resolvedEventType)
    .input("issueDate", sql.Date, issueDate)
    .input("dueDate", sql.Date, dueDate)
    .input("subtotal", sql.Decimal(12, 2), Number(subtotal))
    .input("taxRate", sql.Decimal(5, 2), Number(taxRate))
    .input("status", sql.NVarChar, "pending")
    .query(`
      INSERT INTO dbo.Invoices (
        invoiceNumber,
        eventId,
        eventName,
        clientName,
        clientEmail,
        eventTitle,
        eventType,
        issueDate,
        dueDate,
        subtotal,
        taxRate,
        status,
        createdAt
      )
      OUTPUT inserted.*
      VALUES (
        @invoiceNumber,
        @eventId,
        @eventName,
        @clientName,
        @clientEmail,
        @eventTitle,
        @eventType,
        @issueDate,
        @dueDate,
        @subtotal,
        @taxRate,
        @status,
        GETDATE()
      );
    `);

  const created = result.recordset[0];

  await pool.request()
    .input('eventId', sql.UniqueIdentifier, event.id)
    .input('title', sql.NVarChar, resolvedEventTitle)
    .query(`
      INSERT INTO dbo.Notifications (id, type, priority, title, message, isRead, relatedEntity, relatedId, recipientUserId, createdAt)
      SELECT NEWID(), 'payment', 'normal', N'Facture créée', CONCAT(N'Une facture a été créée pour votre événement « ', @title, N' ».'), 0, 'event', @eventId, e.organizerId, SYSUTCDATETIME()
      FROM dbo.Events e
      WHERE e.id = @eventId;
    `);

  return created;
}

async function updateInvoiceStatus(invoiceId, status) {
  const pool = await getPool();

  const existsR = await pool
    .request()
    .input("invoiceId", sql.Int, invoiceId)
    .query(`SELECT TOP 1 id FROM dbo.Invoices WHERE id = @invoiceId;`);

  if (!existsR.recordset.length) {
    const err = new Error("Facture introuvable.");
    err.statusCode = 404;
    throw err;
  }

  await pool
    .request()
    .input("invoiceId", sql.Int, invoiceId)
    .input("status", sql.NVarChar, normalizeInvoiceStatus(status))
    .query(`
      UPDATE dbo.Invoices
      SET status = @status
      WHERE id = @invoiceId;
    `);

  return { message: "Statut mis à jour ✅" };
}

async function deleteInvoice(invoiceId) {
  const pool = await getPool();

  const usageR = await pool
    .request()
    .input("invoiceId", sql.Int, invoiceId)
    .query(`
      SELECT
        (SELECT COUNT(*) FROM dbo.Payments WHERE invoiceId = @invoiceId) AS paymentsCount,
        (SELECT COUNT(*) FROM dbo.Refunds WHERE invoiceId = @invoiceId) AS refundsCount;
    `);

  const row = usageR.recordset[0] || {};
  if (Number(row.paymentsCount || 0) > 0 || Number(row.refundsCount || 0) > 0) {
    const err = new Error("Impossible de supprimer une facture liée à des paiements ou remboursements.");
    err.statusCode = 409;
    throw err;
  }

  const result = await pool
    .request()
    .input("invoiceId", sql.Int, invoiceId)
    .query(`
      DELETE FROM dbo.Invoices
      WHERE id = @invoiceId;
    `);

  return { deleted: result.rowsAffected?.[0] || 0 };
}


async function listNotifications() {
  const pool = await getPool();
  const result = await pool.request().query(`
    SELECT TOP 100 id, type, priority, title, message, relatedEntity, relatedId, createdAt, isRead
    FROM dbo.Notifications
    WHERE recipientUserId IN (SELECT id FROM dbo.Users WHERE role IN ('accounting', 'admin') AND status='approved')
       OR recipientUserId IS NULL
    ORDER BY isRead ASC, createdAt DESC;
  `);
  return result.recordset || [];
}

async function markNotificationRead(notificationId) {
  const pool = await getPool();
  const result = await pool.request().input('notificationId', sql.UniqueIdentifier, notificationId).query(`
    UPDATE dbo.Notifications
    SET isRead = 1
    WHERE id = @notificationId;
  `);
  return { updated: result.rowsAffected?.[0] || 0 };
}

async function recalculateInvoiceStatus(pool, invoiceId) {
  const invoiceR = await pool.request().input('invoiceId', sql.Int, Number(invoiceId)).query(`
    SELECT TOP 1 id, total, dueDate
    FROM dbo.Invoices
    WHERE id = @invoiceId;
  `);
  const invoice = invoiceR.recordset?.[0] || null;
  if (!invoice) {
    const err = new Error('Facture introuvable.');
    err.statusCode = 404;
    throw err;
  }

  const paidR = await pool.request().input('invoiceId', sql.Int, Number(invoiceId)).query(`
    SELECT ISNULL(SUM(amount), 0) AS paidSum
    FROM dbo.Payments
    WHERE invoiceId = @invoiceId AND status = 'completed';
  `);
  const paidSum = Number(paidR.recordset?.[0]?.paidSum || 0);
  const total = Number(invoice.total || 0);
  let newStatus = 'pending';
  if (paidSum >= total && total > 0) newStatus = 'paid';
  else if (paidSum > 0) newStatus = 'partial';
  else if (invoice.dueDate && new Date(invoice.dueDate) < new Date()) newStatus = 'late';

  await pool.request().input('invoiceId', sql.Int, Number(invoiceId)).input('status', sql.NVarChar, newStatus).query(`
    UPDATE dbo.Invoices
    SET status = @status,
        paidAt = CASE WHEN @status = 'paid' THEN CAST(GETDATE() AS DATE) ELSE paidAt END
    WHERE id = @invoiceId;
  `);

  return { paidSum, remainingAmount: Math.max(total - paidSum, 0), invoiceStatus: newStatus };
}

async function updatePaymentStatus(paymentId, status) {
  const pool = await getPool();
  const paymentR = await pool.request().input('paymentId', sql.Int, Number(paymentId)).query(`
    SELECT TOP 1 p.id, p.invoiceId, p.status, p.amount, p.paymentNumber, i.clientName, COALESCE(i.eventTitle, i.eventName) AS eventTitle
    FROM dbo.Payments p
    INNER JOIN dbo.Invoices i ON i.id = p.invoiceId
    WHERE p.id = @paymentId;
  `);
  const payment = paymentR.recordset?.[0] || null;
  if (!payment) {
    const err = new Error('Paiement introuvable.');
    err.statusCode = 404;
    throw err;
  }

  await pool.request().input('paymentId', sql.Int, Number(paymentId)).input('status', sql.NVarChar, status).query(`
    UPDATE dbo.Payments
    SET status = @status
    WHERE id = @paymentId;
  `);

  const calc = await recalculateInvoiceStatus(pool, payment.invoiceId);

  if (status === 'completed' || status === 'failed' || status === 'cancelled') {
    const notifTitle = status === 'completed' ? 'Paiement simulé validé' : 'Paiement simulé refusé';
    const notifMessage = status === 'completed'
      ? `Le paiement simulé ${payment.paymentNumber} pour ${payment.eventTitle} a été validé par la comptabilité.`
      : `Le paiement simulé ${payment.paymentNumber} pour ${payment.eventTitle} a été refusé ou annulé par la comptabilité.`;

    await pool.request()
      .input('invoiceId', sql.Int, Number(payment.invoiceId))
      .input('title', sql.NVarChar, notifTitle)
      .input('message', sql.NVarChar, notifMessage)
      .query(`
        INSERT INTO dbo.Notifications (id, type, priority, title, message, isRead, relatedEntity, relatedId, recipientUserId, createdAt)
        SELECT NEWID(), 'payment', 'normal', @title, @message, 0, 'invoice', NULL, e.organizerId, SYSUTCDATETIME()
        FROM dbo.Invoices i
        INNER JOIN dbo.Events e ON e.id = i.eventId
        WHERE i.id = @invoiceId;
      `);
  }

  return { success: true, ...calc };
}

async function listPayments({ search = "", status = "" }) {
  const pool = await getPool();
  const req = pool.request();

  let where = "WHERE 1=1";

  if (search.trim()) {
    where += `
      AND (
        p.paymentNumber LIKE @search
        OR i.invoiceNumber LIKE @search
        OR i.clientName LIKE @search
        OR i.eventName LIKE @search
        OR i.eventTitle LIKE @search
        OR p.method LIKE @search
      )
    `;
    req.input("search", sql.NVarChar, `%${search.trim()}%`);
  }

  if (status.trim()) {
    where += ` AND p.status = @status`;
    req.input("status", sql.NVarChar, status.trim());
  }

  const result = await req.query(`
    SELECT
      p.id,
      p.paymentNumber,
      p.invoiceId,
      p.amount,
      p.method,
      p.paidAt,
      p.reference,
      p.status,
      p.createdAt,
      i.invoiceNumber,
      i.clientName,
      i.clientEmail,
      COALESCE(i.eventTitle, i.eventName) AS eventTitle,
      i.eventType,
      i.total,
      i.status AS invoiceStatus,
      ISNULL((
        SELECT SUM(px.amount)
        FROM dbo.Payments px
        WHERE px.invoiceId = i.id
          AND px.status = 'completed'
      ), 0) AS paidSum,
      (
        i.total - ISNULL((
          SELECT SUM(px.amount)
          FROM dbo.Payments px
          WHERE px.invoiceId = i.id
            AND px.status = 'completed'
        ), 0)
      ) AS remainingAmount
    FROM dbo.Payments p
    INNER JOIN dbo.Invoices i ON i.id = p.invoiceId
    ${where}
    ORDER BY p.paidAt DESC, p.id DESC;
  `);

  return result.recordset;
}

async function createPayment({ invoiceId, amount, method, paidAt, reference }) {
  const pool = await getPool();

  const invoiceR = await pool
    .request()
    .input("invoiceId", sql.Int, Number(invoiceId))
    .query(`
      SELECT TOP 1 id, invoiceNumber, total, dueDate
      FROM dbo.Invoices
      WHERE id = @invoiceId;
    `);

  const invoice = invoiceR.recordset[0];
  if (!invoice) {
    const err = new Error("Facture introuvable.");
    err.statusCode = 404;
    throw err;
  }

  const countR = await pool.request().query(`
    SELECT COUNT(*) + 1 AS nextNum
    FROM dbo.Payments
    WHERE YEAR(createdAt) = YEAR(GETDATE());
  `);

  const nextNum = String(countR.recordset[0]?.nextNum || 1).padStart(3, "0");
  const paymentNumber = `PAY-${new Date().getFullYear()}-${nextNum}`;

  await pool
    .request()
    .input("invoiceId", sql.Int, Number(invoiceId))
    .input("amount", sql.Decimal(12, 2), Number(amount))
    .input("method", sql.NVarChar, method)
    .input("paidAt", sql.Date, paidAt)
    .input("reference", sql.NVarChar, reference || null)
    .input("paymentNumber", sql.NVarChar, paymentNumber)
    .input("status", sql.NVarChar, "completed")
    .query(`
      INSERT INTO dbo.Payments (
        invoiceId,
        amount,
        method,
        paidAt,
        reference,
        createdAt,
        paymentNumber,
        status
      )
      VALUES (
        @invoiceId,
        @amount,
        @method,
        @paidAt,
        @reference,
        GETDATE(),
        @paymentNumber,
        @status
      );
    `);

  const paidSumR = await pool
    .request()
    .input("invoiceId", sql.Int, Number(invoiceId))
    .query(`
      SELECT ISNULL(SUM(amount), 0) AS paidSum
      FROM dbo.Payments
      WHERE invoiceId = @invoiceId
        AND status = 'completed';
    `);

  const paidSum = Number(paidSumR.recordset[0]?.paidSum || 0);
  const total = Number(invoice.total || 0);

  let newStatus = "pending";
  if (paidSum >= total) newStatus = "paid";
  else if (paidSum > 0) newStatus = "partial";

  const today = new Date();
  const dueDate = invoice.dueDate ? new Date(invoice.dueDate) : null;
  if (newStatus !== "paid" && dueDate && dueDate < today) {
    newStatus = "late";
  }

  await pool
    .request()
    .input("invoiceId", sql.Int, Number(invoiceId))
    .input("status", sql.NVarChar, newStatus)
    .input("paidAt", sql.Date, paidAt)
    .query(`
      UPDATE dbo.Invoices
      SET status = @status,
          paidAt = CASE WHEN @status = 'paid' THEN @paidAt ELSE paidAt END
      WHERE id = @invoiceId;
    `);

  return {
    message: "Paiement enregistré ✅",
    paymentNumber,
    invoiceStatus: newStatus,
    paidSum,
    remainingAmount: Math.max(total - paidSum, 0),
  };
}

async function listRefunds({ search = "", status = "" }) {
  const pool = await getPool();
  const req = pool.request();

  let where = "WHERE 1=1";

  if (search.trim()) {
    where += `
      AND (
        r.refundNumber LIKE @search
        OR i.invoiceNumber LIKE @search
        OR i.clientName LIKE @search
        OR r.reason LIKE @search
      )
    `;
    req.input("search", sql.NVarChar, `%${search.trim()}%`);
  }

  if (status.trim()) {
    where += ` AND r.status = @status`;
    req.input("status", sql.NVarChar, status.trim());
  }

  const result = await req.query(`
    SELECT
      r.id,
      r.refundNumber,
      r.invoiceId,
      r.amount,
      r.reason,
      r.refundDate,
      r.status,
      r.createdAt,
      i.invoiceNumber,
      i.clientName,
      COALESCE(i.eventTitle, i.eventName) AS eventTitle
    FROM dbo.Refunds r
    INNER JOIN dbo.Invoices i ON i.id = r.invoiceId
    ${where}
    ORDER BY r.createdAt DESC, r.id DESC;
  `);

  return result.recordset;
}

async function createRefund({ invoiceId, amount, reason, refundDate }) {
  const pool = await getPool();

  const invoiceR = await pool
    .request()
    .input("invoiceId", sql.Int, Number(invoiceId))
    .query(`SELECT TOP 1 id FROM dbo.Invoices WHERE id = @invoiceId;`);

  if (!invoiceR.recordset.length) {
    const err = new Error("Facture introuvable.");
    err.statusCode = 404;
    throw err;
  }

  const countR = await pool.request().query(`
    SELECT COUNT(*) + 1 AS nextNum
    FROM dbo.Refunds
    WHERE YEAR(createdAt) = YEAR(GETDATE());
  `);

  const nextNum = String(countR.recordset[0]?.nextNum || 1).padStart(3, "0");
  const refundNumber = `REM-${new Date().getFullYear()}-${nextNum}`;

  const result = await pool
    .request()
    .input("invoiceId", sql.Int, Number(invoiceId))
    .input("amount", sql.Decimal(12, 2), Number(amount))
    .input("reason", sql.NVarChar, reason)
    .input("refundDate", sql.Date, refundDate)
    .input("status", sql.NVarChar, "pending")
    .input("refundNumber", sql.NVarChar, refundNumber)
    .query(`
      INSERT INTO dbo.Refunds (
        invoiceId,
        amount,
        reason,
        refundDate,
        status,
        createdAt,
        refundNumber
      )
      OUTPUT inserted.*
      VALUES (
        @invoiceId,
        @amount,
        @reason,
        @refundDate,
        @status,
        GETDATE(),
        @refundNumber
      );
    `);

  const created = result.recordset[0];

  await pool.request()
    .input('eventId', sql.UniqueIdentifier, event.id)
    .input('title', sql.NVarChar, resolvedEventTitle)
    .query(`
      INSERT INTO dbo.Notifications (id, type, priority, title, message, isRead, relatedEntity, relatedId, recipientUserId, createdAt)
      SELECT NEWID(), 'payment', 'normal', N'Facture créée', CONCAT(N'Une facture a été créée pour votre événement « ', @title, N' ».'), 0, 'event', @eventId, e.organizerId, SYSUTCDATETIME()
      FROM dbo.Events e
      WHERE e.id = @eventId;
    `);

  return created;
}

async function updateRefundStatus(refundId, status) {
  const pool = await getPool();

  const existsR = await pool
    .request()
    .input("refundId", sql.Int, refundId)
    .query(`SELECT TOP 1 id FROM dbo.Refunds WHERE id = @refundId;`);

  if (!existsR.recordset.length) {
    const err = new Error("Remboursement introuvable.");
    err.statusCode = 404;
    throw err;
  }

  await pool
    .request()
    .input("refundId", sql.Int, refundId)
    .input("status", sql.NVarChar, status)
    .query(`
      UPDATE dbo.Refunds
      SET status = @status
      WHERE id = @refundId;
    `);

  return { message: "Statut remboursement mis à jour ✅" };
}

async function deleteRefund(refundId) {
  const pool = await getPool();

  await pool
    .request()
    .input("refundId", sql.Int, refundId)
    .query(`DELETE FROM dbo.Refunds WHERE id = @refundId;`);

  return { deleted: true };
}

async function getReports({ startDate, endDate }) {
  const pool = await getPool();

  const today = new Date();
  const defaultEnd = today.toISOString().slice(0, 10);

  const startObj = new Date();
  startObj.setMonth(startObj.getMonth() - 6);
  const defaultStart = startObj.toISOString().slice(0, 10);

  const start = startDate || defaultStart;
  const end = endDate || defaultEnd;

  const revenueR = await pool
    .request()
    .input("startDate", sql.Date, start)
    .input("endDate", sql.Date, end)
    .query(`
      SELECT
        ISNULL(SUM(amount), 0) AS totalRevenue,
        ISNULL(AVG(amount), 0) AS averagePayment,
        COUNT(*) AS completedPayments
      FROM dbo.Payments
      WHERE status = 'completed'
        AND paidAt BETWEEN @startDate AND @endDate;
    `);

  const invoicesR = await pool
    .request()
    .input("startDate", sql.Date, start)
    .input("endDate", sql.Date, end)
    .query(`
      SELECT COUNT(*) AS invoicesCount
      FROM dbo.Invoices
      WHERE issueDate BETWEEN @startDate AND @endDate;
    `);

  const paidInvoicesR = await pool
    .request()
    .input("startDate", sql.Date, start)
    .input("endDate", sql.Date, end)
    .query(`
      SELECT COUNT(*) AS paidInvoicesCount
      FROM dbo.Invoices
      WHERE issueDate BETWEEN @startDate AND @endDate
        AND status = 'paid';
    `);

  const monthlyR = await pool
    .request()
    .input("startDate", sql.Date, start)
    .input("endDate", sql.Date, end)
    .query(`
      SELECT
        YEAR(paidAt) AS yearValue,
        MONTH(paidAt) AS monthValue,
        SUM(amount) AS revenue
      FROM dbo.Payments
      WHERE status = 'completed'
        AND paidAt BETWEEN @startDate AND @endDate
      GROUP BY YEAR(paidAt), MONTH(paidAt)
      ORDER BY YEAR(paidAt), MONTH(paidAt);
    `);

  const eventTypeR = await pool
    .request()
    .input("startDate", sql.Date, start)
    .input("endDate", sql.Date, end)
    .query(`
      SELECT
        ISNULL(NULLIF(LTRIM(RTRIM(eventType)), ''), 'Non défini') AS eventType,
        COUNT(id) AS invoiceCount,
        ISNULL(SUM(total), 0) AS totalRevenue
      FROM dbo.Invoices
      WHERE issueDate BETWEEN @startDate AND @endDate
      GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(eventType)), ''), 'Non défini')
      ORDER BY totalRevenue DESC;
    `);

  const totalRevenue = Number(revenueR.recordset[0]?.totalRevenue || 0);
  const averagePayment = Number(revenueR.recordset[0]?.averagePayment || 0);
  const completedPayments = Number(revenueR.recordset[0]?.completedPayments || 0);
  const invoicesCount = Number(invoicesR.recordset[0]?.invoicesCount || 0);
  const paidInvoicesCount = Number(paidInvoicesR.recordset[0]?.paidInvoicesCount || 0);

  const monthNames = ["Jan", "Fév", "Mars", "Avr", "Mai", "Juin", "Juil", "Août", "Sept", "Oct", "Nov", "Déc"];

  const revenueByEventType = (eventTypeR.recordset || []).map((row) => ({
    eventType: row.eventType,
    invoiceCount: Number(row.invoiceCount || 0),
    totalRevenue: Number(row.totalRevenue || 0),
    averageRevenue:
      Number(row.invoiceCount || 0) > 0
        ? Number(row.totalRevenue || 0) / Number(row.invoiceCount || 0)
        : 0,
  }));

  const grandTotal = revenueByEventType.reduce((sum, row) => sum + row.totalRevenue, 0);

  return {
    filters: { startDate: start, endDate: end },
    summary: {
      totalRevenue,
      invoicesCount,
      paymentRate: invoicesCount > 0 ? (paidInvoicesCount / invoicesCount) * 100 : 0,
      averagePayment,
      completedPayments,
    },
    charts: {
      monthlyRevenue: (monthlyR.recordset || []).map((row) => ({
        label: `${monthNames[row.monthValue - 1]} ${row.yearValue}`,
        revenue: Number(row.revenue || 0),
      })),
      revenueByEventType: revenueByEventType.map((row) => ({
        ...row,
        percentOfTotal: grandTotal > 0 ? (row.totalRevenue / grandTotal) * 100 : 0,
      })),
    },
  };
}

module.exports = {
  getDashboard,
  listInvoices,
  getInvoiceableEvents,
  createInvoice,
  updateInvoiceStatus,
  deleteInvoice,
  listPayments,
  listNotifications,
  markNotificationRead,
  updatePaymentStatus,
  createPayment,
  listRefunds,
  createRefund,
  updateRefundStatus,
  deleteRefund,
  getReports,
};
