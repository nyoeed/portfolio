// src/repositories/system.repo.js
const { getPool } = require("../config/db");

async function hasAnyAdmin() {
  const pool = await getPool();
  const r = await pool.request().query("SELECT COUNT(*) AS c FROM dbo.Users WHERE role='admin'");
  return (r.recordset?.[0]?.c || 0) > 0;
}

async function existsByEmail({ email }) {
  const pool = await getPool();
  const r = await pool.request().input("email", email).query("SELECT 1 FROM dbo.Users WHERE email=@email");
  return !!r.recordset.length;
}

async function insertAdmin({ fullName, email, passwordHash }) {
  const pool = await getPool();
  const ins = await pool
    .request()
    .input("fullName", fullName)
    .input("email", email)
    .input("passwordHash", passwordHash)
    .query(`
      INSERT INTO dbo.Users (fullName, email, passwordHash, role, status)
      OUTPUT INSERTED.id, INSERTED.fullName, INSERTED.email, INSERTED.role, INSERTED.status
      VALUES (@fullName, @email, @passwordHash, 'admin', 'approved')
    `);

  return ins.recordset[0];
}

module.exports = { hasAnyAdmin, existsByEmail, insertAdmin };