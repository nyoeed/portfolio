
const { getPool, sql } = require("../config/db");

async function getAdminSettings() {
  const pool = await getPool();
  const r = await pool.request().query(`
    SELECT TOP 1
      notifEvents, notifPayments, notifSignup, notifSystem, dailySummaryEnabled, email,
      onlinePaymentEnabled
    FROM dbo.AdminSettings
    ORDER BY id ASC;
  `);
  return r.recordset?.[0] || null;
}

async function getUserById(id) {
  const pool = await getPool();
  const r = await pool.request().input("id", sql.UniqueIdentifier, id).query(`
    SELECT TOP 1
      id, fullName, email, role, status,
      notificationEmailEnabled,
      notificationInAppEnabled
    FROM dbo.Users
    WHERE id=@id;
  `);
  return r.recordset?.[0] || null;
}

async function listUsersByRoles(roles = []) {
  if (!Array.isArray(roles) || !roles.length) return [];
  const pool = await getPool();
  const inSql = roles.map((_, i) => `@role${i}`).join(", ");
  const req = pool.request();
  roles.forEach((role, i) => req.input(`role${i}`, sql.VarChar, role));
  const r = await req.query(`
    SELECT id, fullName, email, role, status, notificationEmailEnabled, notificationInAppEnabled
    FROM dbo.Users
    WHERE status='approved' AND role IN (${inSql});
  `);
  return r.recordset || [];
}

async function createNotification({ recipientUserId = null, type = 'system', priority = 'normal', title, message, relatedEntity = null, relatedId = null }) {
  const pool = await getPool();
  const r = await pool.request()
    .input('recipientUserId', sql.UniqueIdentifier, recipientUserId)
    .input('type', sql.VarChar(20), type)
    .input('priority', sql.VarChar(10), priority)
    .input('title', sql.NVarChar(160), title)
    .input('message', sql.NVarChar(600), message)
    .input('relatedEntity', sql.VarChar(30), relatedEntity)
    .input('relatedId', sql.UniqueIdentifier, relatedId)
    .query(`
      INSERT INTO dbo.Notifications (id, recipientUserId, type, priority, title, message, isRead, relatedEntity, relatedId, createdAt)
      OUTPUT INSERTED.id, INSERTED.recipientUserId, INSERTED.type, INSERTED.priority, INSERTED.title, INSERTED.message, INSERTED.createdAt
      VALUES (NEWID(), @recipientUserId, @type, @priority, @title, @message, 0, @relatedEntity, @relatedId, SYSUTCDATETIME());
    `);
  return r.recordset?.[0] || null;
}

module.exports = {
  getAdminSettings,
  getUserById,
  listUsersByRoles,
  createNotification,
};
