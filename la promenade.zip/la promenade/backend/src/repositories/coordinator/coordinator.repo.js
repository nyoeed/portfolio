const { getPool, sql } = require('../../config/db');

const ACTIVE_EVENT_STATUSES = ['submitted', 'in_review', 'validated', 'confirmed', 'in_coordination', 'in_progress', 'completed'];
const COORDINATOR_EVENT_SCOPE = `${ACTIVE_EVENT_STATUSES.map((s) => `'${s}'`).join(', ')}`;

function coordinatorScope(alias = 'e') {
  return `(${alias}.assignedCoordinatorId=@userId OR (${alias}.assignedCoordinatorId IS NULL AND ${alias}.status IN (${COORDINATOR_EVENT_SCOPE})))`;
}

async function claimEventIfNeeded({ userId, eventId, tx = null }) {
  if (!eventId) return null;
  const request = tx ? new sql.Request(tx) : (await getPool()).request();
  const result = await request
    .input('userId', sql.UniqueIdentifier, userId)
    .input('eventId', sql.UniqueIdentifier, eventId)
    .query(`
      UPDATE dbo.Events
      SET assignedCoordinatorId = COALESCE(assignedCoordinatorId, @userId),
          updatedAt = SYSUTCDATETIME()
      OUTPUT inserted.*
      WHERE id=@eventId
        AND (${coordinatorScope('dbo.Events')});
    `);
  return result.recordset?.[0] || null;
}

async function getEventStakeholders(eventId) {
  const pool = await getPool();
  const result = await pool.request()
    .input('eventId', sql.UniqueIdentifier, eventId)
    .query(`
      SELECT TOP 1
        e.id,
        e.title,
        e.status,
        e.organizerId,
        e.assignedCoordinatorId,
        organizer.fullName AS organizerName,
        organizer.email AS organizerEmail,
        coordinator.fullName AS coordinatorName
      FROM dbo.Events e
      LEFT JOIN dbo.Users organizer ON organizer.id = e.organizerId
      LEFT JOIN dbo.Users coordinator ON coordinator.id = e.assignedCoordinatorId
      WHERE e.id=@eventId;
    `);
  return result.recordset?.[0] || null;
}

async function getDashboard(userId) {
  const pool = await getPool();
  const r = await pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
    DECLARE @startToday DATETIME2 = CAST(CAST(SYSUTCDATETIME() AS date) AS DATETIME2);
    DECLARE @startTomorrow DATETIME2 = DATEADD(DAY, 1, @startToday);
    DECLARE @startWeek DATETIME2 = DATEADD(DAY, 7, @startToday);

    SELECT
      (SELECT COUNT(*) FROM dbo.Events e WHERE ${coordinatorScope('e')} AND e.startAt >= @startToday AND e.startAt < @startTomorrow AND e.status <> 'cancelled') AS eventsToday,
      (SELECT COUNT(*) FROM dbo.Events e WHERE ${coordinatorScope('e')} AND e.startAt >= @startToday AND e.startAt < @startWeek AND e.status <> 'cancelled') AS eventsThisWeek,
      (SELECT COUNT(*) FROM dbo.Events e WHERE ${coordinatorScope('e')} AND e.assignedCoordinatorId IS NULL AND e.status IN ('submitted','in_review','validated','confirmed','in_coordination','in_progress')) AS eventsUnassigned,
      (SELECT COUNT(*) FROM dbo.EventServiceRequests sr JOIN dbo.Events e ON e.id=sr.eventId WHERE ${coordinatorScope('e')} AND sr.status IN ('requested','in_analysis','approved')) AS servicesToConfirm,
      (SELECT COUNT(*) FROM dbo.Reservations r LEFT JOIN dbo.Events e ON e.id=r.eventId WHERE (e.id IS NULL OR ${coordinatorScope('e')}) AND r.status='pending') AS pendingReservations,
      (SELECT COUNT(*) FROM dbo.Invoices i WHERE i.status='overdue') AS overdueInvoices,
      (SELECT COUNT(*) FROM dbo.Notifications n WHERE (n.recipientUserId=@userId OR n.recipientUserId IS NULL) AND n.isRead=0 AND n.priority='urgent') AS urgentAlerts;

    SELECT TOP 8
      e.id,
      e.title,
      e.status,
      e.startAt,
      e.endAt,
      e.participants,
      e.assignedCoordinatorId,
      r.name AS roomName,
      u.fullName AS organizerName,
      CAST((
        (CASE WHEN e.status IN ('validated','confirmed','in_coordination','in_progress','completed') THEN 25 ELSE 0 END) +
        (CASE WHEN EXISTS (SELECT 1 FROM dbo.Reservations rr WHERE rr.eventId=e.id AND rr.status IN ('locked','confirmed')) THEN 20 ELSE 0 END) +
        (CASE WHEN EXISTS (SELECT 1 FROM dbo.EventServiceRequests sr WHERE sr.eventId=e.id AND sr.status IN ('planned','in_progress','completed')) THEN 25 ELSE 0 END) +
        (CASE WHEN EXISTS (SELECT 1 FROM dbo.EventDocuments d WHERE d.eventId=e.id) THEN 15 ELSE 0 END) +
        (CASE WHEN EXISTS (SELECT 1 FROM dbo.EventGuests g WHERE g.eventId=e.id AND g.rsvpStatus='confirmed') THEN 15 ELSE 0 END)
      ) AS INT) AS progressPct
    FROM dbo.Events e
    LEFT JOIN dbo.Rooms r ON r.id=e.roomId
    LEFT JOIN dbo.Users u ON u.id=e.organizerId
    WHERE ${coordinatorScope('e')}
    ORDER BY CASE WHEN e.assignedCoordinatorId IS NULL THEN 0 ELSE 1 END, e.startAt ASC;

    SELECT TOP 12
      n.id, n.type, n.priority, n.title, n.message, n.createdAt, n.relatedEntity, n.relatedId, n.isRead
    FROM dbo.Notifications n
    WHERE (n.recipientUserId=@userId OR n.recipientUserId IS NULL)
    ORDER BY CASE n.priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 ELSE 3 END, n.createdAt DESC;

    SELECT TOP 12
      sr.id,
      s.name AS serviceName,
      s.category,
      sr.status,
      sr.priority,
      sr.plannedStartAt,
      sr.plannedEndAt,
      sr.requestedStartAt,
      sr.requestedEndAt,
      e.id AS eventId,
      e.title AS eventTitle,
      e.assignedCoordinatorId
    FROM dbo.EventServiceRequests sr
    JOIN dbo.Events e ON e.id=sr.eventId
    JOIN dbo.Services s ON s.id=sr.serviceId
    WHERE ${coordinatorScope('e')}
    ORDER BY
      CASE WHEN e.assignedCoordinatorId IS NULL THEN 0 ELSE 1 END,
      CASE sr.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,
      COALESCE(sr.plannedStartAt, sr.requestedStartAt, e.startAt) ASC;
  `);

  return {
    summary: r.recordsets[0]?.[0] || {},
    upcomingEvents: r.recordsets[1] || [],
    alerts: r.recordsets[2] || [],
    serviceQueue: r.recordsets[3] || [],
  };
}

async function listEvents({ userId, status, roomId, type, search }) {
  const pool = await getPool();
  const req = pool.request().input('userId', sql.UniqueIdentifier, userId);
  let where = `WHERE ${coordinatorScope('e')}`;
  if (status) {
    where += ' AND e.status=@status';
    req.input('status', sql.NVarChar, status);
  }
  if (roomId) {
    where += ' AND e.roomId=@roomId';
    req.input('roomId', sql.UniqueIdentifier, roomId);
  }
  if (type) {
    where += ' AND e.type=@type';
    req.input('type', sql.NVarChar, type);
  }
  if (search) {
    where += ' AND (e.title LIKE @search OR u.fullName LIKE @search OR r.name LIKE @search)';
    req.input('search', sql.NVarChar, `%${search}%`);
  }
  const r = await req.query(`
    SELECT
      e.id,
      e.title,
      e.type,
      e.description,
      e.startAt,
      e.endAt,
      e.participants,
      e.budget,
      e.status,
      e.assignedCoordinatorId,
      CASE WHEN e.assignedCoordinatorId IS NULL THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS needsClaim,
      r.id AS roomId,
      r.name AS roomName,
      r.capacity AS roomCapacity,
      u.id AS organizerId,
      u.fullName AS organizerName,
      u.email AS organizerEmail,
      (SELECT COUNT(*) FROM dbo.EventGuests g WHERE g.eventId=e.id) AS guestCount,
      (SELECT COUNT(*) FROM dbo.EventDocuments d WHERE d.eventId=e.id) AS documentCount,
      (SELECT COUNT(*) FROM dbo.EventServiceRequests sr WHERE sr.eventId=e.id) AS serviceCount,
      (SELECT COUNT(*) FROM dbo.EventTasks t WHERE t.eventId=e.id AND t.status IN ('todo','in_progress','blocked')) AS openTaskCount,
      (SELECT TOP 1 i.status FROM dbo.Invoices i WHERE i.eventId=e.id OR i.eventName=e.title ORDER BY i.issueDate DESC, i.id DESC) AS latestInvoiceStatus
    FROM dbo.Events e
    LEFT JOIN dbo.Rooms r ON r.id=e.roomId
    LEFT JOIN dbo.Users u ON u.id=e.organizerId
    ${where}
    ORDER BY CASE WHEN e.assignedCoordinatorId IS NULL THEN 0 ELSE 1 END, e.startAt ASC;
  `);
  return r.recordset || [];
}

async function getEventDetail({ userId, eventId }) {
  await claimEventIfNeeded({ userId, eventId });
  const pool = await getPool();
  const r = await pool.request()
    .input('userId', sql.UniqueIdentifier, userId)
    .input('eventId', sql.UniqueIdentifier, eventId)
    .query(`
      SELECT TOP 1
        e.id, e.title, e.type, e.description, e.startAt, e.endAt, e.participants, e.budget, e.status, e.submittedAt, e.updatedAt,
        e.assignedCoordinatorId,
        r.id AS roomId, r.name AS roomName, r.capacity AS roomCapacity, r.surface, r.status AS roomStatus,
        u.id AS organizerId, u.fullName AS organizerName, u.email AS organizerEmail,
        cu.fullName AS coordinatorName
      FROM dbo.Events e
      LEFT JOIN dbo.Rooms r ON r.id=e.roomId
      LEFT JOIN dbo.Users u ON u.id=e.organizerId
      LEFT JOIN dbo.Users cu ON cu.id=e.assignedCoordinatorId
      WHERE e.id=@eventId AND ${coordinatorScope('e')};

      SELECT id, status, startAt, endAt, createdAt
      FROM dbo.Reservations
      WHERE eventId=@eventId
      ORDER BY createdAt DESC;

      SELECT
        sr.id, sr.quantity, sr.requestedStartAt, sr.requestedEndAt, sr.plannedStartAt, sr.plannedEndAt,
        sr.priority, sr.status, sr.locationNote, sr.remarks, sr.estimatedAmount,
        s.id AS serviceId, s.name AS serviceName, s.category, s.unitLabel, s.price,
        u.fullName AS assignedToName
      FROM dbo.EventServiceRequests sr
      JOIN dbo.Services s ON s.id=sr.serviceId
      LEFT JOIN dbo.Users u ON u.id=sr.assignedToUserId
      WHERE sr.eventId=@eventId
      ORDER BY s.category, s.name;

      SELECT id, firstName, lastName, email, phone, company, rsvpStatus, dietaryNotes, specialNeeds, invitationSentAt, respondedAt
      FROM dbo.EventGuests
      WHERE eventId=@eventId
      ORDER BY lastName, firstName;

      SELECT id, category, title, fileName, filePath, mimeType, fileSizeBytes, versionNo, createdAt
      FROM dbo.EventDocuments
      WHERE eventId=@eventId
      ORDER BY createdAt DESC;

      SELECT id, title, description, dueAt, priority, status, category, createdAt, updatedAt, completedAt
      FROM dbo.EventTasks
      WHERE eventId=@eventId
      ORDER BY CASE status WHEN 'blocked' THEN 1 WHEN 'todo' THEN 2 WHEN 'in_progress' THEN 3 ELSE 4 END, dueAt ASC;

      SELECT id, noteType, content, createdAt, authorUserId,
             (SELECT fullName FROM dbo.Users u WHERE u.id=n.authorUserId) AS authorName
      FROM dbo.EventNotes n
      WHERE eventId=@eventId
      ORDER BY createdAt DESC;

      SELECT TOP 1 id, invoiceNumber, issueDate, dueDate, subtotal, taxRate, total, status
      FROM dbo.Invoices
      WHERE eventId=@eventId OR eventName = (SELECT title FROM dbo.Events WHERE id=@eventId)
      ORDER BY issueDate DESC, id DESC;

      SELECT TOP 1 id, finalParticipants, serviceExecutionScore, incidentCount, operationsComment, incidentsComment, satisfactionComment, updatedAt
      FROM dbo.EventReports
      WHERE eventId=@eventId;

      SELECT TOP 20 id, actionType, summary, detailsJson, createdAt,
             (SELECT fullName FROM dbo.Users u WHERE u.id=a.actorUserId) AS actorName,
             actorRole
      FROM dbo.AuditLogs a
      WHERE (a.entityType='event' AND a.entityId=@eventId)
         OR (a.entityType='service_request' AND a.entityId IN (SELECT id FROM dbo.EventServiceRequests WHERE eventId=@eventId))
      ORDER BY createdAt DESC;
    `);

  return {
    event: r.recordsets[0]?.[0] || null,
    reservations: r.recordsets[1] || [],
    services: r.recordsets[2] || [],
    guests: r.recordsets[3] || [],
    documents: r.recordsets[4] || [],
    tasks: r.recordsets[5] || [],
    notes: r.recordsets[6] || [],
    invoice: r.recordsets[7]?.[0] || null,
    report: r.recordsets[8]?.[0] || null,
    audit: r.recordsets[9] || [],
  };
}

async function updateEventStatus({ userId, eventId, status }) {
  await claimEventIfNeeded({ userId, eventId });
  const pool = await getPool();
  const r = await pool.request()
    .input('userId', sql.UniqueIdentifier, userId)
    .input('eventId', sql.UniqueIdentifier, eventId)
    .input('status', sql.NVarChar, status)
    .query(`
      UPDATE dbo.Events
      SET status=@status, assignedCoordinatorId=COALESCE(assignedCoordinatorId, @userId), updatedAt=SYSUTCDATETIME()
      OUTPUT inserted.*
      WHERE id=@eventId AND assignedCoordinatorId=@userId;
    `);
  return r.recordset?.[0] || null;
}

async function addEventNote({ userId, eventId, authorUserId, content, noteType = 'internal' }) {
  await claimEventIfNeeded({ userId, eventId });
  const pool = await getPool();
  const r = await pool.request()
    .input('eventId', sql.UniqueIdentifier, eventId)
    .input('authorUserId', sql.UniqueIdentifier, authorUserId)
    .input('content', sql.NVarChar(sql.MAX), content)
    .input('noteType', sql.NVarChar, noteType)
    .query(`
      INSERT INTO dbo.EventNotes (eventId, authorUserId, noteType, content)
      OUTPUT inserted.*
      VALUES (@eventId, @authorUserId, @noteType, @content);
    `);
  return r.recordset[0];
}

async function listRoomsCalendar({ userId, from, to }) {
  const pool = await getPool();
  const r = await pool.request()
    .input('userId', sql.UniqueIdentifier, userId)
    .input('from', sql.DateTime2, from)
    .input('to', sql.DateTime2, to)
    .query(`
      SELECT r.id, r.name, r.capacity, r.surface, r.status,
             STUFF((SELECT ', ' + re.label FROM dbo.RoomEquipments re WHERE re.roomId=r.id FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS equipments
      FROM dbo.Rooms r
      ORDER BY r.name;

      SELECT res.id, res.roomId, room.name AS roomName, res.eventId, res.title, res.startAt, res.endAt, res.participants, res.status,
             e.status AS eventStatus,
             e.assignedCoordinatorId,
             CASE WHEN e.id IS NULL THEN CAST(0 AS bit) WHEN ${coordinatorScope('e')} THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS visibleToCoordinator
      FROM dbo.Reservations res
      JOIN dbo.Rooms room ON room.id=res.roomId
      LEFT JOIN dbo.Events e ON e.id=res.eventId
      WHERE res.startAt < @to AND res.endAt > @from
      ORDER BY res.startAt ASC;
    `);
  return { rooms: r.recordsets[0] || [], reservations: (r.recordsets[1] || []).filter((x) => !x.eventId || x.visibleToCoordinator) };
}

async function listConflicts() {
  const pool = await getPool();
  const r = await pool.request().query(`
    SELECT
      a.id AS reservationAId,
      b.id AS reservationBId,
      a.roomId,
      room.name AS roomName,
      a.title AS titleA,
      b.title AS titleB,
      a.startAt AS startA,
      a.endAt AS endA,
      b.startAt AS startB,
      b.endAt AS endB,
      CASE WHEN ISNULL(e1.participants, a.participants) > room.capacity OR ISNULL(e2.participants, b.participants) > room.capacity THEN 1 ELSE 0 END AS capacityConflict
    FROM dbo.Reservations a
    JOIN dbo.Reservations b ON a.roomId=b.roomId AND a.id<b.id
      AND a.status IN ('pending','locked','confirmed')
      AND b.status IN ('pending','locked','confirmed')
      AND a.startAt < b.endAt AND a.endAt > b.startAt
    JOIN dbo.Rooms room ON room.id=a.roomId
    LEFT JOIN dbo.Events e1 ON e1.id=a.eventId
    LEFT JOIN dbo.Events e2 ON e2.id=b.eventId
    ORDER BY a.startAt ASC;
  `);
  return r.recordset || [];
}

async function updateReservationStatus({ reservationId, status, userId }) {
  const pool = await getPool();
  const eventLookup = await pool.request().input('reservationId', sql.UniqueIdentifier, reservationId).query(`SELECT TOP 1 eventId FROM dbo.Reservations WHERE id=@reservationId;`);
  const eventId = eventLookup.recordset?.[0]?.eventId || null;
  if (eventId) await claimEventIfNeeded({ userId, eventId });

  const req = pool.request()
    .input('reservationId', sql.UniqueIdentifier, reservationId)
    .input('status', sql.NVarChar, status)
    .input('userId', sql.UniqueIdentifier, userId);

  const q = status === 'locked'
    ? `UPDATE dbo.Reservations SET status=@status, lockedByCoordinatorId=@userId OUTPUT inserted.* WHERE id=@reservationId;`
    : `UPDATE dbo.Reservations SET status=@status, lockedByCoordinatorId = CASE WHEN @status='locked' THEN @userId ELSE lockedByCoordinatorId END OUTPUT inserted.* WHERE id=@reservationId;`;
  const r = await req.query(q);
  return { reservation: r.recordset?.[0] || null, eventId };
}

async function listServiceRequests({ userId, category, status, eventId }) {
  const pool = await getPool();
  const req = pool.request().input('userId', sql.UniqueIdentifier, userId);
  let where = `WHERE ${coordinatorScope('e')}`;
  if (category) {
    where += ' AND s.category=@category';
    req.input('category', sql.NVarChar, category);
  }
  if (status) {
    where += ' AND sr.status=@status';
    req.input('status', sql.NVarChar, status);
  }
  if (eventId) {
    where += ' AND e.id=@eventId';
    req.input('eventId', sql.UniqueIdentifier, eventId);
  }
  const r = await req.query(`
    SELECT
      sr.id, sr.quantity, sr.requestedStartAt, sr.requestedEndAt, sr.plannedStartAt, sr.plannedEndAt,
      sr.priority, sr.status, sr.locationNote, sr.remarks, sr.estimatedAmount,
      s.id AS serviceId, s.name AS serviceName, s.category, s.unitLabel, s.price,
      e.id AS eventId, e.title AS eventTitle, e.startAt AS eventStartAt, e.endAt AS eventEndAt,
      e.assignedCoordinatorId,
      room.name AS roomName,
      organizer.fullName AS organizerName,
      assignee.fullName AS assignedToName,
      CASE WHEN e.assignedCoordinatorId IS NULL THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS needsClaim
    FROM dbo.EventServiceRequests sr
    JOIN dbo.Services s ON s.id=sr.serviceId
    JOIN dbo.Events e ON e.id=sr.eventId
    LEFT JOIN dbo.Rooms room ON room.id=e.roomId
    LEFT JOIN dbo.Users organizer ON organizer.id=e.organizerId
    LEFT JOIN dbo.Users assignee ON assignee.id=sr.assignedToUserId
    ${where}
    ORDER BY 
      CASE WHEN e.assignedCoordinatorId IS NULL THEN 0 ELSE 1 END,
      CASE sr.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,
      COALESCE(sr.plannedStartAt, sr.requestedStartAt, e.startAt) ASC;
  `);
  return r.recordset || [];
}

async function updateServiceRequest({ userId, serviceRequestId, patch }) {
  const pool = await getPool();
  const eventLookup = await pool.request().input('serviceRequestId', sql.UniqueIdentifier, serviceRequestId).query(`
    SELECT TOP 1 sr.eventId
    FROM dbo.EventServiceRequests sr
    WHERE sr.id=@serviceRequestId;
  `);
  const eventId = eventLookup.recordset?.[0]?.eventId || null;
  if (!eventId) return null;
  await claimEventIfNeeded({ userId, eventId });

  const req = pool.request()
    .input('serviceRequestId', sql.UniqueIdentifier, serviceRequestId)
    .input('userId', sql.UniqueIdentifier, userId);
  const sets = [];
  const fields = [
    ['status', sql.NVarChar],
    ['priority', sql.NVarChar],
    ['plannedStartAt', sql.DateTime2],
    ['plannedEndAt', sql.DateTime2],
    ['quantity', sql.Decimal(10,2)],
    ['locationNote', sql.NVarChar],
    ['remarks', sql.NVarChar(sql.MAX)],
    ['estimatedAmount', sql.Decimal(12,2)],
    ['assignedToUserId', sql.UniqueIdentifier],
  ];
  for (const [k, type] of fields) {
    if (Object.prototype.hasOwnProperty.call(patch, k)) {
      sets.push(`${k}=@${k}`);
      req.input(k, type, patch[k]);
    }
  }
  if (!sets.includes('assignedToUserId=@assignedToUserId')) {
    sets.push('assignedToUserId=COALESCE(assignedToUserId, @userId)');
  }
  sets.push('updatedAt=SYSUTCDATETIME()');
  const r = await req.query(`
    UPDATE sr
    SET ${sets.join(', ')}
    OUTPUT inserted.*
    FROM dbo.EventServiceRequests sr
    JOIN dbo.Events e ON e.id=sr.eventId
    WHERE sr.id=@serviceRequestId AND e.assignedCoordinatorId=@userId;
  `);
  return r.recordset?.[0] || null;
}

async function createTask({ userId, eventId, createdByUserId, assignedToUserId, title, description, dueAt, priority, category }) {
  await claimEventIfNeeded({ userId, eventId });
  const pool = await getPool();
  const r = await pool.request()
    .input('eventId', sql.UniqueIdentifier, eventId)
    .input('createdByUserId', sql.UniqueIdentifier, createdByUserId)
    .input('assignedToUserId', sql.UniqueIdentifier, assignedToUserId || null)
    .input('title', sql.NVarChar, title)
    .input('description', sql.NVarChar(sql.MAX), description || null)
    .input('dueAt', sql.DateTime2, dueAt || null)
    .input('priority', sql.NVarChar, priority)
    .input('category', sql.NVarChar, category)
    .query(`
      INSERT INTO dbo.EventTasks (eventId, createdByUserId, assignedToUserId, title, description, dueAt, priority, category)
      OUTPUT inserted.*
      VALUES (@eventId, @createdByUserId, @assignedToUserId, @title, @description, @dueAt, @priority, @category);
    `);
  return r.recordset[0];
}

async function updateTask({ taskId, patch }) {
  const pool = await getPool();
  const req = pool.request().input('taskId', sql.UniqueIdentifier, taskId);
  const sets = [];
  const fields = [
    ['title', sql.NVarChar],
    ['description', sql.NVarChar(sql.MAX)],
    ['assignedToUserId', sql.UniqueIdentifier],
    ['dueAt', sql.DateTime2],
    ['priority', sql.NVarChar],
    ['status', sql.NVarChar],
    ['category', sql.NVarChar],
  ];
  for (const [k, type] of fields) {
    if (Object.prototype.hasOwnProperty.call(patch, k)) {
      sets.push(`${k}=@${k}`);
      req.input(k, type, patch[k]);
    }
  }
  sets.push('updatedAt=SYSUTCDATETIME()');
  if (patch.status === 'done') sets.push('completedAt=SYSUTCDATETIME()');
  const r = await req.query(`UPDATE dbo.EventTasks SET ${sets.join(', ')} OUTPUT inserted.* WHERE id=@taskId;`);
  return r.recordset?.[0] || null;
}

async function listNotifications({ userId, unreadOnly }) {
  const pool = await getPool();
  const req = pool.request().input('userId', sql.UniqueIdentifier, userId);
  let where = 'WHERE (recipientUserId=@userId OR recipientUserId IS NULL)';
  if (unreadOnly) where += ' AND isRead=0';
  const r = await req.query(`SELECT TOP 100 * FROM dbo.Notifications ${where} ORDER BY createdAt DESC;`);
  return r.recordset || [];
}

async function markNotificationRead({ notificationId, userId }) {
  const pool = await getPool();
  const r = await pool.request()
    .input('notificationId', sql.UniqueIdentifier, notificationId)
    .input('userId', sql.UniqueIdentifier, userId)
    .query(`
      UPDATE dbo.Notifications
      SET isRead=1
      OUTPUT inserted.*
      WHERE id=@notificationId AND (recipientUserId=@userId OR recipientUserId IS NULL);
    `);
  return r.recordset?.[0] || null;
}

async function upsertReport({ userId, eventId, createdByUserId, finalParticipants, serviceExecutionScore, incidentCount, operationsComment, incidentsComment, satisfactionComment }) {
  await claimEventIfNeeded({ userId, eventId });
  const pool = await getPool();
  const r = await pool.request()
    .input('eventId', sql.UniqueIdentifier, eventId)
    .input('createdByUserId', sql.UniqueIdentifier, createdByUserId)
    .input('finalParticipants', sql.Int, finalParticipants)
    .input('serviceExecutionScore', sql.Int, serviceExecutionScore)
    .input('incidentCount', sql.Int, incidentCount)
    .input('operationsComment', sql.NVarChar(sql.MAX), operationsComment || null)
    .input('incidentsComment', sql.NVarChar(sql.MAX), incidentsComment || null)
    .input('satisfactionComment', sql.NVarChar(sql.MAX), satisfactionComment || null)
    .query(`
      MERGE dbo.EventReports AS target
      USING (SELECT @eventId AS eventId) AS src
      ON target.eventId = src.eventId
      WHEN MATCHED THEN
        UPDATE SET
          finalParticipants=@finalParticipants,
          serviceExecutionScore=@serviceExecutionScore,
          incidentCount=@incidentCount,
          operationsComment=@operationsComment,
          incidentsComment=@incidentsComment,
          satisfactionComment=@satisfactionComment,
          updatedAt=SYSUTCDATETIME()
      WHEN NOT MATCHED THEN
        INSERT (eventId, createdByUserId, finalParticipants, serviceExecutionScore, incidentCount, operationsComment, incidentsComment, satisfactionComment)
        VALUES (@eventId, @createdByUserId, @finalParticipants, @serviceExecutionScore, @incidentCount, @operationsComment, @incidentsComment, @satisfactionComment)
      OUTPUT inserted.*;
    `);
  return r.recordset?.[0] || null;
}

async function listReports({ userId }) {
  const pool = await getPool();
  const r = await pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
    SELECT rep.id, rep.finalParticipants, rep.serviceExecutionScore, rep.incidentCount, rep.updatedAt,
           e.id AS eventId, e.title AS eventTitle, e.startAt, e.endAt, e.status,
           r.name AS roomName
    FROM dbo.EventReports rep
    JOIN dbo.Events e ON e.id=rep.eventId
    LEFT JOIN dbo.Rooms r ON r.id=e.roomId
    WHERE ${coordinatorScope('e')}
    ORDER BY rep.updatedAt DESC;
  `);
  return r.recordset || [];
}

async function insertDocument({ userId, eventId, uploadedByUserId, category, title, fileName, filePath, mimeType, fileSizeBytes }) {
  await claimEventIfNeeded({ userId, eventId });
  const pool = await getPool();
  const versionQuery = await pool.request().input('eventId', sql.UniqueIdentifier, eventId).input('title', sql.NVarChar, title).query(`
    SELECT ISNULL(MAX(versionNo),0)+1 AS nextVersion FROM dbo.EventDocuments WHERE eventId=@eventId AND title=@title;
  `);
  const versionNo = versionQuery.recordset?.[0]?.nextVersion || 1;
  const r = await pool.request()
    .input('eventId', sql.UniqueIdentifier, eventId)
    .input('uploadedByUserId', sql.UniqueIdentifier, uploadedByUserId)
    .input('category', sql.NVarChar, category)
    .input('title', sql.NVarChar, title)
    .input('fileName', sql.NVarChar, fileName)
    .input('filePath', sql.NVarChar, filePath)
    .input('mimeType', sql.NVarChar, mimeType || null)
    .input('fileSizeBytes', sql.BigInt, fileSizeBytes || null)
    .input('versionNo', sql.Int, versionNo)
    .query(`
      INSERT INTO dbo.EventDocuments (eventId, uploadedByUserId, category, title, fileName, filePath, mimeType, fileSizeBytes, versionNo)
      OUTPUT inserted.*
      VALUES (@eventId, @uploadedByUserId, @category, @title, @fileName, @filePath, @mimeType, @fileSizeBytes, @versionNo);
    `);
  return r.recordset[0];
}

async function logAudit({ entityType, entityId, actionType, actorUserId, actorRole, summary, detailsJson }) {
  const pool = await getPool();
  await pool.request()
    .input('entityType', sql.NVarChar, entityType)
    .input('entityId', sql.UniqueIdentifier, entityId || null)
    .input('actionType', sql.NVarChar, actionType)
    .input('actorUserId', sql.UniqueIdentifier, actorUserId || null)
    .input('actorRole', sql.NVarChar, actorRole || null)
    .input('summary', sql.NVarChar, summary)
    .input('detailsJson', sql.NVarChar(sql.MAX), detailsJson || null)
    .query(`INSERT INTO dbo.AuditLogs (entityType, entityId, actionType, actorUserId, actorRole, summary, detailsJson)
            VALUES (@entityType, @entityId, @actionType, @actorUserId, @actorRole, @summary, @detailsJson);`);
}

async function createNotification({ recipientUserId, type, priority, title, message, relatedEntity, relatedId, category }) {
  const pool = await getPool();
  await pool.request()
    .input('recipientUserId', sql.UniqueIdentifier, recipientUserId || null)
    .input('type', sql.VarChar, type)
    .input('priority', sql.VarChar, priority)
    .input('title', sql.NVarChar, title)
    .input('message', sql.NVarChar, message || null)
    .input('relatedEntity', sql.VarChar, relatedEntity || null)
    .input('relatedId', sql.UniqueIdentifier, relatedId || null)
    .input('category', sql.NVarChar, category || null)
    .query(`INSERT INTO dbo.Notifications (recipientUserId, type, priority, title, message, relatedEntity, relatedId, category)
            VALUES (@recipientUserId, @type, @priority, @title, @message, @relatedEntity, @relatedId, @category);`);
}

module.exports = {
  getDashboard,
  listEvents,
  getEventDetail,
  updateEventStatus,
  addEventNote,
  listRoomsCalendar,
  listConflicts,
  updateReservationStatus,
  listServiceRequests,
  updateServiceRequest,
  createTask,
  updateTask,
  listNotifications,
  markNotificationRead,
  upsertReport,
  listReports,
  insertDocument,
  logAudit,
  createNotification,
  getEventStakeholders,
  claimEventIfNeeded,
};
