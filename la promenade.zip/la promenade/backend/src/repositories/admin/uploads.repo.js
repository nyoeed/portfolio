// src/repositories/admin/uploads.repo.js
const { getPool, sql } = require("../../config/db");

async function updateRoomImage({ id, imageUrl }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .input("imageUrl", sql.NVarChar, imageUrl)
    .query(`
      UPDATE dbo.Rooms
      SET imageUrl = @imageUrl
      OUTPUT inserted.*
      WHERE id = @id;
    `);

  return r.recordset?.[0] || null;
}

module.exports = { updateRoomImage };