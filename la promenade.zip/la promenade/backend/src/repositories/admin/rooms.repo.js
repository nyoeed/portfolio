// src/repositories/admin/rooms.repo.js
const { getPool, sql } = require("../../config/db");

async function getStats() {
  const pool = await getPool();

  const totalQ = pool.request().query(`SELECT COUNT(*) AS total FROM dbo.Rooms;`);
  const availableQ = pool.request().query(`
    SELECT COUNT(*) AS available
    FROM dbo.Rooms
    WHERE status = 'available';
  `);

  const reservedQ = pool.request().query(`
    SELECT COUNT(DISTINCT r.id) AS reserved
    FROM dbo.Rooms r
    JOIN dbo.Reservations res ON res.roomId = r.id
    WHERE res.status = 'confirmed'
      AND SYSUTCDATETIME() < res.endAt
      AND SYSUTCDATETIME() >= res.startAt;
  `);

  const capQ = pool.request().query(`
    SELECT ISNULL(SUM(capacity),0) AS totalCapacity
    FROM dbo.Rooms;
  `);

  const [t, a, r, c] = await Promise.all([totalQ, availableQ, reservedQ, capQ]);

  return {
    total: Number(t.recordset?.[0]?.total || 0),
    available: Number(a.recordset?.[0]?.available || 0),
    reserved: Number(r.recordset?.[0]?.reserved || 0),
    totalCapacity: Number(c.recordset?.[0]?.totalCapacity || 0),
  };
}

async function listWithDetails() {
  const pool = await getPool();

  const roomsR = await pool.request().query(`
    SELECT id, name, capacity, surface, pricePerDay, status, imageUrl, createdAt
    FROM dbo.Rooms
    ORDER BY createdAt DESC;
  `);

  const rooms = roomsR.recordset || [];
  if (!rooms.length) return [];

  // ⚠️ On garde ta logique IN (...) simple (même si c’est pas parfait)
  const ids = rooms.map((r) => `'${r.id}'`).join(",");

  const eqR = await pool.request().query(`
    SELECT roomId, label
    FROM dbo.RoomEquipments
    WHERE roomId IN (${ids})
    ORDER BY label ASC;
  `);

  const infoR = await pool.request().query(`
    SELECT
      roomId,
      COUNT(*) AS reservationsCount,
      MIN(CASE WHEN startAt >= SYSUTCDATETIME() THEN startAt ELSE NULL END) AS nextStartAt
    FROM dbo.Reservations
    WHERE roomId IN (${ids})
      AND status IN ('pending','confirmed')
    GROUP BY roomId;
  `);

  const eqByRoom = new Map();
  for (const row of eqR.recordset || []) {
    if (!eqByRoom.has(row.roomId)) eqByRoom.set(row.roomId, []);
    eqByRoom.get(row.roomId).push(row.label);
  }

  const infoByRoom = new Map();
  for (const row of infoR.recordset || []) {
    infoByRoom.set(row.roomId, {
      reservationsCount: Number(row.reservationsCount || 0),
      nextStartAt: row.nextStartAt ? new Date(row.nextStartAt).toISOString() : null,
    });
  }

  return rooms.map((r) => ({
    ...r,
    equipments: eqByRoom.get(r.id) || [],
    reservationsCount: infoByRoom.get(r.id)?.reservationsCount ?? 0,
    nextReservationAt: infoByRoom.get(r.id)?.nextStartAt ?? null,
  }));
}

async function createRoomWithEquipments(data) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);

  await tx.begin(sql.ISOLATION_LEVEL.READ_COMMITTED);
  try {
    const insertRoom = await new sql.Request(tx)
      .input("name", sql.NVarChar, data.name)
      .input("capacity", sql.Int, data.capacity)
      .input("surface", sql.Int, data.surface)
      .input("pricePerDay", sql.Decimal(10, 2), data.pricePerDay)
      .input("status", sql.VarChar, data.status)
      .query(`
        INSERT INTO dbo.Rooms (id, name, capacity, surface, pricePerDay, status, imageUrl, createdAt)
        OUTPUT inserted.*
        VALUES (NEWID(), @name, @capacity, @surface, @pricePerDay, @status, NULL, SYSUTCDATETIME());
      `);

    const room = insertRoom.recordset[0];

    for (const label of data.equipments || []) {
      await new sql.Request(tx)
        .input("roomId", sql.UniqueIdentifier, room.id)
        .input("label", sql.NVarChar, label)
        .query(`
          INSERT INTO dbo.RoomEquipments (id, roomId, label)
          VALUES (NEWID(), @roomId, @label);
        `);
    }

    await tx.commit();

    // reproduit ta réponse enrichie après création
    room.equipments = data.equipments || [];
    room.reservationsCount = 0;
    room.nextReservationAt = null;

    return room;
  } catch (e) {
    await tx.rollback();
    throw e;
  }
}

async function updateRoomAndMaybeEquipments(data) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);

  await tx.begin(sql.ISOLATION_LEVEL.READ_COMMITTED);
  try {
    const r = await new sql.Request(tx)
      .input("id", sql.UniqueIdentifier, data.id)
      .input("name", sql.NVarChar, data.name)
      .input("capacity", sql.Int, data.capacity)
      .input("surface", sql.Int, data.surface)
      .input("pricePerDay", sql.Decimal(10, 2), data.pricePerDay)
      .input("status", sql.VarChar, data.status)
      .query(`
        UPDATE dbo.Rooms
        SET
          name = COALESCE(@name, name),
          capacity = COALESCE(@capacity, capacity),
          surface = COALESCE(@surface, surface),
          pricePerDay = COALESCE(@pricePerDay, pricePerDay),
          status = COALESCE(@status, status)
        OUTPUT inserted.*
        WHERE id = @id;
      `);

    if (!r.recordset.length) {
      await tx.rollback();
      return null;
    }

    // Remplacer equipments si fourni
    if (Array.isArray(data.equipments)) {
      await new sql.Request(tx)
        .input("roomId", sql.UniqueIdentifier, data.id)
        .query(`DELETE FROM dbo.RoomEquipments WHERE roomId = @roomId;`);

      for (const label of data.equipments) {
        await new sql.Request(tx)
          .input("roomId", sql.UniqueIdentifier, data.id)
          .input("label", sql.NVarChar, label)
          .query(`
            INSERT INTO dbo.RoomEquipments (id, roomId, label)
            VALUES (NEWID(), @roomId, @label);
          `);
      }
    }

    await tx.commit();

    // ⚠️ ton ancien PATCH renvoyait inserted.* seulement (pas enrichi).
    // On garde le même comportement => on renvoie l'objet de Rooms direct.
    return r.recordset[0];
  } catch (e) {
    await tx.rollback();
    throw e;
  }
}

async function remove({ id }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      DELETE FROM dbo.Rooms WHERE id = @id;
      SELECT @@ROWCOUNT AS affectedRows;
    `);

  const affected = r.recordset?.[0]?.affectedRows ?? 0;
  return affected > 0;
}

module.exports = {
  getStats,
  listWithDetails,
  createRoomWithEquipments,
  updateRoomAndMaybeEquipments,
  remove,
};