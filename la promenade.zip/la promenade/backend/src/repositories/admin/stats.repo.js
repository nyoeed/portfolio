// src/repositories/admin/stats.repo.js
const { getPool } = require("../../config/db");

async function getDashboardStats() {
  const pool = await getPool();

  const totalUsersQ = pool.request().query(`SELECT COUNT(*) AS totalUsers FROM dbo.Users;`);

  const pendingQ = pool.request().query(`
    SELECT COUNT(*) AS pendingRequests
    FROM dbo.Users
    WHERE status = 'pending';
  `);

  const rolesQ = pool.request().query(`
    SELECT role, COUNT(*) AS count
    FROM dbo.Users
    WHERE role IS NOT NULL
    GROUP BY role;
  `);

  const statusQ = pool.request().query(`
    SELECT status, COUNT(*) AS count
    FROM dbo.Users
    GROUP BY status;
  `);

  const newUsersThisMonthQ = pool.request().query(`
    DECLARE @startThisMonth DATETIME2 =
      DATEFROMPARTS(YEAR(SYSUTCDATETIME()), MONTH(SYSUTCDATETIME()), 1);

    SELECT COUNT(*) AS newUsersThisMonth
    FROM dbo.Users
    WHERE createdAt >= @startThisMonth;
  `);

  const newUsersLastMonthQ = pool.request().query(`
    DECLARE @startThisMonth DATETIME2 =
      DATEFROMPARTS(YEAR(SYSUTCDATETIME()), MONTH(SYSUTCDATETIME()), 1);
    DECLARE @startLastMonth DATETIME2 = DATEADD(MONTH, -1, @startThisMonth);

    SELECT COUNT(*) AS newUsersLastMonth
    FROM dbo.Users
    WHERE createdAt >= @startLastMonth AND createdAt < @startThisMonth;
  `);

  const activeEventsQ = pool.request().query(`
    SELECT COUNT(*) AS activeEvents
    FROM dbo.Events
    WHERE status = 'confirmed'
      AND (endAt IS NULL OR endAt >= SYSUTCDATETIME());
  `);

  const newEventsThisWeekQ = pool.request().query(`
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    DECLARE @monday DATE = DATEADD(DAY, -((DATEPART(WEEKDAY, @today) + 5) % 7), @today);

    SELECT COUNT(*) AS newEventsThisWeek
    FROM dbo.Events
    WHERE createdAt >= @monday;
  `);

  const revenueThisMonthQ = pool.request().query(`
    DECLARE @startThisMonth DATETIME2 = DATEFROMPARTS(YEAR(SYSUTCDATETIME()), MONTH(SYSUTCDATETIME()), 1);
    DECLARE @startNextMonth DATETIME2 = DATEADD(MONTH, 1, @startThisMonth);

    SELECT
      ISNULL((SELECT SUM(amount) FROM dbo.Payments WHERE paidAt >= @startThisMonth AND paidAt < @startNextMonth), 0)
      -
      ISNULL((SELECT SUM(amount) FROM dbo.Refunds WHERE createdAt >= @startThisMonth AND createdAt < @startNextMonth), 0)
      AS revenueThisMonth;
  `);

  const revenueLastMonthQ = pool.request().query(`
    DECLARE @startThisMonth DATETIME2 = DATEFROMPARTS(YEAR(SYSUTCDATETIME()), MONTH(SYSUTCDATETIME()), 1);
    DECLARE @startLastMonth DATETIME2 = DATEADD(MONTH, -1, @startThisMonth);

    SELECT
      ISNULL((SELECT SUM(amount) FROM dbo.Payments WHERE paidAt >= @startLastMonth AND paidAt < @startThisMonth), 0)
      -
      ISNULL((SELECT SUM(amount) FROM dbo.Refunds WHERE createdAt >= @startLastMonth AND createdAt < @startThisMonth), 0)
      AS revenueLastMonth;
  `);

  const [
    totalUsersR,
    pendingR,
    rolesR,
    statusR,
    thisMonthR,
    lastMonthR,
    activeEventsR,
    newEventsThisWeekR,
    revenueThisMonthR,
    revenueLastMonthR,
  ] = await Promise.all([
    totalUsersQ,
    pendingQ,
    rolesQ,
    statusQ,
    newUsersThisMonthQ,
    newUsersLastMonthQ,
    activeEventsQ,
    newEventsThisWeekQ,
    revenueThisMonthQ,
    revenueLastMonthQ,
  ]);

  return {
    totalUsers: totalUsersR.recordset?.[0]?.totalUsers ?? 0,
    pendingRequests: pendingR.recordset?.[0]?.pendingRequests ?? 0,
    roles: rolesR.recordset || [],
    statuses: statusR.recordset || [],
    newUsersThisMonth: thisMonthR.recordset?.[0]?.newUsersThisMonth ?? 0,
    newUsersLastMonth: lastMonthR.recordset?.[0]?.newUsersLastMonth ?? 0,
    activeEvents: activeEventsR.recordset?.[0]?.activeEvents ?? 0,
    newEventsThisWeek: newEventsThisWeekR.recordset?.[0]?.newEventsThisWeek ?? 0,
    revenueThisMonth: revenueThisMonthR.recordset?.[0]?.revenueThisMonth ?? 0,
    revenueLastMonth: revenueLastMonthR.recordset?.[0]?.revenueLastMonth ?? 0,
  };
}

module.exports = { getDashboardStats };