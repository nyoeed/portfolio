// src/repositories/admin/invoices.repo.js
// SQL Server repository for invoices / payments / refunds / pdf data

const { getPool, sql } = require("../../config/db");

function coerceDateOrNull(v) {
  if (!v) return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

async function getSettings(pool) {
  const r = await pool.request().query(`
    SELECT TOP 1
      hotelName, email, address, phone, website,
      taxRate, paymentDelayDays, onlinePaymentEnabled
    FROM dbo.AdminSettings
    ORDER BY id ASC;
  `);
  return r.recordset?.[0] || {
    hotelName: "Hôtel La Promenade",
    email: null,
    address: null,
    phone: null,
    website: null,
    taxRate: 0,
    paymentDelayDays: 30,
    onlinePaymentEnabled: 1,
  };
}

// -------------------- Stats --------------------

async function getStats({ from, to } = {}) {
  const pool = await getPool();
  const req = pool.request();

  const fromD = coerceDateOrNull(from);
  const toD = coerceDateOrNull(to);
  let where = "WHERE 1=1";
  if (fromD) {
    where += " AND i.issuedAt >= @from";
    req.input("from", sql.DateTime2, fromD);
  }
  if (toD) {
    where += " AND i.issuedAt < @to";
    req.input("to", sql.DateTime2, toD);
  }

  const q = await req.query(`
    DECLARE @startThisMonth DATETIME2 = DATEFROMPARTS(YEAR(SYSUTCDATETIME()), MONTH(SYSUTCDATETIME()), 1);

    ;WITH PaidByInvoice AS (
      SELECT p.invoiceId, SUM(p.amount) AS paid
      FROM dbo.Payments p
      GROUP BY p.invoiceId
    ),
    RefundedByInvoice AS (
      SELECT r.invoiceId, SUM(r.amount) AS refunded
      FROM dbo.Refunds r
      GROUP BY r.invoiceId
    ),
    Balance AS (
      SELECT
        i.id,
        i.amount AS invoiceAmount,
        ISNULL(p.paid, 0) AS paidAmount,
        ISNULL(r.refunded, 0) AS refundedAmount,
        (i.amount - ISNULL(p.paid, 0) + ISNULL(r.refunded, 0)) AS remaining,
        i.dueAt,
        i.issuedAt
      FROM dbo.Invoices i
      LEFT JOIN PaidByInvoice p ON p.invoiceId = i.id
      LEFT JOIN RefundedByInvoice r ON r.invoiceId = i.id
      ${where}
    )
    SELECT
      (SELECT ISNULL(SUM(amount), 0) FROM dbo.Payments) - (SELECT ISNULL(SUM(amount), 0) FROM dbo.Refunds) AS totalRevenue,
      (SELECT ISNULL(SUM(remaining), 0) FROM Balance WHERE remaining > 0 AND dueAt >= SYSUTCDATETIME()) AS pendingAmount,
      (SELECT ISNULL(SUM(remaining), 0) FROM Balance WHERE remaining > 0 AND dueAt < SYSUTCDATETIME()) AS overdueAmount,
      (SELECT COUNT(*) FROM dbo.Invoices WHERE issuedAt >= @startThisMonth) AS totalInvoices;
  `);

  const r = q.recordset?.[0] || {};
  return {
    totalRevenue: Number(r.totalRevenue || 0),
    pendingAmount: Number(r.pendingAmount || 0),
    overdueAmount: Number(r.overdueAmount || 0),
    totalInvoices: Number(r.totalInvoices || 0),
  };
}

// -------------------- Lists --------------------

async function listInvoices({ from, to, eventId, status } = {}) {
  const pool = await getPool();
  const req = pool.request();

  const fromD = coerceDateOrNull(from);
  const toD = coerceDateOrNull(to);
  let where = "WHERE 1=1";

  if (fromD) {
    where += " AND i.issuedAt >= @from";
    req.input("from", sql.DateTime2, fromD);
  }
  if (toD) {
    where += " AND i.issuedAt < @to";
    req.input("to", sql.DateTime2, toD);
  }
  if (eventId) {
    where += " AND i.eventId = @eventId";
    req.input("eventId", sql.UniqueIdentifier, eventId);
  }

  // status filter accepts: paid | pending | late | overdue (UI)
  let statusFilter = null;
  if (status) {
    const s = String(status);
    statusFilter = s === "overdue" ? "late" : s;
  }
  if (statusFilter) {
    where += " AND statusComputed = @statusFilter";
    req.input("statusFilter", sql.NVarChar, statusFilter);
  }

  const q = await req.query(`
    ;WITH PaidByInvoice AS (
      SELECT p.invoiceId, SUM(p.amount) AS paid
      FROM dbo.Payments p
      GROUP BY p.invoiceId
    ),
    RefundedByInvoice AS (
      SELECT r.invoiceId, SUM(r.amount) AS refunded
      FROM dbo.Refunds r
      GROUP BY r.invoiceId
    ),
    Balance AS (
      SELECT
        i.*,
        ISNULL(p.paid, 0) AS paidAmount,
        ISNULL(r.refunded, 0) AS refundedAmount,
        (i.amount - ISNULL(p.paid, 0) + ISNULL(r.refunded, 0)) AS remaining,
        CASE
          WHEN (i.amount - ISNULL(p.paid, 0) + ISNULL(r.refunded, 0)) <= 0 THEN 'paid'
          WHEN i.dueAt < SYSUTCDATETIME() THEN 'late'
          ELSE 'pending'
        END AS statusComputed
      FROM dbo.Invoices i
      LEFT JOIN PaidByInvoice p ON p.invoiceId = i.id
      LEFT JOIN RefundedByInvoice r ON r.invoiceId = i.id
    )
    SELECT
      b.id,
      b.invoiceNumber,
      b.clientName,
      b.amount,
      b.status,
      b.statusComputed,
      b.issuedAt,
      b.dueAt,
      b.paidAt,
      e.title AS eventTitle,
      b.paidAmount,
      b.refundedAmount,
      b.remaining
    FROM Balance b
    LEFT JOIN dbo.Events e ON e.id = b.eventId
    ${where}
    ORDER BY b.issuedAt DESC;
  `);
  return q.recordset || [];
}

async function listPayments({ from, to } = {}) {
  const pool = await getPool();
  const req = pool.request();

  const fromD = coerceDateOrNull(from);
  const toD = coerceDateOrNull(to);
  let where = "WHERE 1=1";
  if (fromD) {
    where += " AND p.paidAt >= @from";
    req.input("from", sql.DateTime2, fromD);
  }
  if (toD) {
    where += " AND p.paidAt < @to";
    req.input("to", sql.DateTime2, toD);
  }

  const q = await req.query(`
    SELECT
      p.id,
      p.invoiceId,
      p.amount,
      p.method,
      p.provider,
      p.reference,
      p.paidAt,
      i.invoiceNumber,
      i.clientName
    FROM dbo.Payments p
    JOIN dbo.Invoices i ON i.id = p.invoiceId
    ${where}
    ORDER BY p.paidAt DESC;
  `);
  return q.recordset || [];
}

async function listRefunds({ from, to } = {}) {
  const pool = await getPool();
  const req = pool.request();

  const fromD = coerceDateOrNull(from);
  const toD = coerceDateOrNull(to);
  let where = "WHERE 1=1";
  if (fromD) {
    where += " AND r.createdAt >= @from";
    req.input("from", sql.DateTime2, fromD);
  }
  if (toD) {
    where += " AND r.createdAt < @to";
    req.input("to", sql.DateTime2, toD);
  }

  const q = await req.query(`
    SELECT
      r.id,
      r.invoiceId,
      r.amount,
      r.reason,
      r.status,
      r.createdAt,
      i.invoiceNumber,
      i.clientName
    FROM dbo.Refunds r
    JOIN dbo.Invoices i ON i.id = r.invoiceId
    ${where}
    ORDER BY r.createdAt DESC;
  `);
  return q.recordset || [];
}

// -------------------- Details --------------------

async function getInvoiceDetails(invoiceId) {
  const pool = await getPool();

  const headerR = await pool
    .request()
    .input("id", sql.UniqueIdentifier, invoiceId)
    .query(`
      ;WITH PaidByInvoice AS (
        SELECT invoiceId, SUM(amount) AS paid
        FROM dbo.Payments
        WHERE invoiceId = @id
        GROUP BY invoiceId
      ),
      RefundedByInvoice AS (
        SELECT invoiceId, SUM(amount) AS refunded
        FROM dbo.Refunds
        WHERE invoiceId = @id
        GROUP BY invoiceId
      )
      SELECT TOP 1
        i.id,
        i.invoiceNumber,
        i.clientName,
        i.eventId,
        e.title AS eventTitle,
        i.issuedAt,
        i.dueAt,
        i.amount AS total,
        i.subtotal,
        i.taxRate,
        i.taxAmount,
        ISNULL(p.paid,0) AS totalPaid,
        ISNULL(r.refunded,0) AS totalRefunded,
        (i.amount - ISNULL(p.paid,0) + ISNULL(r.refunded,0)) AS balance,
        CASE
          WHEN (i.amount - ISNULL(p.paid,0) + ISNULL(r.refunded,0)) <= 0 THEN 'paid'
          WHEN i.dueAt < SYSUTCDATETIME() THEN 'late'
          ELSE 'pending'
        END AS statusComputed
      FROM dbo.Invoices i
      LEFT JOIN dbo.Events e ON e.id = i.eventId
      LEFT JOIN PaidByInvoice p ON p.invoiceId = i.id
      LEFT JOIN RefundedByInvoice r ON r.invoiceId = i.id
      WHERE i.id = @id;
    `);

  const header = headerR.recordset?.[0] || null;
  if (!header) return null;

  const itemsR = await pool
    .request()
    .input("id", sql.UniqueIdentifier, invoiceId)
    .query(`
      SELECT id, kind, label, quantity, unitLabel, unitPrice, total
      FROM dbo.InvoiceItems
      WHERE invoiceId = @id
      ORDER BY createdAt ASC;
    `);

  const paymentsR = await pool
    .request()
    .input("id", sql.UniqueIdentifier, invoiceId)
    .query(`
      SELECT id, amount, method, provider, reference, paidAt
      FROM dbo.Payments
      WHERE invoiceId = @id
      ORDER BY paidAt DESC;
    `);

  const refundsR = await pool
    .request()
    .input("id", sql.UniqueIdentifier, invoiceId)
    .query(`
      SELECT id, amount, reason, status, createdAt
      FROM dbo.Refunds
      WHERE invoiceId = @id
      ORDER BY createdAt DESC;
    `);

  return {
    guid: header.id,
    invoiceNumber: header.invoiceNumber,
    clientName: header.clientName,
    eventId: header.eventId,
    eventName: header.eventTitle,
    issuedAt: header.issuedAt,
    dueAt: header.dueAt,
    status: header.statusComputed,
    subtotal: Number(header.subtotal ?? 0),
    taxRate: Number(header.taxRate ?? 0),
    taxAmount: Number(header.taxAmount ?? 0),
    total: Number(header.total ?? 0),
    totalPaid: Number(header.totalPaid ?? 0),
    balance: Number(header.balance ?? 0),
    items: (itemsR.recordset || []).map((x) => ({
      id: x.id,
      kind: x.kind,
      label: x.label,
      quantity: Number(x.quantity ?? 1),
      unitLabel: x.unitLabel,
      unitPrice: Number(x.unitPrice ?? 0),
      total: Number(x.total ?? 0),
    })),
    payments: (paymentsR.recordset || []).map((x) => ({
      id: x.id,
      amount: Number(x.amount ?? 0),
      method: x.method,
      provider: x.provider,
      reference: x.reference,
      paidAt: x.paidAt,
    })),
    refunds: (refundsR.recordset || []).map((x) => ({
      id: x.id,
      amount: Number(x.amount ?? 0),
      reason: x.reason,
      status: x.status,
      createdAt: x.createdAt,
    })),
  };
}

// -------------------- Generation (automatisée) --------------------

async function generateInvoiceForEvent({ eventId, clientName, dueAt } = {}) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin(sql.ISOLATION_LEVEL.SERIALIZABLE);

  try {
    // 1) Load settings + event
    const settings = await getSettings(pool);

    const evR = await new sql.Request(tx)
      .input("eventId", sql.UniqueIdentifier, eventId)
      .query(`SELECT TOP 1 id, title FROM dbo.Events WHERE id = @eventId;`);
    const ev = evR.recordset?.[0];
    if (!ev) {
      const e = new Error("Événement introuvable.");
      e.status = 404;
      throw e;
    }

    // 2) Load event items (rooms / services / bundles)
    const items = [];

    const roomsR = await new sql.Request(tx)
      .input("eventId", sql.UniqueIdentifier, eventId)
      .query(`
        SELECT
          er.id,
          r.name AS label,
          er.days,
          er.pricePerDaySnapshot AS unitPrice,
          (er.days * er.pricePerDaySnapshot) AS total
        FROM dbo.EventRooms er
        JOIN dbo.Rooms r ON r.id = er.roomId
        WHERE er.eventId = @eventId;
      `);
    (roomsR.recordset || []).forEach((x) => {
      items.push({ kind: "room", label: `Salle — ${x.label}`, quantity: Number(x.days || 1), unitLabel: "jour", unitPrice: Number(x.unitPrice || 0), total: Number(x.total || 0) });
    });

    const servicesR = await new sql.Request(tx)
      .input("eventId", sql.UniqueIdentifier, eventId)
      .query(`
        SELECT
          es.id,
          s.name AS label,
          es.quantity,
          es.unitLabelSnapshot AS unitLabel,
          es.unitPriceSnapshot AS unitPrice,
          (es.quantity * es.unitPriceSnapshot) AS total
        FROM dbo.EventServices es
        JOIN dbo.Services s ON s.id = es.serviceId
        WHERE es.eventId = @eventId;
      `);
    (servicesR.recordset || []).forEach((x) => {
      items.push({ kind: "service", label: `Service — ${x.label}`, quantity: Number(x.quantity || 1), unitLabel: x.unitLabel || "unité", unitPrice: Number(x.unitPrice || 0), total: Number(x.total || 0) });
    });

    const bundlesR = await new sql.Request(tx)
      .input("eventId", sql.UniqueIdentifier, eventId)
      .query(`
        SELECT
          eb.id,
          b.name AS label,
          eb.quantity,
          eb.unitLabelSnapshot AS unitLabel,
          eb.unitPriceSnapshot AS unitPrice,
          (eb.quantity * eb.unitPriceSnapshot) AS total
        FROM dbo.EventBundles eb
        JOIN dbo.Bundles b ON b.id = eb.bundleId
        WHERE eb.eventId = @eventId;
      `);
    (bundlesR.recordset || []).forEach((x) => {
      items.push({ kind: "bundle", label: `Pack — ${x.label}`, quantity: Number(x.quantity || 1), unitLabel: x.unitLabel || "forfait", unitPrice: Number(x.unitPrice || 0), total: Number(x.total || 0) });
    });

    if (!items.length) {
      const e = new Error("Aucun item lié à cet événement (salle / services / packs).");
      e.status = 400;
      throw e;
    }

    const subtotal = items.reduce((s, it) => s + Number(it.total || 0), 0);
    const taxRate = Number(settings.taxRate || 0);
    const taxAmount = Math.round(subtotal * (taxRate / 100) * 100) / 100;
    const total = Math.round((subtotal + taxAmount) * 100) / 100;

    // 3) Create invoiceNumber (INV-YYYY-###)
    const year = new Date().getUTCFullYear();
    const maxR = await new sql.Request(tx).input("prefix", sql.NVarChar, `INV-${year}-%`).query(`
      SELECT ISNULL(MAX(CAST(RIGHT(invoiceNumber, 3) AS INT)), 0) AS maxN
      FROM dbo.Invoices WITH (UPDLOCK, HOLDLOCK)
      WHERE invoiceNumber LIKE @prefix;
    `);
    const nextN = Number(maxR.recordset?.[0]?.maxN || 0) + 1;
    const invoiceNumber = `INV-${year}-${String(nextN).padStart(3, "0")}`;

    // 4) dueAt
    const dueAtCoerced = coerceDateOrNull(dueAt);
    const delayDays = Number(settings.paymentDelayDays || 30);

    const createdR = await new sql.Request(tx)
      .input("invoiceNumber", sql.NVarChar, invoiceNumber)
      .input("eventId", sql.UniqueIdentifier, eventId)
      .input("clientName", sql.NVarChar, clientName || null)
      .input("subtotal", sql.Decimal(12, 2), subtotal)
      .input("taxRate", sql.Decimal(5, 2), taxRate)
      .input("taxAmount", sql.Decimal(12, 2), taxAmount)
      .input("total", sql.Decimal(12, 2), total)
      .input("dueAt", sql.DateTime2, dueAtCoerced)
      .input("delayDays", sql.Int, delayDays)
      .query(`
        INSERT INTO dbo.Invoices (id, invoiceNumber, eventId, clientName, subtotal, taxRate, taxAmount, amount, status, issuedAt, dueAt)
        OUTPUT inserted.id, inserted.invoiceNumber
        VALUES (
          NEWID(),
          @invoiceNumber,
          @eventId,
          @clientName,
          @subtotal,
          @taxRate,
          @taxAmount,
          @total,
          'pending',
          SYSUTCDATETIME(),
          COALESCE(@dueAt, DATEADD(day, @delayDays, SYSUTCDATETIME()))
        );
      `);
    const inv = createdR.recordset?.[0];

    // 5) Insert invoice items snapshot
    for (const it of items) {
      await new sql.Request(tx)
        .input("invoiceId", sql.UniqueIdentifier, inv.id)
        .input("kind", sql.NVarChar, it.kind)
        .input("label", sql.NVarChar, it.label)
        .input("quantity", sql.Decimal(12, 2), it.quantity)
        .input("unitLabel", sql.NVarChar, it.unitLabel)
        .input("unitPrice", sql.Decimal(12, 2), it.unitPrice)
        .input("total", sql.Decimal(12, 2), it.total)
        .query(`
          INSERT INTO dbo.InvoiceItems (id, invoiceId, kind, label, quantity, unitLabel, unitPrice, total, createdAt)
          VALUES (NEWID(), @invoiceId, @kind, @label, @quantity, @unitLabel, @unitPrice, @total, SYSUTCDATETIME());
        `);
    }

    await tx.commit();
    return { guid: inv.id, invoiceNumber: inv.invoiceNumber };
  } catch (e) {
    try {
      await tx.rollback();
    } catch {}
    throw e;
  }
}

// -------------------- Payments / Refunds --------------------

async function recomputeInvoiceStatus(pool, invoiceId) {
  await pool
    .request()
    .input("invoiceId", sql.UniqueIdentifier, invoiceId)
    .query(`
      ;WITH Paid AS (
        SELECT invoiceId, SUM(amount) AS paid
        FROM dbo.Payments
        WHERE invoiceId = @invoiceId
        GROUP BY invoiceId
      ), Ref AS (
        SELECT invoiceId, SUM(amount) AS refunded
        FROM dbo.Refunds
        WHERE invoiceId = @invoiceId
        GROUP BY invoiceId
      )
      UPDATE i
      SET
        paidAt = CASE WHEN (i.amount - ISNULL(p.paid,0) + ISNULL(r.refunded,0)) <= 0 THEN SYSUTCDATETIME() ELSE NULL END,
        status = CASE
          WHEN (i.amount - ISNULL(p.paid,0) + ISNULL(r.refunded,0)) <= 0 THEN 'paid'
          WHEN i.dueAt < SYSUTCDATETIME() THEN 'late'
          ELSE 'pending'
        END
      FROM dbo.Invoices i
      LEFT JOIN Paid p ON p.invoiceId = i.id
      LEFT JOIN Ref r ON r.invoiceId = i.id
      WHERE i.id = @invoiceId;
    `);
}

async function createPayment(invoiceId, { amount, method, provider, reference, paidAt }) {
  const pool = await getPool();
  await pool
    .request()
    .input("invoiceId", sql.UniqueIdentifier, invoiceId)
    .input("amount", sql.Decimal(12, 2), amount)
    .input("method", sql.NVarChar, method)
    .input("provider", sql.NVarChar, provider || "manual")
    .input("reference", sql.NVarChar, reference)
    .input("paidAt", sql.DateTime2, coerceDateOrNull(paidAt))
    .query(`
      INSERT INTO dbo.Payments (id, invoiceId, amount, method, provider, reference, paidAt)
      VALUES (NEWID(), @invoiceId, @amount, @method, @provider, @reference, COALESCE(@paidAt, SYSUTCDATETIME()));
    `);

  await recomputeInvoiceStatus(pool, invoiceId);
  return { success: true };
}

async function createRefund(invoiceId, { amount, reason, status }) {
  const pool = await getPool();
  await pool
    .request()
    .input("invoiceId", sql.UniqueIdentifier, invoiceId)
    .input("amount", sql.Decimal(12, 2), amount)
    .input("reason", sql.NVarChar, reason)
    .input("status", sql.NVarChar, status || "processed")
    .query(`
      INSERT INTO dbo.Refunds (id, invoiceId, amount, reason, status, createdAt)
      VALUES (NEWID(), @invoiceId, @amount, @reason, @status, SYSUTCDATETIME());
    `);

  await recomputeInvoiceStatus(pool, invoiceId);
  return { success: true };
}

// -------------------- Online payment (mock sessions) --------------------

async function createOnlineCheckout(invoiceId, { amount } = {}) {
  const pool = await getPool();
  const settings = await getSettings(pool);
  if (!settings.onlinePaymentEnabled) {
    const e = new Error("Paiement en ligne désactivé dans Paramètres.");
    e.status = 400;
    throw e;
  }

  // determine remaining balance
  const det = await getInvoiceDetails(invoiceId);
  if (!det) {
    const e = new Error("Facture introuvable.");
    e.status = 404;
    throw e;
  }
  const remaining = Number(det.balance || 0);
  if (remaining <= 0) {
    const e = new Error("La facture est déjà réglée.");
    e.status = 400;
    throw e;
  }

  const chargeAmount = amount ? Math.min(Number(amount), remaining) : remaining;

  const insertR = await pool.request().input("invoiceId", sql.UniqueIdentifier, invoiceId).input("amount", sql.Decimal(12, 2), chargeAmount).query(`
    DECLARE @id UNIQUEIDENTIFIER = NEWID();
    INSERT INTO dbo.OnlinePaymentSessions (id, invoiceId, amount, provider, status, createdAt)
    VALUES (@id, @invoiceId, @amount, 'mock', 'created', SYSUTCDATETIME());
    SELECT @id AS sessionId;
  `);

  const sessionId = insertR.recordset?.[0]?.sessionId;

  // paymentUrl = à brancher sur le frontend (page de paiement)
  return {
    sessionId,
    provider: "mock",
    amount: chargeAmount,
    currency: "CAD",
    paymentUrl: `http://localhost:5173/pay/${sessionId}`,
  };
}

async function confirmOnlineCheckout(sessionId) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin(sql.ISOLATION_LEVEL.SERIALIZABLE);

  try {
    const sessionR = await new sql.Request(tx)
      .input("id", sql.UniqueIdentifier, sessionId)
      .query(`
        SELECT TOP 1 id, invoiceId, amount, status
        FROM dbo.OnlinePaymentSessions WITH (UPDLOCK, HOLDLOCK)
        WHERE id = @id;
      `);
    const sess = sessionR.recordset?.[0];
    if (!sess) {
      const e = new Error("Session introuvable.");
      e.status = 404;
      throw e;
    }
    if (sess.status === "succeeded") {
      await tx.commit();
      return { success: true, alreadySucceeded: true };
    }

    // Mark session succeeded
    await new sql.Request(tx)
      .input("id", sql.UniqueIdentifier, sessionId)
      .query(`UPDATE dbo.OnlinePaymentSessions SET status='succeeded', completedAt=SYSUTCDATETIME() WHERE id=@id;`);

    // Create payment
    await new sql.Request(tx)
      .input("invoiceId", sql.UniqueIdentifier, sess.invoiceId)
      .input("amount", sql.Decimal(12, 2), sess.amount)
      .input("reference", sql.NVarChar, String(sessionId))
      .query(`
        INSERT INTO dbo.Payments (id, invoiceId, amount, method, provider, reference, paidAt)
        VALUES (NEWID(), @invoiceId, @amount, 'Paiement en ligne', 'mock', @reference, SYSUTCDATETIME());
      `);

    // Recompute status
    await recomputeInvoiceStatus(pool, sess.invoiceId);

    await tx.commit();
    return { success: true, invoiceId: sess.invoiceId };
  } catch (e) {
    try {
      await tx.rollback();
    } catch {}
    throw e;
  }
}

// -------------------- PDF data --------------------

async function getInvoiceForPdf(invoiceId) {
  const pool = await getPool();
  const settings = await getSettings(pool);
  const det = await getInvoiceDetails(invoiceId);
  if (!det) return null;

  return {
    hotelName: settings.hotelName,
    hotelEmail: settings.email,
    hotelAddress: settings.address,
    hotelPhone: settings.phone,
    invoiceNumber: det.invoiceNumber,
    clientName: det.clientName,
    eventName: det.eventName,
    issuedAt: det.issuedAt,
    dueAt: det.dueAt,
    subtotal: det.subtotal,
    taxRate: det.taxRate,
    taxAmount: det.taxAmount,
    total: det.total,
    totalPaid: det.totalPaid,
    balance: det.balance,
    items: det.items,
    payments: det.payments,
  };
}

async function getReceiptForPdf(invoiceId) {
  const pool = await getPool();
  const settings = await getSettings(pool);

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, invoiceId)
    .query(`
      SELECT TOP 1
        i.invoiceNumber, i.clientName,
        p.amount, p.method, p.reference, p.paidAt
      FROM dbo.Invoices i
      JOIN dbo.Payments p ON p.invoiceId = i.id
      WHERE i.id = @id
      ORDER BY p.paidAt DESC;
    `);

  const row = r.recordset?.[0];
  if (!row) return null;

  return {
    hotelName: settings.hotelName,
    invoiceNumber: row.invoiceNumber,
    clientName: row.clientName,
    amount: Number(row.amount || 0),
    method: row.method,
    reference: row.reference,
    paidAt: row.paidAt,
  };
}

module.exports = {
  getStats,
  listInvoices,
  listPayments,
  listRefunds,
  getInvoiceDetails,
  generateInvoiceForEvent,
  createPayment,
  createRefund,
  createOnlineCheckout,
  confirmOnlineCheckout,
  getInvoiceForPdf,
  getReceiptForPdf,
};
