// src/repositories/admin/notifications.repo.js
const { getPool, sql } = require("../../config/db");

async function list({ unreadOnly, limit, recipientUserId }) {
  const pool = await getPool();
  const req = pool.request().input("limit", sql.Int, limit);

  const where = [];
  if (unreadOnly) where.push("n.isRead = 0");
  if (recipientUserId) {
    req.input("recipientUserId", sql.UniqueIdentifier, recipientUserId);
    where.push("(n.recipientUserId = @recipientUserId OR n.recipientUserId IS NULL)");
  }

  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

  const r = await req.query(`
    SELECT TOP (@limit)
      n.id, n.type, n.priority, n.title, n.message, n.isRead, n.relatedEntity, n.relatedId, n.recipientUserId, n.createdAt
    FROM dbo.Notifications n
    ${whereSql}
    ORDER BY n.isRead ASC, n.createdAt DESC
  `);

  return r.recordset || [];
}

async function getStats({ recipientUserId }) {
  const pool = await getPool();
  const req = pool.request();
  let where = "";
  if (recipientUserId) {
    req.input("recipientUserId", sql.UniqueIdentifier, recipientUserId);
    where = "WHERE recipientUserId = @recipientUserId OR recipientUserId IS NULL";
  }

  const statsR = await req.query(`
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN isRead = 0 THEN 1 ELSE 0 END) AS unread,
      SUM(CASE WHEN priority = 'urgent' THEN 1 ELSE 0 END) AS highPriority
    FROM dbo.Notifications
    ${where}
  `);

  const settingsR = await pool.request().query(`
    SELECT TOP 1
      notifEvents, notifPayments, notifSignup, notifSystem
    FROM dbo.AdminSettings
    ORDER BY id ASC
  `);

  const s = settingsR.recordset?.[0] || {};
  const x = statsR.recordset?.[0] || { total: 0, unread: 0, highPriority: 0 };

  return {
    total: Number(x.total || 0),
    unread: Number(x.unread || 0),
    highPriority: Number(x.highPriority || 0),
    emailEnabled: !!(s.notifEvents || s.notifPayments || s.notifSignup || s.notifSystem),
  };
}

async function markRead({ id }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      UPDATE dbo.Notifications
      SET isRead = 1
      OUTPUT INSERTED.id, INSERTED.isRead
      WHERE id = @id
    `);

  return r.recordset?.[0] || null;
}

async function markAllRead({ recipientUserId }) {
  const pool = await getPool();
  const req = pool.request();
  let where = "WHERE isRead = 0";
  if (recipientUserId) {
    req.input("recipientUserId", sql.UniqueIdentifier, recipientUserId);
    where += " AND (recipientUserId = @recipientUserId OR recipientUserId IS NULL)";
  }
  await req.query(`
    UPDATE dbo.Notifications
    SET isRead = 1
    ${where}
  `);
}

async function remove({ id }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      DELETE FROM dbo.Notifications
      OUTPUT DELETED.id
      WHERE id = @id
    `);

  return r.recordset?.[0]?.id || null;
}

async function create(data) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("recipientUserId", sql.UniqueIdentifier, data.recipientUserId || null)
    .input("type", sql.VarChar(20), data.type)
    .input("priority", sql.VarChar(10), data.priority)
    .input("title", sql.NVarChar(160), data.title)
    .input("message", sql.NVarChar(600), data.message)
    .input("relatedEntity", sql.VarChar(30), data.relatedEntity)
    .input("relatedId", sql.UniqueIdentifier, data.relatedId)
    .query(`
      INSERT INTO dbo.Notifications (id, recipientUserId, type, priority, title, message, relatedEntity, relatedId, isRead, createdAt)
      OUTPUT INSERTED.id, INSERTED.type, INSERTED.priority, INSERTED.title, INSERTED.message,
             INSERTED.isRead, INSERTED.relatedEntity, INSERTED.relatedId, INSERTED.recipientUserId, INSERTED.createdAt
      VALUES (NEWID(), @recipientUserId, @type, @priority, @title, @message, @relatedEntity, @relatedId, 0, SYSUTCDATETIME())
    `);

  return r.recordset[0];
}

module.exports = { list, getStats, markRead, markAllRead, remove, create };
