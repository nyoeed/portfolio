// src/repositories/admin/bundles.repo.js
const { getPool, sql } = require("../../config/db");

async function listWithServices() {
  const pool = await getPool();

  const bundlesR = await pool.request().query(`
    SELECT id, name, description, unitLabel, price, availability, createdAt
    FROM dbo.Bundles
    ORDER BY createdAt DESC;
  `);

  const itemsR = await pool.request().query(`
    SELECT bi.bundleId, s.id AS serviceId, s.name AS serviceName
    FROM dbo.BundleItems bi
    JOIN dbo.Services s ON s.id = bi.serviceId;
  `);

  const itemsByBundle = new Map();
  for (const row of itemsR.recordset || []) {
    const arr = itemsByBundle.get(row.bundleId) || [];
    arr.push({ id: row.serviceId, name: row.serviceName });
    itemsByBundle.set(row.bundleId, arr);
  }

  return (bundlesR.recordset || []).map((b) => ({
    ...b,
    services: itemsByBundle.get(b.id) || [],
  }));
}

async function createBundleAndItems(data) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);

  await tx.begin();
  try {
    const bundleR = await new sql.Request(tx)
      .input("name", sql.NVarChar, data.name)
      .input("description", sql.NVarChar, data.description)
      .input("unitLabel", sql.NVarChar, data.unitLabel)
      .input("price", sql.Decimal(10, 2), data.price)
      .input("availability", sql.VarChar, data.availability)
      .query(`
        INSERT INTO dbo.Bundles (id, name, description, unitLabel, price, availability, createdAt)
        OUTPUT inserted.*
        VALUES (NEWID(), @name, @description, @unitLabel, @price, @availability, SYSUTCDATETIME());
      `);

    const bundle = bundleR.recordset[0];

    for (const sid of data.serviceIds || []) {
      await new sql.Request(tx)
        .input("bundleId", sql.UniqueIdentifier, bundle.id)
        .input("serviceId", sql.UniqueIdentifier, sid)
        .query(`
          INSERT INTO dbo.BundleItems (id, bundleId, serviceId)
          VALUES (NEWID(), @bundleId, @serviceId);
        `);
    }

    await tx.commit();

    const itemsR = await pool
      .request()
      .input("bundleId", sql.UniqueIdentifier, bundle.id)
      .query(`
        SELECT s.id, s.name
        FROM dbo.BundleItems bi
        JOIN dbo.Services s ON s.id = bi.serviceId
        WHERE bi.bundleId = @bundleId;
      `);

    return { ...bundle, services: itemsR.recordset || [] };
  } catch (e) {
    await tx.rollback();
    throw e;
  }
}

async function updateBundleAndMaybeItems(data) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);

  await tx.begin();
  try {
    const updR = await new sql.Request(tx)
      .input("id", sql.UniqueIdentifier, data.id)
      .input("name", sql.NVarChar, data.name)
      .input("description", sql.NVarChar, data.description)
      .input("unitLabel", sql.NVarChar, data.unitLabel)
      .input("price", sql.Decimal(10, 2), data.price)
      .input("availability", sql.VarChar, data.availability)
      .query(`
        UPDATE dbo.Bundles
        SET
          name = COALESCE(@name, name),
          description = COALESCE(@description, description),
          unitLabel = COALESCE(@unitLabel, unitLabel),
          price = COALESCE(@price, price),
          availability = COALESCE(@availability, availability)
        OUTPUT inserted.*
        WHERE id = @id;
      `);

    if (!updR.recordset.length) {
      await tx.rollback();
      return null;
    }

    const bundle = updR.recordset[0];

    if (Array.isArray(data.serviceIds)) {
      await new sql.Request(tx)
        .input("bundleId", sql.UniqueIdentifier, data.id)
        .query(`DELETE FROM dbo.BundleItems WHERE bundleId = @bundleId;`);

      for (const sid of data.serviceIds) {
        await new sql.Request(tx)
          .input("bundleId", sql.UniqueIdentifier, data.id)
          .input("serviceId", sql.UniqueIdentifier, sid)
          .query(`
            INSERT INTO dbo.BundleItems (id, bundleId, serviceId)
            VALUES (NEWID(), @bundleId, @serviceId);
          `);
      }
    }

    await tx.commit();

    const itemsR = await pool
      .request()
      .input("bundleId", sql.UniqueIdentifier, data.id)
      .query(`
        SELECT s.id, s.name
        FROM dbo.BundleItems bi
        JOIN dbo.Services s ON s.id = bi.serviceId
        WHERE bi.bundleId = @bundleId;
      `);

    return { ...bundle, services: itemsR.recordset || [] };
  } catch (e) {
    await tx.rollback();
    throw e;
  }
}

async function remove({ id }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      DELETE FROM dbo.Bundles WHERE id = @id;
      SELECT @@ROWCOUNT AS affectedRows;
    `);

  const affected = r.recordset?.[0]?.affectedRows ?? 0;
  return affected > 0;
}

module.exports = { listWithServices, createBundleAndItems, updateBundleAndMaybeItems, remove };