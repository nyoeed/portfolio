// src/repositories/admin/services.repo.js
const { getPool, sql } = require("../../config/db");

async function getStats() {
  const pool = await getPool();

  const totalQ = pool.request().query(`SELECT COUNT(*) AS total FROM dbo.Services;`);
  const catQ = pool.request().query(`
    SELECT category, COUNT(*) AS count
    FROM dbo.Services
    GROUP BY category
    ORDER BY COUNT(*) DESC;
  `);

  const [t, c] = await Promise.all([totalQ, catQ]);

  return {
    total: Number(t.recordset?.[0]?.total || 0),
    byCategory: c.recordset || [],
  };
}

async function list({ category }) {
  const pool = await getPool();
  const request = pool.request();

  let where = "WHERE 1=1";
  if (category) {
    where += " AND category = @category";
    request.input("category", sql.NVarChar, category);
  }

  const r = await request.query(`
    SELECT id, name, category, description, unitLabel, price, availability, imageUrl, createdAt
    FROM dbo.Services
    ${where}
    ORDER BY createdAt DESC;
  `);

  return r.recordset || [];
}

async function create(data) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("name", sql.NVarChar, data.name)
    .input("category", sql.NVarChar, data.category)
    .input("description", sql.NVarChar, data.description)
    .input("unitLabel", sql.NVarChar, data.unitLabel)
    .input("price", sql.Decimal(10, 2), data.price)
    .input("availability", sql.VarChar, data.availability)
    .input("imageUrl", sql.NVarChar, data.imageUrl)
    .query(`
      INSERT INTO dbo.Services (id, name, category, description, unitLabel, price, availability, imageUrl, createdAt)
      OUTPUT inserted.*
      VALUES (NEWID(), @name, @category, @description, @unitLabel, @price, @availability, @imageUrl, SYSUTCDATETIME());
    `);

  return r.recordset[0];
}

async function update(data) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, data.id)
    .input("name", sql.NVarChar, data.name)
    .input("category", sql.NVarChar, data.category)
    .input("description", sql.NVarChar, data.description)
    .input("unitLabel", sql.NVarChar, data.unitLabel)
    .input("price", sql.Decimal(10, 2), data.price)
    .input("availability", sql.VarChar, data.availability)
    .input("imageUrl", sql.NVarChar, data.imageUrl)
    .query(`
      UPDATE dbo.Services
      SET
        name = COALESCE(@name, name),
        category = COALESCE(@category, category),
        description = COALESCE(@description, description),
        unitLabel = COALESCE(@unitLabel, unitLabel),
        price = COALESCE(@price, price),
        availability = COALESCE(@availability, availability),
        imageUrl = COALESCE(@imageUrl, imageUrl)
      OUTPUT inserted.*
      WHERE id = @id;
    `);

  return r.recordset?.[0] || null;
}

async function remove({ id }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      DELETE FROM dbo.Services WHERE id = @id;
      SELECT @@ROWCOUNT AS affectedRows;
    `);

  const affected = r.recordset?.[0]?.affectedRows ?? 0;
  return affected > 0;
}

module.exports = { getStats, list, create, update, remove };