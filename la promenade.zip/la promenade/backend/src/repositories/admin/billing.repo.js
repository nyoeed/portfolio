// src/repositories/admin/billing.repo.js
const { getPool } = require("../../config/db");

async function getSummary() {
  const pool = await getPool();
  const r = await pool.request().query(`
    SELECT
      SUM(CASE WHEN status='paid' THEN total ELSE 0 END) AS totalPaid,
      SUM(CASE WHEN status='pending' THEN total ELSE 0 END) AS totalPending,
      SUM(CASE WHEN status='overdue' THEN total ELSE 0 END) AS totalOverdue,

      -- ✅ seulement les factures du mois courant (selon issueDate)
      SUM(CASE 
            WHEN issueDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
             AND issueDate <  DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
            THEN 1 ELSE 0 
          END) AS totalInvoicesThisMonth
    FROM dbo.Invoices;
  `);

  const row = r.recordset[0] || {};
  return {
    totalPaid: Number(row.totalPaid || 0),
    totalPending: Number(row.totalPending || 0),
    totalOverdue: Number(row.totalOverdue || 0),
    totalInvoicesThisMonth: Number(row.totalInvoicesThisMonth || 0),
  };
}

async function listInvoices({ q, status, from, to }) {
  const pool = await getPool();
  const req = pool.request();

  req.input("q", `%${(q || "").trim()}%`);
  req.input("status", (status || "").trim());
  req.input("from", from || null);
  req.input("to", to || null);

  const result = await req.query(`
    SELECT
      id,
      invoiceNumber AS number,
      eventName,
      clientName,
      issueDate AS date,
      dueDate,
      total AS amount,
      status
    FROM dbo.Invoices
    WHERE
      (@status = '' OR status = @status)
      AND (
        @q = '%%'
        OR invoiceNumber LIKE @q
        OR clientName LIKE @q
        OR eventName LIKE @q
      )
      AND (@from IS NULL OR issueDate >= @from)
      AND (@to   IS NULL OR issueDate <= @to)
    ORDER BY issueDate DESC, id DESC;
  `);

  return result.recordset;
}

async function listPayments({ q, from, to }) {
  const pool = await getPool();
  const req = pool.request();

  req.input("q", `%${(q || "").trim()}%`);
  req.input("from", from || null);
  req.input("to", to || null);

  const result = await req.query(`
    SELECT
      p.id,
      i.invoiceNumber AS invoiceNumber,
      i.clientName AS clientName,
      p.amount,
      p.paidAt,
      p.method
    FROM dbo.Payments p
    JOIN dbo.Invoices i ON i.id = p.invoiceId
    WHERE
      (
        @q = '%%'
        OR i.invoiceNumber LIKE @q
        OR i.clientName LIKE @q
        OR p.method LIKE @q
      )
      AND (@from IS NULL OR p.paidAt >= @from)
      AND (@to   IS NULL OR p.paidAt <= @to)
    ORDER BY p.paidAt DESC, p.id DESC;
  `);

  return result.recordset;
}

async function listRefunds({ q, from, to }) {
  const pool = await getPool();
  const req = pool.request();

  req.input("q", `%${(q || "").trim()}%`);
  req.input("from", from || null);
  req.input("to", to || null);

  const result = await req.query(`
    SELECT
      r.id,
      i.invoiceNumber AS invoiceNumber,
      i.clientName AS clientName,
      r.amount,
      r.refundDate AS date,
      r.reason,
      r.status
    FROM dbo.Refunds r
    JOIN dbo.Invoices i ON i.id = r.invoiceId
    WHERE
      (
        @q = '%%'
        OR i.invoiceNumber LIKE @q
        OR i.clientName LIKE @q
        OR r.reason LIKE @q
      )
      AND (@from IS NULL OR r.refundDate >= @from)
      AND (@to   IS NULL OR r.refundDate <= @to)
    ORDER BY r.refundDate DESC, r.id DESC;
  `);

  return result.recordset;
}

async function createRefund({ invoiceNumber, amount, refundDate, reason, status }) {
  const pool = await getPool();

  const invR = await pool
    .request()
    .input("invoiceNumber", invoiceNumber)
    .query(`SELECT TOP 1 id, invoiceNumber, clientName FROM dbo.Invoices WHERE invoiceNumber=@invoiceNumber;`);

  const inv = invR.recordset[0];
  if (!inv) {
    const err = new Error("Facture introuvable");
    err.statusCode = 404;
    throw err;
  }

  const r = await pool
    .request()
    .input("invoiceId", inv.id)
    .input("amount", amount)
    .input("refundDate", refundDate)
    .input("reason", reason)
    .input("status", status)
    .query(`
      INSERT INTO dbo.Refunds (invoiceId, amount, refundDate, reason, status)
      OUTPUT INSERTED.id
      VALUES (@invoiceId, @amount, @refundDate, @reason, @status);
    `);

  const id = r.recordset[0]?.id;

  return {
    id,
    invoiceNumber: inv.invoiceNumber,
    clientName: inv.clientName,
    amount,
    date: refundDate,
    reason,
    status,
  };
}

async function getInvoiceById(id) {
  const pool = await getPool();
  const r = await pool.request().input("id", id).query(`
    SELECT TOP 1 id, invoiceNumber, eventName, clientName, issueDate, dueDate, subtotal, taxRate, total, status
    FROM dbo.Invoices
    WHERE id=@id;
  `);
  return r.recordset[0] || null;
}

module.exports = {
  getSummary,
  listInvoices,
  listPayments,
  listRefunds,
  createRefund,
  getInvoiceById,
};