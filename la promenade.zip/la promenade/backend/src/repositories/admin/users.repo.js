// src/repositories/admin/users.repo.js
const { getPool, sql } = require("../../config/db");

async function listPending() {
  const pool = await getPool();
  const result = await pool.request().query(`
    SELECT id, fullName, email, roleRequested, status, createdAt
    FROM dbo.Users
    WHERE status = 'pending'
    ORDER BY createdAt DESC
  `);
  return result.recordset || [];
}

async function approveRequest({ id }) {
  const pool = await getPool();
  const result = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      UPDATE dbo.Users
      SET status = 'approved',
          role = roleRequested,
          roleRequested = NULL
      WHERE id = @id AND status = 'pending';

      SELECT @@ROWCOUNT AS affectedRows;
    `);

  return (result.recordset?.[0]?.affectedRows ?? 0) > 0;
}

async function rejectRequest({ id }) {
  const pool = await getPool();
  const result = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      UPDATE dbo.Users
      SET status = 'rejected'
      WHERE id = @id AND status = 'pending';

      SELECT @@ROWCOUNT AS affectedRows;
    `);

  return (result.recordset?.[0]?.affectedRows ?? 0) > 0;
}

async function listUsers({ search, role, status }) {
  const pool = await getPool();

  const request = pool.request();
  let where = "WHERE 1=1";

  if (search) {
    where += " AND (fullName LIKE @search OR email LIKE @search)";
    request.input("search", sql.NVarChar, `%${search}%`);
  }
  if (role) {
    where += " AND role = @role";
    request.input("role", sql.VarChar, role);
  }
  if (status) {
    where += " AND status = @status";
    request.input("status", sql.VarChar, status);
  }

  const result = await request.query(`
    SELECT id, fullName, email, role, status, createdAt, lastLoginAt
    FROM dbo.Users
    ${where}
    ORDER BY createdAt DESC
  `);

  return result.recordset || [];
}

async function existsByEmail({ email }) {
  const pool = await getPool();
  const exists = await pool
    .request()
    .input("email", sql.VarChar, email)
    .query(`SELECT TOP 1 id FROM dbo.Users WHERE email = @email`);
  return !!exists.recordset.length;
}

async function createUser({ fullName, email, passwordHash, role }) {
  const pool = await getPool();

  const result = await pool
    .request()
    .input("fullName", sql.NVarChar, fullName)
    .input("email", sql.VarChar, email)
    .input("passwordHash", sql.NVarChar, passwordHash)
    .input("role", sql.VarChar, role)
    .query(`
      INSERT INTO dbo.Users (id, fullName, email, passwordHash, role, status, createdAt)
      OUTPUT inserted.id, inserted.fullName, inserted.email, inserted.role, inserted.status, inserted.createdAt, inserted.lastLoginAt
      VALUES (NEWID(), @fullName, @email, @passwordHash, @role, 'approved', SYSUTCDATETIME());
    `);

  return result.recordset[0];
}

async function countAll() {
  const pool = await getPool();
  const r = await pool.request().query(`SELECT COUNT(*) AS total FROM dbo.Users;`);
  return Number(r.recordset?.[0]?.total || 0);
}

async function updateUserStatus({ id, status }) {
  const pool = await getPool();
  const result = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .input("status", sql.VarChar, status)
    .query(`
      UPDATE dbo.Users
      SET status = @status
      WHERE id = @id;

      SELECT @@ROWCOUNT AS affectedRows;
    `);

  return (result.recordset?.[0]?.affectedRows ?? 0) > 0;
}

async function updateUserRole({ id, role }) {
  const pool = await getPool();
  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .input("role", sql.VarChar, role)
    .query(`
      UPDATE dbo.Users
      SET role = @role
      OUTPUT inserted.id, inserted.fullName, inserted.email, inserted.role, inserted.status, inserted.createdAt, inserted.lastLoginAt
      WHERE id = @id;
    `);

  return r.recordset?.[0] || null;
}

async function emailTakenByAnotherUser({ id, email }) {
  const pool = await getPool();
  const exists = await pool
    .request()
    .input("email", sql.VarChar, email)
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      SELECT TOP 1 id
      FROM dbo.Users
      WHERE email = @email AND id <> @id;
    `);

  return !!exists.recordset.length;
}

async function updateUser({ id, fullName, email, role }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .input("fullName", sql.NVarChar, fullName)
    .input("email", sql.VarChar, email)
    .input("role", sql.VarChar, role)
    .query(`
      UPDATE dbo.Users
      SET fullName = @fullName,
          email = @email,
          role = @role
      OUTPUT inserted.id, inserted.fullName, inserted.email, inserted.role,
             inserted.status, inserted.createdAt, inserted.lastLoginAt
      WHERE id = @id;
    `);

  return r.recordset?.[0] || null;
}

async function deleteUser({ id }) {
  const pool = await getPool();

  const result = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      DELETE FROM dbo.Users
      WHERE id = @id;

      SELECT @@ROWCOUNT AS affectedRows;
    `);

  return (result.recordset?.[0]?.affectedRows ?? 0) > 0;
}

module.exports = {
  listPending,
  approveRequest,
  rejectRequest,
  listUsers,
  existsByEmail,
  createUser,
  countAll,
  updateUserStatus,
  updateUserRole,
  emailTakenByAnotherUser,
  updateUser,
  deleteUser,
};