// src/repositories/admin/settings.repo.js
const { getPool, sql } = require("../../config/db");

async function getFirst() {
  const pool = await getPool();
  const r = await pool.request().query(`
    SELECT TOP 1
      id,
      hotelName, email, address, phone, website,
      taxRate, paymentDelayDays, onlinePaymentEnabled,
      notifEvents, notifPayments, notifSignup, notifSystem, dailySummaryEnabled,
      updatedAt, createdAt
    FROM dbo.AdminSettings
    ORDER BY id ASC
  `);

  return r.recordset?.[0] || null;
}

async function upsertOne(data) {
  const pool = await getPool();

  const exists = await pool
    .request()
    .query(`SELECT TOP 1 id FROM dbo.AdminSettings ORDER BY id ASC`);

  // INSERT si aucune ligne
  if (!exists.recordset.length) {
    const ins = await pool
      .request()
      .input("hotelName", sql.NVarChar(120), data.hotelName)
      .input("email", sql.NVarChar(120), data.email)
      .input("address", sql.NVarChar(200), data.address)
      .input("phone", sql.NVarChar(40), data.phone)
      .input("website", sql.NVarChar(200), data.website)
      .input("taxRate", sql.Decimal(5, 2), data.taxRate)
      .input("paymentDelayDays", sql.Int, data.paymentDelayDays)
      .input("onlinePaymentEnabled", sql.Bit, data.onlinePaymentEnabled)
      .input("notifEvents", sql.Bit, data.notifEvents)
      .input("notifPayments", sql.Bit, data.notifPayments)
      .input("notifSignup", sql.Bit, data.notifSignup)
      .input("notifSystem", sql.Bit, data.notifSystem)
      .input("dailySummaryEnabled", sql.Bit, data.dailySummaryEnabled)
      .query(`
        INSERT INTO dbo.AdminSettings (
          hotelName, email, address, phone, website,
          taxRate, paymentDelayDays, onlinePaymentEnabled,
          notifEvents, notifPayments, notifSignup, notifSystem, dailySummaryEnabled,
          updatedAt
        )
        OUTPUT INSERTED.*
        VALUES (
          @hotelName, @email, @address, @phone, @website,
          @taxRate, @paymentDelayDays, @onlinePaymentEnabled,
          @notifEvents, @notifPayments, @notifSignup, @notifSystem, @dailySummaryEnabled,
          SYSUTCDATETIME()
        )
      `);

    return ins.recordset[0];
  }

  // UPDATE sinon
  const id = exists.recordset[0].id;

  const upd = await pool
    .request()
    .input("id", sql.Int, id)
    .input("hotelName", sql.NVarChar(120), data.hotelName)
    .input("email", sql.NVarChar(120), data.email)
    .input("address", sql.NVarChar(200), data.address)
    .input("phone", sql.NVarChar(40), data.phone)
    .input("website", sql.NVarChar(200), data.website)
    .input("taxRate", sql.Decimal(5, 2), data.taxRate)
    .input("paymentDelayDays", sql.Int, data.paymentDelayDays)
    .input("onlinePaymentEnabled", sql.Bit, data.onlinePaymentEnabled)
    .input("notifEvents", sql.Bit, data.notifEvents)
    .input("notifPayments", sql.Bit, data.notifPayments)
    .input("notifSignup", sql.Bit, data.notifSignup)
    .input("notifSystem", sql.Bit, data.notifSystem)
    .input("dailySummaryEnabled", sql.Bit, data.dailySummaryEnabled)
    .query(`
      UPDATE dbo.AdminSettings
      SET
        hotelName = @hotelName,
        email = @email,
        address = @address,
        phone = @phone,
        website = @website,
        taxRate = @taxRate,
        paymentDelayDays = @paymentDelayDays,
        onlinePaymentEnabled = @onlinePaymentEnabled,
        notifEvents = @notifEvents,
        notifPayments = @notifPayments,
        notifSignup = @notifSignup,
        notifSystem = @notifSystem,
        dailySummaryEnabled = @dailySummaryEnabled,
        updatedAt = SYSUTCDATETIME()
      OUTPUT INSERTED.*
      WHERE id = @id
    `);

  return upd.recordset[0];
}

module.exports = { getFirst, upsertOne };