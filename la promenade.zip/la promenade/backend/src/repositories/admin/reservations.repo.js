// src/repositories/admin/reservations.repo.js
const { getPool, sql } = require("../../config/db");

async function list({ from, to, roomId, status }) {
  const pool = await getPool();
  const request = pool.request();

  let where = "WHERE 1=1";

  if (roomId) {
    where += " AND r.roomId = @roomId";
    request.input("roomId", sql.UniqueIdentifier, roomId);
  }

  if (status) {
    where += " AND r.status = @status";
    request.input("status", sql.VarChar, String(status));
  }

  if (from) {
    where += " AND r.startAt >= @from";
    request.input("from", sql.DateTime2, from);
  }

  if (to) {
    where += " AND r.startAt < @to";
    request.input("to", sql.DateTime2, to);
  }

  const result = await request.query(`
    SELECT
      r.id,
      r.roomId,
      rm.name AS roomName,
      r.title,
      r.startAt,
      r.endAt,
      r.participants,
      r.status,
      r.organizerId,
      u.fullName AS organizerName
    FROM dbo.Reservations r
    JOIN dbo.Rooms rm ON rm.id = r.roomId
    JOIN dbo.Users u ON u.id = r.organizerId
    ${where}
    ORDER BY r.startAt ASC;
  `);

  return result.recordset || [];
}

// SERIALIZABLE + check conflit exactement comme avant
async function createWithConflictCheck({
  roomId,
  organizerId,
  title,
  startAt,
  endAt,
  participants,
  status,
  toIso,
}) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);

  await tx.begin(sql.ISOLATION_LEVEL.SERIALIZABLE);
  try {
    const conflictR = await new sql.Request(tx)
      .input("roomId", sql.UniqueIdentifier, roomId)
      .input("startAt", sql.DateTime2, startAt)
      .input("endAt", sql.DateTime2, endAt)
      .query(`
        SELECT TOP 5
          id, startAt, endAt, title, status
        FROM dbo.Reservations WITH (UPDLOCK, HOLDLOCK)
        WHERE roomId = @roomId
          AND status IN ('pending','confirmed')
          AND (@startAt < endAt AND @endAt > startAt)
        ORDER BY startAt ASC;
      `);

    if (conflictR.recordset?.length) {
      await tx.rollback();

      const err = new Error("Conflit de réservation détecté.");
      err.code = "RESERVATION_CONFLICT";
      err.conflicts = conflictR.recordset.map((x) => ({
        id: x.id,
        title: x.title,
        startAt: toIso(x.startAt),
        endAt: toIso(x.endAt),
        status: x.status,
      }));
      throw err;
    }

    const insertR = await new sql.Request(tx)
      .input("roomId", sql.UniqueIdentifier, roomId)
      .input("organizerId", sql.UniqueIdentifier, organizerId)
      .input("title", sql.NVarChar, title)
      .input("startAt", sql.DateTime2, startAt)
      .input("endAt", sql.DateTime2, endAt)
      .input("participants", sql.Int, participants)
      .input("status", sql.VarChar, status)
      .query(`
        INSERT INTO dbo.Reservations
          (id, roomId, organizerId, title, startAt, endAt, participants, status, createdAt)
        OUTPUT inserted.*
        VALUES
          (NEWID(), @roomId, @organizerId, @title, @startAt, @endAt, @participants, @status, SYSUTCDATETIME());
      `);

    await tx.commit();
    return insertR.recordset[0];
  } catch (e) {
    // si rollback pas encore fait
    try {
      if (tx._aborted !== true) await tx.rollback();
    } catch {}
    throw e;
  }
}

async function updateStatus({ id, status }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .input("status", sql.VarChar, status)
    .query(`
      UPDATE dbo.Reservations
      SET status = @status
      OUTPUT inserted.*
      WHERE id = @id;
    `);

  return r.recordset?.[0] || null;
}

async function remove({ id }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query(`
      DELETE FROM dbo.Reservations WHERE id = @id;
      SELECT @@ROWCOUNT AS affectedRows;
    `);

  const affected = r.recordset?.[0]?.affectedRows ?? 0;
  return affected > 0;
}

module.exports = { list, createWithConflictCheck, updateStatus, remove };