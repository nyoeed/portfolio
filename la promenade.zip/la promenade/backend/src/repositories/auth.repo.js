// src/repositories/auth.repo.js
const { getPool, sql } = require("../config/db");

async function userExistsByEmail({ email }) {
  const pool = await getPool();
  const r = await pool
    .request()
    .input("email", sql.VarChar, email)
    .query("SELECT 1 FROM dbo.Users WHERE email=@email");
  return !!r.recordset.length;
}

async function insertPendingUser({ fullName, email, passwordHash, roleRequested }) {
  const pool = await getPool();

  await pool
    .request()
    .input("fullName", sql.NVarChar, fullName)
    .input("email", sql.VarChar, email)
    .input("passwordHash", sql.NVarChar, passwordHash)
    .input("roleRequested", sql.VarChar, roleRequested)
    .query(`
      INSERT INTO dbo.Users (fullName, email, passwordHash, status, roleRequested, role)
      VALUES (@fullName, @email, @passwordHash, 'pending', @roleRequested, NULL)
    `);
}

async function findUserForLogin({ email }) {
  const pool = await getPool();

  const r = await pool
    .request()
    .input("email", sql.VarChar, email)
    .query(`
      SELECT TOP 1 id, email, fullName, passwordHash, role, status
      FROM dbo.Users
      WHERE email=@email
    `);

  return r.recordset?.[0] || null;
}

async function updateLastLogin({ id }) {
  const pool = await getPool();
  await pool
    .request()
    .input("id", sql.UniqueIdentifier, id)
    .query("UPDATE dbo.Users SET lastLoginAt=SYSUTCDATETIME() WHERE id=@id");
}

async function findUserByEmail({ email }) {
  const pool = await getPool();
  const r = await pool.request().input("email", sql.VarChar, email).query(`
    SELECT TOP 1 id, email, fullName, role, status
    FROM dbo.Users
    WHERE email=@email
  `);
  return r.recordset?.[0] || null;
}

async function updatePasswordById({ id, passwordHash }) {
  const pool = await getPool();
  const r = await pool.request()
    .input("id", sql.UniqueIdentifier, id)
    .input("passwordHash", sql.NVarChar, passwordHash)
    .query(`
      UPDATE dbo.Users
      SET passwordHash=@passwordHash, updatedAt=SYSUTCDATETIME()
      WHERE id=@id;
      SELECT @@ROWCOUNT AS affectedRows;
    `);
  return (r.recordset?.[0]?.affectedRows ?? 0) > 0;
}

async function getUserProfile({ id }) {
  const pool = await getPool();
  const r = await pool.request().input('id', sql.UniqueIdentifier, id).query(`
    SELECT TOP 1
      id, fullName, email, role, status, createdAt, lastLoginAt,
      phone, organization, jobTitle, addressLine, postalCode, city, country,
      notificationEmailEnabled, notificationSmsEnabled, notificationInAppEnabled
    FROM dbo.Users
    WHERE id=@id;
  `);
  return r.recordset?.[0] || null;
}

async function updateUserProfile({ id, data }) {
  const pool = await getPool();
  const normalizedEmail = data.email ? String(data.email).trim() : null;
  if (normalizedEmail) {
    const emailCheck = await pool.request()
      .input('id', sql.UniqueIdentifier, id)
      .input('email', sql.NVarChar, normalizedEmail)
      .query(`SELECT TOP 1 id FROM dbo.Users WHERE email=@email AND id<>@id;`);
    if (emailCheck.recordset?.length) {
      const err = new Error('Email already used');
      err.code = 'EMAIL_EXISTS';
      throw err;
    }
  }

  const result = await pool.request()
    .input('id', sql.UniqueIdentifier, id)
    .input('fullName', sql.NVarChar, data.fullName || null)
    .input('email', sql.NVarChar, normalizedEmail)
    .input('phone', sql.NVarChar, data.phone || null)
    .input('organization', sql.NVarChar, data.organization || null)
    .input('jobTitle', sql.NVarChar, data.jobTitle || null)
    .input('addressLine', sql.NVarChar, data.addressLine || null)
    .input('postalCode', sql.NVarChar, data.postalCode || null)
    .input('city', sql.NVarChar, data.city || null)
    .input('country', sql.NVarChar, data.country || null)
    .input('notificationEmailEnabled', sql.Bit, data.notificationEmailEnabled == null ? 1 : (data.notificationEmailEnabled ? 1 : 0))
    .input('notificationSmsEnabled', sql.Bit, data.notificationSmsEnabled ? 1 : 0)
    .input('notificationInAppEnabled', sql.Bit, data.notificationInAppEnabled == null ? 1 : (data.notificationInAppEnabled ? 1 : 0))
    .query(`
      UPDATE dbo.Users
      SET fullName = COALESCE(@fullName, fullName),
          email = COALESCE(@email, email),
          phone = @phone,
          organization = @organization,
          jobTitle = @jobTitle,
          addressLine = @addressLine,
          postalCode = @postalCode,
          city = @city,
          country = @country,
          notificationEmailEnabled = @notificationEmailEnabled,
          notificationSmsEnabled = @notificationSmsEnabled,
          notificationInAppEnabled = @notificationInAppEnabled
      OUTPUT INSERTED.id, INSERTED.fullName, INSERTED.email, INSERTED.role, INSERTED.status,
             INSERTED.phone, INSERTED.organization, INSERTED.jobTitle, INSERTED.addressLine,
             INSERTED.postalCode, INSERTED.city, INSERTED.country,
             INSERTED.notificationEmailEnabled, INSERTED.notificationSmsEnabled, INSERTED.notificationInAppEnabled
      WHERE id=@id;
    `);
  return result.recordset?.[0] || null;
}

module.exports = { userExistsByEmail, insertPendingUser, findUserForLogin, updateLastLogin, findUserByEmail, updatePasswordById, getUserProfile, updateUserProfile };