const fs = require('fs');
const path = require('path');
const { getPool, sql } = require('../config/db');

function isoDate(value) {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

function toStoredFilePath(filePath) {
  if (!filePath) return null;
  if (filePath.startsWith('/uploads/')) return filePath;
  const normalized = String(filePath).replace(/\\/g, '/');
  const idx = normalized.lastIndexOf('/uploads/');
  if (idx >= 0) return normalized.slice(idx);
  return filePath;
}

function toDiskFilePath(filePath) {
  if (!filePath) return null;
  if (filePath.startsWith('/uploads/')) {
    return path.join(__dirname, '..', '..', filePath.replace(/^\/+/, ''));
  }
  return path.resolve(filePath);
}

async function getEventOwned(pool, userId, eventId, tx = null) {
  const request = tx ? new sql.Request(tx) : pool.request();
  const result = await request
    .input('eventId', sql.UniqueIdentifier, eventId)
    .input('userId', sql.UniqueIdentifier, userId)
    .query(`
      SELECT TOP 1 id, title, startAt, endAt, participants, roomId, status
      FROM dbo.Events
      WHERE id=@eventId AND organizerId=@userId;
    `);
  return result.recordset?.[0] || null;
}

async function validateRoomAvailability(tx, { roomId, startAt, endAt, participants, eventId = null }) {
  if (!roomId) return;

  const roomCheck = await new sql.Request(tx)
    .input('roomId', sql.UniqueIdentifier, roomId)
    .query(`
      SELECT TOP 1 id, name, capacity, status
      FROM dbo.Rooms
      WHERE id=@roomId;
    `);

  const room = roomCheck.recordset?.[0];
  if (!room) {
    const err = new Error('Salle introuvable.');
    err.statusCode = 404;
    throw err;
  }

  if (room.status && room.status !== 'available') {
    const err = new Error('Cette salle n’est pas disponible actuellement.');
    err.statusCode = 409;
    throw err;
  }

  if (participants && room.capacity != null && Number(participants) > Number(room.capacity)) {
    const err = new Error(`La capacité maximale de la salle ${room.name} est de ${room.capacity} personnes.`);
    err.statusCode = 400;
    throw err;
  }

  const conflictRequest = new sql.Request(tx)
    .input('roomId', sql.UniqueIdentifier, roomId)
    .input('startAt', sql.DateTime2, startAt)
    .input('endAt', sql.DateTime2, endAt);

  let conflictWhere = `
    roomId=@roomId
    AND status IN ('pending','locked','confirmed')
    AND startAt < @endAt
    AND endAt > @startAt
  `;
  if (eventId) {
    conflictWhere += ' AND ISNULL(eventId, \'00000000-0000-0000-0000-000000000000\') <> @eventId';
    conflictRequest.input('eventId', sql.UniqueIdentifier, eventId);
  }

  const conflict = await conflictRequest.query(`
    SELECT TOP 1 id, title, startAt, endAt
    FROM dbo.Reservations
    WHERE ${conflictWhere}
    ORDER BY startAt ASC;
  `);

  if (conflict.recordset?.length) {
    const err = new Error('Cette salle est déjà réservée sur ce créneau.');
    err.statusCode = 409;
    throw err;
  }
}

async function syncReservationForEvent(tx, userId, event, submit) {
  if (!event.roomId || !submit) {
    await new sql.Request(tx)
      .input('eventId', sql.UniqueIdentifier, event.id)
      .input('organizerId', sql.UniqueIdentifier, userId)
      .query(`
        UPDATE dbo.Reservations
        SET status='cancelled'
        WHERE eventId=@eventId AND organizerId=@organizerId AND status <> 'cancelled';
      `);
    return;
  }

  await validateRoomAvailability(tx, {
    roomId: event.roomId,
    startAt: event.startAt,
    endAt: event.endAt,
    participants: event.participants,
    eventId: event.id,
  });

  const existing = await new sql.Request(tx)
    .input('eventId', sql.UniqueIdentifier, event.id)
    .input('organizerId', sql.UniqueIdentifier, userId)
    .query(`
      SELECT TOP 1 id
      FROM dbo.Reservations
      WHERE eventId=@eventId AND organizerId=@organizerId
      ORDER BY createdAt DESC;
    `);

  if (existing.recordset?.length) {
    await new sql.Request(tx)
      .input('reservationId', sql.UniqueIdentifier, existing.recordset[0].id)
      .input('roomId', sql.UniqueIdentifier, event.roomId)
      .input('title', sql.NVarChar, event.title)
      .input('startAt', sql.DateTime2, event.startAt)
      .input('endAt', sql.DateTime2, event.endAt)
      .input('participants', sql.Int, Number(event.participants || 0))
      .query(`
        UPDATE dbo.Reservations
        SET roomId=@roomId,
            title=@title,
            startAt=@startAt,
            endAt=@endAt,
            participants=@participants,
            status='pending'
        WHERE id=@reservationId;
      `);
  } else {
    await new sql.Request(tx)
      .input('roomId', sql.UniqueIdentifier, event.roomId)
      .input('organizerId', sql.UniqueIdentifier, userId)
      .input('title', sql.NVarChar, event.title)
      .input('startAt', sql.DateTime2, event.startAt)
      .input('endAt', sql.DateTime2, event.endAt)
      .input('participants', sql.Int, Number(event.participants || 0))
      .input('status', sql.VarChar, 'pending')
      .input('eventId', sql.UniqueIdentifier, event.id)
      .query(`
        INSERT INTO dbo.Reservations (id, roomId, organizerId, title, startAt, endAt, participants, status, createdAt, eventId)
        VALUES (NEWID(), @roomId, @organizerId, @title, @startAt, @endAt, @participants, @status, SYSUTCDATETIME(), @eventId);
      `);
  }
}


async function selectCoordinatorId(tx) {
  const result = await new sql.Request(tx).query(`
    SELECT TOP 1 u.id
    FROM dbo.Users u
    OUTER APPLY (
      SELECT COUNT(*) AS activeEvents
      FROM dbo.Events e
      WHERE e.assignedCoordinatorId = u.id
        AND e.status IN ('submitted','in_review','validated','confirmed','in_coordination','in_progress')
    ) loadInfo
    WHERE u.role = 'coordinator'
      AND u.status = 'approved'
    ORDER BY loadInfo.activeEvents ASC, u.createdAt ASC;
  `);
  return result.recordset?.[0]?.id || null;
}

async function assignCoordinatorToEvent(tx, eventId, coordinatorId = null) {
  const resolvedCoordinatorId = coordinatorId || await selectCoordinatorId(tx);
  if (!resolvedCoordinatorId) return null;

  const result = await new sql.Request(tx)
    .input('eventId', sql.UniqueIdentifier, eventId)
    .input('coordinatorId', sql.UniqueIdentifier, resolvedCoordinatorId)
    .query(`
      UPDATE dbo.Events
      SET assignedCoordinatorId = COALESCE(assignedCoordinatorId, @coordinatorId),
          updatedAt = SYSUTCDATETIME()
      OUTPUT inserted.assignedCoordinatorId
      WHERE id = @eventId;
    `);

  return result.recordset?.[0]?.assignedCoordinatorId || resolvedCoordinatorId;
}

async function notifyUsersByRoles(tx, roles, { type = 'event', priority = 'normal', title, message, relatedEntity = null, relatedId = null, category = null }) {
  if (!Array.isArray(roles) || !roles.length) return;
  const rolesSql = roles.map((role) => `'${String(role).replace(/'/g, "''")}'`).join(', ');
  await new sql.Request(tx)
    .input('type', sql.VarChar, type)
    .input('priority', sql.VarChar, priority)
    .input('title', sql.NVarChar, title)
    .input('message', sql.NVarChar, message)
    .input('relatedEntity', sql.VarChar, relatedEntity)
    .input('relatedId', sql.UniqueIdentifier, relatedId || null)
    .input('category', sql.NVarChar, category || null)
    .query(`
      INSERT INTO dbo.Notifications (
        id, type, priority, title, message, isRead, relatedEntity, relatedId, recipientUserId, category, createdAt
      )
      SELECT NEWID(), @type, @priority, @title, @message, 0, @relatedEntity, @relatedId, u.id, @category, SYSUTCDATETIME()
      FROM dbo.Users u
      WHERE u.role IN (${rolesSql})
        AND u.status = 'approved';
    `);
}

async function notifySpecificUser(tx, recipientUserId, { type = 'event', priority = 'normal', title, message, relatedEntity = null, relatedId = null, category = null }) {
  if (!recipientUserId) return;
  await new sql.Request(tx)
    .input('recipientUserId', sql.UniqueIdentifier, recipientUserId)
    .input('type', sql.VarChar, type)
    .input('priority', sql.VarChar, priority)
    .input('title', sql.NVarChar, title)
    .input('message', sql.NVarChar, message)
    .input('relatedEntity', sql.VarChar, relatedEntity)
    .input('relatedId', sql.UniqueIdentifier, relatedId || null)
    .input('category', sql.NVarChar, category || null)
    .query(`
      INSERT INTO dbo.Notifications (
        id, type, priority, title, message, isRead, relatedEntity, relatedId, recipientUserId, category, createdAt
      )
      VALUES (NEWID(), @type, @priority, @title, @message, 0, @relatedEntity, @relatedId, @recipientUserId, @category, SYSUTCDATETIME());
    `);
}

async function replaceEventServiceRequests(tx, userId, eventId, serviceRequests, submit) {
  await new sql.Request(tx)
    .input('eventId', sql.UniqueIdentifier, eventId)
    .query(`DELETE FROM dbo.EventServiceRequests WHERE eventId=@eventId;`);

  if (!submit || !Array.isArray(serviceRequests) || !serviceRequests.length) return;

  for (const item of serviceRequests) {
    const serviceId = typeof item === 'string' ? item : item.serviceId;
    const quantity = Number(item?.quantity ?? 1);
    const remarks = item?.remarks || null;
    const serviceRow = await new sql.Request(tx)
      .input('serviceId', sql.UniqueIdentifier, serviceId)
      .query(`
        SELECT TOP 1 id, price, availability
        FROM dbo.Services
        WHERE id=@serviceId;
      `);

    const service = serviceRow.recordset?.[0] || null;
    if (!service) {
      const err = new Error('Service introuvable.');
      err.statusCode = 404;
      throw err;
    }
    if (service.availability && service.availability !== 'available') {
      const err = new Error('Ce service n’est pas disponible actuellement.');
      err.statusCode = 409;
      throw err;
    }

    await new sql.Request(tx)
      .input('eventId', sql.UniqueIdentifier, eventId)
      .input('serviceId', sql.UniqueIdentifier, serviceId)
      .input('requestedByUserId', sql.UniqueIdentifier, userId)
      .input('quantity', sql.Decimal(10,2), quantity)
      .input('estimatedAmount', sql.Decimal(12,2), Number(service.price || 0) * quantity)
      .input('remarks', sql.NVarChar, remarks)
      .query(`
        INSERT INTO dbo.EventServiceRequests
          (id, eventId, serviceId, requestedByUserId, assignedToUserId, quantity, requestedStartAt, requestedEndAt, status, estimatedAmount, remarks, createdAt, updatedAt)
        VALUES (
          NEWID(),
          @eventId,
          @serviceId,
          @requestedByUserId,
          (SELECT assignedCoordinatorId FROM dbo.Events WHERE id=@eventId),
          @quantity,
          (SELECT startAt FROM dbo.Events WHERE id=@eventId),
          (SELECT endAt FROM dbo.Events WHERE id=@eventId),
          'requested',
          @estimatedAmount,
          @remarks,
          SYSUTCDATETIME(),
          SYSUTCDATETIME()
        );
      `);
  }
}


async function notifyAccountingUsers(tx, payload) {
  await notifyUsersByRoles(tx, ['accounting', 'admin'], payload);
}

async function linkInvoicesToEvent(tx, event) {
  await new sql.Request(tx)
    .input('eventId', sql.UniqueIdentifier, event.id)
    .input('eventTitle', sql.NVarChar, event.title)
    .query(`
      UPDATE dbo.Invoices
      SET eventId = @eventId,
          eventTitle = COALESCE(eventTitle, @eventTitle)
      WHERE eventId IS NULL
        AND COALESCE(eventTitle, eventName) = @eventTitle;
    `);
}

async function getDashboard(userId) {
  const pool = await getPool();
  const req = pool.request().input('userId', sql.UniqueIdentifier, userId);

  const [statsR, nextEventR, unpaidR, notificationsR] = await Promise.all([
    req.query(`
      SELECT
        COUNT(*) AS totalEvents,
        SUM(CASE
          WHEN e.startAt >= SYSUTCDATETIME()
           AND e.status IN ('submitted','in_review','validated','confirmed','in_coordination','in_progress')
          THEN 1 ELSE 0
        END) AS upcomingEvents,
        SUM(ISNULL(e.participants, 0)) AS totalGuests,
        COUNT(DISTINCT CASE
          WHEN iu.id IS NOT NULL THEN e.id
          ELSE NULL
        END) AS unpaidInvoices
      FROM dbo.Events e
      LEFT JOIN (
        SELECT DISTINCT
          id,
          eventId,
          eventTitle = COALESCE(eventTitle, eventName)
        FROM dbo.Invoices
        WHERE status IN ('pending','partial','late')
      ) iu
        ON iu.eventId = e.id
        OR (iu.eventId IS NULL AND iu.eventTitle = e.title)
      WHERE e.organizerId = @userId;
    `),
    pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
      SELECT TOP 1
        e.id, e.title, e.type, e.startAt, e.endAt, e.status, e.participants,
        r.name AS roomName
      FROM dbo.Events e
      LEFT JOIN dbo.Rooms r ON r.id = e.roomId
      WHERE e.organizerId = @userId
        AND e.startAt >= SYSUTCDATETIME()
        AND e.status <> 'cancelled'
      ORDER BY e.startAt ASC;
    `),
    pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
      SELECT TOP 5
        i.id, i.invoiceNumber, COALESCE(i.eventTitle, i.eventName, e.title) AS eventTitle, i.total, i.status, i.dueDate
      FROM dbo.Invoices i
      INNER JOIN dbo.Events e
        ON e.id = i.eventId
        OR (i.eventId IS NULL AND COALESCE(i.eventTitle, i.eventName) = e.title)
      WHERE e.organizerId = @userId
        AND i.status IN ('pending','partial','late')
      ORDER BY i.dueDate ASC;
    `),
    pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
      SELECT TOP 8
        n.id, n.type, n.priority, n.title, n.message, n.isRead, n.createdAt
      FROM dbo.Notifications n
      WHERE n.recipientUserId = @userId
         OR EXISTS (
            SELECT 1 FROM dbo.Events e
            WHERE e.organizerId = @userId
              AND n.relatedEntity = 'event'
              AND n.relatedId = e.id
         )
      ORDER BY n.createdAt DESC;
    `),
  ]);

  return {
    summary: statsR.recordset?.[0] || { totalEvents: 0, upcomingEvents: 0, totalGuests: 0, unpaidInvoices: 0 },
    nextEvent: nextEventR.recordset?.[0] || null,
    unpaidInvoices: unpaidR.recordset || [],
    notifications: notificationsR.recordset || [],
  };
}

async function listEvents(userId, filters = {}) {
  const pool = await getPool();
  const req = pool.request().input('userId', sql.UniqueIdentifier, userId);
  let where = 'WHERE e.organizerId = @userId';

  if (filters.status) {
    where += ' AND e.status = @status';
    req.input('status', sql.NVarChar, filters.status);
  }
  if (filters.search) {
    where += ' AND (e.title LIKE @search OR e.type LIKE @search OR r.name LIKE @search)';
    req.input('search', sql.NVarChar, `%${filters.search}%`);
  }

  const result = await req.query(`
    WITH guestAgg AS (
      SELECT eventId, COUNT(*) AS guestCount
      FROM dbo.EventGuests
      GROUP BY eventId
    ),
    serviceAgg AS (
      SELECT eventId, COUNT(*) AS serviceCount
      FROM dbo.EventServiceRequests
      GROUP BY eventId
    ),
    documentAgg AS (
      SELECT eventId, COUNT(*) AS documentCount
      FROM dbo.EventDocuments
      GROUP BY eventId
    ),
    paidAgg AS (
      SELECT i.eventId, SUM(p.amount) AS paidAmount
      FROM dbo.Payments p
      INNER JOIN dbo.Invoices i ON i.id = p.invoiceId
      WHERE p.status = 'completed' AND i.eventId IS NOT NULL
      GROUP BY i.eventId
    )
    SELECT
      e.id, e.title, e.type, e.description, e.startAt, e.endAt, e.participants, e.budget, e.status,
      e.createdAt, e.updatedAt, e.submittedAt,
      r.id AS roomId, r.name AS roomName,
      ISNULL(ga.guestCount, 0) AS guestCount,
      ISNULL(sa.serviceCount, 0) AS serviceCount,
      ISNULL(da.documentCount, 0) AS documentCount,
      ISNULL(pa.paidAmount, 0) AS paidAmount
    FROM dbo.Events e
    LEFT JOIN dbo.Rooms r ON r.id = e.roomId
    LEFT JOIN guestAgg ga ON ga.eventId = e.id
    LEFT JOIN serviceAgg sa ON sa.eventId = e.id
    LEFT JOIN documentAgg da ON da.eventId = e.id
    LEFT JOIN paidAgg pa ON pa.eventId = e.id
    ${where}
    ORDER BY e.createdAt DESC;
  `);

  return (result.recordset || []).map((row) => {
    const progress = row.status === 'completed' ? 100 : row.status === 'confirmed' ? 85 : row.status === 'validated' ? 70 : row.status === 'in_review' ? 55 : row.status === 'submitted' ? 40 : row.status === 'draft' ? 20 : row.status === 'cancelled' ? 0 : 30;
    return { ...row, progress };
  });
}

async function getEvent(userId, eventId) {
  const pool = await getPool();
  const result = await pool.request()
    .input('eventId', sql.UniqueIdentifier, eventId)
    .input('userId', sql.UniqueIdentifier, userId)
    .query(`
      SELECT TOP 1
        e.id, e.title, e.type, e.description, e.startAt, e.endAt, e.participants, e.budget, e.status,
        e.createdAt, e.updatedAt, e.submittedAt,
        e.roomId,
        r.name AS roomName
      FROM dbo.Events e
      LEFT JOIN dbo.Rooms r ON r.id = e.roomId
      WHERE e.id=@eventId AND e.organizerId=@userId;
    `);

  const event = result.recordset?.[0] || null;
  if (!event) return null;

  const servicesR = await pool.request()
    .input('eventId', sql.UniqueIdentifier, eventId)
    .query(`
      SELECT serviceId, quantity, remarks
      FROM dbo.EventServiceRequests
      WHERE eventId=@eventId
      ORDER BY createdAt ASC;
    `);

  const serviceRequests = (servicesR.recordset || []).map((row) => ({
    serviceId: row.serviceId,
    quantity: Number(row.quantity || 1),
    remarks: row.remarks || '',
  }));

  return {
    ...event,
    serviceIds: serviceRequests.map((row) => row.serviceId),
    serviceRequests,
  };
}

async function createEvent(userId, data) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    const submit = !!data.submit;
    const eventId = data.id || null;
    const status = submit ? 'submitted' : 'draft';

    if (data.roomId && submit) {
      await validateRoomAvailability(tx, {
        roomId: data.roomId,
        startAt: data.startAt,
        endAt: data.endAt,
        participants: Number(data.participants || 0),
      });
    }

    const assignedCoordinatorId = submit ? await selectCoordinatorId(tx) : null;

    const eventR = await new sql.Request(tx)
      .input('eventId', sql.UniqueIdentifier, eventId)
      .input('title', sql.NVarChar, data.title)
      .input('type', sql.NVarChar, data.type || null)
      .input('description', sql.NVarChar, data.description || null)
      .input('startAt', sql.DateTime2, data.startAt)
      .input('endAt', sql.DateTime2, data.endAt)
      .input('participants', sql.Int, Number(data.participants || 0))
      .input('budget', sql.Decimal(12,2), Number(data.budget || 0))
      .input('status', sql.NVarChar, status)
      .input('organizerId', sql.UniqueIdentifier, userId)
      .input('roomId', sql.UniqueIdentifier, data.roomId || null)
      .input('assignedCoordinatorId', sql.UniqueIdentifier, assignedCoordinatorId)
      .query(`
        INSERT INTO dbo.Events
          (id, title, type, description, startAt, endAt, participants, budget, status, organizerId, roomId, assignedCoordinatorId, submittedAt, createdAt, updatedAt)
        OUTPUT inserted.*
        VALUES
          (ISNULL(@eventId, NEWID()), @title, @type, @description, @startAt, @endAt, @participants, @budget, @status, @organizerId, @roomId, @assignedCoordinatorId,
           CASE WHEN @status = 'submitted' THEN SYSUTCDATETIME() ELSE NULL END,
           SYSUTCDATETIME(), SYSUTCDATETIME());
      `);

    const event = eventR.recordset[0];

    await syncReservationForEvent(tx, userId, event, submit);
    await replaceEventServiceRequests(tx, userId, event.id, data.serviceRequests || data.serviceIds, submit);
    await linkInvoicesToEvent(tx, event);

    if (submit) {
      const coordinatorId = event.assignedCoordinatorId || await assignCoordinatorToEvent(tx, event.id, assignedCoordinatorId);
      await notifySpecificUser(tx, userId, {
        type: 'event',
        priority: 'normal',
        title: 'Demande soumise',
        message: 'Votre événement a été soumis pour validation et coordination.',
        relatedEntity: 'event',
        relatedId: event.id,
        category: 'event',
      });

      if (coordinatorId) {
        await notifySpecificUser(tx, coordinatorId, {
          type: 'event',
          priority: 'high',
          title: 'Nouvel événement à prendre en charge',
          message: `L’événement « ${event.title} » vient d’être soumis et attend votre validation opérationnelle.`,
          relatedEntity: 'event',
          relatedId: event.id,
          category: 'coordination',
        });
      } else {
        await notifyUsersByRoles(tx, ['coordinator'], {
          type: 'event',
          priority: 'high',
          title: 'Nouvel événement à prendre en charge',
          message: `L’événement « ${event.title} » vient d’être soumis et attend une affectation coordonnateur.`,
          relatedEntity: 'event',
          relatedId: event.id,
          category: 'coordination',
        });
      }

      await notifyAccountingUsers(tx, {
        type: 'event',
        priority: 'normal',
        title: 'Nouvel événement à facturer',
        message: `L’événement « ${event.title} » a été soumis par un organisateur et attend une prise en charge comptable.`,
        relatedEntity: 'event',
        relatedId: event.id,
        category: 'billing',
      });
    }

    await tx.commit();
    return await getEvent(userId, event.id);
  } catch (error) {
    try { await tx.rollback(); } catch {}
    throw error;
  }
}

async function updateEvent(userId, eventId, data) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    const existing = await getEventOwned(pool, userId, eventId, tx);
    if (!existing || !['draft', 'submitted', 'in_review'].includes(existing.status)) {
      await tx.rollback();
      return null;
    }

    const submit = typeof data.submit === 'boolean' ? data.submit : existing.status !== 'draft';
    const nextStatus = submit ? (existing.status === 'draft' ? 'submitted' : existing.status) : 'draft';

    if (data.roomId && submit) {
      await validateRoomAvailability(tx, {
        roomId: data.roomId,
        startAt: data.startAt,
        endAt: data.endAt,
        participants: Number(data.participants || 0),
        eventId,
      });
    }

    const result = await new sql.Request(tx)
      .input('id', sql.UniqueIdentifier, eventId)
      .input('userId', sql.UniqueIdentifier, userId)
      .input('title', sql.NVarChar, data.title)
      .input('type', sql.NVarChar, data.type || null)
      .input('description', sql.NVarChar, data.description || null)
      .input('startAt', sql.DateTime2, data.startAt)
      .input('endAt', sql.DateTime2, data.endAt)
      .input('participants', sql.Int, Number(data.participants || 0))
      .input('budget', sql.Decimal(12,2), Number(data.budget || 0))
      .input('roomId', sql.UniqueIdentifier, data.roomId || null)
      .input('status', sql.NVarChar, nextStatus)
      .input('assignedCoordinatorId', sql.UniqueIdentifier, submit ? await selectCoordinatorId(tx) : null)
      .query(`
        UPDATE dbo.Events
        SET title=@title,
            type=@type,
            description=@description,
            startAt=@startAt,
            endAt=@endAt,
            participants=@participants,
            budget=@budget,
            roomId=@roomId,
            status=@status,
            assignedCoordinatorId = CASE WHEN @status='submitted' THEN COALESCE(assignedCoordinatorId, @assignedCoordinatorId) ELSE assignedCoordinatorId END,
            submittedAt = CASE
              WHEN @status='submitted' AND submittedAt IS NULL THEN SYSUTCDATETIME()
              ELSE submittedAt
            END,
            updatedAt=SYSUTCDATETIME()
        OUTPUT inserted.*
        WHERE id=@id AND organizerId=@userId AND status IN ('draft','submitted','in_review');
      `);

    const event = result.recordset?.[0] || null;
    if (!event) {
      await tx.rollback();
      return null;
    }

    await syncReservationForEvent(tx, userId, event, submit);
    await replaceEventServiceRequests(tx, userId, event.id, data.serviceRequests || data.serviceIds, submit);
    await linkInvoicesToEvent(tx, event);

    if (submit) {
      const coordinatorId = event.assignedCoordinatorId || await assignCoordinatorToEvent(tx, event.id);
      await notifySpecificUser(tx, userId, {
        type: 'event',
        priority: 'normal',
        title: existing.status === 'draft' ? 'Demande soumise' : 'Événement mis à jour',
        message: existing.status === 'draft'
          ? 'Votre événement a été soumis pour validation et coordination.'
          : 'Votre événement a été mis à jour. Les équipes concernées ont été notifiées.',
        relatedEntity: 'event',
        relatedId: event.id,
        category: 'event',
      });

      if (coordinatorId) {
        await notifySpecificUser(tx, coordinatorId, {
          type: 'event',
          priority: existing.status === 'draft' ? 'high' : 'normal',
          title: existing.status === 'draft' ? 'Nouvel événement à prendre en charge' : 'Événement organisateur mis à jour',
          message: existing.status === 'draft'
            ? `L’événement « ${event.title} » vient d’être soumis et attend votre validation opérationnelle.`
            : `L’organisateur a modifié l’événement « ${event.title} ». Vérifiez la coordination, la salle et les services.`,
          relatedEntity: 'event',
          relatedId: event.id,
          category: 'coordination',
        });
      }

      await notifyAccountingUsers(tx, {
        type: 'event',
        priority: 'normal',
        title: 'Événement à suivre côté comptabilité',
        message: `L’événement « ${event.title} » a été soumis ou mis à jour et attend une vérification de la facturation.`,
        relatedEntity: 'event',
        relatedId: event.id,
        category: 'billing',
      });
    }

    await tx.commit();
    return await getEvent(userId, eventId);
  } catch (error) {
    try { await tx.rollback(); } catch {}
    throw error;
  }
}

async function cancelEvent(userId, eventId) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    const existing = await getEventOwned(pool, userId, eventId, tx);
    if (!existing || ['completed', 'cancelled'].includes(existing.status)) {
      await tx.rollback();
      return false;
    }

    const result = await new sql.Request(tx)
      .input('id', sql.UniqueIdentifier, eventId)
      .input('userId', sql.UniqueIdentifier, userId)
      .query(`
        UPDATE dbo.Events
        SET status='cancelled', updatedAt=SYSUTCDATETIME()
        OUTPUT inserted.id
        WHERE id=@id AND organizerId=@userId AND status NOT IN ('completed', 'cancelled');
      `);

    if (!result.recordset?.length) {
      await tx.rollback();
      return false;
    }

    await new sql.Request(tx)
      .input('id', sql.UniqueIdentifier, eventId)
      .input('userId', sql.UniqueIdentifier, userId)
      .query(`
        UPDATE dbo.Reservations
        SET status='cancelled'
        WHERE eventId=@id AND organizerId=@userId AND status <> 'cancelled';

        UPDATE dbo.EventServiceRequests
        SET status='cancelled', updatedAt=SYSUTCDATETIME()
        WHERE eventId=@id AND requestedByUserId=@userId AND status NOT IN ('completed', 'cancelled');
      `);

    await tx.commit();
    return true;
  } catch (error) {
    try { await tx.rollback(); } catch {}
    throw error;
  }
}

async function listRooms(filters = {}) {
  const pool = await getPool();
  const req = pool.request();
  let where = 'WHERE 1=1';
  if (filters.search) {
    where += ' AND r.name LIKE @search';
    req.input('search', sql.NVarChar, `%${filters.search}%`);
  }
  if (filters.minCapacity) {
    where += ' AND r.capacity >= @minCapacity';
    req.input('minCapacity', sql.Int, Number(filters.minCapacity));
  }
  if (filters.maxPrice) {
    where += ' AND r.pricePerDay <= @maxPrice';
    req.input('maxPrice', sql.Decimal(10,2), Number(filters.maxPrice));
  }
  if (filters.startAt) req.input('startAt', sql.DateTime2, filters.startAt); else req.input('startAt', sql.DateTime2, null);
  if (filters.endAt) req.input('endAt', sql.DateTime2, filters.endAt); else req.input('endAt', sql.DateTime2, null);
  if (filters.availableOnly && filters.startAt && filters.endAt) {
    where += `
      AND NOT EXISTS (
        SELECT 1
        FROM dbo.Reservations rs
        WHERE rs.roomId = r.id
          AND rs.status IN ('pending','locked','confirmed')
          AND rs.startAt < @endAt
          AND rs.endAt > @startAt
      )
    `;
  }

  const rows = await req.query(`
    SELECT r.id, r.name, r.capacity, r.surface, r.pricePerDay, r.status, r.imageUrl,
      STRING_AGG(eq.label, ', ') AS equipments,
      CASE
        WHEN @startAt IS NOT NULL AND @endAt IS NOT NULL AND EXISTS (
          SELECT 1
          FROM dbo.Reservations rs
          WHERE rs.roomId = r.id
            AND rs.status IN ('pending','locked','confirmed')
            AND rs.startAt < @endAt
            AND rs.endAt > @startAt
        ) THEN CAST(0 AS bit)
        ELSE CAST(1 AS bit)
      END AS isAvailable
    FROM dbo.Rooms r
    LEFT JOIN dbo.RoomEquipments eq ON eq.roomId = r.id
    ${where}
    GROUP BY r.id, r.name, r.capacity, r.surface, r.pricePerDay, r.status, r.imageUrl
    ORDER BY r.name ASC;
  `);
  return rows.recordset || [];
}

async function getCalendar(roomId) {
  const pool = await getPool();
  const req = pool.request();
  let where = "WHERE r.status IN ('pending','locked','confirmed')";
  if (roomId) {
    where += ' AND r.roomId = @roomId';
    req.input('roomId', sql.UniqueIdentifier, roomId);
  }
  const result = await req.query(`
    SELECT r.id, r.roomId, rm.name AS roomName, r.title, r.startAt, r.endAt, r.status
    FROM dbo.Reservations r
    INNER JOIN dbo.Rooms rm ON rm.id = r.roomId
    ${where}
    ORDER BY r.startAt ASC;
  `);
  return result.recordset || [];
}

async function listReservations(userId) {
  const pool = await getPool();
  const result = await pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
    SELECT r.id, r.title, r.startAt, r.endAt, r.status, r.participants, rm.name AS roomName, r.eventId
    FROM dbo.Reservations r
    INNER JOIN dbo.Rooms rm ON rm.id = r.roomId
    WHERE r.organizerId = @userId
    ORDER BY r.startAt DESC;
  `);
  return result.recordset || [];
}

async function listServices(userId, filters = {}) {
  const pool = await getPool();
  const req = pool.request().input('userId', sql.UniqueIdentifier, userId);
  let where = 'WHERE e.organizerId = @userId';
  if (filters.category) {
    where += ' AND s.category = @category';
    req.input('category', sql.NVarChar, filters.category);
  }
  if (filters.eventId) {
    where += ' AND sr.eventId = @eventId';
    req.input('eventId', sql.UniqueIdentifier, filters.eventId);
  }
  const result = await req.query(`
    SELECT sr.id, sr.eventId, sr.serviceId, e.title AS eventTitle, s.name AS serviceName, s.category, sr.quantity,
           sr.status, sr.estimatedAmount, sr.createdAt, sr.remarks
    FROM dbo.EventServiceRequests sr
    INNER JOIN dbo.Events e ON e.id = sr.eventId
    INNER JOIN dbo.Services s ON s.id = sr.serviceId
    ${where}
    ORDER BY sr.createdAt DESC;
  `);
  return result.recordset || [];
}

async function listServiceCatalog(category) {
  const pool = await getPool();
  const req = pool.request();
  let where = "WHERE availability = 'available'";
  if (category) {
    where += ' AND category = @category';
    req.input('category', sql.NVarChar, category);
  }
  const result = await req.query(`SELECT id, name, category, description, unitLabel, price, imageUrl FROM dbo.Services ${where} ORDER BY category, name;`);
  return result.recordset || [];
}

async function createServiceRequest(userId, data) {
  const pool = await getPool();
  const eventCheck = await pool.request()
    .input('eventId', sql.UniqueIdentifier, data.eventId)
    .input('userId', sql.UniqueIdentifier, userId)
    .query(`
      SELECT TOP 1 id, title, status, startAt, endAt, assignedCoordinatorId
      FROM dbo.Events
      WHERE id=@eventId AND organizerId=@userId;
    `);
  if (!eventCheck.recordset.length) return null;

  const event = eventCheck.recordset[0];
  const status = event.status;
  if (['draft', 'cancelled', 'completed'].includes(status)) {
    const err = new Error('Cet événement ne peut pas recevoir de nouvelle demande de service.');
    err.statusCode = 409;
    throw err;
  }

  const serviceCheck = await pool.request()
    .input('serviceId', sql.UniqueIdentifier, data.serviceId)
    .query(`SELECT TOP 1 id, price, availability FROM dbo.Services WHERE id=@serviceId;`);
  const service = serviceCheck.recordset?.[0] || null;
  if (!service) {
    const err = new Error('Service introuvable.');
    err.statusCode = 404;
    throw err;
  }
  if (service.availability && service.availability !== 'available') {
    const err = new Error('Ce service n’est pas disponible actuellement.');
    err.statusCode = 409;
    throw err;
  }

  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    const coordinatorId = event.assignedCoordinatorId || await assignCoordinatorToEvent(tx, data.eventId);
    const result = await new sql.Request(tx)
      .input('eventId', sql.UniqueIdentifier, data.eventId)
      .input('serviceId', sql.UniqueIdentifier, data.serviceId)
      .input('requestedByUserId', sql.UniqueIdentifier, userId)
      .input('assignedToUserId', sql.UniqueIdentifier, coordinatorId)
      .input('quantity', sql.Decimal(10,2), Number(data.quantity || 1))
      .input('requestedStartAt', sql.DateTime2, data.requestedStartAt || event.startAt || null)
      .input('requestedEndAt', sql.DateTime2, data.requestedEndAt || event.endAt || null)
      .input('priority', sql.NVarChar, data.priority || 'medium')
      .input('locationNote', sql.NVarChar, data.locationNote || null)
      .input('estimatedAmount', sql.Decimal(12,2), Number(service.price || 0) * Number(data.quantity || 1))
      .input('remarks', sql.NVarChar, data.remarks || null)
      .query(`
        INSERT INTO dbo.EventServiceRequests (
          id, eventId, serviceId, requestedByUserId, assignedToUserId, quantity, requestedStartAt, requestedEndAt,
          priority, status, locationNote, estimatedAmount, remarks, createdAt, updatedAt
        )
        OUTPUT inserted.*
        VALUES (
          NEWID(), @eventId, @serviceId, @requestedByUserId, @assignedToUserId, @quantity, @requestedStartAt, @requestedEndAt,
          @priority, 'requested', @locationNote, @estimatedAmount, @remarks, SYSUTCDATETIME(), SYSUTCDATETIME()
        );
      `);

    const inserted = result.recordset?.[0] || null;
    if (inserted) {
      await notifySpecificUser(tx, userId, {
        type: 'service_request',
        priority: 'normal',
        title: 'Demande de service envoyée',
        message: 'Votre demande de service a été transmise à la coordination.',
        relatedEntity: 'service_request',
        relatedId: inserted.id,
        category: 'services',
      });

      if (coordinatorId) {
        await notifySpecificUser(tx, coordinatorId, {
          type: 'service_request',
          priority: data.priority === 'critical' ? 'urgent' : 'high',
          title: 'Nouvelle demande de service',
          message: `Une nouvelle demande de service a été ajoutée à l’événement « ${event.title} ».`,
          relatedEntity: 'service_request',
          relatedId: inserted.id,
          category: 'services',
        });
      } else {
        await notifyUsersByRoles(tx, ['coordinator'], {
          type: 'service_request',
          priority: 'high',
          title: 'Nouvelle demande de service',
          message: `Une nouvelle demande de service a été ajoutée à l’événement « ${event.title} ».`,
          relatedEntity: 'service_request',
          relatedId: inserted.id,
          category: 'services',
        });
      }
    }

    await tx.commit();
    return inserted;
  } catch (error) {
    try { await tx.rollback(); } catch {}
    throw error;
  }
}

async function listGuests(userId, eventId) {
  const pool = await getPool();
  const req = pool.request().input('userId', sql.UniqueIdentifier, userId);
  let where = 'WHERE e.organizerId = @userId';
  if (eventId) {
    where += ' AND g.eventId = @eventId';
    req.input('eventId', sql.UniqueIdentifier, eventId);
  }
  const result = await req.query(`
    SELECT g.id, g.eventId, e.title AS eventTitle, g.firstName, g.lastName, g.email, g.phone, g.company,
           g.rsvpStatus, g.dietaryNotes, g.specialNeeds, g.plusOne, g.notes, g.createdAt
    FROM dbo.EventGuests g
    INNER JOIN dbo.Events e ON e.id = g.eventId
    ${where}
    ORDER BY g.createdAt DESC;
  `);
  return result.recordset || [];
}

async function createGuest(userId, data) {
  const pool = await getPool();
  const allowed = await pool.request().input('eventId', sql.UniqueIdentifier, data.eventId).input('userId', sql.UniqueIdentifier, userId).query(`SELECT TOP 1 id FROM dbo.Events WHERE id=@eventId AND organizerId=@userId;`);
  if (!allowed.recordset.length) return null;
  const result = await pool.request()
    .input('eventId', sql.UniqueIdentifier, data.eventId)
    .input('firstName', sql.NVarChar, data.firstName)
    .input('lastName', sql.NVarChar, data.lastName)
    .input('email', sql.NVarChar, data.email || null)
    .input('phone', sql.NVarChar, data.phone || null)
    .input('company', sql.NVarChar, data.company || null)
    .input('rsvpStatus', sql.NVarChar, data.rsvpStatus || 'pending')
    .input('dietaryNotes', sql.NVarChar, data.dietaryNotes || null)
    .input('specialNeeds', sql.NVarChar, data.specialNeeds || null)
    .input('plusOne', sql.Bit, data.plusOne ? 1 : 0)
    .input('notes', sql.NVarChar, data.notes || null)
    .query(`
      INSERT INTO dbo.EventGuests (id, eventId, firstName, lastName, email, phone, company, rsvpStatus, dietaryNotes, specialNeeds, plusOne, notes, createdAt)
      OUTPUT inserted.*
      VALUES (NEWID(), @eventId, @firstName, @lastName, @email, @phone, @company, @rsvpStatus, @dietaryNotes, @specialNeeds, @plusOne, @notes, SYSUTCDATETIME());
    `);
  return result.recordset?.[0] || null;
}

async function updateGuest(userId, guestId, data) {
  const pool = await getPool();
  const result = await pool.request()
    .input('id', sql.UniqueIdentifier, guestId)
    .input('userId', sql.UniqueIdentifier, userId)
    .input('firstName', sql.NVarChar, data.firstName)
    .input('lastName', sql.NVarChar, data.lastName)
    .input('email', sql.NVarChar, data.email || null)
    .input('phone', sql.NVarChar, data.phone || null)
    .input('company', sql.NVarChar, data.company || null)
    .input('rsvpStatus', sql.NVarChar, data.rsvpStatus || 'pending')
    .input('dietaryNotes', sql.NVarChar, data.dietaryNotes || null)
    .input('specialNeeds', sql.NVarChar, data.specialNeeds || null)
    .input('plusOne', sql.Bit, data.plusOne ? 1 : 0)
    .input('notes', sql.NVarChar, data.notes || null)
    .query(`
      UPDATE g
      SET firstName=@firstName, lastName=@lastName, email=@email, phone=@phone, company=@company,
          rsvpStatus=@rsvpStatus, dietaryNotes=@dietaryNotes, specialNeeds=@specialNeeds, plusOne=@plusOne, notes=@notes
      OUTPUT inserted.*
      FROM dbo.EventGuests g
      INNER JOIN dbo.Events e ON e.id = g.eventId
      WHERE g.id=@id AND e.organizerId=@userId;
    `);
  return result.recordset?.[0] || null;
}

async function deleteGuest(userId, guestId) {
  const pool = await getPool();
  const result = await pool.request().input('id', sql.UniqueIdentifier, guestId).input('userId', sql.UniqueIdentifier, userId).query(`
    DELETE g
    FROM dbo.EventGuests g
    INNER JOIN dbo.Events e ON e.id = g.eventId
    WHERE g.id=@id AND e.organizerId=@userId;
    SELECT @@ROWCOUNT AS affectedRows;
  `);
  return (result.recordset?.[0]?.affectedRows || 0) > 0;
}

async function listDocuments(userId, eventId) {
  const pool = await getPool();
  const req = pool.request().input('userId', sql.UniqueIdentifier, userId);
  let where = 'WHERE e.organizerId = @userId';
  if (eventId) { where += ' AND d.eventId = @eventId'; req.input('eventId', sql.UniqueIdentifier, eventId); }
  const result = await req.query(`
    SELECT d.id, d.eventId, e.title AS eventTitle, d.category, d.title, d.fileName, d.filePath, d.mimeType, d.fileSizeBytes, d.createdAt
    FROM dbo.EventDocuments d
    INNER JOIN dbo.Events e ON e.id = d.eventId
    ${where}
    ORDER BY d.createdAt DESC;
  `);
  return (result.recordset || []).map((doc) => ({
    ...doc,
    filePath: toStoredFilePath(doc.filePath),
  }));
}

async function createDocument(userId, data) {
  const pool = await getPool();
  const allowed = await pool.request().input('eventId', sql.UniqueIdentifier, data.eventId).input('userId', sql.UniqueIdentifier, userId).query(`SELECT TOP 1 id FROM dbo.Events WHERE id=@eventId AND organizerId=@userId;`);
  if (!allowed.recordset.length) return null;
  const storedFilePath = toStoredFilePath(data.filePath);
  const result = await pool.request()
    .input('eventId', sql.UniqueIdentifier, data.eventId)
    .input('uploadedByUserId', sql.UniqueIdentifier, userId)
    .input('category', sql.NVarChar, data.category || 'piece_jointe')
    .input('title', sql.NVarChar, data.title)
    .input('fileName', sql.NVarChar, data.fileName)
    .input('filePath', sql.NVarChar, storedFilePath)
    .input('mimeType', sql.NVarChar, data.mimeType || null)
    .input('fileSizeBytes', sql.BigInt, data.fileSizeBytes || null)
    .query(`
      INSERT INTO dbo.EventDocuments (id, eventId, uploadedByUserId, category, title, fileName, filePath, mimeType, fileSizeBytes, createdAt)
      OUTPUT inserted.*
      VALUES (NEWID(), @eventId, @uploadedByUserId, @category, @title, @fileName, @filePath, @mimeType, @fileSizeBytes, SYSUTCDATETIME());
    `);
  return result.recordset?.[0] || null;
}

async function deleteDocument(userId, docId) {
  const pool = await getPool();
  const doc = await pool.request().input('id', sql.UniqueIdentifier, docId).input('userId', sql.UniqueIdentifier, userId).query(`
    SELECT TOP 1 d.filePath
    FROM dbo.EventDocuments d
    INNER JOIN dbo.Events e ON e.id = d.eventId
    WHERE d.id=@id AND e.organizerId=@userId;
  `);
  const filePath = doc.recordset?.[0]?.filePath;
  const result = await pool.request().input('id', sql.UniqueIdentifier, docId).input('userId', sql.UniqueIdentifier, userId).query(`
    DELETE d FROM dbo.EventDocuments d
    INNER JOIN dbo.Events e ON e.id = d.eventId
    WHERE d.id=@id AND e.organizerId=@userId;
    SELECT @@ROWCOUNT AS affectedRows;
  `);
  if ((result.recordset?.[0]?.affectedRows || 0) > 0 && filePath) {
    try {
      const diskPath = toDiskFilePath(filePath);
      if (diskPath && fs.existsSync(diskPath)) fs.unlinkSync(diskPath);
    } catch {}
    return true;
  }
  return false;
}

async function getBilling(userId) {
  const pool = await getPool();
  const invoicesR = await pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
    SELECT i.*, COALESCE(i.eventTitle, i.eventName, e.title) AS eventLabel,
      ISNULL((
        SELECT SUM(p.amount)
        FROM dbo.Payments p
        WHERE p.invoiceId = i.id
          AND p.status = 'completed'
      ), 0) AS paidSum,
      (
        i.total - ISNULL((
          SELECT SUM(p.amount)
          FROM dbo.Payments p
          WHERE p.invoiceId = i.id
            AND p.status = 'completed'
        ), 0)
      ) AS remainingAmount,
      (SELECT COUNT(*) FROM dbo.Payments p WHERE p.invoiceId = i.id AND p.status = 'pending') AS pendingPaymentRequests
    FROM dbo.Invoices i
    INNER JOIN dbo.Events e
      ON e.id = i.eventId
      OR (i.eventId IS NULL AND COALESCE(i.eventTitle, i.eventName) = e.title)
    WHERE e.organizerId=@userId
    ORDER BY i.issueDate DESC;
  `);
  const paymentsR = await pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
    SELECT p.*, i.invoiceNumber, COALESCE(i.eventTitle, i.eventName, e.title) AS eventLabel
    FROM dbo.Payments p
    INNER JOIN dbo.Invoices i ON i.id = p.invoiceId
    INNER JOIN dbo.Events e
      ON e.id = i.eventId
      OR (i.eventId IS NULL AND COALESCE(i.eventTitle, i.eventName) = e.title)
    WHERE e.organizerId=@userId
    ORDER BY p.createdAt DESC, p.id DESC;
  `);
  return { invoices: invoicesR.recordset || [], payments: paymentsR.recordset || [] };
}

async function createSimulatedPayment(userId, data) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    const invoiceId = Number(data.invoiceId);
    const invoiceR = await new sql.Request(tx)
      .input('invoiceId', sql.Int, invoiceId)
      .input('userId', sql.UniqueIdentifier, userId)
      .query(`
        SELECT TOP 1 i.id, i.invoiceNumber, i.total, i.status, i.eventId, COALESCE(i.eventTitle, i.eventName, e.title) AS eventLabel
        FROM dbo.Invoices i
        INNER JOIN dbo.Events e ON e.id = i.eventId OR (i.eventId IS NULL AND COALESCE(i.eventTitle, i.eventName) = e.title)
        WHERE i.id = @invoiceId AND e.organizerId = @userId;
      `);

    const invoice = invoiceR.recordset?.[0] || null;
    if (!invoice) {
      const err = new Error('Facture introuvable.');
      err.statusCode = 404;
      throw err;
    }

    if (!['pending', 'partial', 'late'].includes(invoice.status)) {
      const err = new Error('Cette facture ne peut pas recevoir un paiement simulé.');
      err.statusCode = 409;
      throw err;
    }

    const pendingR = await new sql.Request(tx)
      .input('invoiceId', sql.Int, invoiceId)
      .query(`SELECT COUNT(*) AS pendingCount FROM dbo.Payments WHERE invoiceId=@invoiceId AND status='pending';`);
    if (Number(pendingR.recordset?.[0]?.pendingCount || 0) > 0) {
      const err = new Error('Une demande de paiement simulé est déjà en attente pour cette facture.');
      err.statusCode = 409;
      throw err;
    }

    const paidR = await new sql.Request(tx)
      .input('invoiceId', sql.Int, invoiceId)
      .query(`SELECT ISNULL(SUM(amount), 0) AS paidSum FROM dbo.Payments WHERE invoiceId=@invoiceId AND status='completed';`);
    const paidSum = Number(paidR.recordset?.[0]?.paidSum || 0);
    const remainingAmount = Math.max(Number(invoice.total || 0) - paidSum, 0);
    const amount = Number(data.amount || remainingAmount);
    if (amount <= 0 || amount > remainingAmount) {
      const err = new Error('Le montant simulé est invalide.');
      err.statusCode = 400;
      throw err;
    }

    const countR = await new sql.Request(tx).query(`
      SELECT COUNT(*) + 1 AS nextNum
      FROM dbo.Payments
      WHERE YEAR(createdAt) = YEAR(GETDATE());
    `);
    const nextNum = String(countR.recordset?.[0]?.nextNum || 1).padStart(3, '0');
    const paymentNumber = `PAY-${new Date().getFullYear()}-${nextNum}`;
    const paidAt = new Date().toISOString().slice(0, 10);

    await new sql.Request(tx)
      .input('invoiceId', sql.Int, invoiceId)
      .input('amount', sql.Decimal(12, 2), amount)
      .input('method', sql.NVarChar, data.method || 'Virement bancaire')
      .input('paidAt', sql.Date, paidAt)
      .input('reference', sql.NVarChar, data.reference || `SIM-${paymentNumber}`)
      .input('paymentNumber', sql.NVarChar, paymentNumber)
      .input('status', sql.NVarChar, 'pending')
      .query(`
        INSERT INTO dbo.Payments (invoiceId, amount, method, paidAt, reference, createdAt, paymentNumber, status)
        VALUES (@invoiceId, @amount, @method, @paidAt, @reference, SYSUTCDATETIME(), @paymentNumber, @status);
      `);

    await new sql.Request(tx)
      .input('recipientUserId', sql.UniqueIdentifier, userId)
      .input('relatedId', sql.Int, invoiceId)
      .query(`
        INSERT INTO dbo.Notifications (id, type, priority, title, message, isRead, relatedEntity, relatedId, recipientUserId, createdAt)
        VALUES (NEWID(), 'payment', 'normal', N'Paiement simulé envoyé', N'Votre paiement simulé a été transmis à la comptabilité pour validation.', 0, 'invoice', NULL, @recipientUserId, SYSUTCDATETIME());
      `);

    await notifyAccountingUsers(tx, {
      type: 'payment',
      priority: 'normal',
      title: 'Paiement simulé à valider',
      message: `Un paiement simulé de ${amount.toFixed(2)} $ a été soumis pour la facture ${invoice.invoiceNumber} (${invoice.eventLabel}).`,
      relatedEntity: 'invoice',
      relatedId: invoice.eventId || null,
    });

    await tx.commit();
    return { success: true, paymentNumber, status: 'pending' };
  } catch (error) {
    try { await tx.rollback(); } catch {}
    throw error;
  }
}

async function getReports(userId, eventId) {
  const pool = await getPool();
  const req = pool.request().input('userId', sql.UniqueIdentifier, userId);
  let eventWhere = 'WHERE e.organizerId = @userId';
  if (eventId) { eventWhere += ' AND e.id=@eventId'; req.input('eventId', sql.UniqueIdentifier, eventId); }
  const eventsR = await req.query(`SELECT e.id, e.title, e.type, e.startAt, e.endAt, e.budget, e.participants FROM dbo.Events e ${eventWhere} ORDER BY e.startAt DESC;`);
  const events = eventsR.recordset || [];
  if (!events.length) return { events: [], report: null };
  const selected = events[0];
  const detailsR = await pool.request().input('eventId', sql.UniqueIdentifier, selected.id).input('eventTitle', sql.NVarChar, selected.title).query(`
    SELECT 
      ISNULL((SELECT COUNT(*) FROM dbo.EventGuests WHERE eventId=@eventId),0) AS invitedCount,
      ISNULL((SELECT COUNT(*) FROM dbo.EventGuests WHERE eventId=@eventId AND rsvpStatus='confirmed'),0) AS confirmedCount,
      ISNULL((SELECT COUNT(*) FROM dbo.EventGuests WHERE eventId=@eventId AND rsvpStatus='declined'),0) AS declinedCount,
      ISNULL((SELECT SUM(estimatedAmount) FROM dbo.EventServiceRequests WHERE eventId=@eventId),0) AS serviceEstimated,
      ISNULL((
        SELECT SUM(p.amount)
        FROM dbo.Payments p
        INNER JOIN dbo.Invoices i ON i.id = p.invoiceId
        WHERE p.status='completed'
          AND (i.eventId=@eventId OR (i.eventId IS NULL AND COALESCE(i.eventTitle, i.eventName)=@eventTitle))
      ),0) AS paidAmount,
      ISNULL((
        SELECT SUM(i.total)
        FROM dbo.Invoices i
        WHERE i.eventId=@eventId OR (i.eventId IS NULL AND COALESCE(i.eventTitle, i.eventName)=@eventTitle)
      ),0) AS invoicedTotal,
      (SELECT TOP 1 finalParticipants FROM dbo.EventReports WHERE eventId=@eventId) AS finalParticipants,
      (SELECT TOP 1 serviceExecutionScore FROM dbo.EventReports WHERE eventId=@eventId) AS serviceExecutionScore,
      (SELECT TOP 1 satisfactionScore FROM dbo.EventReports WHERE eventId=@eventId) AS satisfactionScore,
      (SELECT TOP 1 summaryText FROM dbo.EventReports WHERE eventId=@eventId) AS summaryText
  `);
  const d = detailsR.recordset[0] || {};
  return { events, report: { event: selected, metrics: d } };
}

async function getProfile(userId) {
  const pool = await getPool();
  const result = await pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
    SELECT id, fullName, email, phone, organization, jobTitle, photoUrl, addressLine, postalCode, city, country,
           notificationEmailEnabled, notificationSmsEnabled, notificationInAppEnabled
    FROM dbo.Users WHERE id=@userId;
  `);
  return result.recordset?.[0] || null;
}

async function updateProfile(userId, data) {
  const pool = await getPool();
  const normalizedEmail = data.email ? String(data.email).trim() : null;
  if (normalizedEmail) {
    const emailCheck = await pool.request()
      .input('userId', sql.UniqueIdentifier, userId)
      .input('email', sql.NVarChar, normalizedEmail)
      .query(`
        SELECT TOP 1 id
        FROM dbo.Users
        WHERE email=@email AND id<>@userId;
      `);
    if (emailCheck.recordset?.length) {
      const err = new Error('Cet email est déjà utilisé.');
      err.statusCode = 409;
      throw err;
    }
  }

  const result = await pool.request()
    .input('userId', sql.UniqueIdentifier, userId)
    .input('fullName', sql.NVarChar, data.fullName)
    .input('email', sql.NVarChar, normalizedEmail)
    .input('phone', sql.NVarChar, data.phone || null)
    .input('organization', sql.NVarChar, data.organization || null)
    .input('jobTitle', sql.NVarChar, data.jobTitle || null)
    .input('addressLine', sql.NVarChar, data.addressLine || null)
    .input('postalCode', sql.NVarChar, data.postalCode || null)
    .input('city', sql.NVarChar, data.city || null)
    .input('country', sql.NVarChar, data.country || null)
    .input('notificationEmailEnabled', sql.Bit, data.notificationEmailEnabled == null ? 1 : (data.notificationEmailEnabled ? 1 : 0))
    .input('notificationSmsEnabled', sql.Bit, data.notificationSmsEnabled ? 1 : 0)
    .input('notificationInAppEnabled', sql.Bit, data.notificationInAppEnabled == null ? 1 : (data.notificationInAppEnabled ? 1 : 0))
    .query(`
      UPDATE dbo.Users
      SET fullName=@fullName,
          email=COALESCE(@email, email),
          phone=@phone,
          organization=@organization,
          jobTitle=@jobTitle,
          addressLine=@addressLine,
          postalCode=@postalCode,
          city=@city,
          country=@country,
          notificationEmailEnabled=@notificationEmailEnabled,
          notificationSmsEnabled=@notificationSmsEnabled,
          notificationInAppEnabled=@notificationInAppEnabled
      OUTPUT inserted.id, inserted.fullName, inserted.email, inserted.phone, inserted.organization, inserted.jobTitle,
             inserted.photoUrl, inserted.addressLine, inserted.postalCode, inserted.city, inserted.country,
             inserted.notificationEmailEnabled, inserted.notificationSmsEnabled, inserted.notificationInAppEnabled
      WHERE id=@userId;
    `);
  return result.recordset?.[0] || null;
}

async function listNotifications(userId) {
  const pool = await getPool();
  const result = await pool.request().input('userId', sql.UniqueIdentifier, userId).query(`
    SELECT TOP 50 id, type, priority, title, message, isRead, createdAt
    FROM dbo.Notifications n
    WHERE n.recipientUserId=@userId
       OR EXISTS (
          SELECT 1
          FROM dbo.Events e
          WHERE e.organizerId=@userId
            AND n.relatedEntity='event'
            AND n.relatedId=e.id
       )
    ORDER BY createdAt DESC;
  `);
  return result.recordset || [];
}

async function markNotificationRead(userId, notificationId) {
  const pool = await getPool();
  const result = await pool.request().input('userId', sql.UniqueIdentifier, userId).input('id', sql.UniqueIdentifier, notificationId).query(`
    UPDATE dbo.Notifications
    SET isRead=1
    OUTPUT inserted.id
    WHERE id=@id
      AND (
        recipientUserId=@userId
        OR EXISTS (
          SELECT 1
          FROM dbo.Events e
          WHERE e.organizerId=@userId
            AND dbo.Notifications.relatedEntity='event'
            AND dbo.Notifications.relatedId=e.id
        )
      );
  `);
  return !!(result.recordset && result.recordset.length);
}

module.exports = {
  getDashboard,
  listEvents,
  getEvent,
  createEvent,
  updateEvent,
  cancelEvent,
  listRooms,
  getCalendar,
  listReservations,
  listServices,
  listServiceCatalog,
  createServiceRequest,
  listGuests,
  createGuest,
  updateGuest,
  deleteGuest,
  listDocuments,
  createDocument,
  deleteDocument,
  getBilling,
  createSimulatedPayment,
  getReports,
  getProfile,
  updateProfile,
  listNotifications,
  markNotificationRead,
};
