// src/middleware/validateGuid.js
function isGuid(x) {
  return /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$/.test(
    String(x || "")
  );
}

function validateGuid(paramName = "id") {
  return (req, res, next) => {
    const value = req.params[paramName];
    if (!isGuid(value)) {
      return res.status(400).json({ message: `ID invalide (GUID attendu): ${paramName}` });
    }
    next();
  };
}

module.exports = { validateGuid, isGuid };