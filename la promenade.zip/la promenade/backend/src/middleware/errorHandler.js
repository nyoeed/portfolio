// src/middleware/errorHandler.js
function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);

  // Upload (multer)
  if (err && err.name === "MulterError") {
    return res.status(400).json({ message: err.message || "Upload error" });
  }

  // Erreur custom
  const status = err.statusCode || err.status || 500;

  return res.status(status).json({
    message: err.message || "Server error",
    // tu peux enlever en prod si tu veux
    error: err.error || undefined,
  });
}

module.exports = { errorHandler };