
function isEnabled() {
  return String(process.env.MAIL_SIMULATION_DISABLED || '').toLowerCase() !== 'true';
}

async function sendMail({ to, subject, text, meta }) {
  if (!to || !isEnabled()) return { ok: false, simulated: true, reason: 'mail disabled or missing recipient' };

  const payload = {
    to,
    subject,
    text,
    meta: meta || null,
    sentAt: new Date().toISOString(),
    simulated: true,
  };

  console.log('[mail:simulated]', JSON.stringify(payload));
  return { ok: true, simulated: true };
}

module.exports = { sendMail };
