
const repo = require('../repositories/notification-center.repo');
const { sendMail } = require('./mail.service');

function categoryToSettingKey(category) {
  if (category === 'event') return 'notifEvents';
  if (category === 'payment') return 'notifPayments';
  if (category === 'signup') return 'notifSignup';
  return 'notifSystem';
}

async function canNotify(category, user) {
  const settings = await repo.getAdminSettings();
  const globalKey = categoryToSettingKey(category);
  const globallyEnabled = settings ? !!settings[globalKey] : true;
  const internalEnabled = user?.notificationInAppEnabled !== false;
  const emailEnabled = user?.notificationEmailEnabled !== false && globallyEnabled;
  return { globallyEnabled, internalEnabled, emailEnabled };
}

async function notifyUser({ recipientUserId, type='system', priority='normal', title, message, relatedEntity=null, relatedId=null, category='system' }) {
  if (!recipientUserId || !title) return null;
  const user = await repo.getUserById(recipientUserId);
  if (!user || user.status !== 'approved') return null;
  const perms = await canNotify(category, user);

  let notification = null;
  if (perms.globallyEnabled && perms.internalEnabled) {
    notification = await repo.createNotification({ recipientUserId, type, priority, title, message, relatedEntity, relatedId });
  }
  if (perms.emailEnabled && user.email) {
    await sendMail({ to: user.email, subject: `[La Promenade] ${title}`, text: message || title, meta: { recipientUserId, type, category, relatedEntity, relatedId } });
  }
  return notification;
}

async function notifyRoles({ roles = [], type='system', priority='normal', title, message, relatedEntity=null, relatedId=null, category='system' }) {
  const users = await repo.listUsersByRoles(roles);
  const out = [];
  for (const user of users) {
    const x = await notifyUser({ recipientUserId: user.id, type, priority, title, message, relatedEntity, relatedId, category });
    if (x) out.push(x);
  }
  return out;
}

module.exports = { notifyUser, notifyRoles };
