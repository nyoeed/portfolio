const repo = require("../../repositories/accounting/accounting.repo");

async function getDashboard() {
  return repo.getDashboard();
}

async function listInvoices(filters) {
  return repo.listInvoices(filters);
}

async function getInvoiceableEvents() {
  return repo.getInvoiceableEvents();
}

async function createInvoice(data) {
  const { eventId, issueDate, dueDate, subtotal, taxRate } = data || {};
  if (!eventId || !issueDate || !dueDate || subtotal == null || taxRate == null) {
    const err = new Error("Champs obligatoires manquants.");
    err.statusCode = 400;
    throw err;
  }

  if (Number(subtotal) < 0 || Number(taxRate) < 0) {
    const err = new Error("Les montants de la facture sont invalides.");
    err.statusCode = 400;
    throw err;
  }

  if (new Date(dueDate) < new Date(issueDate)) {
    const err = new Error("La date d’échéance doit être postérieure à la date d’émission.");
    err.statusCode = 400;
    throw err;
  }

  return repo.createInvoice(data);
}

async function updateInvoiceStatus(invoiceId, status) {
  const allowed = ["pending", "partial", "paid", "late", "cancelled"];
  if (!allowed.includes(status)) {
    const err = new Error("Statut invalide.");
    err.statusCode = 400;
    throw err;
  }
  return repo.updateInvoiceStatus(Number(invoiceId), status);
}

async function deleteInvoice(invoiceId) {
  return repo.deleteInvoice(Number(invoiceId));
}

async function listPayments(filters) {
  return repo.listPayments(filters);
}

async function listNotifications() {
  return repo.listNotifications();
}

async function markNotificationRead(notificationId) {
  return repo.markNotificationRead(notificationId);
}

async function updatePaymentStatus(paymentId, status) {
  const allowed = ['pending', 'completed', 'failed', 'cancelled'];
  if (!allowed.includes(status)) {
    const err = new Error('Statut paiement invalide.');
    err.statusCode = 400;
    throw err;
  }
  return repo.updatePaymentStatus(Number(paymentId), status);
}

async function createPayment(data) {
  const { invoiceId, amount, method, paidAt } = data || {};
  if (!invoiceId || amount == null || !method || !paidAt) {
    const err = new Error("Champs obligatoires manquants.");
    err.statusCode = 400;
    throw err;
  }
  return repo.createPayment(data);
}

async function listRefunds(filters) {
  return repo.listRefunds(filters);
}

async function createRefund(data) {
  const { invoiceId, amount, reason, refundDate } = data || {};
  if (!invoiceId || amount == null || !reason || !refundDate) {
    const err = new Error("Champs obligatoires manquants.");
    err.statusCode = 400;
    throw err;
  }
  return repo.createRefund(data);
}

async function updateRefundStatus(refundId, status) {
  const allowed = ["pending", "approved", "processed", "rejected"];
  if (!allowed.includes(status)) {
    const err = new Error("Statut remboursement invalide.");
    err.statusCode = 400;
    throw err;
  }
  return repo.updateRefundStatus(Number(refundId), status);
}

async function deleteRefund(refundId) {
  return repo.deleteRefund(Number(refundId));
}

async function getReports(filters) {
  return repo.getReports(filters);
}

module.exports = {
  getDashboard,
  listInvoices,
  getInvoiceableEvents,
  createInvoice,
  updateInvoiceStatus,
  deleteInvoice,
  listPayments,
  listNotifications,
  markNotificationRead,
  updatePaymentStatus,
  createPayment,
  listRefunds,
  createRefund,
  updateRefundStatus,
  deleteRefund,
  getReports,
};
