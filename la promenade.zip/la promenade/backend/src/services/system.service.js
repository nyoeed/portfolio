// src/services/system.service.js
const bcrypt = require("bcrypt");
const { z } = require("zod");

const systemRepo = require("../repositories/system.repo");

// ⚠️ ici on aura besoin de signToken (donc du fichier utils qui le contient)
const { signToken } = require("../utils/jwt"); // à adapter si ton fichier s'appelle autrement

async function isInitialized() {
  return systemRepo.hasAnyAdmin();
}

async function initAdmin(body) {
  const schema = z.object({
    fullName: z.string().min(2),
    email: z.string().email(),
    password: z.string().min(8),
    secretKey: z.string().min(1),
  });

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    const err = new Error("Invalid data");
    err.code = "BAD_DATA";
    throw err;
  }

  const { fullName, email, password, secretKey } = parsed.data;

  if (secretKey !== process.env.INIT_ADMIN_SECRET) {
    const err = new Error("Invalid secret key");
    err.code = "BAD_SECRET";
    throw err;
  }

  const initialized = await systemRepo.hasAnyAdmin();
  if (initialized) {
    const err = new Error("Already initialized");
    err.code = "ALREADY_INIT";
    throw err;
  }

  const exists = await systemRepo.existsByEmail({ email });
  if (exists) {
    const err = new Error("Email already used");
    err.code = "EMAIL_EXISTS";
    throw err;
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const user = await systemRepo.insertAdmin({
    fullName,
    email,
    passwordHash,
  });

  const token = signToken({ id: user.id, role: user.role, status: user.status, email: user.email });

  return { token, user };
}

module.exports = { isInitialized, initAdmin };