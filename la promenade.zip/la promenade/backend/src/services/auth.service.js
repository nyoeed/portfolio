// src/services/auth.service.js
const bcrypt = require("bcrypt");
const { z } = require("zod");

const authRepo = require("../repositories/auth.repo");
const { signToken } = require("../utils/jwt");
const { notifyUser } = require("./notification-center.service");

// 
const registerSchema = z.object({
  fullName: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8),
  roleRequested: z.enum(["organizer", "coordinator", "accounting"]),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

async function register(body) {
  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) {
    const err = new Error("Invalid data");
    err.code = "BAD_DATA";
    throw err;
  }

  const { fullName, email, password, roleRequested } = parsed.data;

  const exists = await authRepo.userExistsByEmail({ email });
  if (exists) {
    const err = new Error("Email already used");
    err.code = "EMAIL_EXISTS";
    throw err;
  }

  const passwordHash = await bcrypt.hash(password, 12);

  await authRepo.insertPendingUser({
    fullName,
    email,
    passwordHash,
    roleRequested,
  });

  // identique : pas de token
  return { message: "Registered. Pending approval." };
}

async function login(body) {
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    const err = new Error("Invalid data");
    err.code = "BAD_DATA";
    throw err;
  }

  const { email, password } = parsed.data;

  const u = await authRepo.findUserForLogin({ email });
  if (!u) {
    const err = new Error("Invalid credentials");
    err.code = "INVALID_CREDENTIALS";
    throw err;
  }

  const ok = await bcrypt.compare(password, u.passwordHash);
  if (!ok) {
    const err = new Error("Invalid credentials");
    err.code = "INVALID_CREDENTIALS";
    throw err;
  }

  await authRepo.updateLastLogin({ id: u.id });

  const user = {
    id: u.id,
    email: u.email,
    fullName: u.fullName,
    role: u.role,
    status: u.status,
  };

  const token = signToken({
    id: user.id,
    role: user.role,
    status: user.status,
    email: user.email,
  });

  return { token, user };
}


const forgotPasswordSchema = z.object({ email: z.string().email() });
const resetPasswordSchema = z.object({ token: z.string().min(10), password: z.string().min(8) });

async function forgotPassword(body) {
  const parsed = forgotPasswordSchema.safeParse(body);
  if (!parsed.success) {
    const err = new Error("Invalid data");
    err.code = "BAD_DATA";
    throw err;
  }

  const email = parsed.data.email.trim().toLowerCase();
  const user = await authRepo.findUserByEmail({ email });
  if (!user) {
    return { ok: true, message: "Si cet email existe, un lien de réinitialisation a été généré." };
  }

  const token = signToken({ sub: user.id, email: user.email, purpose: 'password_reset' }, process.env.JWT_RESET_EXPIRES_IN || '15m');

  await notifyUser({
    recipientUserId: user.id,
    type: 'user',
    priority: 'urgent',
    title: 'Réinitialisation du mot de passe',
    message: `Un lien de réinitialisation a été demandé pour votre compte. Utilisez le jeton suivant dans l’interface : ${token}`,
    relatedEntity: 'user',
    relatedId: user.id,
    category: 'system',
  });

  return { ok: true, message: "Si cet email existe, un lien de réinitialisation a été généré.", resetToken: token };
}

async function resetPassword(body) {
  const parsed = resetPasswordSchema.safeParse(body);
  if (!parsed.success) {
    const err = new Error("Invalid data");
    err.code = "BAD_DATA";
    throw err;
  }

  const jwt = require('jsonwebtoken');
  let payload;
  try {
    payload = jwt.verify(parsed.data.token, process.env.JWT_SECRET);
  } catch {
    const err = new Error('Token invalide ou expiré');
    err.code = 'INVALID_TOKEN';
    throw err;
  }

  if (payload.purpose !== 'password_reset' || !payload.sub) {
    const err = new Error('Token invalide');
    err.code = 'INVALID_TOKEN';
    throw err;
  }

  const passwordHash = await bcrypt.hash(parsed.data.password, 12);
  const ok = await authRepo.updatePasswordById({ id: payload.sub, passwordHash });
  if (!ok) {
    const err = new Error('Utilisateur introuvable');
    err.code = 'NOT_FOUND';
    throw err;
  }

  await notifyUser({
    recipientUserId: payload.sub,
    type: 'user',
    priority: 'normal',
    title: 'Mot de passe réinitialisé',
    message: 'Votre mot de passe a été mis à jour avec succès.',
    relatedEntity: 'user',
    relatedId: payload.sub,
    category: 'system',
  });

  return { ok: true, message: 'Mot de passe mis à jour.' };
}


async function getMe(user) {
  if (!user?.id) {
    const err = new Error('Unauthorized');
    err.code = 'UNAUTHORIZED';
    throw err;
  }
  return authRepo.getUserProfile({ id: user.id });
}

async function updateMe(user, body) {
  if (!user?.id) {
    const err = new Error('Unauthorized');
    err.code = 'UNAUTHORIZED';
    throw err;
  }
  const fullName = body.fullName == null ? undefined : String(body.fullName).trim();
  const email = body.email == null ? undefined : String(body.email).trim().toLowerCase();
  const payload = {
    fullName: fullName || undefined,
    email: email || undefined,
    phone: body.phone,
    organization: body.organization,
    jobTitle: body.jobTitle,
    addressLine: body.addressLine,
    postalCode: body.postalCode,
    city: body.city,
    country: body.country,
    notificationEmailEnabled: body.notificationEmailEnabled,
    notificationSmsEnabled: body.notificationSmsEnabled,
    notificationInAppEnabled: body.notificationInAppEnabled,
  };
  return authRepo.updateUserProfile({ id: user.id, data: payload });
}

module.exports = { register, login, forgotPassword, resetPassword, getMe, updateMe };
