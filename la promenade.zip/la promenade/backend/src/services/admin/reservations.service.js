// src/services/admin/reservations.service.js
const reservationsRepo = require("../../repositories/admin/reservations.repo");

function isValidDate(d) {
  const x = new Date(d);
  return !Number.isNaN(x.getTime());
}
function toIso(d) {
  return new Date(d).toISOString();
}

async function list(query) {
  const { from, to, roomId, status } = query || {};

  // on suit ton ancien comportement : on applique les filtres seulement si dates valides
  const filters = {
    roomId: roomId || null,
    status: status || null,
    from: from && isValidDate(from) ? new Date(from) : null,
    to: to && isValidDate(to) ? new Date(to) : null,
  };

  return reservationsRepo.list(filters);
}

async function create(body) {
  const { roomId, organizerId, title, startAt, endAt, participants, status } = body || {};

  if (!roomId || !organizerId || !title || !startAt || !endAt || participants == null) {
    throw new Error("roomId, organizerId, title, startAt, endAt, participants requis.");
  }
  if (!isValidDate(startAt) || !isValidDate(endAt)) {
    throw new Error("startAt/endAt invalides.");
  }

  const s = new Date(startAt);
  const e = new Date(endAt);
  if (e <= s) {
    throw new Error("endAt doit être > startAt.");
  }

  const allowedStatus = ["pending", "confirmed", "cancelled"];
  const st = allowedStatus.includes(status) ? status : "pending";

  try {
    return await reservationsRepo.createWithConflictCheck({
      roomId,
      organizerId,
      title: String(title).trim(),
      startAt: s,
      endAt: e,
      participants: Number(participants),
      status: st,
      toIso,
    });
  } catch (err) {
    // repo peut remonter un conflit structuré
    if (err.code === "RESERVATION_CONFLICT") throw err;
    throw err;
  }
}

async function updateStatus({ id, status }) {
  const allowed = ["pending", "confirmed", "cancelled"];
  if (!allowed.includes(status)) throw new Error("Status invalide.");

  const updated = await reservationsRepo.updateStatus({ id, status });
  if (!updated) throw new Error("Réservation introuvable.");
  return updated;
}

async function remove({ id }) {
  const ok = await reservationsRepo.remove({ id });
  if (!ok) throw new Error("Réservation introuvable.");
  return true;
}

module.exports = { list, create, updateStatus, remove };