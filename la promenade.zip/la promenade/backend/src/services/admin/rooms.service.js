// src/services/admin/rooms.service.js
const roomsRepo = require("../../repositories/admin/rooms.repo");

async function getStats() {
  return roomsRepo.getStats();
}

async function list() {
  // reproduit ton enrichissement: equipments + reservationsCount + nextReservationAt
  return roomsRepo.listWithDetails();
}

async function create(body) {
  const { name, capacity, surface, pricePerDay, status, equipments } = body || {};

  if (!name || capacity == null || pricePerDay == null) {
    throw new Error("name, capacity, pricePerDay sont requis.");
  }

  const allowedStatus = ["available", "maintenance", "reserved"];
  const roomStatus = status && allowedStatus.includes(status) ? status : "available";

  const eq = Array.isArray(equipments)
    ? equipments.map((x) => String(x).trim()).filter(Boolean)
    : [];

  const created = await roomsRepo.createRoomWithEquipments({
    name: String(name).trim(),
    capacity: Number(capacity),
    surface: surface == null ? null : Number(surface),
    pricePerDay: Number(pricePerDay),
    status: roomStatus,
    equipments: eq,
  });

  return created;
}

async function update({ id, body }) {
  const { name, capacity, surface, pricePerDay, status, equipments } = body || {};

  const allowedStatus = ["available", "maintenance", "reserved"];
  if (status && !allowedStatus.includes(status)) {
    throw new Error("status invalide.");
  }

  const eq =
    Array.isArray(equipments) ? equipments.map((x) => String(x).trim()).filter(Boolean) : null;

  const updated = await roomsRepo.updateRoomAndMaybeEquipments({
    id,
    name: name != null ? String(name).trim() : null,
    capacity: capacity != null ? Number(capacity) : null,
    surface: surface != null ? Number(surface) : null,
    pricePerDay: pricePerDay != null ? Number(pricePerDay) : null,
    status: status != null ? status : null,
    equipments: eq, // null => pas toucher, array => remplacer
  });

  if (!updated) throw new Error("Salle introuvable.");
  return updated;
}

async function remove({ id }) {
  const ok = await roomsRepo.remove({ id });
  if (!ok) throw new Error("Salle introuvable.");
  return true;
}

module.exports = { getStats, list, create, update, remove };