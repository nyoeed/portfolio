// src/services/admin/notifications.service.js
const notificationsRepo = require("../../repositories/admin/notifications.repo");

function isGuid(x) {
  return /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$/.test(
    String(x || "")
  );
}

function isTrue(v) {
  return v === true || v === 1 || v === "1" || v === "true";
}
function safeType(t) {
  const allowed = new Set(["payment", "event", "user", "system"]);
  return allowed.has(t) ? t : "system";
}
function safePriority(p) {
  return p === "urgent" ? "urgent" : "normal";
}

async function list(query, user) {
  const tab = String(query.tab || "all");
  const unreadOnly = tab === "unread" || isTrue(query.unread);
  const limit = Math.min(Math.max(Number(query.limit || 200), 1), 500);
  return notificationsRepo.list({ unreadOnly, limit, recipientUserId: user?.id || null });
}

async function getStats(user) {
  return notificationsRepo.getStats({ recipientUserId: user?.id || null });
}

async function markRead({ id }) {
  if (!isGuid(id)) {
    const err = new Error("bad id");
    err.code = "BAD_ID";
    throw err;
  }

  const row = await notificationsRepo.markRead({ id });
  if (!row) {
    const err = new Error("not found");
    err.code = "NOT_FOUND";
    throw err;
  }
  return row;
}

async function markAllRead(user) {
  await notificationsRepo.markAllRead({ recipientUserId: user?.id || null });
  return true;
}

async function remove({ id }) {
  if (!isGuid(id)) {
    const err = new Error("bad id");
    err.code = "BAD_ID";
    throw err;
  }

  const deletedId = await notificationsRepo.remove({ id });
  if (!deletedId) {
    const err = new Error("not found");
    err.code = "NOT_FOUND";
    throw err;
  }

  return { ok: true, id: deletedId };
}

async function create(body) {
  const type = safeType(String(body.type || "system"));
  const priority = safePriority(String(body.priority || "normal"));
  const title = String(body.title || "").trim();
  const message = body.message == null ? null : String(body.message).trim();
  const relatedEntity = body.relatedEntity == null ? null : String(body.relatedEntity).trim();

  const relatedIdRaw = body.relatedId || null;
  const relatedId = relatedIdRaw && isGuid(relatedIdRaw) ? relatedIdRaw : null;
  const recipientUserIdRaw = body.recipientUserId || null;
  const recipientUserId = recipientUserIdRaw && isGuid(recipientUserIdRaw) ? recipientUserIdRaw : null;

  if (!title) {
    const err = new Error("title required");
    err.code = "BAD_TITLE";
    throw err;
  }

  return notificationsRepo.create({
    recipientUserId,
    type,
    priority,
    title,
    message,
    relatedEntity,
    relatedId,
  });
}

module.exports = { list, getStats, markRead, markAllRead, remove, create };
