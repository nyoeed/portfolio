// src/services/admin/stats.service.js
const statsRepo = require("../../repositories/admin/stats.repo");

async function get() {
  const data = await statsRepo.getDashboardStats();

  const revenueThisMonth = Number(data.revenueThisMonth || 0);
  const revenueLastMonth = Number(data.revenueLastMonth || 0);

  const revenueChangePct =
    revenueLastMonth === 0 ? null : ((revenueThisMonth - revenueLastMonth) / revenueLastMonth) * 100;

  return {
    totalUsers: Number(data.totalUsers || 0),
    pendingRequests: Number(data.pendingRequests || 0),

    roles: data.roles || [],
    statuses: data.statuses || [],

    newUsersThisMonth: Number(data.newUsersThisMonth || 0),
    newUsersLastMonth: Number(data.newUsersLastMonth || 0),

    activeEvents: Number(data.activeEvents || 0),
    newEventsThisWeek: Number(data.newEventsThisWeek || 0),

    revenueThisMonth,
    revenueLastMonth,
    revenueChangePct,
  };
}

module.exports = { get };