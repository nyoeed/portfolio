// src/services/admin/bundles.service.js
const bundlesRepo = require("../../repositories/admin/bundles.repo");

const ALLOWED_UNITS = ["par personne", "par jour", "forfait"];
const ALLOWED_AVAIL = ["available", "unavailable"];

async function list() {
  return bundlesRepo.listWithServices();
}

async function create(body) {
  const { name, description, unitLabel, price, availability, serviceIds } = body || {};

  if (!name || !unitLabel || price == null) {
    throw new Error("name, unitLabel, price requis.");
  }

  if (!ALLOWED_UNITS.includes(unitLabel)) throw new Error("unitLabel invalide.");

  const av = ALLOWED_AVAIL.includes(availability) ? availability : "available";

  const p = Number(price);
  if (!Number.isFinite(p) || p < 0) throw new Error("price invalide.");

  const ids = Array.isArray(serviceIds) ? serviceIds : [];

  return bundlesRepo.createBundleAndItems({
    name: String(name).trim(),
    description: description ? String(description).trim() : null,
    unitLabel,
    price: p,
    availability: av,
    serviceIds: ids,
  });
}

async function update({ id, body }) {
  const { name, description, unitLabel, price, availability, serviceIds } = body || {};

  if (unitLabel && !ALLOWED_UNITS.includes(unitLabel)) throw new Error("unitLabel invalide.");

  if (availability && !ALLOWED_AVAIL.includes(availability)) {
    throw new Error("availability invalide.");
  }

  const p = price != null ? Number(price) : null;
  if (price != null && (!Number.isFinite(p) || p < 0)) throw new Error("price invalide.");

  const ids = Array.isArray(serviceIds) ? serviceIds : null;

  const updated = await bundlesRepo.updateBundleAndMaybeItems({
    id,
    name: name != null ? String(name).trim() : null,
    description: description != null ? String(description).trim() : null,
    unitLabel: unitLabel != null ? unitLabel : null,
    price: price != null ? p : null,
    availability: availability != null ? availability : null,
    serviceIds: ids, // null => ne pas toucher, array => remplacer
  });

  if (!updated) throw new Error("Forfait introuvable.");
  return updated;
}

async function remove({ id }) {
  const ok = await bundlesRepo.remove({ id });
  if (!ok) throw new Error("Forfait introuvable.");
  return true;
}

module.exports = { list, create, update, remove };