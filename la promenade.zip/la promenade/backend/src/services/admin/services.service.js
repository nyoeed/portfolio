// src/services/admin/services.service.js
const servicesRepo = require("../../repositories/admin/services.repo");

const ALLOWED_CATS = ["Traiteur", "Audiovisuel", "Sécurité", "Logistique", "Autres"];
const ALLOWED_UNITS = ["par personne", "par jour", "par heure", "forfait", "par unité"];
const ALLOWED_AVAIL = ["available", "unavailable"];

async function getStats() {
  return servicesRepo.getStats();
}

async function list({ category }) {
  if (category && !ALLOWED_CATS.includes(category)) {
    // on peut soit refuser, soit ignorer. Ton ancien code refusait uniquement en create/update.
    // Ici on suit l’ancien list: accepte n'importe quoi => ça retourne vide. Donc pas de validation stricte.
  }
  return servicesRepo.list({ category });
}

async function create({ body, file }) {
  const { name, category, description, unitLabel, price, availability } = body || {};

  if (!name || !category || !unitLabel || price == null) {
    throw new Error("name, category, unitLabel, price requis.");
  }
  if (!ALLOWED_CATS.includes(category)) throw new Error("Catégorie invalide.");
  if (!ALLOWED_UNITS.includes(unitLabel)) throw new Error("unitLabel invalide.");

  const av = ALLOWED_AVAIL.includes(availability) ? availability : "available";
  const p = Number(price);
  if (!Number.isFinite(p) || p < 0) throw new Error("price invalide.");

  const imageUrl = file ? `/uploads/services/${file.filename}` : null;

  return servicesRepo.create({
    name: String(name).trim(),
    category: String(category).trim(),
    description: description ? String(description).trim() : null,
    unitLabel,
    price: p,
    availability: av,
    imageUrl,
  });
}

async function update({ id, body, file }) {
  const { name, category, description, unitLabel, price, availability } = body || {};

  if (category && !ALLOWED_CATS.includes(category)) throw new Error("Catégorie invalide.");
  if (unitLabel && !ALLOWED_UNITS.includes(unitLabel)) throw new Error("unitLabel invalide.");
  if (availability && !ALLOWED_AVAIL.includes(availability)) throw new Error("availability invalide.");

  const p = price != null ? Number(price) : null;
  if (price != null && (!Number.isFinite(p) || p < 0)) throw new Error("price invalide.");

  const imageUrl = file ? `/uploads/services/${file.filename}` : null;

  const updated = await servicesRepo.update({
    id,
    name: name != null ? String(name).trim() : null,
    category: category != null ? String(category).trim() : null,
    description: description != null ? String(description).trim() : null,
    unitLabel: unitLabel != null ? unitLabel : null,
    price: price != null ? p : null,
    availability: availability != null ? availability : null,
    imageUrl, // null si pas de fichier (repo fera COALESCE)
  });

  if (!updated) throw new Error("Service introuvable.");
  return updated;
}

async function remove({ id }) {
  const ok = await servicesRepo.remove({ id });
  if (!ok) throw new Error("Service introuvable.");
  return true;
}

module.exports = { getStats, list, create, update, remove };