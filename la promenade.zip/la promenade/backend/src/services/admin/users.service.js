// src/services/admin/users.service.js
const bcrypt = require("bcryptjs");
const usersRepo = require("../../repositories/admin/users.repo");
const { notifyRoles, notifyUser } = require("../notification-center.service");

const ALLOWED_ROLES = ["admin", "organizer", "coordinator", "accounting"];
const ALLOWED_STATUSES = ["approved", "rejected", "pending"];

const strongPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/;

async function listPending() {
  return usersRepo.listPending();
}

async function approveRequest({ id }) {
  const affected = await usersRepo.approveRequest({ id });
  if (!affected) {
    const err = new Error("Not found");
    err.code = "NOT_FOUND";
    throw err;
  }
  await notifyUser({
    recipientUserId: id,
    type: 'user',
    priority: 'normal',
    title: 'Compte approuvé',
    message: 'Votre compte a été approuvé. Vous pouvez maintenant vous connecter à la plateforme.',
    relatedEntity: 'user',
    relatedId: id,
    category: 'signup',
  });
  return true;
}

async function rejectRequest({ id }) {
  const affected = await usersRepo.rejectRequest({ id });
  if (!affected) {
    const err = new Error("Not found");
    err.code = "NOT_FOUND";
    throw err;
  }
  await notifyUser({
    recipientUserId: id,
    type: 'user',
    priority: 'urgent',
    title: 'Compte refusé',
    message: 'Votre demande a été refusée. Contactez l’administrateur pour plus d’informations.',
    relatedEntity: 'user',
    relatedId: id,
    category: 'signup',
  });
  return true;
}

async function listUsers(query) {
  const search = (query.search || "").trim();
  const role = (query.role || "").trim();
  const status = (query.status || "").trim();

  return usersRepo.listUsers({ search, role, status });
}

async function createUser(body) {
  const { fullName, email, password, role } = body || {};

  if (!fullName || !email || !password || !role) {
    throw new Error("Champs manquants");
  }

  if (!strongPassword.test(password)) {
    throw new Error(
      "Mot de passe trop faible (8 caractères, majuscule, minuscule, chiffre, caractère spécial requis)."
    );
  }

  if (!ALLOWED_ROLES.includes(role)) {
    throw new Error("Rôle invalide");
  }

  const cleanEmail = String(email).trim().toLowerCase();

  const exists = await usersRepo.existsByEmail({ email: cleanEmail });
  if (exists) {
    const err = new Error("Email déjà utilisé");
    err.code = "EMAIL_EXISTS";
    throw err;
  }

  const passwordHash = await bcrypt.hash(password, 10);

  const created = await usersRepo.createUser({
    fullName: String(fullName).trim(),
    email: cleanEmail,
    passwordHash,
    role,
  });

  await notifyRoles({
    roles: ['admin'],
    type: 'user',
    priority: 'normal',
    title: 'Nouvel utilisateur créé',
    message: `${created.fullName} (${created.role}) a été créé par l’administration.`,
    relatedEntity: 'user',
    relatedId: created.id,
    category: 'signup',
  });

  return created;
}

async function getUsersMeta() {
  const total = await usersRepo.countAll();
  return { total: Number(total || 0) };
}

async function updateUserStatus({ id, status }) {
  if (!ALLOWED_STATUSES.includes(status)) {
    throw new Error("Status invalide.");
  }

  const affected = await usersRepo.updateUserStatus({ id, status });
  if (!affected) {
    const err = new Error("Not found");
    err.code = "NOT_FOUND";
    throw err;
  }
  await notifyUser({
    recipientUserId: id,
    type: 'user',
    priority: status === 'rejected' ? 'urgent' : 'normal',
    title: 'Statut du compte mis à jour',
    message: `Le statut de votre compte est maintenant : ${status}.`,
    relatedEntity: 'user',
    relatedId: id,
    category: 'signup',
  });
  return true;
}

async function updateUserRole({ id, role }) {
  if (!ALLOWED_ROLES.includes(role)) throw new Error("Rôle invalide");

  const updated = await usersRepo.updateUserRole({ id, role });
  if (!updated) {
    const err = new Error("Not found");
    err.code = "NOT_FOUND";
    throw err;
  }
  return updated;
}

async function updateUser({ id, body }) {
  const { fullName, email, role } = body || {};

  if (!fullName || !email || !role) {
    throw new Error("fullName, email, role sont requis.");
  }
  if (!ALLOWED_ROLES.includes(role)) throw new Error("Rôle invalide");

  const cleanFullName = String(fullName).trim();
  const cleanEmail = String(email).trim().toLowerCase();

  const emailTaken = await usersRepo.emailTakenByAnotherUser({
    id,
    email: cleanEmail,
  });
  if (emailTaken) {
    const err = new Error("Email déjà utilisé");
    err.code = "EMAIL_EXISTS";
    throw err;
  }

  const updated = await usersRepo.updateUser({
    id,
    fullName: cleanFullName,
    email: cleanEmail,
    role,
  });

  if (!updated) {
    const err = new Error("Not found");
    err.code = "NOT_FOUND";
    throw err;
  }
  return updated;
}

async function deleteUser({ id, requesterId }) {
  if (requesterId && String(requesterId).toLowerCase() === String(id).toLowerCase()) {
    const err = new Error("Self delete");
    err.code = "SELF_DELETE";
    throw err;
  }

  const affected = await usersRepo.deleteUser({ id });
  if (!affected) {
    const err = new Error("Not found");
    err.code = "NOT_FOUND";
    throw err;
  }
  return true;
}

module.exports = {
  listPending,
  approveRequest,
  rejectRequest,
  listUsers,
  createUser,
  getUsersMeta,
  updateUserStatus,
  updateUserRole,
  updateUser,
  deleteUser,
};