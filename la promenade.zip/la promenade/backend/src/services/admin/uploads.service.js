// src/services/admin/uploads.service.js
const uploadsRepo = require("../../repositories/admin/uploads.repo");

async function updateRoomImage({ id, filename }) {
  const imageUrl = `/uploads/rooms/${filename}`;

  const updated = await uploadsRepo.updateRoomImage({
    id,
    imageUrl,
  });

  if (!updated) {
    throw new Error("Salle introuvable.");
  }

  return updated;
}

module.exports = { updateRoomImage };