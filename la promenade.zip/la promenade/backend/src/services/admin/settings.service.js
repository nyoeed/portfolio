// src/services/admin/settings.service.js
const settingsRepo = require("../../repositories/admin/settings.repo");

// utilitaires identiques à l’ancien
function asString(v, max = 200) {
  if (v == null) return null;
  const s = String(v).trim();
  if (!s) return null;
  return s.length > max ? s.slice(0, max) : s;
}
function asBool(v) {
  return v === true || v === 1 || v === "1" || v === "true" || v === "on";
}
function asNumber(v) {
  if (v == null || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}
function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function normalizeDbRow(x) {
  return {
    hotelName: x.hotelName,
    email: x.email,
    address: x.address || "",
    phone: x.phone || "",
    website: x.website || "",
    taxRate: Number(x.taxRate),
    paymentDelayDays: Number(x.paymentDelayDays),
    onlinePaymentEnabled: !!x.onlinePaymentEnabled,
    notifEvents: !!x.notifEvents,
    notifPayments: !!x.notifPayments,
    notifSignup: !!x.notifSignup,
    notifSystem: !!x.notifSystem,
    dailySummaryEnabled: !!x.dailySummaryEnabled,
    updatedAt: x.updatedAt,
    createdAt: x.createdAt,
  };
}

async function get() {
  const row = await settingsRepo.getFirst();
  if (!row) {
    // mêmes valeurs par défaut que l’ancien code
    return {
      hotelName: "Hôtel La Promenade",
      email: "contact@lapromenade.com",
      address: "",
      phone: "",
      website: "",
      taxRate: 20,
      paymentDelayDays: 30,
      onlinePaymentEnabled: true,
      notifEvents: true,
      notifPayments: true,
      notifSignup: true,
      notifSystem: true,
      dailySummaryEnabled: false,
    };
  }
  return normalizeDbRow(row);
}

async function upsert(body) {
  const hotelName = asString(body.hotelName, 120) || "Hôtel La Promenade";
  const email = asString(body.email, 120) || "contact@lapromenade.com";
  const address = asString(body.address, 200);
  const phone = asString(body.phone, 40);
  const website = asString(body.website, 200);

  let taxRate = asNumber(body.taxRate);
  if (taxRate == null) taxRate = 20;
  taxRate = clamp(taxRate, 0, 100);

  let paymentDelayDays = asNumber(body.paymentDelayDays);
  if (paymentDelayDays == null) paymentDelayDays = 30;
  paymentDelayDays = Math.trunc(clamp(paymentDelayDays, 0, 365));

  const onlinePaymentEnabled = asBool(body.onlinePaymentEnabled);

  const notifEvents = asBool(body.notifEvents);
  const notifPayments = asBool(body.notifPayments);
  const notifSignup = asBool(body.notifSignup);
  const notifSystem = asBool(body.notifSystem);
  const dailySummaryEnabled = asBool(body.dailySummaryEnabled);

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error("Email invalide.");
  }

  const row = await settingsRepo.upsertOne({
    hotelName,
    email,
    address,
    phone,
    website,
    taxRate,
    paymentDelayDays,
    onlinePaymentEnabled,
    notifEvents,
    notifPayments,
    notifSignup,
    notifSystem,
    dailySummaryEnabled,
  });

  return normalizeDbRow(row);
}

module.exports = { get, upsert };