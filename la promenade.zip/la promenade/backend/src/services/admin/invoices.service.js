// src/services/admin/invoices.service.js
// Facturation & paiements (module Invoices)

const PDFDocument = require("pdfkit");
const invoicesRepo = require("../../repositories/admin/invoices.repo");

function mapStatusForUi(dbStatus) {
  // DB: paid | pending | late
  // UI: paid | pending | overdue
  if (dbStatus === "late") return "overdue";
  if (dbStatus === "paid") return "paid";
  return "pending";
}

function ensurePositiveMoney(n, label) {
  const x = Number(n);
  if (!Number.isFinite(x) || x <= 0) {
    const e = new Error(`${label} invalide`);
    e.status = 400;
    throw e;
  }
  return Math.round(x * 100) / 100;
}

function toIso(d) {
  if (!d) return null;
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return null;
  return dt.toISOString();
}

async function getStats({ from, to } = {}) {
  return invoicesRepo.getStats({ from, to });
}

async function listInvoices({ from, to, eventId, status } = {}) {
  const rows = await invoicesRepo.listInvoices({ from, to, eventId, status });
  return rows.map((r) => ({
    id: r.invoiceNumber,
    guid: r.id,
    eventName: r.eventTitle,
    clientName: r.clientName,
    date: toIso(r.issuedAt),
    dueDate: toIso(r.dueAt),
    amount: Number(r.amount || 0),
    status: mapStatusForUi(r.statusComputed || r.status),
  }));
}

async function listPayments({ from, to } = {}) {
  const rows = await invoicesRepo.listPayments({ from, to });
  return rows.map((r) => ({
    id: r.id,
    invoiceId: r.invoiceNumber,
    invoiceGuid: r.invoiceId,
    clientName: r.clientName,
    amount: Number(r.amount || 0),
    paidAt: toIso(r.paidAt),
    method: r.method,
    provider: r.provider || null,
    reference: r.reference || null,
  }));
}

async function listRefunds({ from, to } = {}) {
  const rows = await invoicesRepo.listRefunds({ from, to });
  return rows.map((r) => ({
    id: r.id,
    invoiceId: r.invoiceNumber,
    invoiceGuid: r.invoiceId,
    clientName: r.clientName,
    amount: -Math.abs(Number(r.amount || 0)),
    date: toIso(r.createdAt),
    reason: r.reason,
    status: r.status,
  }));
}

async function getInvoiceDetails(invoiceGuid) {
  const x = await invoicesRepo.getInvoiceDetails(invoiceGuid);
  if (!x) {
    const e = new Error("Facture introuvable.");
    e.status = 404;
    throw e;
  }
  return {
    ...x,
    status: mapStatusForUi(x.statusComputed || x.status),
  };
}

async function generateInvoiceForEvent({ eventId, clientName, dueAt } = {}) {
  if (!eventId) {
    const e = new Error("eventId requis");
    e.status = 400;
    throw e;
  }
  return invoicesRepo.generateInvoiceForEvent({
    eventId,
    clientName: clientName ? String(clientName) : null,
    dueAt: dueAt || null,
  });
}

async function createPayment(invoiceGuid, payload) {
  const amount = ensurePositiveMoney(payload?.amount, "Montant");
  const method = String(payload?.method || "Carte bancaire");
  const provider = payload?.provider ? String(payload.provider) : "manual";
  const reference = payload?.reference ? String(payload.reference) : null;
  const paidAt = payload?.paidAt || null;
  return invoicesRepo.createPayment(invoiceGuid, { amount, method, provider, reference, paidAt });
}

async function createRefund(invoiceGuid, payload) {
  const amount = ensurePositiveMoney(payload?.amount, "Montant");
  const reason = payload?.reason ? String(payload.reason) : null;
  const status = payload?.status ? String(payload.status) : "processed";
  return invoicesRepo.createRefund(invoiceGuid, { amount, reason, status });
}

// Online payment (mock provider)
async function createOnlineCheckout(invoiceGuid, payload) {
  const amount = payload?.amount ? ensurePositiveMoney(payload.amount, "Montant") : null;
  return invoicesRepo.createOnlineCheckout(invoiceGuid, { amount });
}

async function confirmOnlineCheckout(sessionId) {
  if (!sessionId) {
    const e = new Error("sessionId requis");
    e.status = 400;
    throw e;
  }
  return invoicesRepo.confirmOnlineCheckout(String(sessionId));
}

// --- PDF helpers ---
function docToBuffer(doc) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    doc.on("data", (c) => chunks.push(c));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
    doc.end();
  });
}

function moneyFmt(n, currency = "$") {
  const v = Number(n || 0);
  return `${v.toFixed(2)} ${currency}`;
}

function dateFmtFR(d) {
  if (!d) return "—";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return "—";
  return dt.toLocaleDateString("fr-CA", { year: "numeric", month: "short", day: "2-digit" });
}

async function generateInvoicePdf(invoiceGuid) {
  const invoice = await invoicesRepo.getInvoiceForPdf(invoiceGuid);
  if (!invoice) {
    const e = new Error("Facture introuvable.");
    e.status = 404;
    throw e;
  }

  const doc = new PDFDocument({ size: "A4", margin: 48 });

  // Header
  doc.fontSize(18).text(invoice.hotelName || "Hôtel La Promenade", { align: "left" });
  doc.fontSize(10).fillColor("#444");
  if (invoice.hotelAddress) doc.text(invoice.hotelAddress, { align: "left" });
  if (invoice.hotelEmail) doc.text(`Email: ${invoice.hotelEmail}`, { align: "left" });
  if (invoice.hotelPhone) doc.text(`Téléphone: ${invoice.hotelPhone}`, { align: "left" });
  doc.fillColor("#000");
  doc.moveDown(1);

  doc.fontSize(14).text("FACTURE", { align: "right" });
  doc.fontSize(10).fillColor("#444").text(`N° ${invoice.invoiceNumber}`, { align: "right" });
  doc.fillColor("#000");
  doc.moveDown(0.5);

  // Client & event
  doc.fontSize(11).text(`Client: ${invoice.clientName || "—"}`);
  doc.text(`Événement: ${invoice.eventName || "—"}`);
  doc.text(`Date d'émission: ${dateFmtFR(invoice.issuedAt)}`);
  doc.text(`Échéance: ${dateFmtFR(invoice.dueAt)}`);
  doc.moveDown(1);

  // Items
  doc.fontSize(11).text("Détails", { underline: true });
  doc.moveDown(0.5);

  const startX = doc.x;
  const colLabel = startX;
  const colQty = startX + 280;
  const colUnit = startX + 340;
  const colTotal = startX + 440;

  doc.fontSize(9).fillColor("#666");
  doc.text("Description", colLabel, doc.y, { continued: false });
  doc.text("Qté", colQty, doc.y - 9);
  doc.text("PU", colUnit, doc.y - 9);
  doc.text("Total", colTotal, doc.y - 9);
  doc.fillColor("#000");
  doc.moveDown(0.4);

  const items = invoice.items || [];
  if (!items.length) {
    doc.fontSize(10).fillColor("#444").text("Aucun détail disponible.");
    doc.fillColor("#000");
  } else {
    items.forEach((it) => {
      const y = doc.y;
      doc.fontSize(10).text(it.label, colLabel, y, { width: 270 });
      doc.text(String(it.quantity ?? 1), colQty, y);
      doc.text(moneyFmt(it.unitPrice), colUnit, y);
      doc.text(moneyFmt(it.total), colTotal, y);
      doc.moveDown(0.3);
    });
  }

  doc.moveDown(1);
  doc.fontSize(10);
  doc.text(`Sous-total: ${moneyFmt(invoice.subtotal)}`, { align: "right" });
  doc.text(`TVA (${Number(invoice.taxRate || 0).toFixed(2)}%): ${moneyFmt(invoice.taxAmount)}`, { align: "right" });
  doc.fontSize(12).text(`TOTAL: ${moneyFmt(invoice.total)}`, { align: "right" });
  doc.moveDown(1);

  // Payments
  doc.fontSize(11).text("Paiements", { underline: true });
  doc.moveDown(0.4);
  const pays = invoice.payments || [];
  if (!pays.length) {
    doc.fontSize(10).fillColor("#444").text("Aucun paiement enregistré.");
    doc.fillColor("#000");
  } else {
    pays.forEach((p) => {
      doc.fontSize(10).text(`- ${dateFmtFR(p.paidAt)} • ${p.method} • ${moneyFmt(p.amount)}`);
    });
  }
  doc.moveDown(0.6);
  doc.fontSize(10).text(`Total payé: ${moneyFmt(invoice.totalPaid)}`, { align: "right" });
  doc.text(`Solde: ${moneyFmt(invoice.balance)}`, { align: "right" });

  doc.moveDown(2);
  doc.fontSize(9).fillColor("#666").text("Document généré automatiquement.", { align: "center" });

  const buffer = await docToBuffer(doc);
  return { buffer, filename: `${invoice.invoiceNumber}.pdf` };
}

async function generateReceiptPdf(invoiceGuid) {
  const receipt = await invoicesRepo.getReceiptForPdf(invoiceGuid);
  if (!receipt) {
    const e = new Error("Aucun paiement trouvé pour générer un reçu.");
    e.status = 400;
    throw e;
  }

  const doc = new PDFDocument({ size: "A4", margin: 48 });

  doc.fontSize(18).text(receipt.hotelName || "Hôtel La Promenade");
  doc.moveDown(0.4);
  doc.fontSize(12).fillColor("#444").text("REÇU DE PAIEMENT");
  doc.fillColor("#000");
  doc.moveDown(1);

  doc.fontSize(11).text(`Facture: ${receipt.invoiceNumber}`);
  doc.text(`Client: ${receipt.clientName || "—"}`);
  doc.text(`Montant: ${moneyFmt(receipt.amount)}`);
  doc.text(`Méthode: ${receipt.method}`);
  doc.text(`Date: ${dateFmtFR(receipt.paidAt)}`);
  if (receipt.reference) doc.text(`Référence: ${receipt.reference}`);

  doc.moveDown(2);
  doc.fontSize(10).fillColor("#666").text("Merci pour votre paiement.", { align: "center" });

  const buffer = await docToBuffer(doc);
  return { buffer, filename: `RECEIPT_${receipt.invoiceNumber}.pdf` };
}

module.exports = {
  getStats,
  listInvoices,
  listPayments,
  listRefunds,
  getInvoiceDetails,
  generateInvoiceForEvent,
  createPayment,
  createRefund,
  createOnlineCheckout,
  confirmOnlineCheckout,
  generateInvoicePdf,
  generateReceiptPdf,
};
