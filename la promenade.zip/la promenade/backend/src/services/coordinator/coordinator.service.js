const repo = require('../../repositories/coordinator/coordinator.repo');

const EVENT_STATUSES = ['draft','submitted','in_review','validated','confirmed','in_coordination','in_progress','completed','cancelled'];
const SERVICE_STATUSES = ['requested','in_analysis','approved','planned','in_progress','completed','refused','cancelled'];
const PRIORITIES = ['low','medium','high','critical'];
const TASK_STATUSES = ['todo','in_progress','blocked','done','cancelled'];

function assertAllowed(value, allowed, label) {
  if (!allowed.includes(value)) throw new Error(`${label} invalide.`);
}
function maybeDate(value) {
  if (value == null || value === '') return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) throw new Error('Date invalide.');
  return d;
}

async function getDashboard(user) {
  return repo.getDashboard(user.id);
}

async function listEvents(user, query) {
  return repo.listEvents({
    userId: user.id,
    status: query.status || null,
    roomId: query.roomId || null,
    type: query.type || null,
    search: query.search || null,
  });
}

async function getEventDetail(user, eventId) {
  const detail = await repo.getEventDetail({ userId: user.id, eventId });
  if (!detail.event) throw new Error('Événement introuvable.');
  return detail;
}

async function updateEventStatus(user, eventId, body) {
  const status = body?.status;
  assertAllowed(status, EVENT_STATUSES, 'Statut événement');
  const updated = await repo.updateEventStatus({ userId: user.id, eventId, status });
  if (!updated) throw new Error('Événement introuvable.');
  const stakeholders = await repo.getEventStakeholders(eventId);
  await repo.logAudit({
    entityType: 'event',
    entityId: eventId,
    actionType: 'status_changed',
    actorUserId: user.id,
    actorRole: user.role,
    summary: `Statut événement mis à jour vers ${status}`,
    detailsJson: JSON.stringify({ status }),
  });
  await repo.createNotification({
    recipientUserId: stakeholders?.organizerId || null,
    type: 'event',
    priority: status === 'cancelled' ? 'urgent' : 'normal',
    title: `Événement ${updated.title} : ${status}`,
    message: `Le coordonnateur a mis à jour le statut de l'événement vers ${status}.`,
    relatedEntity: 'event',
    relatedId: eventId,
    category: 'coordination',
  });
  return updated;
}

async function addEventNote(user, eventId, body) {
  if (!body?.content?.trim()) throw new Error('Le contenu de la note est requis.');
  const note = await repo.addEventNote({
    userId: user.id,
    eventId,
    authorUserId: user.id,
    content: body.content.trim(),
    noteType: body.noteType || 'internal',
  });
  await repo.logAudit({
    entityType: 'event',
    entityId: eventId,
    actionType: 'note_added',
    actorUserId: user.id,
    actorRole: user.role,
    summary: 'Note interne ajoutée',
    detailsJson: JSON.stringify({ noteType: body.noteType || 'internal' }),
  });
  return note;
}

async function listRoomsCalendar(user, query) {
  const from = maybeDate(query.from) || new Date();
  const to = maybeDate(query.to) || new Date(Date.now() + 1000 * 60 * 60 * 24 * 14);
  return repo.listRoomsCalendar({ userId: user.id, from, to });
}

async function listConflicts() {
  return repo.listConflicts();
}

async function updateReservationStatus(user, reservationId, body) {
  const status = body?.status;
  assertAllowed(status, ['pending','locked','confirmed','cancelled'], 'Statut réservation');
  const updated = await repo.updateReservationStatus({ reservationId, status, userId: user.id });
  if (!updated?.reservation) throw new Error('Réservation introuvable.');
  await repo.logAudit({
    entityType: 'reservation',
    entityId: reservationId,
    actionType: 'reservation_status_changed',
    actorUserId: user.id,
    actorRole: user.role,
    summary: `Réservation passée à ${status}`,
    detailsJson: JSON.stringify({ reservationId, status }),
  });
  return updated.reservation;
}

async function listServiceRequests(user, query) {
  return repo.listServiceRequests({
    userId: user.id,
    category: query.category || null,
    status: query.status || null,
    eventId: query.eventId || null,
  });
}

async function updateServiceRequest(user, serviceRequestId, body) {
  const patch = {};
  if (body.status != null) {
    assertAllowed(body.status, SERVICE_STATUSES, 'Statut service');
    patch.status = body.status;
  }
  if (body.priority != null) {
    assertAllowed(body.priority, PRIORITIES, 'Priorité');
    patch.priority = body.priority;
  }
  if (body.quantity != null) patch.quantity = Number(body.quantity);
  if (body.estimatedAmount != null) patch.estimatedAmount = Number(body.estimatedAmount);
  if (body.locationNote != null) patch.locationNote = body.locationNote;
  if (body.remarks != null) patch.remarks = body.remarks;
  if (body.assignedToUserId != null) patch.assignedToUserId = body.assignedToUserId || null;
  if (body.plannedStartAt !== undefined) patch.plannedStartAt = maybeDate(body.plannedStartAt);
  if (body.plannedEndAt !== undefined) patch.plannedEndAt = maybeDate(body.plannedEndAt);

  const updated = await repo.updateServiceRequest({ userId: user.id, serviceRequestId, patch });
  if (!updated) throw new Error('Demande de service introuvable.');
  const stakeholders = await repo.getEventStakeholders(updated.eventId);
  await repo.logAudit({
    entityType: 'service_request',
    entityId: serviceRequestId,
    actionType: 'service_request_updated',
    actorUserId: user.id,
    actorRole: user.role,
    summary: 'Demande de service mise à jour',
    detailsJson: JSON.stringify(patch),
  });
  await repo.createNotification({
    recipientUserId: stakeholders?.organizerId || null,
    type: 'service_request',
    priority: ['refused'].includes(updated.status) ? 'high' : 'normal',
    title: `Service ${updated.status}`,
    message: `Le service demandé pour l’événement « ${stakeholders?.title || 'événement'} » est maintenant au statut ${updated.status}.`,
    relatedEntity: 'service_request',
    relatedId: serviceRequestId,
    category: 'services',
  });
  return updated;
}

async function createTask(user, body) {
  if (!body?.eventId) throw new Error('eventId requis.');
  if (!body?.title?.trim()) throw new Error('Le titre de la tâche est requis.');
  const priority = body.priority || 'medium';
  assertAllowed(priority, PRIORITIES, 'Priorité');
  const task = await repo.createTask({
    userId: user.id,
    eventId: body.eventId,
    createdByUserId: user.id,
    assignedToUserId: body.assignedToUserId || null,
    title: body.title.trim(),
    description: body.description || null,
    dueAt: maybeDate(body.dueAt),
    priority,
    category: body.category || 'checklist',
  });
  await repo.logAudit({
    entityType: 'task',
    entityId: task.id,
    actionType: 'task_created',
    actorUserId: user.id,
    actorRole: user.role,
    summary: `Nouvelle tâche: ${task.title}`,
    detailsJson: JSON.stringify({ eventId: body.eventId }),
  });
  return task;
}

async function updateTask(user, taskId, body) {
  const patch = {};
  for (const key of ['title','description','assignedToUserId','category']) {
    if (body[key] !== undefined) patch[key] = body[key] || null;
  }
  if (body.dueAt !== undefined) patch.dueAt = maybeDate(body.dueAt);
  if (body.priority !== undefined) {
    assertAllowed(body.priority, PRIORITIES, 'Priorité');
    patch.priority = body.priority;
  }
  if (body.status !== undefined) {
    assertAllowed(body.status, TASK_STATUSES, 'Statut tâche');
    patch.status = body.status;
  }
  const updated = await repo.updateTask({ taskId, patch });
  if (!updated) throw new Error('Tâche introuvable.');
  await repo.logAudit({
    entityType: 'task',
    entityId: taskId,
    actionType: 'task_updated',
    actorUserId: user.id,
    actorRole: user.role,
    summary: 'Tâche mise à jour',
    detailsJson: JSON.stringify(patch),
  });
  return updated;
}

async function listNotifications(user, query) {
  return repo.listNotifications({ userId: user.id, unreadOnly: String(query.unreadOnly || '') === 'true' });
}

async function markNotificationRead(user, notificationId) {
  const updated = await repo.markNotificationRead({ notificationId, userId: user.id });
  if (!updated) throw new Error('Notification introuvable.');
  return updated;
}

async function upsertReport(user, eventId, body) {
  const report = await repo.upsertReport({
    userId: user.id,
    eventId,
    createdByUserId: user.id,
    finalParticipants: Number(body.finalParticipants || 0),
    serviceExecutionScore: body.serviceExecutionScore == null ? null : Number(body.serviceExecutionScore),
    incidentCount: Number(body.incidentCount || 0),
    operationsComment: body.operationsComment,
    incidentsComment: body.incidentsComment,
    satisfactionComment: body.satisfactionComment,
  });
  await repo.logAudit({
    entityType: 'event',
    entityId: eventId,
    actionType: 'report_saved',
    actorUserId: user.id,
    actorRole: user.role,
    summary: 'Rapport post-événement sauvegardé',
    detailsJson: JSON.stringify({ incidentCount: report.incidentCount, finalParticipants: report.finalParticipants }),
  });
  return report;
}

async function listReports(user) {
  return repo.listReports({ userId: user.id });
}

async function saveDocument(user, eventId, body, file) {
  if (!file) throw new Error('Aucun fichier reçu.');
  const doc = await repo.insertDocument({
    userId: user.id,
    eventId,
    uploadedByUserId: user.id,
    category: body.category || 'piece_jointe',
    title: body.title?.trim() || file.originalname,
    fileName: file.filename,
    filePath: `/uploads/events/${eventId}/${file.filename}`,
    mimeType: file.mimetype,
    fileSizeBytes: file.size,
  });
  await repo.logAudit({
    entityType: 'event',
    entityId: eventId,
    actionType: 'document_uploaded',
    actorUserId: user.id,
    actorRole: user.role,
    summary: `Document téléversé: ${doc.title}`,
    detailsJson: JSON.stringify({ category: doc.category, fileName: doc.fileName }),
  });
  const stakeholders = await repo.getEventStakeholders(eventId);
  await repo.createNotification({
    recipientUserId: stakeholders?.organizerId || null,
    type: 'event',
    priority: 'normal',
    title: 'Nouveau document ajouté',
    message: `Le document ${doc.title} a été ajouté à l’événement « ${stakeholders?.title || 'événement'} ».`,
    relatedEntity: 'event_document',
    relatedId: doc.id,
    category: 'documents',
  });
  return doc;
}

module.exports = {
  getDashboard,
  listEvents,
  getEventDetail,
  updateEventStatus,
  addEventNote,
  listRoomsCalendar,
  listConflicts,
  updateReservationStatus,
  listServiceRequests,
  updateServiceRequest,
  createTask,
  updateTask,
  listNotifications,
  markNotificationRead,
  upsertReport,
  listReports,
  saveDocument,
};
