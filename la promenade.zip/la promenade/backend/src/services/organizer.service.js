const repo = require('../repositories/organizer.repo');

const EVENT_MUTABLE_STATUSES = new Set(['draft', 'submitted', 'in_review']);
const EVENT_CANCELLABLE_STATUSES = new Set(['draft', 'submitted', 'in_review', 'validated', 'confirmed']);
const EVENT_SERVICE_ELIGIBLE_STATUSES = new Set(['submitted', 'in_review', 'validated', 'confirmed', 'in_coordination', 'in_progress']);
const RSVP_STATUSES = new Set(['pending', 'confirmed', 'declined']);
const ALLOWED_DOCUMENT_MIME_TYPES = new Set([
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/jpg',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'text/plain',
]);

function createError(message, statusCode = 400) {
  const err = new Error(message);
  err.statusCode = statusCode;
  return err;
}

function requireFields(data, fields) {
  for (const field of fields) {
    if (data[field] == null || data[field] === '') {
      throw createError(`Champ requis manquant: ${field}`, 400);
    }
  }
}

function trimString(value) {
  if (value == null) return '';
  return String(value).trim();
}

function optionalString(value) {
  const trimmed = trimString(value);
  return trimmed || null;
}

function toNonNegativeNumber(value, field, { allowEmpty = true, decimals = false } = {}) {
  if (value == null || value === '') {
    if (allowEmpty) return 0;
    throw createError(`Champ requis manquant: ${field}`, 400);
  }
  const parsed = decimals ? Number(value) : Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) {
    throw createError(`Valeur invalide pour ${field}.`, 400);
  }
  if (parsed < 0) {
    throw createError(`${field} ne peut pas être négatif.`, 400);
  }
  return parsed;
}

function toBoolean(value, fallback = false) {
  if (value == null) return fallback;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') return ['true', '1', 'yes', 'on'].includes(value.toLowerCase());
  return Boolean(value);
}

function validateIsoDateOrder(startAt, endAt) {
  const start = new Date(startAt);
  const end = new Date(endAt);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    throw createError('Les dates de début et de fin sont invalides.', 400);
  }
  if (start >= end) {
    throw createError('La date de fin doit être après la date de début.', 400);
  }
  return { startAt: start.toISOString(), endAt: end.toISOString() };
}

function normalizeServiceRequests(data = {}) {
  const raw = Array.isArray(data.serviceRequests)
    ? data.serviceRequests
    : Array.isArray(data.serviceIds)
      ? data.serviceIds.map((serviceId) => ({ serviceId }))
      : [];

  return raw
    .map((item) => {
      if (!item) return null;
      const serviceId = typeof item === 'string' ? item : item.serviceId;
      if (!serviceId) return null;
      const quantity = Number(item.quantity ?? 1);
      if (!Number.isFinite(quantity) || quantity <= 0) {
        throw createError('Chaque service doit avoir une quantité valide supérieure à 0.', 400);
      }
      return {
        serviceId,
        quantity,
        remarks: optionalString(item.remarks),
      };
    })
    .filter(Boolean);
}

function validateEmail(value, field = 'email', { required = false } = {}) {
  const normalized = optionalString(value);
  if (!normalized) {
    if (required) throw createError(`Champ requis manquant: ${field}`, 400);
    return null;
  }
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized);
  if (!ok) {
    throw createError(`Format invalide pour ${field}.`, 400);
  }
  return normalized.toLowerCase();
}

async function ensureEventAllowed(userId, eventId, allowedStatuses, actionLabel) {
  const event = await repo.getEvent(userId, eventId);
  if (!event) {
    throw createError('Événement introuvable.', 404);
  }
  if (!allowedStatuses.has(event.status)) {
    throw createError(`Cet événement ne peut pas être ${actionLabel} dans son état actuel.`, 409);
  }
  return event;
}

function normalizeEventPayload(data = {}) {
  requireFields(data, ['title', 'startAt', 'endAt']);
  const title = trimString(data.title);
  if (title.length < 3) {
    throw createError('Le titre doit contenir au moins 3 caractères.', 400);
  }

  const { startAt, endAt } = validateIsoDateOrder(data.startAt, data.endAt);
  const participants = toNonNegativeNumber(data.participants, 'participants', { allowEmpty: true, decimals: false });
  const budget = toNonNegativeNumber(data.budget, 'budget', { allowEmpty: true, decimals: true });

  return {
    title,
    type: optionalString(data.type),
    description: optionalString(data.description),
    participants,
    budget,
    roomId: data.roomId || null,
    startAt,
    endAt,
    submit: toBoolean(data.submit, false),
    serviceRequests: normalizeServiceRequests(data),
  };
}

function normalizeGuestPayload(data = {}, { requireEventId = true } = {}) {
  if (requireEventId) requireFields(data, ['eventId', 'firstName', 'lastName']);
  else requireFields(data, ['firstName', 'lastName']);

  const firstName = trimString(data.firstName);
  const lastName = trimString(data.lastName);
  if (firstName.length < 2 || lastName.length < 2) {
    throw createError('Le prénom et le nom doivent contenir au moins 2 caractères.', 400);
  }

  const rsvpStatus = optionalString(data.rsvpStatus) || 'pending';
  if (!RSVP_STATUSES.has(rsvpStatus)) {
    throw createError('Statut RSVP invalide.', 400);
  }

  return {
    eventId: data.eventId || null,
    firstName,
    lastName,
    email: validateEmail(data.email, 'email', { required: false }),
    phone: optionalString(data.phone),
    company: optionalString(data.company),
    rsvpStatus,
    dietaryNotes: optionalString(data.dietaryNotes),
    specialNeeds: optionalString(data.specialNeeds),
    plusOne: toBoolean(data.plusOne, false),
    notes: optionalString(data.notes),
  };
}

function normalizeProfilePayload(data = {}) {
  requireFields(data, ['fullName']);
  const fullName = trimString(data.fullName);
  if (fullName.length < 3) {
    throw createError('Le nom complet doit contenir au moins 3 caractères.', 400);
  }

  return {
    fullName,
    email: validateEmail(data.email, 'email', { required: false }),
    phone: optionalString(data.phone),
    organization: optionalString(data.organization),
    jobTitle: optionalString(data.jobTitle),
    addressLine: optionalString(data.addressLine),
    postalCode: optionalString(data.postalCode),
    city: optionalString(data.city),
    country: optionalString(data.country),
    notificationEmailEnabled: toBoolean(data.notificationEmailEnabled, true),
    notificationSmsEnabled: toBoolean(data.notificationSmsEnabled, false),
    notificationInAppEnabled: toBoolean(data.notificationInAppEnabled, true),
  };
}

module.exports = {
  getDashboard: (userId) => repo.getDashboard(userId),
  listEvents: (userId, filters) => repo.listEvents(userId, filters),
  getEvent: async (userId, eventId) => {
    const row = await repo.getEvent(userId, eventId);
    if (!row) {
      throw createError('Événement introuvable.', 404);
    }
    return row;
  },
  createEvent: async (userId, data) => {
    const payload = normalizeEventPayload(data);
    return repo.createEvent(userId, payload);
  },
  updateEvent: async (userId, eventId, data) => {
    const existing = await ensureEventAllowed(userId, eventId, EVENT_MUTABLE_STATUSES, 'modifié');
    const payload = normalizeEventPayload({
      ...existing,
      ...data,
      submit: data.submit == null ? existing.status !== 'draft' : data.submit,
    });
    const row = await repo.updateEvent(userId, eventId, payload);
    if (!row) {
      throw createError('Impossible de modifier cet événement.', 404);
    }
    return row;
  },
  cancelEvent: async (userId, eventId) => {
    await ensureEventAllowed(userId, eventId, EVENT_CANCELLABLE_STATUSES, 'annulé');
    const ok = await repo.cancelEvent(userId, eventId);
    if (!ok) {
      throw createError('Événement introuvable.', 404);
    }
    return { success: true };
  },
  listRooms: (filters) => repo.listRooms(filters),
  getCalendar: (roomId) => repo.getCalendar(roomId),
  listReservations: (userId) => repo.listReservations(userId),
  listServices: (userId, category) => repo.listServices(userId, category),
  listServiceCatalog: (category) => repo.listServiceCatalog(category),
  createServiceRequest: async (userId, data) => {
    requireFields(data, ['eventId', 'serviceId']);
    await ensureEventAllowed(userId, data.eventId, EVENT_SERVICE_ELIGIBLE_STATUSES, 'utilisé pour une demande de service');
    const quantity = toNonNegativeNumber(data.quantity ?? 1, 'quantity', { allowEmpty: false, decimals: true });
    if (quantity <= 0) {
      throw createError('La quantité doit être supérieure à 0.', 400);
    }
    const row = await repo.createServiceRequest(userId, {
      eventId: data.eventId,
      serviceId: data.serviceId,
      quantity,
      remarks: optionalString(data.remarks),
    });
    if (!row) {
      throw createError('Événement introuvable pour cette demande.', 404);
    }
    return row;
  },
  listGuests: (userId, eventId) => repo.listGuests(userId, eventId),
  createGuest: async (userId, data) => {
    const payload = normalizeGuestPayload(data, { requireEventId: true });
    const row = await repo.createGuest(userId, payload);
    if (!row) {
      throw createError('Impossible d’ajouter cet invité.', 404);
    }
    return row;
  },
  updateGuest: async (userId, guestId, data) => {
    const payload = normalizeGuestPayload(data, { requireEventId: false });
    const row = await repo.updateGuest(userId, guestId, payload);
    if (!row) {
      throw createError('Invité introuvable.', 404);
    }
    return row;
  },
  deleteGuest: async (userId, guestId) => {
    const ok = await repo.deleteGuest(userId, guestId);
    if (!ok) {
      throw createError('Invité introuvable.', 404);
    }
    return { success: true };
  },
  listDocuments: (userId, eventId) => repo.listDocuments(userId, eventId),
  createDocument: async (userId, data) => {
    requireFields(data, ['eventId', 'title', 'fileName', 'filePath', 'mimeType']);
    const title = trimString(data.title);
    if (title.length < 2) {
      throw createError('Le titre du document est trop court.', 400);
    }
    if (!ALLOWED_DOCUMENT_MIME_TYPES.has(data.mimeType)) {
      throw createError('Type de document non autorisé.', 400);
    }
    const row = await repo.createDocument(userId, {
      ...data,
      title,
      category: optionalString(data.category) || 'piece_jointe',
    });
    if (!row) {
      throw createError('Impossible d’ajouter ce document.', 404);
    }
    return row;
  },
  deleteDocument: async (userId, docId) => {
    const ok = await repo.deleteDocument(userId, docId);
    if (!ok) {
      throw createError('Document introuvable.', 404);
    }
    return { success: true };
  },
  getBilling: (userId) => repo.getBilling(userId),
  createSimulatedPayment: async (userId, data) => {
    requireFields(data, ['invoiceId']);
    const amount = Number(data.amount || 0);
    if (!Number.isFinite(amount) || amount <= 0) {
      throw createError('Le montant doit être supérieur à 0.', 400);
    }
    return repo.createSimulatedPayment(userId, {
      invoiceId: Number(data.invoiceId),
      amount,
      method: optionalString(data.method) || 'Virement bancaire',
      reference: optionalString(data.reference),
    });
  },
  getReports: (userId, eventId) => repo.getReports(userId, eventId),
  getProfile: async (userId) => {
    const row = await repo.getProfile(userId);
    if (!row) {
      throw createError('Profil introuvable.', 404);
    }
    return row;
  },
  updateProfile: async (userId, data) => {
    const row = await repo.updateProfile(userId, normalizeProfilePayload(data));
    if (!row) {
      throw createError('Profil introuvable.', 404);
    }
    return row;
  },
  listNotifications: (userId) => repo.listNotifications(userId),
  markNotificationRead: async (userId, notificationId) => {
    const ok = await repo.markNotificationRead(userId, notificationId);
    if (!ok) {
      throw createError('Notification introuvable.', 404);
    }
    return { success: true };
  },
};
