const path = require('path');
const organizerService = require('../services/organizer.service');

function userId(req) {
  return req.user.id;
}

async function wrap(resolver, req, res, next) {
  try {
    const data = await resolver();
    res.json(data);
  } catch (e) {
    next(e);
  }
}

module.exports = {
  getDashboard: (req, res, next) => wrap(() => organizerService.getDashboard(userId(req)), req, res, next),
  listEvents: (req, res, next) => wrap(() => organizerService.listEvents(userId(req), req.query), req, res, next),
  getEvent: (req, res, next) => wrap(() => organizerService.getEvent(userId(req), req.params.id), req, res, next),
  createEvent: (req, res, next) => wrap(() => organizerService.createEvent(userId(req), req.body || {}), req, res, next),
  updateEvent: (req, res, next) => wrap(() => organizerService.updateEvent(userId(req), req.params.id, req.body || {}), req, res, next),
  cancelEvent: (req, res, next) => wrap(() => organizerService.cancelEvent(userId(req), req.params.id), req, res, next),
  listRooms: (req, res, next) => wrap(() => organizerService.listRooms(req.query || {}), req, res, next),
  getCalendar: (req, res, next) => wrap(() => organizerService.getCalendar(req.query.roomId || null), req, res, next),
  listReservations: (req, res, next) => wrap(() => organizerService.listReservations(userId(req)), req, res, next),
  listServices: (req, res, next) => wrap(() => organizerService.listServices(userId(req), { category: req.query.category || null, eventId: req.query.eventId || null }), req, res, next),
  listServiceCatalog: (req, res, next) => wrap(() => organizerService.listServiceCatalog(req.query.category || null), req, res, next),
  createServiceRequest: (req, res, next) => wrap(() => organizerService.createServiceRequest(userId(req), req.body || {}), req, res, next),
  listGuests: (req, res, next) => wrap(() => organizerService.listGuests(userId(req), req.query.eventId || null), req, res, next),
  createGuest: (req, res, next) => wrap(() => organizerService.createGuest(userId(req), req.body || {}), req, res, next),
  updateGuest: (req, res, next) => wrap(() => organizerService.updateGuest(userId(req), req.params.id, req.body || {}), req, res, next),
  deleteGuest: (req, res, next) => wrap(() => organizerService.deleteGuest(userId(req), req.params.id), req, res, next),
  listDocuments: (req, res, next) => wrap(() => organizerService.listDocuments(userId(req), req.query.eventId || null), req, res, next),
  uploadDocument: (req, res, next) => wrap(() => organizerService.createDocument(userId(req), {
    eventId: req.body.eventId,
    category: req.body.category,
    title: req.body.title || req.file?.originalname,
    fileName: req.file?.originalname,
    filePath: req.file ? `/uploads/organizer-documents/${req.file.filename}` : null,
    mimeType: req.file?.mimetype,
    fileSizeBytes: req.file?.size,
  }), req, res, next),
  deleteDocument: (req, res, next) => wrap(() => organizerService.deleteDocument(userId(req), req.params.id), req, res, next),
  getBilling: (req, res, next) => wrap(() => organizerService.getBilling(userId(req)), req, res, next),
  createSimulatedPayment: (req, res, next) => wrap(() => organizerService.createSimulatedPayment(userId(req), req.body || {}), req, res, next),
  getReports: (req, res, next) => wrap(() => organizerService.getReports(userId(req), req.query.eventId || null), req, res, next),
  getProfile: (req, res, next) => wrap(() => organizerService.getProfile(userId(req)), req, res, next),
  updateProfile: (req, res, next) => wrap(() => organizerService.updateProfile(userId(req), req.body || {}), req, res, next),
  listNotifications: (req, res, next) => wrap(() => organizerService.listNotifications(userId(req)), req, res, next),
  markNotificationRead: (req, res, next) => wrap(() => organizerService.markNotificationRead(userId(req), req.params.id), req, res, next),
};
