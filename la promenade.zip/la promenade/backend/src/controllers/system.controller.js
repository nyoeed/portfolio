// src/controllers/system.controller.js
const systemService = require("../services/system.service");

async function getInitStatus(req, res) {
  try {
    const initialized = await systemService.isInitialized();
    return res.json({ initialized });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function initAdmin(req, res) {
  try {
    const out = await systemService.initAdmin(req.body || {});
    return res.status(201).json(out); // {token, user}
  } catch (err) {
    console.error(err);

    if (err.code === "BAD_DATA") return res.status(400).json({ message: "Invalid data" });
    if (err.code === "BAD_SECRET") return res.status(403).json({ message: "Invalid secret key" });
    if (err.code === "ALREADY_INIT")
      return res.status(409).json({
        message:
          "System already initialized. New admins must be created internally by an existing admin.",
      });
    if (err.code === "EMAIL_EXISTS") return res.status(409).json({ message: "Email already used" });

    return res.status(500).json({ message: "Erreur", error: err.message });
  }
}

module.exports = { getInitStatus, initAdmin };