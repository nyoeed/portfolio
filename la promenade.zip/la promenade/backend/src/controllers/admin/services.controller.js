// src/controllers/admin/services.controller.js
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const servicesService = require("../../services/admin/services.service");

// ===== Upload config (services) =====
function makeServicesUploader() {
  const dir = path.join(__dirname, "..", "..", "..", "uploads", "services");
  fs.mkdirSync(dir, { recursive: true });

  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, dir),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase() || ".jpg";
      cb(null, `${Date.now()}-${Math.random().toString(16).slice(2)}${ext}`);
    },
  });

  const imageFilter = (req, file, cb) => {
    const ok = ["image/jpeg", "image/png", "image/webp"].includes(file.mimetype);
    cb(ok ? null : new Error("Format image invalide (jpg/png/webp uniquement)."), ok);
  };

  return multer({
    storage,
    fileFilter: imageFilter,
    limits: { fileSize: 5 * 1024 * 1024 },
  });
}

const upload = makeServicesUploader();

function runSingleUpload(req, res) {
  return new Promise((resolve, reject) => {
    upload.single("image")(req, res, (err) => {
      if (err) return reject(err);
      resolve();
    });
  });
}

// ===== Controllers =====
async function getStats(req, res) {
  try {
    const data = await servicesService.getStats();
    return res.json(data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function list(req, res) {
  try {
    const category = (req.query.category || "").trim();
    const items = await servicesService.list({ category });
    return res.json(items);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function create(req, res) {
  try {
    await runSingleUpload(req, res);

    const result = await servicesService.create({
      body: req.body,
      file: req.file || null,
    });

    return res.status(201).json(result);
  } catch (err) {
    console.error(err);
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function update(req, res) {
  try {
    await runSingleUpload(req, res);

    const result = await servicesService.update({
      id: req.params.id,
      body: req.body,
      file: req.file || null,
    });

    return res.json(result);
  } catch (err) {
    console.error(err);
    // si service introuvable on met 404, sinon 400/500
    if (String(err.message || "").toLowerCase().includes("introuvable")) {
      return res.status(404).json({ message: err.message });
    }
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function remove(req, res) {
  try {
    await servicesService.remove({ id: req.params.id });
    return res.json({ message: "Service supprimé" });
  } catch (err) {
    console.error(err);
    if (String(err.message || "").toLowerCase().includes("introuvable")) {
      return res.status(404).json({ message: err.message });
    }
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

module.exports = { getStats, list, create, update, remove };