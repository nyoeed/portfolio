// src/controllers/admin/bundles.controller.js
const bundlesService = require("../../services/admin/bundles.service");

async function list(req, res) {
  try {
    const data = await bundlesService.list();
    return res.json(data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function create(req, res) {
  try {
    const created = await bundlesService.create(req.body || {});
    return res.status(201).json(created);
  } catch (err) {
    console.error(err);
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function update(req, res) {
  try {
    const updated = await bundlesService.update({
      id: req.params.id,
      body: req.body || {},
    });
    return res.json(updated);
  } catch (err) {
    console.error(err);
    if (String(err.message || "").toLowerCase().includes("introuvable")) {
      return res.status(404).json({ message: err.message });
    }
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function remove(req, res) {
  try {
    await bundlesService.remove({ id: req.params.id });
    return res.json({ message: "Forfait supprimé ✅" });
  } catch (err) {
    console.error(err);
    if (String(err.message || "").toLowerCase().includes("introuvable")) {
      return res.status(404).json({ message: err.message });
    }
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

module.exports = { list, create, update, remove };