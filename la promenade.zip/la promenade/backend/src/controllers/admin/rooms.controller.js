// src/controllers/admin/rooms.controller.js
const roomsService = require("../../services/admin/rooms.service");

async function getStats(req, res) {
  try {
    const data = await roomsService.getStats();
    return res.json(data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function list(req, res) {
  try {
    const items = await roomsService.list();
    return res.json(items);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function create(req, res) {
  try {
    const room = await roomsService.create(req.body || {});
    return res.status(201).json(room);
  } catch (err) {
    console.error(err);
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function update(req, res) {
  try {
    const room = await roomsService.update({
      id: req.params.id,
      body: req.body || {},
    });
    return res.json(room);
  } catch (err) {
    console.error(err);
    if (String(err.message || "").toLowerCase().includes("introuvable")) {
      return res.status(404).json({ message: err.message });
    }
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function remove(req, res) {
  try {
    await roomsService.remove({ id: req.params.id });
    return res.json({ message: "Salle supprimée ✅" });
  } catch (err) {
    console.error(err);
    if (String(err.message || "").toLowerCase().includes("introuvable")) {
      return res.status(404).json({ message: err.message });
    }
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

module.exports = { getStats, list, create, update, remove };