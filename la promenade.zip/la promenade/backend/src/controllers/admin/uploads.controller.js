// src/controllers/admin/uploads.controller.js
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const uploadsService = require("../../services/admin/uploads.service");

// ====== Multer config (ROOMS only) ======
function makeRoomsUploader() {
  const dir = path.join(__dirname, "..", "..", "..", "uploads", "rooms");
  fs.mkdirSync(dir, { recursive: true });

  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, dir),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase() || ".jpg";
      // nom stable basé sur l'id (exactement comme avant)
      cb(null, `${req.params.id}${ext}`);
    },
  });

  const imageFilter = (req, file, cb) => {
    const ok = ["image/jpeg", "image/png", "image/webp"].includes(file.mimetype);
    cb(ok ? null : new Error("Format image invalide (jpg/png/webp uniquement)."), ok);
  };

  return multer({
    storage,
    fileFilter: imageFilter,
    limits: { fileSize: 5 * 1024 * 1024 },
  });
}

const upload = makeRoomsUploader();

function runUpload(req, res) {
  return new Promise((resolve, reject) => {
    upload.single("image")(req, res, (err) => {
      if (err) return reject(err);
      resolve();
    });
  });
}

// ===== Controller =====
async function uploadRoomImage(req, res) {
  try {
    await runUpload(req, res);

    if (!req.file) {
      return res.status(400).json({ message: "Aucun fichier reçu." });
    }

    const result = await uploadsService.updateRoomImage({
      id: req.params.id,
      filename: req.file.filename,
    });

    return res.json({
      message: "Image mise à jour ✅",
      room: result,
    });
  } catch (err) {
    console.error(err);

    if (String(err.message).toLowerCase().includes("introuvable")) {
      return res.status(404).json({ message: err.message });
    }

    return res.status(400).json({ message: err.message || "Erreur upload." });
  }
}

module.exports = { uploadRoomImage };