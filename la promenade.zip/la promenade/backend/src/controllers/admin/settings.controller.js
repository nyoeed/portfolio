// src/controllers/admin/settings.controller.js
const settingsService = require("../../services/admin/settings.service");

async function get(req, res) {
  try {
    const data = await settingsService.get();
    return res.json(data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function upsert(req, res) {
  try {
    const data = await settingsService.upsert(req.body || {});
    return res.json(data);
  } catch (err) {
    console.error(err);
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

module.exports = { get, upsert };