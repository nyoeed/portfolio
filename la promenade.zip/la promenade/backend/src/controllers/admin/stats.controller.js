// src/controllers/admin/stats.controller.js
const statsService = require("../../services/admin/stats.service");

async function get(req, res) {
  try {
    const data = await statsService.get();
    return res.json(data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

module.exports = { get };