// src/controllers/admin/users.controller.js
const usersService = require("../../services/admin/users.service");

async function listPending(req, res) {
  try {
    const items = await usersService.listPending();
    return res.json(items);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function approveRequest(req, res) {
  try {
    await usersService.approveRequest({ id: req.params.id });
    return res.json({ message: "Demande approuvée ✅" });
  } catch (err) {
    console.error(err);
    if (err.code === "NOT_FOUND") {
      return res.status(404).json({
        message:
          "Aucune demande pending trouvée pour cet utilisateur (déjà traitée ou id invalide).",
      });
    }
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function rejectRequest(req, res) {
  try {
    await usersService.rejectRequest({ id: req.params.id });
    return res.json({ message: "Demande rejetée ❌" });
  } catch (err) {
    console.error(err);
    if (err.code === "NOT_FOUND") {
      return res.status(404).json({ message: "Aucune demande pending trouvée." });
    }
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function listUsers(req, res) {
  try {
    const items = await usersService.listUsers(req.query || {});
    return res.json(items);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function createUser(req, res) {
  try {
    const created = await usersService.createUser(req.body || {});
    return res.status(201).json(created);
  } catch (err) {
    console.error(err);
    const msg = err.message || "Erreur.";

    // mêmes statuts que ton ancien code
    if (err.code === "EMAIL_EXISTS") return res.status(409).json({ message: msg });
    return res.status(400).json({ message: msg });
  }
}

async function getUsersMeta(req, res) {
  try {
    const meta = await usersService.getUsersMeta();
    return res.json(meta);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function updateUserStatus(req, res) {
  try {
    await usersService.updateUserStatus({
      id: req.params.id,
      status: req.body?.status,
    });
    return res.json({ message: "Statut mis à jour ✅" });
  } catch (err) {
    console.error(err);
    if (err.code === "NOT_FOUND") return res.status(404).json({ message: "Utilisateur introuvable." });
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function updateUserRole(req, res) {
  try {
    const user = await usersService.updateUserRole({
      id: req.params.id,
      role: req.body?.role,
    });
    return res.json(user);
  } catch (err) {
    console.error(err);
    if (err.code === "NOT_FOUND") return res.status(404).json({ message: "User introuvable" });
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function updateUser(req, res) {
  try {
    const user = await usersService.updateUser({
      id: req.params.id,
      body: req.body || {},
    });
    return res.json(user);
  } catch (err) {
    console.error(err);
    if (err.code === "EMAIL_EXISTS") return res.status(409).json({ message: "Email déjà utilisé" });
    if (err.code === "NOT_FOUND") return res.status(404).json({ message: "Utilisateur introuvable." });
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function deleteUser(req, res) {
  try {
    await usersService.deleteUser({
      id: req.params.id,
      requesterId: req.user?.id || null,
    });
    return res.json({ message: "Utilisateur supprimé ✅" });
  } catch (err) {
    console.error(err);
    if (err.code === "SELF_DELETE") {
      return res.status(400).json({ message: "Impossible de supprimer ton propre compte." });
    }
    if (err.code === "NOT_FOUND") {
      return res.status(404).json({ message: "Utilisateur introuvable." });
    }
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

module.exports = {
  listPending,
  approveRequest,
  rejectRequest,
  listUsers,
  createUser,
  getUsersMeta,
  updateUserStatus,
  updateUserRole,
  updateUser,
  deleteUser,
};