// src/controllers/admin/invoices.controller.js

const invoicesService = require("../../services/admin/invoices.service");

function pickPeriod(req) {
  const from = req.query.from || null;
  const to = req.query.to || null;
  return { from, to };
}

async function getStats(req, res, next) {
  try {
    const { from, to } = pickPeriod(req);
    const data = await invoicesService.getStats({ from, to });
    return res.json(data);
  } catch (err) {
    next(err);
  }
}

async function listInvoices(req, res, next) {
  try {
    const { from, to } = pickPeriod(req);
    const eventId = req.query.eventId || null;
    const status = req.query.status || null; // paid | pending | late (DB) or overdue (UI) accepted in repo
    const items = await invoicesService.listInvoices({ from, to, eventId, status });
    return res.json(items);
  } catch (err) {
    next(err);
  }
}

async function getInvoiceDetails(req, res, next) {
  try {
    const { id } = req.params; // GUID
    const data = await invoicesService.getInvoiceDetails(id);
    return res.json(data);
  } catch (err) {
    next(err);
  }
}

async function listPayments(req, res, next) {
  try {
    const { from, to } = pickPeriod(req);
    const items = await invoicesService.listPayments({ from, to });
    return res.json(items);
  } catch (err) {
    next(err);
  }
}

async function listRefunds(req, res, next) {
  try {
    const { from, to } = pickPeriod(req);
    const items = await invoicesService.listRefunds({ from, to });
    return res.json(items);
  } catch (err) {
    next(err);
  }
}

async function generateInvoiceForEvent(req, res, next) {
  try {
    const payload = req.body || {};
    const created = await invoicesService.generateInvoiceForEvent(payload);
    return res.status(201).json(created);
  } catch (err) {
    next(err);
  }
}

async function createPayment(req, res, next) {
  try {
    const invoiceId = req.params.id;
    const payload = req.body || {};
    const created = await invoicesService.createPayment(invoiceId, payload);
    return res.status(201).json(created);
  } catch (err) {
    next(err);
  }
}

async function createRefund(req, res, next) {
  try {
    const invoiceId = req.params.id;
    const payload = req.body || {};
    const created = await invoicesService.createRefund(invoiceId, payload);
    return res.status(201).json(created);
  } catch (err) {
    next(err);
  }
}

// Online payment (mock checkout)
async function createOnlineCheckout(req, res, next) {
  try {
    const invoiceId = req.params.id;
    const payload = req.body || {};
    const data = await invoicesService.createOnlineCheckout(invoiceId, payload);
    return res.status(201).json(data);
  } catch (err) {
    next(err);
  }
}

async function confirmOnlineCheckout(req, res, next) {
  try {
    const { sessionId } = req.body || {};
    const data = await invoicesService.confirmOnlineCheckout(sessionId);
    return res.status(200).json(data);
  } catch (err) {
    next(err);
  }
}

async function downloadInvoicePdf(req, res, next) {
  try {
    const { id } = req.params;
    const { buffer, filename } = await invoicesService.generateInvoicePdf(id);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    return res.send(buffer);
  } catch (err) {
    next(err);
  }
}

async function downloadReceiptPdf(req, res, next) {
  try {
    const { id } = req.params;
    const { buffer, filename } = await invoicesService.generateReceiptPdf(id);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    return res.send(buffer);
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getStats,
  listInvoices,
  getInvoiceDetails,
  listPayments,
  listRefunds,
  generateInvoiceForEvent,
  createPayment,
  createRefund,
  createOnlineCheckout,
  confirmOnlineCheckout,
  downloadInvoicePdf,
  downloadReceiptPdf,
};
