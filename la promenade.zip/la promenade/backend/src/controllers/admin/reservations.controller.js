// src/controllers/admin/reservations.controller.js
const reservationsService = require("../../services/admin/reservations.service");

async function list(req, res) {
  try {
    const items = await reservationsService.list(req.query || {});
    return res.json(items);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function create(req, res) {
  try {
    const created = await reservationsService.create(req.body || {});
    return res.status(201).json(created);
  } catch (err) {
    console.error(err);

    // on garde ton comportement : conflit => 409 avec conflicts
    if (err.code === "RESERVATION_CONFLICT") {
      return res.status(409).json({
        message: "Conflit de réservation détecté.",
        conflicts: err.conflicts || [],
      });
    }

    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function updateStatus(req, res) {
  try {
    const updated = await reservationsService.updateStatus({
      id: req.params.id,
      status: req.body?.status,
    });
    return res.json(updated);
  } catch (err) {
    console.error(err);
    if (String(err.message || "").toLowerCase().includes("introuvable")) {
      return res.status(404).json({ message: err.message });
    }
    return res.status(400).json({ message: err.message || "Erreur." });
  }
}

async function remove(req, res) {
  try {
    await reservationsService.remove({ id: req.params.id });
    return res.json({ message: "Réservation supprimée ✅" });
  } catch (err) {
    console.error(err);
    if (String(err.message || "").toLowerCase().includes("introuvable")) {
      return res.status(404).json({ message: err.message });
    }
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

module.exports = { list, create, updateStatus, remove };