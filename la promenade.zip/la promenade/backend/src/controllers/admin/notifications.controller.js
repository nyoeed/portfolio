// src/controllers/admin/notifications.controller.js
const notificationsService = require("../../services/admin/notifications.service");

async function list(req, res) {
  try {
    const data = await notificationsService.list(req.query || {}, req.user || null);
    return res.json(data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function getStats(req, res) {
  try {
    const data = await notificationsService.getStats(req.user || null);
    return res.json(data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function markRead(req, res) {
  try {
    const out = await notificationsService.markRead({ id: req.params.id });
    return res.json(out);
  } catch (err) {
    console.error(err);
    if (err.code === "BAD_ID") return res.status(400).json({ message: "ID invalide (GUID attendu)." });
    if (err.code === "NOT_FOUND") return res.status(404).json({ message: "Notification introuvable." });
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function markAllRead(req, res) {
  try {
    await notificationsService.markAllRead(req.user || null);
    return res.json({ ok: true });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function remove(req, res) {
  try {
    const out = await notificationsService.remove({ id: req.params.id });
    return res.json(out);
  } catch (err) {
    console.error(err);
    if (err.code === "BAD_ID") return res.status(400).json({ message: "ID invalide (GUID attendu)." });
    if (err.code === "NOT_FOUND") return res.status(404).json({ message: "Notification introuvable." });
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

async function create(req, res) {
  try {
    const out = await notificationsService.create(req.body || {});
    return res.status(201).json(out);
  } catch (err) {
    console.error(err);
    if (err.code === "BAD_TITLE") return res.status(400).json({ message: "title est requis." });
    return res.status(500).json({ message: "Erreur SQL", error: err.message });
  }
}

module.exports = { list, getStats, markRead, markAllRead, remove, create };
