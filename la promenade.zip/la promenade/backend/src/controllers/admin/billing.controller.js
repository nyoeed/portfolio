// src/controllers/admin/billing.controller.js
const billingRepo = require("../../repositories/admin/billing.repo");

async function getSummary(req, res, next) {
  try {
    const data = await billingRepo.getSummary();
    res.json(data);
  } catch (e) {
    next(e);
  }
}

async function listInvoices(req, res, next) {
  try {
    const { q = "", status = "", from = "", to = "" } = req.query;
    const rows = await billingRepo.listInvoices({ q, status, from, to });
    res.json(rows);
  } catch (e) {
    next(e);
  }
}

async function listPayments(req, res, next) {
  try {
    const { q = "", from = "", to = "" } = req.query;
    const rows = await billingRepo.listPayments({ q, from, to });
    res.json(rows);
  } catch (e) {
    next(e);
  }
}

async function listRefunds(req, res, next) {
  try {
    const { q = "", from = "", to = "" } = req.query;
    const rows = await billingRepo.listRefunds({ q, from, to });
    res.json(rows);
  } catch (e) {
    next(e);
  }
}

async function createRefund(req, res, next) {
  try {
    const { invoiceNumber, clientName, amount, date, reason, status } = req.body;

    if (!invoiceNumber || !reason || !date) {
      return res.status(400).json({ message: "invoiceNumber, date et reason sont requis." });
    }

    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt === 0) {
      return res.status(400).json({ message: "amount invalide." });
    }

    const created = await billingRepo.createRefund({
      invoiceNumber,
      clientName: clientName || "",
      amount: amt, // peut être négatif depuis le front
      refundDate: date,
      reason,
      status: status || "processed",
    });

    res.status(201).json(created);
  } catch (e) {
    next(e);
  }
}

async function downloadInvoicePdf(req, res, next) {
  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).json({ message: "id invalide" });

    const invoice = await billingRepo.getInvoiceById(id);
    if (!invoice) return res.status(404).json({ message: "Facture introuvable" });

    // Stub PDF (plus tard on générera un vrai PDF)
    const content = `%PDF-1.4
1 0 obj<<>>endobj
trailer<<>>
%%EOF`;

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${invoice.invoiceNumber}.pdf"`);
    res.send(Buffer.from(content));
  } catch (e) {
    next(e);
  }
}

module.exports = {
  getSummary,
  listInvoices,
  listPayments,
  listRefunds,
  createRefund,
  downloadInvoicePdf,
};