// src/controllers/auth.controller.js
const authService = require("../services/auth.service");

async function register(req, res) {
  try {
    const out = await authService.register(req.body || {});
    return res.status(201).json(out); // { message: "Registered. Pending approval." }
  } catch (err) {
    console.error(err);

    if (err.code === "BAD_DATA") {
      return res.status(400).json({ message: "Invalid data" });
    }
    if (err.code === "EMAIL_EXISTS") {
      return res.status(409).json({ message: "Email already used" });
    }

    return res.status(500).json({ message: "Erreur serveur", error: err.message });
  }
}

async function login(req, res) {
  try {
    const out = await authService.login(req.body || {});
    return res.json(out); // { token, user }
  } catch (err) {
    console.error(err);

    if (err.code === "BAD_DATA") {
      return res.status(400).json({ message: "Invalid data" });
    }
    if (err.code === "INVALID_CREDENTIALS") {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    return res.status(500).json({ message: "Erreur serveur", error: err.message });
  }
}

async function forgotPassword(req, res) {
  try {
    const out = await authService.forgotPassword(req.body || {});
    return res.json(out);
  } catch (err) {
    console.error(err);
    if (err.code === 'BAD_DATA') return res.status(400).json({ message: 'Invalid data' });
    return res.status(500).json({ message: 'Erreur serveur', error: err.message });
  }
}

async function resetPassword(req, res) {
  try {
    const out = await authService.resetPassword(req.body || {});
    return res.json(out);
  } catch (err) {
    console.error(err);
    if (err.code === 'BAD_DATA') return res.status(400).json({ message: 'Invalid data' });
    if (err.code === 'INVALID_TOKEN') return res.status(400).json({ message: err.message });
    if (err.code === 'NOT_FOUND') return res.status(404).json({ message: err.message });
    return res.status(500).json({ message: 'Erreur serveur', error: err.message });
  }
}


async function getMe(req, res) {
  try {
    const out = await authService.getMe(req.user);
    return res.json(out || {});
  } catch (err) {
    console.error(err);
    if (err.code === 'UNAUTHORIZED') return res.status(401).json({ message: 'Unauthorized' });
    return res.status(500).json({ message: 'Erreur serveur', error: err.message });
  }
}

async function updateMe(req, res) {
  try {
    const out = await authService.updateMe(req.user, req.body || {});
    return res.json(out || {});
  } catch (err) {
    console.error(err);
    if (err.code === 'UNAUTHORIZED') return res.status(401).json({ message: 'Unauthorized' });
    if (err.code === 'EMAIL_EXISTS') return res.status(409).json({ message: 'Email already used' });
    return res.status(500).json({ message: 'Erreur serveur', error: err.message });
  }
}

module.exports = { register, login, forgotPassword, resetPassword, getMe, updateMe };