const service = require("../../services/accounting/accounting.service");

async function getDashboard(req, res, next) {
  try {
    const data = await service.getDashboard();
    res.json(data);
  } catch (e) {
    next(e);
  }
}

async function listInvoices(req, res, next) {
  try {
    const rows = await service.listInvoices({
      search: req.query.search || "",
      status: req.query.status || "",
    });
    res.json(rows);
  } catch (e) {
    next(e);
  }
}


async function listInvoiceableEvents(req, res, next) {
  try {
    const rows = await service.getInvoiceableEvents();
    res.json(rows);
  } catch (e) {
    next(e);
  }
}

async function createInvoice(req, res, next) {
  try {
    const created = await service.createInvoice(req.body || {});
    res.status(201).json(created);
  } catch (e) {
    next(e);
  }
}

async function updateInvoiceStatus(req, res, next) {
  try {
    const result = await service.updateInvoiceStatus(req.params.id, req.body?.status);
    res.json(result);
  } catch (e) {
    next(e);
  }
}

async function deleteInvoice(req, res, next) {
  try {
    const result = await service.deleteInvoice(req.params.id);
    res.json(result);
  } catch (e) {
    next(e);
  }
}

async function listNotifications(req, res, next) {
  try {
    const rows = await service.listNotifications();
    res.json(rows);
  } catch (e) {
    next(e);
  }
}

async function markNotificationRead(req, res, next) {
  try {
    const result = await service.markNotificationRead(req.params.id);
    res.json(result);
  } catch (e) {
    next(e);
  }
}

async function listPayments(req, res, next) {
  try {
    const rows = await service.listPayments({
      search: req.query.search || "",
      status: req.query.status || "",
    });
    res.json(rows);
  } catch (e) {
    next(e);
  }
}

async function updatePaymentStatus(req, res, next) {
  try {
    const result = await service.updatePaymentStatus(req.params.id, req.body?.status);
    res.json(result);
  } catch (e) {
    next(e);
  }
}

async function createPayment(req, res, next) {
  try {
    const created = await service.createPayment(req.body || {});
    res.status(201).json(created);
  } catch (e) {
    next(e);
  }
}

async function listRefunds(req, res, next) {
  try {
    const rows = await service.listRefunds({
      search: req.query.search || "",
      status: req.query.status || "",
    });
    res.json(rows);
  } catch (e) {
    next(e);
  }
}

async function createRefund(req, res, next) {
  try {
    const created = await service.createRefund(req.body || {});
    res.status(201).json(created);
  } catch (e) {
    next(e);
  }
}

async function updateRefundStatus(req, res, next) {
  try {
    const result = await service.updateRefundStatus(req.params.id, req.body?.status);
    res.json(result);
  } catch (e) {
    next(e);
  }
}

async function deleteRefund(req, res, next) {
  try {
    const result = await service.deleteRefund(req.params.id);
    res.json(result);
  } catch (e) {
    next(e);
  }
}

async function getReports(req, res, next) {
  try {
    const result = await service.getReports({
      startDate: req.query.startDate || "",
      endDate: req.query.endDate || "",
    });
    res.json(result);
  } catch (e) {
    next(e);
  }
}

module.exports = {
  getDashboard,
  listInvoices,
  listInvoiceableEvents,
  createInvoice,
  updateInvoiceStatus,
  deleteInvoice,
  listNotifications,
  markNotificationRead,
  listPayments,
  updatePaymentStatus,
  createPayment,
  listRefunds,
  createRefund,
  updateRefundStatus,
  deleteRefund,
  getReports,
};
