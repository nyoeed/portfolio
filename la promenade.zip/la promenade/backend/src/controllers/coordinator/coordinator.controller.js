const fs = require('fs');
const path = require('path');
const multer = require('multer');
const service = require('../../services/coordinator/coordinator.service');

function makeEventDocsUploader() {
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(__dirname, '..', '..', '..', 'uploads', 'events', req.params.id);
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname || '');
      const safeBase = path.basename(file.originalname || 'document', ext).replace(/[^a-zA-Z0-9-_]/g, '_').slice(0, 80);
      cb(null, `${Date.now()}_${safeBase}${ext}`);
    },
  });

  return multer({
    storage,
    limits: { fileSize: 10 * 1024 * 1024 },
  });
}

const docsUpload = makeEventDocsUploader();

function runSingleUpload(req, res) {
  return new Promise((resolve, reject) => {
    docsUpload.single('file')(req, res, (err) => {
      if (err) return reject(err);
      resolve();
    });
  });
}

function handleError(res, err) {
  console.error(err);
  const msg = err.message || 'Erreur serveur';
  if (msg.toLowerCase().includes('introuvable')) return res.status(404).json({ message: msg });
  return res.status(400).json({ message: msg });
}

async function dashboard(req, res) {
  try {
    return res.json(await service.getDashboard(req.user));
  } catch (err) { return handleError(res, err); }
}
async function listEvents(req, res) {
  try {
    return res.json(await service.listEvents(req.user, req.query || {}));
  } catch (err) { return handleError(res, err); }
}
async function getEventDetail(req, res) {
  try {
    return res.json(await service.getEventDetail(req.user, req.params.id));
  } catch (err) { return handleError(res, err); }
}
async function updateEventStatus(req, res) {
  try {
    return res.json(await service.updateEventStatus(req.user, req.params.id, req.body || {}));
  } catch (err) { return handleError(res, err); }
}
async function addEventNote(req, res) {
  try {
    return res.status(201).json(await service.addEventNote(req.user, req.params.id, req.body || {}));
  } catch (err) { return handleError(res, err); }
}
async function listRoomsCalendar(req, res) {
  try {
    return res.json(await service.listRoomsCalendar(req.user, req.query || {}));
  } catch (err) { return handleError(res, err); }
}
async function listConflicts(req, res) {
  try {
    return res.json(await service.listConflicts());
  } catch (err) { return handleError(res, err); }
}
async function updateReservationStatus(req, res) {
  try {
    return res.json(await service.updateReservationStatus(req.user, req.params.id, req.body || {}));
  } catch (err) { return handleError(res, err); }
}
async function listServiceRequests(req, res) {
  try {
    return res.json(await service.listServiceRequests(req.user, req.query || {}));
  } catch (err) { return handleError(res, err); }
}
async function updateServiceRequest(req, res) {
  try {
    return res.json(await service.updateServiceRequest(req.user, req.params.id, req.body || {}));
  } catch (err) { return handleError(res, err); }
}
async function createTask(req, res) {
  try {
    return res.status(201).json(await service.createTask(req.user, req.body || {}));
  } catch (err) { return handleError(res, err); }
}
async function updateTask(req, res) {
  try {
    return res.json(await service.updateTask(req.user, req.params.id, req.body || {}));
  } catch (err) { return handleError(res, err); }
}
async function listNotifications(req, res) {
  try {
    return res.json(await service.listNotifications(req.user, req.query || {}));
  } catch (err) { return handleError(res, err); }
}
async function markNotificationRead(req, res) {
  try {
    return res.json(await service.markNotificationRead(req.user, req.params.id));
  } catch (err) { return handleError(res, err); }
}
async function listReports(req, res) {
  try {
    return res.json(await service.listReports(req.user));
  } catch (err) { return handleError(res, err); }
}
async function upsertReport(req, res) {
  try {
    return res.json(await service.upsertReport(req.user, req.params.eventId, req.body || {}));
  } catch (err) { return handleError(res, err); }
}
async function uploadEventDocument(req, res) {
  try {
    await runSingleUpload(req, res);
    return res.status(201).json(await service.saveDocument(req.user, req.params.id, req.body || {}, req.file));
  } catch (err) { return handleError(res, err); }
}

module.exports = {
  dashboard,
  listEvents,
  getEventDetail,
  updateEventStatus,
  addEventNote,
  listRoomsCalendar,
  listConflicts,
  updateReservationStatus,
  listServiceRequests,
  updateServiceRequest,
  createTask,
  updateTask,
  listNotifications,
  markNotificationRead,
  listReports,
  upsertReport,
  uploadEventDocument,
};
