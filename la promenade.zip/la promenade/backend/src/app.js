// src/app.js
const express = require("express");
const cors = require("cors");
const path = require("path");

const routes = require("./routes");
const { loadEnv } = require("./config/env");
const { errorHandler } = require("./middleware/errorHandler");

function createApp() {
  // ✅ valide env ici aussi (optionnel, mais safe)
  loadEnv();

  const app = express();

  app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

  app.use(cors({ origin: process.env.CORS_ORIGIN || "http://localhost:5173", credentials: true }));
  app.use(express.json());

  app.get("/health", (req, res) => res.json({ ok: true }));

  app.use("/api", routes);

  // ✅ TOUJOURS en dernier
  app.use(errorHandler);

  return app;
}

module.exports = { createApp };