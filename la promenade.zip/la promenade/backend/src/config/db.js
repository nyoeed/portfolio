const sql = require("mssql");

const encrypt = String(process.env.DB_ENCRYPT).toLowerCase() === "true";

const config = {
  server: process.env.DB_SERVER,
  port: Number(process.env.DB_PORT || 1433),
  database: process.env.DB_DATABASE,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    // ✅ Si encrypt est ON, on trust le cert local
    encrypt,
    trustServerCertificate: true,
  },
  // ✅ évite les timeouts agressifs
  connectionTimeout: 30000,
  requestTimeout: 30000,
};

let pool;

async function getPool() {
  if (pool) return pool;
  pool = await sql.connect(config);
  return pool;
}

module.exports = { sql, getPool };