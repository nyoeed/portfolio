// src/config/env.js
function required(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing environment variable: ${name}`);
  return v;
}

function optional(name, fallback = null) {
  const v = process.env[name];
  return v == null || v === "" ? fallback : v;
}

function optionalNumber(name, fallback) {
  const raw = process.env[name];
  if (raw == null || raw === "") return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n)) throw new Error(`Invalid number env var: ${name}`);
  return n;
}

function optionalBool(name, fallback = false) {
  const raw = process.env[name];
  if (raw == null || raw === "") return fallback;
  return String(raw).toLowerCase() === "true";
}

function loadEnv() {
  // DB
  const DB_SERVER = required("DB_SERVER");
  const DB_DATABASE = required("DB_DATABASE");
  const DB_USER = required("DB_USER");
  const DB_PASSWORD = required("DB_PASSWORD");
  const DB_PORT = optionalNumber("DB_PORT", 1433);
  const DB_ENCRYPT = optionalBool("DB_ENCRYPT", false);

  // API
  const PORT = optionalNumber("PORT", 4000);

  // JWT
  const JWT_SECRET = required("JWT_SECRET");
  const JWT_EXPIRES_IN = optional("JWT_EXPIRES_IN", "7d");

  // System init
  const INIT_ADMIN_SECRET = required("INIT_ADMIN_SECRET");

  // Front
  const CORS_ORIGIN = optional("CORS_ORIGIN", "http://localhost:5173");

  return {
    PORT,
    CORS_ORIGIN,
    JWT_SECRET,
    JWT_EXPIRES_IN,
    INIT_ADMIN_SECRET,
    DB_SERVER,
    DB_PORT,
    DB_DATABASE,
    DB_USER,
    DB_PASSWORD,
    DB_ENCRYPT,
  };
}

module.exports = { loadEnv };