#Portfolio Next.js – Ibrahima Nabi DIALLO

#Description du projet

Ce projet est un portfolio développé avec Next.js d
Il permet de présenter :
- mon profil
- mes compétences techniques
- mes projets réalisés
- des témoignages d’utilisateurs

L’application inclut également un système d’authentification (inscription / connexion) et un backend intégré avec les API routes de Next.js.

---

//Technologies utilisées

- Next.js (App Router)
- React
- Redux Toolkit
- Node.js
- Sequelize
- SQLite
- CSS

---

#Fonctionnalités principales

- Page d’accueil avec présentation
- Liste des projets (chargés depuis le backend)
- Détails d’un projet
- Authentification utilisateur (login / inscription)
- Protection des pages (accès réservé aux utilisateurs connectés)
- Gestion des témoignages (CRUD)
- Interface responsive (mobile / tablette / ordinateur)

---

// Structure du projet

```bash
app/
  ├── api/              # Backend (Next API)
  ├── login/
  ├── register/
  ├── projects/
  ├── testimonials/
components/
lib/
models/
store/
public/