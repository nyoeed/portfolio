"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";

export default function Navbar() {
  const [user, setUser] = useState(null);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    fetch("/api/auth/login")
      .then((res) => res.json())
      .then((data) => {
        if (data.user) setUser(data.user);
        else setUser(null);
      })
      .catch(() => setUser(null));
  }, [pathname]);

  async function handleLogout() {
    await fetch("/api/auth/login", { method: "DELETE" });
    setUser(null);
    router.push("/");
    router.refresh();
  }

  return (
    <header className="navbar">
      <div className="nav-container">
        <Link href="/" className="logo">
          Anibe Noe
        </Link>

        <nav className="nav-links">
          <Link href="/">Accueil</Link>
          <Link href="/projects">Projets</Link>
          <Link href="/testimonials">Témoignages</Link>

          {user ? (
            <>
              <span className="welcome-text">Bonjour {user.name}</span>
              <button onClick={handleLogout} className="logout-btn">
                Déconnexion
              </button>
            </>
          ) : (
            <>
              <Link href="/register">Inscription</Link>
              <Link href="/login">Connexion</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
