import Link from 'next/link';

export default function TestimonialCard({ testimonial, currentUserId, onDelete }) {
  return (
    <div className="card">
      <p>{testimonial.message}</p>
      <p className="small-text">Par : {testimonial.User?.name || 'Visiteur'}</p>

      {currentUserId === testimonial.userId && (
        <div className="actions">
          <Link href={`/testimonials/${testimonial.id}/edit`} className="button button-secondary">
            Modifier
          </Link>
          <button className="button-danger" onClick={() => onDelete(testimonial.id)}>
            Supprimer
          </button>
        </div>
      )}
    </div>
  );
}
