import Link from 'next/link';

export default function ProjectCard({ project }) {
  return (
    <div className="card">
      <img src={project.imageUrl || 'https://via.placeholder.com/600x300'} alt={project.title} style={{ borderRadius: '12px', marginBottom: '12px', height: '180px', objectFit: 'cover', width: '100%' }} />
      <h3>{project.title}</h3>
      <p>{project.description.slice(0, 120)}...</p>
      <div>
        {project.technologies.split(',').map((tech) => (
          <span className="badge" key={tech.trim()}>{tech.trim()}</span>
        ))}
      </div>
      <div className="actions">
        <Link href={`/projects/${project.id}`} className="button">Voir détails</Link>
      </div>
    </div>
  );
}
