export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <h3>Anibe Noe</h3>
        <p className="footer-text">
          Portfolio personnel orienté développement web et applications modernes.
        </p>
        <p className="footer-copy">© 2026 Anibe Noe - Portfolio Next.js</p>
      </div>
    </footer>
  );
}
