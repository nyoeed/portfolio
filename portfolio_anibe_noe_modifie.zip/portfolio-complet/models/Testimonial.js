import { DataTypes } from 'sequelize';
import { sequelize } from '@/lib/db';
import { User } from '@/models/User';

export const Testimonial =
  sequelize.models.Testimonial ||
  sequelize.define('Testimonial', {
    message: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  });

if (!User.associations.testimonials) {
  User.hasMany(Testimonial, {
    foreignKey: 'userId',
    as: 'testimonials',
    onDelete: 'CASCADE',
  });
}

if (!Testimonial.associations.user) {
  Testimonial.belongsTo(User, {
    foreignKey: 'userId',
    as: 'user',
  });
}