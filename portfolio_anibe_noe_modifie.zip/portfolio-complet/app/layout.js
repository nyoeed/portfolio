import "./globals.css";
import StoreProvider from "@/store/StoreProvider";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata = {
  title: "Anibe Noe | Portfolio",
  description: "Portfolio développeur de Anibe Noe",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body>
        <StoreProvider>
          <Navbar />
          <main className="page container">{children}</main>
          <Footer />
        </StoreProvider>
      </body>
    </html>
  );
}
