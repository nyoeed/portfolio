'use client';

import axios from 'axios';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [success, setSuccess] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Nom obligatoire';
    if (!form.email.trim()) newErrors.email = 'Email obligatoire';
    if (!form.password.trim()) newErrors.password = 'Mot de passe obligatoire';
    else if (form.password.length < 6) newErrors.password = 'Minimum 6 caractères';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');
    setSuccess('');

    if (!validate()) return;

    try {
      await axios.post('/api/auth/register', form);
      setSuccess('Inscription réussie. Redirection vers la page de connexion...');
      setTimeout(() => router.push('/login'), 1500);
    } catch (error) {
      setServerError(error.response?.data?.message || 'Erreur d’inscription');
    }
  };

  return (
    <div className="auth-box card">
      <h1>Inscription</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Nom complet</label>
          <input type="text" name="name" value={form.name} onChange={handleChange} />
          {errors.name && <p className="error">{errors.name}</p>}
        </div>

        <div className="form-group">
          <label>Email</label>
          <input type="email" name="email" value={form.email} onChange={handleChange} />
          {errors.email && <p className="error">{errors.email}</p>}
        </div>

        <div className="form-group">
          <label>Mot de passe</label>
          <input type="password" name="password" value={form.password} onChange={handleChange} />
          {errors.password && <p className="error">{errors.password}</p>}
        </div>

        {serverError && <p className="error">{serverError}</p>}
        {success && <p className="success">{success}</p>}
        <button type="submit">S’inscrire</button>
      </form>
      <p style={{ marginTop: '12px' }}>
        Déjà un compte ? <Link href="/login">Se connecter</Link>
      </p>
    </div>
  );
}
