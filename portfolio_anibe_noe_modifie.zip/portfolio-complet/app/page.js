import Image from "next/image";
import Link from "next/link";
import { initDb } from "@/lib/initDb";
import { Project } from "@/models/Project";

async function getProjects() {
  await initDb();
  return Project.findAll({ order: [["id", "ASC"]], raw: true });
}

export default async function HomePage() {
  const projects = await getProjects();

  return (
    <main className="home-page">
      <section className="hero hero-modern">
        <div className="hero-text">
          <span className="eyebrow">Portfolio développeur</span>
          <h1>Anibe Noe</h1>
          <h2>Développeur junior full stack</h2>

          <p>
            Je conçois des applications web claires, modernes et utiles. Mon
            objectif est de transformer des besoins concrets en solutions
            fonctionnelles avec une interface propre et une logique métier bien
            structurée.
          </p>

          <p>
            Je travaille principalement avec <strong>React</strong>, <strong>Next.js</strong>,
            <strong> JavaScript</strong>, <strong>Node.js</strong>, <strong>SQL</strong> et
            le développement d&apos;applications orientées projet.
          </p>

          <div className="hero-actions">
            <Link href="/projects" className="primary-btn">
              Voir mes projets
            </Link>
            <Link href="/testimonials" className="secondary-btn">
              Voir les témoignages
            </Link>
          </div>
        </div>

        <div className="hero-image hero-photo-card">
          <img
            src="/profil.jpg"
            alt="Photo de Anibe Noe"
            className="profile-image"
          />
        </div>
      </section>

      <section className="projects-section">
        <div className="section-heading">
          <span>Projets sélectionnés</span>
          <h2>Mes projets récents</h2>
        </div>

        <div className="projects-grid">
          {projects.length === 0 ? (
            <p>Aucun projet disponible pour le moment.</p>
          ) : (
            projects.map((project) => (
              <article key={project.id} className="project-card modern-card">
                <Image
                  src={project.imageUrl}
                  alt={project.title}
                  width={500}
                  height={260}
                  className="project-image"
                />

                <h3>{project.title}</h3>
                <p>{project.description}</p>

                <div className="tags">
                  {project.technologies.split(",").map((tech, index) => (
                    <span key={index} className="tag">
                      {tech.trim()}
                    </span>
                  ))}
                </div>

                <Link href={`/projects/${project.id}`} className="details-btn">
                  Voir détails
                </Link>
              </article>
            ))
          )}
        </div>
      </section>
    </main>
  );
}
