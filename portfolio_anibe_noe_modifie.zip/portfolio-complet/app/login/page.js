'use client';

import axios from 'axios';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { setUser } from '@/store/slices/authSlice';

export default function LoginPage() {
  const router = useRouter();
  const dispatch = useDispatch();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!form.email.trim()) newErrors.email = 'Email obligatoire';
    if (!form.password.trim()) newErrors.password = 'Mot de passe obligatoire';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');

    if (!validate()) return;

    try {
      const response = await axios.post('/api/auth/login', form);
      dispatch(setUser(response.data.user));
      router.push('/');
    } catch (error) {
      setServerError(error.response?.data?.message || 'Erreur de connexion');
    }
  };

  return (
    <div className="auth-box card">
      <h1>Connexion</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Email</label>
          <input type="email" name="email" value={form.email} onChange={handleChange} />
          {errors.email && <p className="error">{errors.email}</p>}
        </div>

        <div className="form-group">
          <label>Mot de passe</label>
          <input type="password" name="password" value={form.password} onChange={handleChange} />
          {errors.password && <p className="error">{errors.password}</p>}
        </div>

        {serverError && <p className="error">{serverError}</p>}
        <button type="submit">Se connecter</button>
      </form>
      <p style={{ marginTop: '12px' }}>
        Pas de compte ? <Link href="/register">Créer un compte</Link>
      </p>
    </div>
  );
}
