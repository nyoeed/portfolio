'use client';

import axios from 'axios';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function EditTestimonialPage({ params }) {
  const router = useRouter();
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTestimonial = async () => {
      try {
        const response = await axios.get(`/api/testimonials/${params.id}`);
        setMessage(response.data.testimonial.message);
      } catch (err) {
        setError(err.response?.data?.message || 'Erreur de chargement');
      }
    };

    fetchTestimonial();
  }, [params.id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!message.trim()) {
      setError('Le message est obligatoire');
      return;
    }

    try {
      await axios.put(`/api/testimonials/${params.id}`, { message });
      router.push('/testimonials');
    } catch (err) {
      setError(err.response?.data?.message || 'Erreur de modification');
    }
  };

  return (
    <div className="card auth-box">
      <h1>Modifier le témoignage</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Message</label>
          <textarea value={message} onChange={(e) => setMessage(e.target.value)} />
          {error && <p className="error">{error}</p>}
        </div>
        <button type="submit">Mettre à jour</button>
      </form>
    </div>
  );
}
