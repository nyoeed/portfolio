'use client';

import axios from 'axios';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function NewTestimonialPage() {
  const router = useRouter();
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!message.trim()) {
      setError('Le message est obligatoire');
      return;
    }

    try {
      await axios.post('/api/testimonials', { message });
      router.push('/testimonials');
    } catch (err) {
      setError(err.response?.data?.message || 'Erreur lors de l’envoi');
    }
  };

  return (
    <div className="card auth-box">
      <h1>Nouveau témoignage</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Message</label>
          <textarea value={message} onChange={(e) => setMessage(e.target.value)} />
          {error && <p className="error">{error}</p>}
        </div>
        <button type="submit">Enregistrer</button>
      </form>
    </div>
  );
}
