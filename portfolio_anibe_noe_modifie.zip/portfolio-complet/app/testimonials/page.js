"use client";

import { useEffect, useState } from "react";

export default function TestimonialsPage() {
  const [testimonials, setTestimonials] = useState([]);
  const [message, setMessage] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");

  async function loadTestimonials() {
    const res = await fetch("/api/testimonials");
    const data = await res.json();
    setTestimonials(data.testimonials || []);
  }

  useEffect(() => {
    loadTestimonials();
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");

    if (!message.trim()) {
      setError("Le témoignage est obligatoire.");
      return;
    }

    const method = editingId ? "PUT" : "POST";

    const res = await fetch("/api/testimonials", {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: editingId,
        message,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      setError(data.message || "Erreur.");
      return;
    }

    setMessage("");
    setEditingId(null);
    loadTestimonials();
  }

  function handleEdit(testimonial) {
    setMessage(testimonial.message);
    setEditingId(testimonial.id);
  }

  return (
    <main className="container">
      <section className="page-section">
        <h1>Témoignages</h1>
        <p>
          Cette page permet aux visiteurs connectés de consulter et de laisser
          des témoignages.
        </p>

        <div className="auth-card" style={{ maxWidth: "700px", marginBottom: "30px" }}>
          <h2>{editingId ? "Modifier un témoignage" : "Laisser un témoignage"}</h2>

          <form onSubmit={handleSubmit}>
            <label>Message</label>
            <textarea
              rows="5"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Écrivez votre témoignage ici"
            />

            {error && <p className="error-text">{error}</p>}

            <button type="submit">
              {editingId ? "Modifier" : "Publier"}
            </button>
          </form>
        </div>

        <div className="projects-grid">
          {testimonials.map((testimonial) => (
            <article key={testimonial.id} className="project-card">
              <h3>{testimonial.user?.name || "Utilisateur"}</h3>
              <p>{testimonial.message}</p>
              <button onClick={() => handleEdit(testimonial)} className="details-btn">
                Modifier
              </button>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}