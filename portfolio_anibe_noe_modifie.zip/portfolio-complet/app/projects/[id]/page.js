import Image from "next/image";
import Link from "next/link";
import { initDb } from "@/lib/initDb";
import { Project } from "@/models/Project";

async function getProject(id) {
  await initDb();
  return Project.findByPk(id, { raw: true });
}

export default async function ProjectDetailsPage({ params }) {
  const project = await getProject(params.id);

  if (!project) {
    return (
      <main className="container">
        <p>Projet introuvable.</p>
      </main>
    );
  }

  return (
    <main className="container">
      <section className="project-details">
        <Image
          src={project.imageUrl}
          alt={project.title}
          width={800}
          height={400}
          className="details-image"
        />

        <h1>{project.title}</h1>
        <p>{project.description}</p>

        <h3>Technologies utilisées</h3>
        <ul>
          {project.technologies.split(",").map((tech, index) => (
            <li key={index}>{tech.trim()}</li>
          ))}
        </ul>

        {project.githubUrl ? (
          <a
            href={project.githubUrl}
            target="_blank"
            rel="noreferrer"
            className="details-btn"
          >
            Voir le projet sur GitHub
          </a>
        ) : null}

        <div style={{ marginTop: "20px" }}>
          <Link href="/projects">← Retour aux projets</Link>
        </div>
      </section>
    </main>
  );
}
