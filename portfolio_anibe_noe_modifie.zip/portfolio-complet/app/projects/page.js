import Link from "next/link";
import Image from "next/image";
import { initDb } from "@/lib/initDb";
import { Project } from "@/models/Project";

async function getProjects() {
  await initDb();
  return Project.findAll({ order: [["id", "ASC"]], raw: true });
}

export default async function ProjectsPage() {
  const projects = await getProjects();

  return (
    <main className="container">
      <section className="page-section">
        <h1>Mes projets</h1>
        <p>
          Voici une sélection de projets réalisés autour du développement web et
          de la conception d&apos;applications utiles, avec une attention portée à
          l&apos;expérience utilisateur, à l&apos;organisation des données et à la qualité
          de l&apos;interface.
        </p>

        <div className="projects-grid">
          {projects.map((project) => (
            <article key={project.id} className="project-card modern-card">
              <Image
                src={project.imageUrl}
                alt={project.title}
                width={500}
                height={260}
                className="project-image"
              />
              <h2>{project.title}</h2>
              <p>{project.description}</p>

              <div className="tags">
                {project.technologies.split(",").map((tech, index) => (
                  <span key={index} className="tag">
                    {tech.trim()}
                  </span>
                ))}
              </div>

              <Link href={`/projects/${project.id}`} className="details-btn">
                Voir détails
              </Link>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
