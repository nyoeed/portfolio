import { initDb } from '@/lib/initDb';
import { Project } from '@/models/Project';
import { jsonResponse, errorResponse } from '@/lib/response';

export async function GET(_, { params }) {
  await initDb();
  const project = await Project.findByPk(params.id);
  if (!project) return errorResponse('Projet introuvable', 404);
  return jsonResponse({ project });
}

export async function PUT(request, { params }) {
  await initDb();
  const project = await Project.findByPk(params.id);
  if (!project) return errorResponse('Projet introuvable', 404);

  const { title, description, technologies, imageUrl, githubUrl } = await request.json();
  await project.update({ title, description, technologies, imageUrl, githubUrl });

  return jsonResponse({ message: 'Projet mis à jour', project });
}

export async function DELETE(_, { params }) {
  await initDb();
  const project = await Project.findByPk(params.id);
  if (!project) return errorResponse('Projet introuvable', 404);

  await project.destroy();
  return jsonResponse({ message: 'Projet supprimé' });
}
