import { initDb } from '@/lib/initDb';
import { Project } from '@/models/Project';
import { jsonResponse, errorResponse } from '@/lib/response';

export async function GET() {
  await initDb();
  const projects = await Project.findAll({ order: [['id', 'DESC']] });
  return jsonResponse({ projects });
}

export async function POST(request) {
  await initDb();
  const { title, description, technologies, imageUrl, githubUrl } = await request.json();

  if (!title || !description || !technologies) {
    return errorResponse('Titre, description et technologies sont obligatoires');
  }

  const project = await Project.create({ title, description, technologies, imageUrl, githubUrl });
  return jsonResponse({ message: 'Projet ajouté', project }, 201);
}
