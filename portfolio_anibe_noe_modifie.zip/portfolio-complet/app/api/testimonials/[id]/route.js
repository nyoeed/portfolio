import { initDb } from '@/lib/initDb';
import { Testimonial } from '@/models/Testimonial';
import { User } from '@/models/User';
import { getCurrentUser } from '@/lib/auth';
import { jsonResponse, errorResponse } from '@/lib/response';

export async function GET(_, { params }) {
  await initDb();
  const testimonial = await Testimonial.findByPk(params.id, {
    include: [{ model: User, attributes: ['id', 'name', 'email'] }],
  });

  if (!testimonial) return errorResponse('Témoignage introuvable', 404);
  return jsonResponse({ testimonial });
}

export async function PUT(request, { params }) {
  await initDb();
  const currentUser = await getCurrentUser();
  if (!currentUser) return errorResponse('Connexion obligatoire', 401);

  const testimonial = await Testimonial.findByPk(params.id);
  if (!testimonial) return errorResponse('Témoignage introuvable', 404);
  if (testimonial.userId !== currentUser.id) return errorResponse('Action non autorisée', 403);

  const { message } = await request.json();
  if (!message) return errorResponse('Le message est obligatoire');

  await testimonial.update({ message });
  return jsonResponse({ message: 'Témoignage mis à jour', testimonial });
}

export async function DELETE(_, { params }) {
  await initDb();
  const currentUser = await getCurrentUser();
  if (!currentUser) return errorResponse('Connexion obligatoire', 401);

  const testimonial = await Testimonial.findByPk(params.id);
  if (!testimonial) return errorResponse('Témoignage introuvable', 404);
  if (testimonial.userId !== currentUser.id) return errorResponse('Action non autorisée', 403);

  await testimonial.destroy();
  return jsonResponse({ message: 'Témoignage supprimé' });
}
