import { initDb } from '@/lib/initDb';
import { Testimonial } from '@/models/Testimonial';
import { User } from '@/models/User';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  try {
    await initDb();

    const testimonials = await Testimonial.findAll({
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email'],
        },
      ],
      order: [['id', 'DESC']],
    });

    return Response.json({ testimonials }, { status: 200 });
  } catch (error) {
    console.error('TESTIMONIALS GET ERROR:', error);
    return Response.json(
      {
        message: 'Erreur serveur lors du chargement des témoignages',
        error: error.message,
      },
      { status: 500 }
    );
  }
}

export async function POST(request) {
  try {
    await initDb();

    const currentUser = await getCurrentUser();

    if (!currentUser) {
      return Response.json(
        { message: 'Connexion obligatoire' },
        { status: 401 }
      );
    }

    const { message } = await request.json();

    if (!message || !message.trim()) {
      return Response.json(
        { message: 'Le message est obligatoire' },
        { status: 400 }
      );
    }

    const testimonial = await Testimonial.create({
      message: message.trim(),
      userId: currentUser.id,
    });

    const testimonialWithUser = await Testimonial.findByPk(testimonial.id, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email'],
        },
      ],
    });

    return Response.json(
      {
        message: 'Témoignage ajouté',
        testimonial: testimonialWithUser,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('TESTIMONIALS POST ERROR:', error);
    return Response.json(
      {
        message: 'Erreur serveur lors de l’ajout du témoignage',
        error: error.message,
      },
      { status: 500 }
    );
  }
}

export async function PUT(request) {
  try {
    await initDb();

    const currentUser = await getCurrentUser();

    if (!currentUser) {
      return Response.json(
        { message: 'Connexion obligatoire' },
        { status: 401 }
      );
    }

    const { id, message } = await request.json();

    if (!id || !message || !message.trim()) {
      return Response.json(
        { message: 'Id et message obligatoires' },
        { status: 400 }
      );
    }

    const testimonial = await Testimonial.findByPk(id);

    if (!testimonial) {
      return Response.json(
        { message: 'Témoignage introuvable' },
        { status: 404 }
      );
    }

    if (testimonial.userId !== currentUser.id) {
      return Response.json(
        { message: 'Modification non autorisée' },
        { status: 403 }
      );
    }

    testimonial.message = message.trim();
    await testimonial.save();

    const updatedTestimonial = await Testimonial.findByPk(testimonial.id, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email'],
        },
      ],
    });

    return Response.json(
      {
        message: 'Témoignage modifié',
        testimonial: updatedTestimonial,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('TESTIMONIALS PUT ERROR:', error);
    return Response.json(
      {
        message: 'Erreur serveur lors de la modification',
        error: error.message,
      },
      { status: 500 }
    );
  }
}