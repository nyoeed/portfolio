import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import { User } from '@/models/User';
import { initDb } from '@/lib/initDb';
import { createToken } from '@/lib/jwt';
import { errorResponse, jsonResponse } from '@/lib/response';
import { getCurrentUser } from '@/lib/auth';

export async function POST(request) {
  try {
    await initDb();

    const { email, password } = await request.json();

    if (!email || !password) {
      return errorResponse('Email et mot de passe obligatoires');
    }

    const user = await User.findOne({ where: { email } });

    if (!user) {
      return errorResponse('Utilisateur introuvable', 404);
    }

    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return errorResponse('Mot de passe incorrect', 401);
    }

    const token = createToken({
      id: user.id,
      name: user.name,
      email: user.email,
    });

    cookies().set('token', token, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24,
    });

    return jsonResponse({
      message: 'Connexion réussie',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (error) {
    console.error('LOGIN POST ERROR:', error);
    return Response.json(
      {
        message: 'Erreur serveur login',
        error: error.message,
        stack: String(error),
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const user = await getCurrentUser();

    if (!user) {
      return errorResponse('Non authentifié', 401);
    }

    return jsonResponse({ user });
  } catch (error) {
    console.error('LOGIN GET ERROR:', error);
    return Response.json(
      {
        message: 'Erreur serveur profil',
        error: error.message,
        stack: String(error),
      },
      { status: 500 }
    );
  }
}

export async function DELETE() {
  try {
    cookies().set('token', '', { path: '/', maxAge: 0 });
    return jsonResponse({ message: 'Déconnexion réussie' });
  } catch (error) {
    console.error('LOGIN DELETE ERROR:', error);
    return Response.json(
      {
        message: 'Erreur serveur logout',
        error: error.message,
      },
      { status: 500 }
    );
  }
}