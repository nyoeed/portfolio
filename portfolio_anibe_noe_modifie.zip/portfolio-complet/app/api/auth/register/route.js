import bcrypt from 'bcryptjs';
import { User } from '@/models/User';
import { initDb } from '@/lib/initDb';
import { errorResponse, jsonResponse } from '@/lib/response';

export async function POST(request) {
  try {
    await initDb();

    const { name, email, password } = await request.json();

    if (!name || !email || !password) {
      return errorResponse('Tous les champs sont obligatoires');
    }

    if (password.length < 6) {
      return errorResponse('Le mot de passe doit contenir au moins 6 caractères');
    }

    const existingUser = await User.findOne({ where: { email } });

    if (existingUser) {
      return errorResponse('Cet email existe déjà');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
    });

    return jsonResponse(
      {
        message: 'Inscription réussie',
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
        },
      },
      201
    );
  } catch (error) {
    console.error('REGISTER ERROR:', error);
    return Response.json(
      {
        message: 'Erreur serveur inscription',
        error: error.message,
        stack: String(error),
      },
      { status: 500 }
    );
  }
}