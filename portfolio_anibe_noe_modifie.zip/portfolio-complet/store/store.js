import { configureStore } from '@reduxjs/toolkit';
import authReducer from '@/store/slices/authSlice';
import projectReducer from '@/store/slices/projectSlice';
import testimonialReducer from '@/store/slices/testimonialSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    projects: projectReducer,
    testimonials: testimonialReducer,
  },
});
